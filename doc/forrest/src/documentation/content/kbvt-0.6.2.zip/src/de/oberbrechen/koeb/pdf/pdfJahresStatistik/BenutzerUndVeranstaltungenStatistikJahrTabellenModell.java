/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfJahresStatistik;

import java.util.Date;
import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell f�r die Benutzer und Veranstaltungsstatistiken eines Jahres
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public class BenutzerUndVeranstaltungenStatistikJahrTabellenModell extends TabellenModell {
  
  String[] namen;
  String[] datenString;
  int[] daten;

  public BenutzerUndVeranstaltungenStatistikJahrTabellenModell(int jahr) {
    
    Zeitraum zeitraum = new Zeitraum(jahr);
    BenutzerFactory benutzerFactory = Datenbank.getInstance().getBenutzerFactory();
    VeranstaltungFactory veranstaltungFactory = Datenbank.getInstance().getVeranstaltungFactory();
    VeranstaltungsteilnahmeFactory teilnahmeFactory = Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();
    AusleiheFactory ausleiheFactory = Datenbank.getInstance().getAusleiheFactory();
    
    int zeilenAnzahl=14;
    namen = new String[zeilenAnzahl];
    daten = new int[zeilenAnzahl];

    BenutzerListe alleBenutzer = benutzerFactory.getAlleBenutzer(); 
    
    //Hole alle Daten
    VeranstaltungenListe veranstaltungen = 
      veranstaltungFactory.getAlleVeranstaltungenInZeitraum(zeitraum);
    BenutzerListe teilnehmer = new BenutzerListe();
    int teilnehmerAnzahlTermine = 0;
    int teilnehmerAnzahlTermineJung = 0;
    int termineAnzahl = 0;
    
    for (int i=0; i < veranstaltungen.size(); i++) {
      Veranstaltung veranstaltung = (Veranstaltung) veranstaltungen.get(i);      
      BenutzerListe veranstaltungTeilnehmer = 
        teilnahmeFactory.getTeilnehmerListe(veranstaltung);      
      int veranstaltungTeilnehmerAnzahl = 
        veranstaltungTeilnehmer.size();
      int veranstaltungTeilnehmerAnzahlJung =
        getAnzahlJungeBenutzer(veranstaltungTeilnehmer, zeitraum.getEnde());
        
      Iterator it = veranstaltung.getTermine().iterator();
      while (it.hasNext()) {
        Termin termin = (Termin) it.next();
        if (zeitraum.liegtIn(termin.getBeginn())) {
          termineAnzahl++;
          teilnehmerAnzahlTermine += veranstaltungTeilnehmerAnzahl;
          teilnehmerAnzahlTermineJung += veranstaltungTeilnehmerAnzahlJung;
        }
        if (termineAnzahl > 0) {
          teilnehmer.addAll(veranstaltungTeilnehmer);
        }
      }
    }        
    
    AusleihzeitraumListe ausleihzeitraumListe =
      ausleiheFactory.getGetaetigteAusleihzeitraeumeInZeitraum(zeitraum);
    
    BenutzerListe leser = new BenutzerListe();
    for (int i=0; i < ausleihzeitraumListe.size(); i++) {
      Ausleihzeitraum ausleihzeitraum = (Ausleihzeitraum) 
        ausleihzeitraumListe.get(i);
      leser.add(ausleihzeitraum.getAusleihe().getBenutzer());
    }
    
    BenutzerListe aktiveBenutzer = new BenutzerListe();
    aktiveBenutzer.addAll(leser);
    aktiveBenutzer.addAll(teilnehmer);
        
    BenutzerListe doppeltAktiveBenutzer = new BenutzerListe();
    doppeltAktiveBenutzer.addAll(leser);
    doppeltAktiveBenutzer.retainAll(teilnehmer);
    

    final String jungString = "unter 12";
    
    namen[0] = "Benutzer";
    daten[0] = alleBenutzer.size();

    namen[1] = "Benutzer "+jungString;
    daten[1] = getAnzahlJungeBenutzer(alleBenutzer, zeitraum.getEnde());

    namen[2] = "Benutzer mit Ausleihen";
    daten[2] = leser.size();
    
    namen[3] = "Benutzer mit Ausleihen "+jungString;
    daten[3] = getAnzahlJungeBenutzer(leser, zeitraum.getEnde());
        
    namen[4] = "Teilnehmer an Veranstaltungen";
    daten[4] = teilnehmer.size();
    
    namen[5] = "Teilnehmer an Veranstaltungen "+jungString;
    daten[5] = getAnzahlJungeBenutzer(teilnehmer, zeitraum.getEnde());
    
    namen[6] = "aktive Benutzer";
    daten[6] = aktiveBenutzer.size();
    
    namen[7] = "aktive Benutzer "+jungString;
    daten[7] = getAnzahlJungeBenutzer(aktiveBenutzer, zeitraum.getEnde());
    
    namen[8] = "doppelt aktive Benutzer";
    daten[8] = doppeltAktiveBenutzer.size();
    
    namen[9] = "doppelt aktive Benutzer "+jungString;
    daten[9] = getAnzahlJungeBenutzer(doppeltAktiveBenutzer, zeitraum.getEnde());
    

    namen[10] = "Veranstaltungen";
    daten[10] = veranstaltungen.size();
    
    namen[11] = "Termine";
    daten[11] = termineAnzahl;
        
    namen[12] = "Teilnahmen an Terminen";
    daten[12] = teilnehmerAnzahlTermine;
    
    namen[13] = "Teilnahmen an Terminen "+jungString;
    daten[13] = teilnehmerAnzahlTermineJung;
    
    setSpaltenAusrichtung(2, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
  }

  private int getAnzahlJungeBenutzer(BenutzerListe liste, Date zeitpunkt) {
    int erg = 0;
    
    for (int i=0; i < liste.size(); i++) {
      Benutzer benutzer = (Benutzer) liste.get(i);
      if (benutzer.getGeburtsdatum() != null && 
          benutzer.getAlter(zeitpunkt) < 12) erg++;
    }
    
    return erg;
  }
  
  public int getSpaltenAnzahl() {
    return 2;
  }

  public int getZeilenAnzahl() {
    return namen.length;
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr < 3) return "";
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (spaltenNr == 1) return namen[zeilenNr-1];
    if (spaltenNr == 2) return (daten[zeilenNr-1] == 0?"-":Integer.toString(daten[zeilenNr-1]));
    return "Fehler";
  } 
}
