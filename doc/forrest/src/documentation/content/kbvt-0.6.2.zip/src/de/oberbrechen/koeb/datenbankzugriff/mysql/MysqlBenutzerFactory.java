/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public class MysqlBenutzerFactory extends AbstractBenutzerFactory {

	private String standardBenutzerwohnort = null;

	public Benutzer erstelleNeu() {
    return new MysqlBenutzer();
	}

	public String getStandardBenutzerwohnort() {
    if (standardBenutzerwohnort != null) return standardBenutzerwohnort;
    
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select count(*) as anzahl, ort from benutzer group by ort order" +
				  " by anzahl DESC limit 1");
      boolean ortGefunden = result.next();
      if (!ortGefunden) {
        MysqlDatenbank.getMysqlInstance().endTransaktion();
        MysqlDatenbank.getMysqlInstance().releaseStatement(statement);        
        return null;
      }
      String erg = result.getString("ort");

      MysqlDatenbank.getMysqlInstance().endTransaktion();
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      standardBenutzerwohnort = erg;
      return erg;
    } catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Bestimmen des Standardwohnorts!", true);
    }
    return null;
	}

	public BenutzerListe getAlleBenutzer() {
    clearCache();
    BenutzerListe liste = new BenutzerListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select * from benutzer;");
      while (result.next()) {

        Benutzer neuBenutzer = new MysqlBenutzer(result);

        cache.put(new Integer(neuBenutzer.getId()), neuBenutzer);
        liste.addNoDuplicate(neuBenutzer);
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Benutzerliste!", true);
    }

    return liste;
	}

	public Liste getAlleOrte() {
    Liste liste = new Liste();

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select distinct ort from benutzer;");
      while (result.next()) {
        String ort = result.getString("ort");
        if (ort != null) liste.add(ort);
      }

      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Wohnortsliste der Benutzer!", true);
    }

    liste.setSortierung(Liste.StringSortierung, false);
    return liste;
	}

	public int sucheBenutzername(String benutzername) 
    throws DatenNichtGefundenException {
    int erg = 0;

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
			  "select id from benutzer where "+
			  "Benutzername=\""+benutzername+"\"");

      boolean benutzerGefunden = result.next();
      if (!benutzerGefunden) throw new DatenNichtGefundenException(
        "Ein Benutzer mit dem Benutzernamen '"+benutzername+"' existiert "+
        "nicht.");

      erg = result.getInt(1);
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des " +        "Benutzers mit dem Benutzernamen '"+benutzername+"'!", true);
    }

    return erg;
	}

	public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
		return new MysqlBenutzer(id);
	}

}