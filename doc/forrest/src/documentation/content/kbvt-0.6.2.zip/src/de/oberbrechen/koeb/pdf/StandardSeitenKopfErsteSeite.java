/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import com.lowagie.text.pdf.*;

/**
 * Der Standard-Seitenkopf f�r jede Seite.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.7 $
 */
public class StandardSeitenKopfErsteSeite implements SeitenKopfFuss{

  final BaseFont schrift = PdfDokument.schriftFett;
  final float schriftGroesse = 24;

  String textLinks;
  String textMitte;
  String textRechts;

  SeitenKopfFuss normalerSeitenKopf;

  /**
   * Erstellt einen neuen Standard-Seitenkopf f�r die erste Seite einer
   * pdf-Tabelle, die nach der �berschrift den �bergebenen SeitenKopf anzeigt.
   */
  public StandardSeitenKopfErsteSeite(String links, String mitte, String rechts,
    SeitenKopfFuss normalerSeitenKopf) {

    textLinks = links;
    textMitte = mitte;
    textRechts = rechts;

    this.normalerSeitenKopf = normalerSeitenKopf;
  }

  /**
   * Setzt den als �berschrift anzuzeigenden Text
   *
   * @param links Text, der linksb�ndig angezeigt werden soll
   * @param mitte Text, der zentriert angezeigt werden soll
   * @param rechts Text, der rechtsb�ndig angezeigt werden soll
   */
  public void setText(String links, String mitte, String rechts) {
    textLinks = links;
    textMitte = mitte;
    textRechts = rechts;
  }

  //Doku siehe bitte Interface
  public float getHoehe(int seitenNr) {
    if (normalerSeitenKopf == null) return 40;
    return 40+normalerSeitenKopf.getHoehe(seitenNr);
  }

  //Doku siehe bitte Interface
  public PdfTemplate getSeitenKopfFuss(
    ErweitertesPdfDokument pdfDokument, 
    PdfContentByte pdf, int seitenNr) {

    
    float hoehe = this.getHoehe(seitenNr); 
    PdfTemplate template = pdf.createTemplate(
      pdfDokument.getSeitenBreite(), hoehe);
    
    //bestimme Positionen
    float linkerRand = pdfDokument.getSeitenRandLinks();
    float rechterRand = pdfDokument.getSeitenBreite() -
                        pdfDokument.getSeitenRandRechts();
    float mitte = (rechterRand + linkerRand) / 2;
    float breite = rechterRand - linkerRand;

    //Text ausgeben
    float textBreite = -40;
    float textLinksBreite = 0;
    if (textLinks != null) {
      textLinksBreite = schrift.getWidthPoint(textLinks, schriftGroesse);
      textBreite += 40+textLinksBreite;
    }

    float textMitteBreite = 0;
    if (textMitte != null) {
      textMitteBreite = schrift.getWidthPoint(textMitte, schriftGroesse);
      textBreite += 40+textMitteBreite;
    }

    float textRechtsBreite = 0;
    if (textRechts != null) {
      textRechtsBreite = schrift.getWidthPoint(textRechts, schriftGroesse);
      textBreite += 40+textRechtsBreite;
    }

    float textScalierung = 1;
    if (textBreite > breite)
      textScalierung =  breite / textBreite;

    template.beginText();
    template.setFontAndSize(schrift, schriftGroesse);
    template.setHorizontalScaling(textScalierung*100);

    if (textLinks != null) {
      template.setTextMatrix(linkerRand, hoehe-18);
      template.showText(textLinks);
    }

    if (textMitte != null) {
      template.setTextMatrix(mitte - ((textMitteBreite * textScalierung) / 2), hoehe-18);
      template.showText(textMitte);
    }

    if (textRechts != null) {
      template.setTextMatrix(rechterRand - textRechtsBreite*textScalierung, hoehe-18);
      template.showText(textRechts);
    }

    template.endText();

    if (normalerSeitenKopf != null) {
      PdfTemplate normalerSeitenKopfTemplate =
        normalerSeitenKopf.getSeitenKopfFuss(pdfDokument, pdf, seitenNr);
      template.addTemplate(normalerSeitenKopfTemplate, 0, hoehe-40-
        normalerSeitenKopfTemplate.getHeight());
    }

    return template;
  }

  //Doku siehe bitte Interface
  public void finalisiere(int gesamtseitenAnzahl) {
    //nichts zu tun!
  }
}