/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

/**
 * Diese Klasse repr�sentiert die Teilnahme eines Benutzers an einer
 * Veranstaltung der B�cherei.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public abstract class AbstractVeranstaltungsteilnahme 
  extends AbstractDatenbankzugriff implements Veranstaltungsteilnahme {

	protected Benutzer benutzer;
	protected Veranstaltung veranstaltung;
	protected int anmeldenr;
	protected String bemerkungen;

  public AbstractVeranstaltungsteilnahme(Benutzer benutzer,
    Veranstaltung veranstaltung) {    
    if (benutzer == null || veranstaltung == null)
      throw new IllegalArgumentException();
    
    this.benutzer = benutzer;
    this.veranstaltung = veranstaltung;
    this.bemerkungen = null;
    this.anmeldenr = 0;
  }

	public AbstractVeranstaltungsteilnahme() {
		this.benutzer = null;
		this.veranstaltung = null;
		this.bemerkungen = null;
		this.anmeldenr = 0;
	}

  public Benutzer getBenutzer() {
    return benutzer;
  }

  public Veranstaltung getVeranstaltung() {
    return veranstaltung;
  }

  public int getAnmeldeNr() {
    return anmeldenr;
  }

  public String getBemerkungen() {
    return bemerkungen;
  }

  public void setBemerkungen(String bemerkungen) {
    setIstNichtGespeichert();
    this.bemerkungen = DatenmanipulationsFunktionen.formatString(bemerkungen);
  }

  public String toString() {
    return benutzer.getName()+" nimmt an der Veranstaltung "+
      veranstaltung.getTitel()+" teil!";
  }

  public String toDebugString() {
    return this.toString();
  }
}