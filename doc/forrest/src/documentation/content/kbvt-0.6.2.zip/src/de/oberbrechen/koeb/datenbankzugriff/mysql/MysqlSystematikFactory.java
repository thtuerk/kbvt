/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;
import java.util.Hashtable;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.AbstractSystematikFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbankzugriff;
import de.oberbrechen.koeb.datenbankzugriff.Systematik;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlSystematikFactory extends AbstractSystematikFactory {

  Hashtable nameHashtable = new Hashtable();
    
	public Systematik erstelleNeu() {
    return new MysqlSystematik();
	}

 
	public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
		return new MysqlSystematik(id);
	}


  public SystematikListe getAlleSystematiken() {
		clearCache();		
    return ladeSystematikListe("select * from systematik;");
  }

  public SystematikListe getAlleHauptSystematiken() {
    return ladeSystematikListe("select * from systematik where isNull(SpezialisiertID);");
  }  
      
  public Systematik get(String name) {    
    Systematik erg = (Systematik) nameHashtable.get(name);
    if (erg != null) return erg;
    
    try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
					"select id from systematik where name=\""+name+"\"");
			boolean gefunden = result.next();
			if (!gefunden)
			  throw new DatenNichtGefundenException("Es konnte keine Systematik " +
			  		"mit dem Namen '"+name+"' gefunden werden");
			
			erg = (Systematik) get(result.getInt("id"));
      nameHashtable.put(name, erg);
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der Systematik mit dem Namen '"+name+"'!", true);		
		}
    
    if (ladeAusCache(erg.getId()) == null)
      cache.put(new Integer(erg.getId()), erg);
    return erg;
  }
  
  public SystematikListe ladeSystematikListe(String sqlQuery) {
    SystematikListe liste = new SystematikListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(sqlQuery);
      while (result.next()) {
        int id = result.getInt("id");        
        Systematik systematik = (Systematik) ladeAusCache(id);
        if (systematik == null) {           
          systematik = new MysqlSystematik(result);
          cache.put(new Integer(systematik.getId()), systematik);
        }
        liste.addNoDuplicate(systematik);
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Systematikliste!", true);
    }

    return liste;
  }

  
  public void loescheAlleSystematiken() {
    try {
      clearCache();
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();

      statement.execute("delete from medium_gehoert_zu_systematik");
      statement.execute("update systematik set spezialisiertID=null");
      statement.execute("delete from systematik");

      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim L�schen!", true);
    }
  }

  public void clearCache() {
    super.clearCache();
    nameHashtable.clear();
  }

}