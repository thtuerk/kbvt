/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import java.util.Date;

/**
 * Diese Klasse ist ein Datencontainer, der Informationen zu einer m�glichen
 * Verl�ngerung kapselt.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class VerlaengerungsInformationen {
  Date von, bis;
  boolean erlaubt;
  String bemerkungen;

  public VerlaengerungsInformationen(boolean erlaubt, String bemerkungen,
																		 Date von, Date bis) {
    this.erlaubt = erlaubt;
    this.bemerkungen = bemerkungen;
    this.von = von;
    this.bis = bis;
  }
  
	/**
	 * Liefert, ob eine Verl�ngerung erlaubt ist.
	 * @return ob eine Verl�ngerung erlaubt ist.
	 */
	public boolean istErlaubt() {
		return erlaubt;
	}

	/**
   * Liefert Bemerkungen zur Verl�ngerung. Vor allem wird evtl. eine
   * Begr�ndung geliefert, warum Verl�ngern nicht m�glich ist.
   * @return Bemerkungen
   */
  public String getBemerkungen() {
    return bemerkungen;
  }

  /**
   * Liefert den Zeitpunkt, bis zu dem verl�ngert werden soll.
   * @return den Zeitpunkt, bis zu dem verl�ngert werden soll.
   */
  public Date getBis() {
    return bis;
  }


  /**
   * Liefert den Zeitpunkt, ab dem verl�ngert werden soll.
   * @return den Zeitpunkt, ab dem verl�ngert werden soll.
   */
  public Date getVon() {
    return von;
  }

}