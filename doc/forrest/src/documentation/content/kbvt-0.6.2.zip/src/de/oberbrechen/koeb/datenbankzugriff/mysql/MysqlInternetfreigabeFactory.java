/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;
import java.util.Date;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.InternetfreigabenListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlInternetfreigabeFactory 
	extends AbstractInternetfreigabeFactory {


  protected Internetfreigabe ladeAktuelleInternetfreigabe(Client client) {
		if (client == null || client.istNeu()) {
		  throw new IllegalArgumentException("Es d�rfen nur gespeicherte Clients "+
		  "�bergeben werden!");
		}
		Internetfreigabe erg = null;
    try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
					"select * from internet_zugang where clientID="+client.getId()+
			    " order by von DESC limit 1");
			if (result.next()) erg = new MysqlInternetfreigabe(result);				
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der aktuellen Internetfreigabe!", true);
		}
	
		return erg;
  }

  public InternetfreigabenListe getAlleInternetfreigabenInZeitraum(
      Date von, Date bis) {
		InternetfreigabenListe liste = new InternetfreigabenListe();
		try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
						
			PreparedStatement statement = (PreparedStatement) 
				connection.prepareStatement(
			    "select * from internet_zugang where von >= ? and von <= ?;");
			statement.setDate(1, DatenmanipulationsFunktionen.utilDate2sqlDate(von));
			statement.setDate(2, DatenmanipulationsFunktionen.utilDate2sqlDate(bis));

			ResultSet result = (ResultSet) statement.executeQuery();			
			while (result.next()) {
				Internetfreigabe freigabe = new MysqlInternetfreigabe(result);

				liste.addNoDuplicate(freigabe);
			}
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der Internetfreigaben im Zeitraum!", true);
		}

		return liste;
  }

  public void sperren(Client client) {
		try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
						
			PreparedStatement statement = (PreparedStatement) 
				connection.prepareStatement(
					"update internet_zugang set bis = ? where isNull(bis) and clientID = ?;");
			statement.setTimestamp(1, DatenmanipulationsFunktionen.utilDate2sqlTimestamp(new Date()));
			statement.setInt(2, client.getId());
  
			statement.execute();
			
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, "Fehler beim Sperren "+
				"der Internetfreigabe f�r den Client "+client+"!", true);
		}
    entferneAusClientCache(client);
  }

  public Datenbankzugriff ladeAusDatenbank(int id) {
    return new MysqlInternetfreigabe(id);
  }

  public Internetfreigabe freigeben(Benutzer benutzer, Client client,
																		Mitarbeiter mitarbeiter, Date beginn) {
    Internetfreigabe result = 
    	new MysqlInternetfreigabe(benutzer, client, mitarbeiter, beginn);
    result.save();
    entferneAusClientCache(client);    
    return result;
  }

  public int[] getErstesLetztesJahrEinerInternetfreigabe() {
    int[] erg = new int[2];
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement(); 
      
      ResultSet result = (ResultSet) statement.executeQuery("select min(year(von)), max(year(von)) from internet_zugang");
      result.next();
      erg[0] = result.getInt(1);
      erg[1] = result.getInt(2);
      
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Internetzug�nge!", true);
    }

    return erg;
  }
}