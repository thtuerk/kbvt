/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAusleihStatistik;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfigurationAusleihzeitraumTagesDaten;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfigurationDaten;
import de.oberbrechen.koeb.datenbankzugriff.AusleiheFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt ein PdfDokument, das eine Liste aller aktuellen Mahnungen
 * enthaelt.
 */
public class PdfAusleihstatistik extends PdfDokument {  
  
  private static SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM");  
  
  private PdfTemplateDokument pdfDokument; 
  private AuswahlKonfiguration statistik;
  private int jahr;
  private int monat;
  private AusleihStatistikTabellenModell[] statistiken;
  
  public PdfAusleihstatistik(int jahr, AuswahlKonfiguration statistik) {
    this(-1, jahr, statistik);
  }

  public PdfAusleihstatistik(int monat, int jahr, AuswahlKonfiguration statistik) {
    this.monat = monat;
    this.jahr = jahr;
    this.statistik = statistik;
    
    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(30);
    String titel;
    if (monat > 0) {
      titel = "Ausleihstatistik "+getMonatName(monat)+" "+jahr;      
    } else {
      titel = "Ausleihstatistik "+jahr;
    }
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }
  
  private String getMonatName(int monat) {
    Calendar monatKalender = Calendar.getInstance();
    monatKalender.set(jahr, monat-1, 1);
    return monatDateFormat.format(monatKalender.getTime());    
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) throws Exception {
    initStatistiken(monat);
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1);
    Vector templates = new Vector();

    if (monat > 0) {
      AusleihStatistikTabellenModell tabellenModell = statistiken[monat];
      
      if (tabellenModell.getZeilenAnzahl() > 0) {
        PdfTabelle tabelle = new PdfTabelle(tabellenModell);
        while (tabelle.hasNextTemplate()) {
          PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
          templates.add(tabellenTemplate);
        }
      }    
    } else {    
      for (int monat=1; monat < 13; monat++) {
        AusleihStatistikTabellenModell tabellenModell = statistiken[monat];
        
        if (tabellenModell.getZeilenAnzahl() > 1) {
          PdfTabelle tabelle = new PdfTabelle(tabellenModell);
          while (tabelle.hasNextTemplate()) {
            PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent(), getMonatName(monat)+" "+jahr);
            templates.add(tabellenTemplate);
          }
        }
      }
  
      //Gesamtsumme
      TabellenModell tabellenModell = statistiken[0];
      PdfTabelle tabelle = new PdfTabelle(tabellenModell);
      while (tabelle.hasNextTemplate()) {
        PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
        templates.add(0, tabellenTemplate);
      }
    }                
    pdfDokument.setTemplates((PdfTemplate[]) templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }

  
  private void initStatistiken(int monat) {
    //lade passende Ausleihzeitraeume    
    AusleiheFactory ausleiheFactory =
      Datenbank.getInstance().getAusleiheFactory();
    Zeitraum zeitraum = monat > 0?new Zeitraum(monat, jahr):new Zeitraum(jahr);
    AusleihzeitraumListe liste =
      ausleiheFactory.getGetaetigteAusleihzeitraeumeInZeitraum(zeitraum);

    AuswahlKonfigurationDaten daten = statistik.bewerte(liste);
    daten.ueberpruefeChecks();
    
    AuswahlKonfigurationAusleihzeitraumTagesDaten tagesDaten =
      new AuswahlKonfigurationAusleihzeitraumTagesDaten(daten);
    
    statistiken = new AusleihStatistikTabellenModell[13];
    if (monat > 0) {
      statistiken[monat] = new AusleihStatistikTabellenModell(tagesDaten, monat, jahr, pdfDokument); 
    } else {
      for(int m=1; m <= 12; m++) {
        statistiken[m] = new AusleihStatistikTabellenModell(tagesDaten, m, jahr, pdfDokument); 
      }      
      statistiken[0] = new AusleihStatistikTabellenModell(tagesDaten, jahr, pdfDokument);
    }
  }   
 }

