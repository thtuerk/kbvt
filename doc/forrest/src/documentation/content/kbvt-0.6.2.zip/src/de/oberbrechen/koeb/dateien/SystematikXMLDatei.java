/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien;

import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;

import net.n3.nanoxml.*;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.Systematik;
import de.oberbrechen.koeb.datenbankzugriff.SystematikFactory;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
* Dieses Klasse dient dazu eine XML-Systematik-Datei f�r
* auszulesen und zu schreiben. 
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $
*/

public class SystematikXMLDatei {
  
  protected SystematikFactory systematikFactory =
    Datenbank.getInstance().getSystematikFactory();
  protected static SystematikXMLDatei instance;
  
  /**
   * Liefert eine Instanz der StatistikXMLDatei
   *
   * @return eine Instanz
   */
  public static SystematikXMLDatei getInstance() {
    if (instance == null) instance = new SystematikXMLDatei();

    return instance;
  }

  /**
   * Importiert alle Systematiken aus der Datei und speichert sie in der Datenbank.
   * @param file die zu importierende Datei
   */
  public void importSystematiken(File file) {
    try {
      IXMLParser parser = XMLParserFactory.createDefaultXMLParser();
      IXMLReader reader = new StdXMLReader(new FileReader(file));  
      parser.setReader(reader);
      IXMLElement xml = (IXMLElement) parser.parse();
      
      Hashtable systematikHash = new Hashtable();
      for (int i=0; i < xml.getChildrenCount(); i++) {
        saveSystematik(xml.getChildAtIndex(i), systematikHash);
      }
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Systematikdatei " +        "'"+file+"'.", false);
    }   
  }

  /**
   * Versucht die in dem �bergebenen Element gespeicherten Informationen
   * in ein Sysematik-Objekt einzulesen und speichert dies.
   * @return Object
   */
  private Systematik saveSystematik(IXMLElement element, Hashtable systematikHash) {
    Systematik erg = systematikFactory.erstelleNeu();
    erg.setName(element.getAttribute("name", null));
    erg.setBeschreibung(element.getAttribute("beschreibung", null));
    
    String obersystematikString = element.getAttribute("obersystematik", null);
    if (obersystematikString != null) {
      erg.setDirekteObersystematik(
        (Systematik) systematikHash.get(obersystematikString));
    }
    erg.save();
    systematikHash.put(erg.getName(), erg);
    
    return erg;
  }
    
  /**
   * Liefert ein XML-Element, dass die Daten der �bergebenen Systematik enth�lt
   * @param systematik die zu codierende Systematik
   * @return den erstellten Knoten
   */
  private XMLElement getSystematikKnoten(Systematik systematik) {
    XMLElement beschreibungKnoten = new XMLElement("Systematik");
    beschreibungKnoten.setAttribute("name", systematik.getName());
    
    if (systematik.getBeschreibung() != null) {
      beschreibungKnoten.setAttribute("beschreibung", systematik.getBeschreibung());
    }
    if (systematik.getDirekteObersystematik() != null) {
      beschreibungKnoten.setAttribute("obersystematik", 
          systematik.getDirekteObersystematik().getName());
    }
    
    return beschreibungKnoten;
  }
  
  /**
   * Speichert alle Informationen in die Datei   */
  public void exportSystematiken(File file) {
    IXMLElement root = new XMLElement("Systematiken");
    
    SystematikListe daten = systematikFactory.getAlleHauptSystematiken();
    Iterator it = daten.iterator();
    while (it.hasNext()) {
      Systematik systematik = (Systematik) it.next();      
      addSystematikMitUntersystematiken(systematik, root);
    }
    
    try {
      FileWriter fileWriter = new FileWriter(file);
      new XMLWriter(fileWriter).write(root, true);
      fileWriter.close();
    } catch (IOException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Exportieren der Systematiken", false);
    }    
  }

  private void addSystematikMitUntersystematiken(Systematik systematik, IXMLElement root) {
    root.addChild(getSystematikKnoten(systematik));
    
    Iterator it = systematik.getDirekteUntersystematiken().iterator();
    while (it.hasNext()) {
      Systematik unterSystematik = (Systematik) it.next();      
      addSystematikMitUntersystematiken(unterSystematik, root);
    }
  }
}