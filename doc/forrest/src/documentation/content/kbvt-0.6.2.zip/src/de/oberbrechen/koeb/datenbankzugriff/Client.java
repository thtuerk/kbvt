/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

/**
* Dieses Interface repr�sentiert einen Client, f�r den z.B. die Internetfreigabe
* get�tigt werden kann.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.10 $
*/

public interface Client extends Datenbankzugriff {
    
  /**
   * Liefert die IP des Clients.
   * Achtung: Es wird kein Konsitenzcheck durchgef�hrt. Es kann
   * also nicht garantiert werden, dass das Ergebnis eine
   * g�ltige IP-Adresse ist.
   * @return IP des Clients
   */
  public String getIP();

  /**
   * Liefert den Namen des Clients.
   * @return den Namen des Clients
   */
  public String getName();

  /**
   * Setzt die IP des Clients.
   * @param ip die neue IP
   */
  public void setIP(String ip);

  /**
   * Setzt den Namen des Clients.
   */
  public void setName(String name);
}
