/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Iterator;

import de.oberbrechen.koeb.datenstrukturen.SystematikListe;


/**
 * Diese Klasse bietet die grundlegenden Methoden des
 * Interfaces Benutzer.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public abstract class AbstractSystematik extends AbstractDatenbankzugriff 
  implements Systematik {

  protected String name, beschreibung;
  protected Systematik direkteObersystematik;
  protected SystematikListe direkteUntersystematiken;
  protected SystematikListe alleUntersystematiken;

  public AbstractSystematik() {
    name = null;
    beschreibung = null;
    direkteUntersystematiken = null;
    alleUntersystematiken = null;
    direkteObersystematik = null;
  }
  
  public String getName() {
    return name;
  }

  public String getBeschreibung() {
    return beschreibung;
  }

  public void setName(String name) {
    setIstNichtGespeichert();
    this.name = DatenmanipulationsFunktionen.formatString(name);
  }

  public void setBeschreibung(String beschreibung) {
    setIstNichtGespeichert();
    this.beschreibung = DatenmanipulationsFunktionen.formatString(beschreibung);
  }

  public String toString() {
    return name;
  }

  public String toDebugString() {
    return this.getName() + " ("+this.getId()+")\n"+this.getBeschreibung();
  }

  protected abstract SystematikListe ladeDirekteUntersystematiken();

  protected SystematikListe ladeAlleUntersystematiken() {
    SystematikListe liste = new SystematikListe();
    
    liste.add(this);       
    Iterator it = getDirekteUntersystematiken().iterator();
    
    while (it.hasNext()) {
      Systematik aktuelleSystematik = (Systematik) it.next();
      liste.addAll(((AbstractSystematik) aktuelleSystematik).ladeAlleUntersystematiken());
    }
    
    return liste;
  } 
  
  public SystematikListe getDirekteUntersystematiken() {
		if (direkteUntersystematiken == null) 
		  direkteUntersystematiken = ladeDirekteUntersystematiken();
    SystematikListe result = new SystematikListe();
    result.addAllNoDuplicate(direkteUntersystematiken);
		return result;
	}
	
  public SystematikListe getAlleUntersystematiken() {
    if (alleUntersystematiken == null) 
      alleUntersystematiken = ladeAlleUntersystematiken();
    SystematikListe result = new SystematikListe();
    result.addAllNoDuplicate(alleUntersystematiken);
    return result;
  }

  /**
   * F�gt alle Obersystematiken der Systematik zur �bergebenen liste hinzu
   * @param liste die zu ver�ndernde Liste
   */
	protected void addAlleObersystematiken(SystematikListe liste) {
    if (getDirekteObersystematik() != null) {
      liste.add(getDirekteObersystematik());
      ((AbstractSystematik) getDirekteObersystematik()).addAlleObersystematiken(liste);    
    }
  }
  
  public SystematikListe getAlleObersystematiken() {
    SystematikListe liste = new SystematikListe();    
    addAlleObersystematiken(liste);    
    return liste;
	}
    
  public Systematik getDirekteObersystematik() {
    return direkteObersystematik;
  }

  public void setDirekteObersystematik(Systematik systematik) {
    setIstNichtGespeichert();
    direkteObersystematik = systematik;
  }
}