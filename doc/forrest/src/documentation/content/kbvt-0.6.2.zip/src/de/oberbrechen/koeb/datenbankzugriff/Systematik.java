/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.SystematikListe;

/**
 * Dieses Interface repr�sentiert eine Systematik.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.12 $
 */

public interface Systematik extends Datenbankzugriff {

  /**
   * Liefert der Namen der Systematik
   * @return den Namen der Systematik
   */
  public String getName();

  /**
   * Setzt den Namen der Systematik
   * @param name der neue Name der Systematik
   */
  public void setName(String name);

  /**
   * Setzt die Beschreibung der Systematik
   * @param beschreibung die neue Beschreibung der Systematik
   */
  public void setBeschreibung(String beschreibung);
  
  /**
   * Liefert die Beschreibung der Systematik
   * @return die Beschreibung der Systematik
   */
  public String getBeschreibung();

  /**
   * Liefert eine Liste aller Untersystematiken der Systematik. Eine Systematik
   * ist dabei immer Untersystematik von sich selbst.
   * @return eine Liste aller Untersystematiken der Systematik
   */
  public SystematikListe getAlleUntersystematiken();

  /**
   * Liefert eine Liste aller Obersystematiken der Systematik.
   * @return eine Liste aller Obersystematiken der Systematik
   */
  public SystematikListe getAlleObersystematiken();

  /**
   * Liefert eine Liste der direkten Untersystematiken der Systematik.
   * @return eine Liste der direkten Untersystematiken der Systematik
   */
  public SystematikListe getDirekteUntersystematiken();

  /**
   * Liefert die direkte Obersystematik der Systematik.
   * @return die direkte Obersystematik der Systematik
   */
  public Systematik getDirekteObersystematik();

  /**
   * Setzt die direkte Obersystematik der Systematik.
   * @param systematik die neue direkte Obersystematik der Systematik
   */
  public void setDirekteObersystematik(Systematik systematik);

  /**
   * Bestimmt, ob die Systematik eine Untersystematik der �bergebenen
   * Systematik ist.
   * @param systematik
   * @return true gdw wenn dies der Fall ist
   */
  public boolean istUntersystematikVon(Systematik systematik);  
}