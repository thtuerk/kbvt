/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.alleEinstellungenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.EinstellungenListe;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Einstellungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class EinstellungenTableModel extends AbstractTableModel {

  private EinstellungenListe daten;
  
  public EinstellungenTableModel() {
  }
  
  public void refresh() {
    EinstellungFactory einstellungFactory =
      Datenbank.getInstance().getEinstellungFactory();
    daten = einstellungFactory.getAlleEinstellungen();
    daten.setSortierung(EinstellungenListe.AlphabetischeSortierung);
    fireTableDataChanged();
  }
  
  public EinstellungenListe getDaten() {
    return daten;
  } 
    
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 5;
  }

  public String getColumnName(int columnIndex) {
    switch (columnIndex) {
      case 0: return "ID";
      case 1: return "Client";
      case 2: return "Mitarbeiter";
      case 3: return "Name";
      case 4: return "Wert";
    }

    return "nicht definierte Spalte";
  }

  public int getDefaultColumnWidth(int columnIndex) {
    switch (columnIndex) {
      case 0: return 50;
      case 1: return 50;
      case 2: return 50;
      case 3: return 750;
      case 4: return 500;
    }

    return 500;
  }
  
  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Einstellung gewaehlteEinstellung = getEinstellung(rowIndex);
    
    switch (columnIndex) {
      case 0: 
        return Integer.toString(gewaehlteEinstellung.getId());        
      case 1: 
        if (gewaehlteEinstellung.getClient() != null) {
          return gewaehlteEinstellung.getClient().getName();
        } else {
          return "-";
        } 
      case 2: 
        if (gewaehlteEinstellung.getMitarbeiter() != null) {
          return gewaehlteEinstellung.getMitarbeiter().getBenutzer().getName();
        } else {
          return "-";
        }         
      case 3:
        return gewaehlteEinstellung.getName();
      case 4: 
        return gewaehlteEinstellung.getWert();
    }
    
    return "nicht definierte Spalte";
  }

  public Einstellung getEinstellung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Einstellung) daten.get(rowIndex);
  }
    
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex == 4);
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (columnIndex != 4) return;
    
    Einstellung gewaehlteEinstellung = getEinstellung(rowIndex);
    gewaehlteEinstellung.setWert(aValue.toString());
    gewaehlteEinstellung.save();      
  }
}
