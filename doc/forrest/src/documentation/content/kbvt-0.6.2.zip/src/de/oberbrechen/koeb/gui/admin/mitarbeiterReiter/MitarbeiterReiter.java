/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.mitarbeiterReiter;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenbankzugriff.Mitarbeiter;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.gui.admin.AdminMainReiter;
import de.oberbrechen.koeb.gui.admin.Main;
import de.oberbrechen.koeb.gui.components.MitarbeiterPanel;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Benutzer in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.7 $
 */

public class MitarbeiterReiter extends JPanel implements AdminMainReiter {

  Main hauptFenster;
  MitarbeiterPanel mitarbeiterPanel;
  boolean istVeraenderbar;
  MitarbeiterTableModel mitarbeiterTableModel;
  JTable mitarbeiterTabelle;
  
  // die verwendeten Buttons;
  private JButton neuButton = new JButton();
  private JButton saveButton = new JButton();
  private JButton ladenButton = new JButton();

  void neuenMitarbeiterAnlegen() {
    setVeraenderbar(true);
    mitarbeiterTabelle.clearSelection();
    mitarbeiterPanel.setMitarbeiter(null);
  }

  //Doku siehe bitte Interface
  public void refresh() {
    if (mitarbeiterTabelle.getSelectedRow() == -1) {
      mitarbeiterTabelle.getSelectionModel().setSelectionInterval(0, 0);
    }
      
    if (!istVeraenderbar) {
      Mitarbeiter aktuellerMitarbeiter = mitarbeiterPanel.getMitarbeiter();
      if (aktuellerMitarbeiter != null) {
        aktuellerMitarbeiter.reload(); 
        mitarbeiterPanel.setMitarbeiter(aktuellerMitarbeiter);
      }
    }
  }

  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  void setVeraenderbar(boolean veraenderbar) {
    istVeraenderbar = veraenderbar;
    hauptFenster.erlaubeAenderungen(!veraenderbar);
    mitarbeiterTabelle.setEnabled(!veraenderbar);
    
    //Buttons anpassen
    neuButton.setEnabled(!veraenderbar);

    if (!veraenderbar) {
      ladenButton.setText("L�schen");
      saveButton.setText("Bearbeiten");
    } else {
      ladenButton.setText("�nderungen verwerfen");
      saveButton.setText("Speichern");
    }

    mitarbeiterPanel.setVeraenderbar(veraenderbar);
  }

  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public MitarbeiterReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  void jbInit() throws Exception {
    //Mitarbeiterpanel
    mitarbeiterPanel = new MitarbeiterPanel(hauptFenster);
    mitarbeiterPanel.setBorder(BorderFactory.createEmptyBorder(15,0,0,0));

    //Tabelle
    mitarbeiterTableModel = new MitarbeiterTableModel();
    mitarbeiterTabelle = new JTable(mitarbeiterTableModel);
    mitarbeiterTabelle.getSelectionModel().addListSelectionListener(
      new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          int gewaehlteReihe = mitarbeiterTabelle.getSelectedRow();
          if (gewaehlteReihe != -1) {
            Mitarbeiter gewaehlterMitarbeiter = mitarbeiterTableModel.
              getMitarbeiter(gewaehlteReihe);
            mitarbeiterPanel.setMitarbeiter(gewaehlterMitarbeiter);
          }
        }
      }
    );
    mitarbeiterTableModel.addTableModelListener(new TableModelListener() {
      public void tableChanged(TableModelEvent e) {
        int gewaehlteReihe = mitarbeiterTabelle.getSelectedRow();
        if (gewaehlteReihe != -1) {
          Mitarbeiter gewaehlterMitarbeiter = mitarbeiterTableModel.
            getMitarbeiter(gewaehlteReihe);
          mitarbeiterPanel.setMitarbeiter(gewaehlterMitarbeiter);
        }
      }
    });
    JScrollPane jScrollPane1 = new JScrollPane(mitarbeiterTabelle);
    jScrollPane1.setMinimumSize(new Dimension(100,40));
    jScrollPane1.setPreferredSize(new Dimension(100,40));
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));
    JPanel mitarbeiterTablePanel = new JPanel();
    mitarbeiterTablePanel.setBorder(BorderFactory.createEmptyBorder(0,0,10,0));    
    mitarbeiterTablePanel.setLayout(new BorderLayout());
    mitarbeiterTablePanel.add(jScrollPane1, BorderLayout.CENTER);
    
    //Button-Panel
    neuButton.setText("Neuen Mitarbeiter anlegen");
    neuButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        neuenMitarbeiterAnlegen();
      }
    });
    saveButton.setText("Speichern");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (istVeraenderbar) {
          saveChanges();
        } else {
          setVeraenderbar(true);
        }
      }
    });
    ladenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!istVeraenderbar) {
          loescheMitarbeiter();
        } else {
          aenderungenVerwerfen();
        }
      }
    });
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 3, 15, 5));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    buttonPanel.add(saveButton, null);
    buttonPanel.add(ladenButton, null);
    buttonPanel.add(neuButton, null);

    //Alles Zusammenbauen
    JSplitPane jSplitPane1 = new JSplitPane();
    jSplitPane1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));    
    jSplitPane1.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane1.add(mitarbeiterTablePanel, JSplitPane.TOP);
    jSplitPane1.add(mitarbeiterPanel, JSplitPane.BOTTOM);
    jSplitPane1.setResizeWeight(1.0);
    this.add(jSplitPane1, BorderLayout.CENTER);
    
    this.setLayout(new BorderLayout());
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(jSplitPane1, BorderLayout.CENTER);
  }

  /**
   * L�d die Orte neu aus der Datenbank
   */
  public void aktualisiere() {
    mitarbeiterPanel.aktualisiere();
    setVeraenderbar(istVeraenderbar);
  }

  /**
   * L�scht den aktuellen Mitarbeiter
   */
  void loescheMitarbeiter() {
    boolean loeschenOK = mitarbeiterPanel.loescheMitarbeiter();
    if (loeschenOK) {
      mitarbeiterTableModel.refresh();
      mitarbeiterTabelle.getSelectionModel().setSelectionInterval(0, 0);
    } 
  }

  /**
   * Speichert die gemachten �nderungen
   */
  void saveChanges() {
    boolean speichernOK = mitarbeiterPanel.saveChanges();
    if (speichernOK) {
      setVeraenderbar(false);
      mitarbeiterTableModel.addMitarbeiter(mitarbeiterPanel.getMitarbeiter());
    }
  }

  /**
   * Verwirft die aktuellen �nderungen.
   */
  void aenderungenVerwerfen() {
    Mitarbeiter currentMitarbeiter = mitarbeiterPanel.getMitarbeiter();
    
    if (currentMitarbeiter == null) {
      mitarbeiterTabelle.getSelectionModel().setSelectionInterval(0,0);
    } else {
      try {
        currentMitarbeiter.reload();
        mitarbeiterPanel.setMitarbeiter(currentMitarbeiter);        
      } catch (DatenNichtGefundenException e) {
        mitarbeiterTableModel.refresh();
        mitarbeiterTabelle.getSelectionModel().setSelectionInterval(0,0);
      }
    }
    
         
    setVeraenderbar(false);
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }
  
  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}