/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.TerminListe;

/**
 * Dieses Interface repr�sentiert eine Systematik.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.15 $
 */
public interface Veranstaltung extends Datenbankzugriff {

  /**
   * Liefert den Ansprechpartner der Veranstaltung
   * @return den Ansprechpartner der Veranstaltung
   */
  public String getAnsprechpartner();
  
  /**
   * Liefert die Beschreibung der Veranstaltung
   * @return die Beschreibung der Veranstaltung
   */
  public String getBeschreibung();

  /**
   * Liefert die Bezugsgruppe der Veranstaltung
   * @return die Bezugsgruppe der Veranstaltung
   */
  public String getBezugsgruppe();

  /**
   * Liefert die Kosten f�r diese Veranstaltung
   * @return die Kosten f�r diese Veranstaltung
   */
  public double getKosten();
  
  /**
   * Liefert die Kosten f�r diese Veranstaltung als String
   * @return die Kosten im Format "0.00 "+Waehrung
   */
  public String getKostenFormatiert();

  /**
   * Liefert den gek�rzten Titel der Veranstaltung
   * @return den gek�rzten Titel der Veranstaltung
   */
  public String getKurzTitel();

  /**
   * Liefert die maximale Teilnehmeranzahl. Eine maximale Teilnehmeranzahl
   * von 0 bedeutet, dass beliebig viele Teilnehmer erlaubt sind.
   */
  public int getMaximaleTeilnehmerAnzahl();

  /**
   * Liefert Liste aller Termine der Veranstaltung.
   * @return eine Liste der Termine der Veranstaltung
   */
  public TerminListe getTermine();
  
  /**
   * Liefert der Titel der Veranstaltung
   * @return den Titel der Veranstaltung
   */
  public String getTitel();

  /**
   * Liefert die Gruppe der Veranstaltung
   * @return die Gruppe der Veranstaltung
   */
  public Veranstaltungsgruppe getVeranstaltungsgruppe();

  /**
   * Liefert die Waehrung, in der die 
   * Kosten dieser Veranstaltung angegeben sind.
   * @return die Waehrung
   */
  public String getWaehrung();

  /**
   * Bestimmt, ob f�r die Veranstaltung eine Anmeldung erforderlich ist
   * @return <code>true</code> gdw f�r die Veranstaltung
   *   eine Anmeldung erforderlich ist
   */
  public boolean istAnmeldungErforderlich();

  /**
   * Setzt, ob f�r die Veranstaltung eine Anmeldung erforderlich ist
   * @param anmeldungErforderlich f�r die Veranstaltung
   *   eine Anmeldung erforderlich ist
   */
  public void setAnmeldungErforderlich(boolean anmeldungErforderlich);

  /**
   * Setzt den Ansprechpartner der Veranstaltung
   * @param der neue Ansprechpartner der Veranstaltung
   */
  public void setAnsprechpartner(String ansprechpartner);

  /**
   * Setzt die Beschreibung der Veranstaltung
   * @param beschreibung die neue Beschreibung der Veranstaltung
   */
  public void setBeschreibung(String beschreibung);

  /**
   * Setzt die Bezugsgruppe der Veranstaltung
   * @param bezugsgruppe die Bezugsgruppe der Veranstaltung
   */
  public void setBezugsgruppe(String bezugsgruppe);

  /**
   * Setzt die Kosten f�r diese Veranstaltung
   * @param kosten die neuen Kosten f�r diese Veranstaltung
   */
  public void setKosten(double kosten);
  
  /**
   * Setzt den gek�rzten Titel der Veranstaltung
   * @return kurzTitel der neue gek�rzte Titel der Veranstaltung
   */
  public void setKurzTitel(String kurzTitel);

  /**
   * Setzt die maximale Teilnehmeranzahl. Eine maximale Teilnehmeranzahl
   * von 0 bedeutet, dass beliebig viele Teilnehmer erlaubt sind.
   * @param maxTeilnehmerAnzahl die neue maximale Teilnehmeranzahl
   */
  public void setMaximaleTeilnehmerAnzahl(int maxTeilnehmerAnzahl);

  /**
   * Setzt die Termine der Veranstaltung.
   * @param termine die neuen Termine der Veranstaltung
   */
  public void setTermine(TerminListe termine);

  /**
   * Setzt den Titel der Veranstaltung
   * @param titel der neue Titel der Veranstaltung
   */
  public void setTitel(String titel);
  
  /**
   * Setzt die Gruppe der Veranstaltung
   * @param die neue Gruppe der Veranstaltung
   */
  public void setVeranstaltungsgruppe(
    Veranstaltungsgruppe veranstaltungsgruppe);

  /**
   * Setzt die W�hrung, in der die Kosten dieser Veranstaltung angegeben
   * sind.
   * @param waehrung die neue W�hrung
   */
  public void setWaehrung(String waehrung);
}