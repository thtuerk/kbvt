/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfJahresStatistik;

import javax.swing.JFrame;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;


/**
* Diese Klasse erstellt eine Jahresstatistik 
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class PdfJahresstatistikAusgabenFactory implements AusgabenFactory {

  AuswahlKonfiguration ausleihStatistik = null;
  AuswahlKonfiguration bestandStatistik = null;
  
  public void setParameter(String name, String wert) throws ParameterException {
    if (name != null && name.equals("AusleihStatistik")) {
      ausleihStatistik = parseAuswahlKonfiguration(wert);
    } else if (name != null && name.equals("BestandStatistik")) {
      bestandStatistik = parseAuswahlKonfiguration(wert);
    } else {
      throw new ParameterException("Diese Factory unterst�tzt keinen Parameter '"+name+"'!");
    }
  }

  private AuswahlKonfiguration parseAuswahlKonfiguration(String file) throws ParameterException {
    try {
      return new AuswahlKonfiguration(file);
    } catch (Exception e) {
      throw new ParameterException("Fehler beim Parsen von '"+file+"'!\n"+e.getMessage());
    }        
  }
  public void addToKnoten(AusgabenTreeKnoten knoten) throws Exception {
    if (ausleihStatistik == null)
      throw new Exception("Der Parameter \"AusleihStatistik\" wurde nicht gesetzt!");
    
    int[] jahrInterval = Datenbank.getInstance().getAusleiheFactory().
      getErstesLetztesJahrEinerAusleihe();
    for (int i=jahrInterval[0]; i <= jahrInterval[1]; i++) {
      addToKnoten(knoten, i);    
    }
  }
  
  public void addToKnoten(AusgabenTreeKnoten knoten, final int jahr) throws Exception {
    knoten.addAusgabe(new Ausgabe() {
      public String getName() {
        return "Jahresstatistik "+jahr;
      }

      public String getBeschreibung() {
        return "Statistik �ber Ausleihen, Bestand, Veranstaltungen, etc. f�r das Jahr "+jahr+"!";
      }

      public void run(JFrame hauptFenster) throws Exception {
        new PdfJahresstatistik(jahr, ausleihStatistik, bestandStatistik).zeige(false);
      }
    });
  }

  public String getName() {
    return "Internet-Jahresstatistik-Factory";      
  }

  public String getBeschreibung() {
    return null;
  }
}
