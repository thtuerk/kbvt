/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import java.util.*;
import java.text.Collator;

import de.oberbrechen.koeb.datenbankzugriff.DatenmanipulationsFunktionen;

class ListeIterator implements Iterator {
  int pos = -1;
  Liste liste;

  public ListeIterator(Liste liste) {
    this.liste = liste;
  }

  public boolean hasNext() {
    return pos+1 < liste.size();
  }

  public Object next() {
    pos++;
    return liste.get(pos);
  }

  public void remove() {
    liste.remove(pos);
  }
}

/**
* Diese Klasse repr�sentiert eine Liste, die sortiert oder unsortiert sein kann.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.13 $
*/

public class Liste extends Observable implements SortedSet, Observer {

  private static final int initArraySize = 20;
  protected static final Collator collator = Collator.getInstance();
  
  protected int nullCompare(String a, String b) {
    return collator.compare(DatenmanipulationsFunktionen.entferneNull(a),
        DatenmanipulationsFunktionen.entferneNull(b));    
  }
  
  //Sortiert die Elemente alphabetisch nach ihrer String-Repr�sentation.
  public static final int StringSortierung = 1;

  private Comparator comparator;

  private Object[] daten;
  private int size;

  public Liste() {
    size = 0;
    daten= new Object[initArraySize];
    comparator = null;
  }

  /**
   * Setzt die Sortierung f�r die Liste.
   * @param sortierung der Comparator, mit dem die Elemente verglichen werden
   *   sollen, <code>null</code> f�r unsortiert
   */
  public void setSortierung(Comparator sortierung) {
    this.comparator = sortierung;
    resort(); //inklusive notifyObservers
  }

  /**
   * Sortiert die Liste neu nach der gew�hlten Sortierung. Dies kann n�tig sein,
   * wenn die Elemente der Liste zwischenzeitlich ge�ndert wurden.
   */
  public void resort() {
    if (!istSortiert()) return;
    if (size() > 1) Arrays.sort(daten, 0, size(), comparator);
    
    setChanged();
    notifyObservers();    
  }

	/**
	 * Wechselt die Sortierung der Liste.
	 * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten dieser Klasse
	 * ansprechbar. 0 steht daf�r, dass die Liste unsortiert sein soll.
	 * Diese Methode entspricht einem Aufruf mit dem Parameter umgekehrte Sortierung false.
	 */
  public void setSortierung(int sortierung){
	  this.setSortierung(sortierung, false);
	}

	/**
   * Wechselt die Sortierung der Liste.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten dieser Klasse
   * ansprechbar. 0 steht daf�r, dass die Liste unsortiert sein soll.
   *
   * @param sortierung die anzuwendende Sortierung
   * @param umgekehrteSortierung soll die Sortierreihenfolge umgekehrt werden
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   */
  public void setSortierung(int sortierung, final boolean umgekehrteSortierung){
    if (sortierung == 0) {
      comparator = null;
      return;
    }

    final Comparator sort;
    if (sortierung == StringSortierung) {
      final Collator col = Collator.getInstance();
      sort = new Comparator() {
        public int compare(Object a, Object b) {
          return col.compare(a.toString(), b.toString());
      }};
    } else {
      sort = getComparatorFuerSortierung(sortierung);
    }


    comparator = new Comparator() {
      public int compare(Object a, Object b) {
        if (a.equals(b)) return 0;
        int erg = sort.compare(a, b);
        if (umgekehrteSortierung) erg = -1*erg;
        if (erg == 0) erg = b.hashCode() - a.hashCode();
        return erg;
      }};

    setSortierung(comparator); //inklusive resort und notifyObservers
  }


  public void update(Observable o, Object arg) {
    if (!istSortiert()) return;
    int index = indexOf(o);
    if (index == -1) return;

    //lokales Resort
    while (index > 0 && comparator.compare(daten[index-1], o) > 0) {
      daten[index] = daten[index-1];
      index--;
    }

    while (index < this.size()-1 &&
           comparator.compare(daten[index+1], o) < 0) {
      daten[index] = daten[index+1];
      index++;
    }
    daten[index] = o;
    
    setChanged();
    notifyObservers();    
  }

  /**
   * Liefert einen Comparator f�r die �bergebene Sortierung.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten dieser Klasse
   * ansprechbar. Die StringSortierung und 0 d�rfen nicht verwendet werden.
   *
   * @param sortierung die anzuwendende Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   */
  protected Comparator getComparatorFuerSortierung(int sortierung) {
    throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
      sortierung + " ist unbekannt!");
  }

  /**
   * Bestimmt, ob die Liste sortiert ist.
   * @return <code>true</code> gdw. die Liste sortiert ist
   */
  public boolean istSortiert() {
    return (comparator != null);
  }

  public Comparator comparator() {
    return comparator;
  }

  public int indexOf(Object o) {
    if (o == null) throw new NullPointerException();
    for (int i = 0; i < size(); i++) {
      if (daten[i] != null && daten[i].equals(o)) return i;
    }
    return -1;
  }

  public SortedSet subSet(Object fromElement, Object toElement) {
    throw new java.lang.UnsupportedOperationException("Method subSet() not supported.");
  }

  public SortedSet headSet(Object toElement) {
    throw new java.lang.UnsupportedOperationException("Method headSet() not supported.");
  }

  public SortedSet tailSet(Object fromElement) {
    throw new java.lang.UnsupportedOperationException("Method tailSet() not supported.");
  }

  public Object first() {
    if (isEmpty()) throw new NoSuchElementException("Set is empty!");
    return get(0);
  }

  public Object last() {
    if (isEmpty()) throw new NoSuchElementException("Set is empty!");
    return get(size()-1);
  }

  public int size() {
    return size;
  }

  public boolean contains(Object o) {
    return (indexOf(o) != -1);
  }

  public Iterator iterator() {
    return new ListeIterator(this);
  }

  /**
   * F�gt ein Element zur Liste hinzu, wobei vom Aufrufer die Garantie
   * �bernommen wird, dass das Element noch nicht in der Liste vorkommt.
   * Dies wird von der Methode add zus�tzlich gepr�ft. Daher ist diese Methode
   * performanter.
   * @param o das neue Object
   */
  public void addNoDuplicate(Object o) {
    if (daten.length == size()) vergroessereArray();

    if (o instanceof Observable) ((Observable) o).addObserver(this);

    if (istSortiert())
      addSortiert(o);
    else
      addUnsortiert(o);
      
    setChanged();
    notifyObservers();      
  }

  public boolean add(Object o) {
    if (o == null) throw new NullPointerException("Zu einer Liste darf nicht NULL hinzugefuegt werden!");
    if (this.contains(o)) return false;
    addNoDuplicate(o);
    setChanged();
    notifyObservers();
    return true;
  }

  /**
   * F�gt die Elemenet der
   * uebergebene Collection zur Liste hinzu, wobei vom Aufrufer die Garantie
   * �bernommen wird, dass diese Elemente noch nicht in der Liste vorkommen.
   * Dies wird von der Methode addAll zus�tzlich gepr�ft. Daher ist die Methode
   * addAllNoDuplicate performanter.
   * @param o das neue Object
   */
  public boolean addAllNoDuplicate(Collection c) {
    garantiereGroesse(this.size()+c.size());

    boolean elementeEingefuegt = (c.size() > 0);
    Iterator i = c.iterator();
    int pos = size;
    while (i.hasNext()) {
      Object currentObject = i.next();
      if (currentObject instanceof Observable)
        ((Observable) currentObject).addObserver(this);
      daten[pos] = currentObject;
      pos++;
    }
    size = pos;
    resort();
    if (elementeEingefuegt) {
      setChanged();
      notifyObservers();          
    }
    return elementeEingefuegt;
  }

  public boolean addAll(Collection c) {
    garantiereGroesse(this.size()+c.size());

    boolean elementeEingefuegt = false;
    Iterator i = c.iterator();
    int pos = size;
    while (i.hasNext()) {
      Object currentObject = i.next();
      if (!contains(currentObject)) {
        elementeEingefuegt = true;
        if (currentObject instanceof Observable)
          ((Observable) currentObject).addObserver(this);
        daten[pos] = currentObject;
        pos++;
      }
    }
    size = pos;
    resort();
    
    if (elementeEingefuegt) {
      setChanged();
      notifyObservers();
    }        
    return elementeEingefuegt;
  }

  public boolean removeAll(Collection c) {
    boolean geloescht = false;
    Iterator i = c.iterator();
    while (i.hasNext()) {
      Object currentObject = i.next();
      geloescht |= remove(currentObject);
    }
    
    if (geloescht) {
      setChanged();
      notifyObservers();
    }
      
   return geloescht;
  }

  /**
   * F�gt das �bergebene Object zu einer sortierten Liste hinzu.
   * Es wird erwartet, dass das Object noch nicht in der Menge vorhanden ist
   * und au�erdem genug Platz zur Verf�gung steht.
   * @param o das hinzuzuf�gende Object
   */
  private void addSortiert(Object o) {
    //Insertionsort
    int currentPos = size();
    while (currentPos > 0 && comparator().compare(daten[currentPos-1], o) > 0) {
      daten[currentPos] = daten[currentPos-1];
      currentPos--;
    }
    daten[currentPos] = o;
    size++;
  }

  /**
   * F�gt das �bergebene Object zu einer sortierten Liste hinzu.
   * Es wird erwartet, dass das Object noch nicht in der Menge vorhanden ist
   * und au�erdem genug Platz zur Verf�gung steht.
   * @param o das hinzuzuf�gende Object
   */
  private void addUnsortiert(Object o) {
    daten[size]=o;
    size++;
  }

  /**
   * Verdoppelt die zur Verf�gung stehende Arraygr��e.
   */
  private int vergroessereArray() {
    Object[] neueDaten = new Object[daten.length*2];
    for (int i=0; i < size(); i++) {
      neueDaten[i] = daten[i];
    }
    daten = neueDaten;
    return daten.length;
  }

  /**
   * Erweitert den internen Datentyp, falls n�tig, so dass er mindestens
   * die �bergebene Datenmenge aufnehmen kann.
   *
   * @param size die ben�tigte Gr��e
   */
  public void garantiereGroesse(int size) {
    if (daten.length > size) return;
    if (daten.length*2 > size) size = 2*daten.length;

    Object[] neueDaten = new Object[size];
    for (int i=0; i < size(); i++) {
      neueDaten[i] = daten[i];
    }
    daten = neueDaten;
  }

  public Object get(int index) {
    if (index < 0 || index >= size()) throw new IndexOutOfBoundsException();

    return daten[index];
  }

  /**
   * Entfernt das letzte Element aus der Liste
   * @return das entfernte Element
   */
  public Object removeLast() {
		if (isEmpty()) throw new NoSuchElementException("Set is empty!");
    size--;
    return daten[size];
  }
  
  public Object remove(int index) {
    if (index < 0 || index >= size()) throw new IndexOutOfBoundsException();

    if (daten[index] instanceof Observable)
      ((Observable) daten[index]).deleteObserver(this);

    size--;
    Object returnValue = daten[index];
    for (int i=index; i < size(); i++) {
      daten[i] = daten[i+1];
    }
    
    setChanged();
    notifyObservers();

    return returnValue;
  }

  public boolean remove(Object o) {
    int pos = indexOf(o);
    if (pos == -1) return false;

    remove(pos);
    setChanged();
    notifyObservers();
    return true;
  }

  public void clear() {
    for (int i = 0; i < size(); i++) {
      if (daten[i] instanceof Observable)
        ((Observable) daten[i]).deleteObserver(this);
      daten[i] = null;
    }
    size = 0;
    
    setChanged();
    notifyObservers();    
  }

  public boolean equals(Object o) {
    if (!(o instanceof Liste)) return false;
    if (((Liste) o).comparator() != this.comparator()) return false;
    return super.equals(o);
  }

  public boolean isEmpty() {
    return (size == 0);
  }

  public Object[] toArray() {
    Object[] erg = new Object[this.size()];
    for (int i=0; i < this.size(); i++) {
      erg[i] = daten[i];
    }
    return erg;
  }

  public Object[] toArray(Object[] a) {
    if (a.length < size)
        a = (Object[])java.lang.reflect.Array.newInstance(
                              a.getClass().getComponentType(), size);

    for (int i=0; i < this.size(); i++) {
      a[i] = daten[i];
    }

    if (a.length > size) a[size] = null;

    return a;
  }

  public boolean containsAll(Collection c) {
    Iterator it = c.iterator();
    while (it.hasNext())
      if (!contains(it.next())) return false;

    return true;
  }

  public boolean retainAll(Collection c) {
    boolean modified = false;
    Iterator e = iterator();
    while (e.hasNext()) {
      if(!c.contains(e.next())) {
        e.remove();
        modified = true;
      }
    }
    
    if (modified) {
      setChanged();
      notifyObservers();
    }      
    return modified;
  }
  
  public String toString() {
    StringBuffer erg = new StringBuffer();
    for (int i=0; i < size; i++) {
      erg.append(daten[i]);
      erg.append("\n");
    }
    return erg.toString();
  }

  /**
   * Liefert die die durch Kommata getrennten, von format bestimmten
   * Repr�sentationen der Elemente der Liste
   * @param format
   * @return die durch Kommata getrennte Liste
   */
  public String toKommaGetrenntenString(Format format) {
    StringBuffer erg = new StringBuffer();
    for (int i=0; i < size()-1; i++) {
      erg.append(format.format(daten[i]));
      erg.append(", ");
    }
    erg.append(format.format(daten[size()-1]));
    return erg.toString();
  }

  /**
   * Liefert die die durch Kommata getrennten
   * Repr�sentationen der Elemente der Liste.
   * @return die durch Kommata getrennte Liste
   */
  public String toKommaGetrenntenString() {
    return toKommaGetrenntenString(new Format());
  }
}