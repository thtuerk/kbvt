/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse stellt eine Verbindung mit einer MySQL-Datenbank her. Neben
 * den normalen Datenbank-Funktionen, werden daher auch Funktionen angeboten,
 * um eine Verbindung mit der Datenbank zu erhalten und Statements auf diesen.
 * Au�erdem werden Methoden f�r Transaktionen bereitgestellt. Statements und
 * Connections werden dabei geteilt. Es ist aber n�tig, dass paralle Threads 
 * sich nicht gegenseitig beeinflussen k�nnen. Deshalb erh�lt jeder Thread
 * eine feste Connection zugewiesen. Bei der Benutzung ist jedoch zu beachten,
 * dass keine Statements �ber Threadgrenzen hinweg weitergegeben werden d�rfen, 
 * da Statements fest an eine Connection gebunden
 * sind. Au�erdem ist auf allen Connections AutoCommit ausgeschaltet. Daher
 * sollte nur mit Transaktionen gearbeitet werden. Verschaltelte Transaktionen
 * werden so interpretiert, dass zwar keine neue Transaktion begonnen, wird,
 * aber im Folgenden zwei Beende-Befehle n�tig sind. Aufgrund dieses Verhaltens
 * muss extrem vorsichtig mit Aborts umgegangen werden.
 *  
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.7 $
 */
public class MysqlDatenbank extends Datenbank {
  // die statische Instanz f�r das Signleton
  private static MysqlDatenbank datenbankInstanz = null;
  
  static SimpleDateFormat sqldateFormat =
    new SimpleDateFormat("yyyy-MM-dd");
  
  private int[] transaktionstiefe;
    
  // die Threads, die Verbindungen anforderten und deren Anzahl
  private Thread[] threads;
  private int threadCount;
  
  // die Verbindung mit der Datenbank
  private Connection[] verbindungen;

  // Queue in der verf�gbare Statements gespeichert werden
  private LinkedList[] cache;

  //Daten um neue Connections zu erzeugen
  private String connectionStatement;
  private String configString;

  
  /**
   * Liefert ein verf�gbares Statement zur�ck.
   * Die Erzeugung neuer <code>Statement</code>-Objekte ist aufwendig. Daher
   * werden vorhandene Objekte wiederverwendet. Die Methode <code>getStatemet
   * </code> liefert ein verf�gbares, nicht aber notwendigerweise neu erzeugtes
   * Statement.
   *
   * @return verf�gbares Statement
   * @see #releaseStatement
   */
  public Statement getStatement() {
    int threadID = getThreadID();
     
    if (cache[threadID].isEmpty()) {
      try {
        return (Statement) verbindungen[threadID].createStatement();
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Erzeugen eines neuen Statements!", true);
      }
      return null;
    } else {
      return (Statement) cache[threadID].removeFirst();
    }
  }

 /**
   * Gibt ein Statement zur Verwendung frei.
   * Die Erzeugung neuer <code>Statement</code>-Objekte ist aufwendig. Daher
   * werden vorhandene Objekte wiederverwendet. Die Methode
   * <code>releaseStatemet</code> markiert das �bergebene Statement als
   * verf�gbar.
   *
   * @param statement das freizugebende Statement
   * @see #getStatement
   */
  public synchronized void releaseStatement(Statement statement) {
    int threadID = getThreadID();
    cache[threadID].addLast(statement);
  }


  /**
   * Liefert ein <code>Connection</code>-Objekt, das zur ge�ffneten Datenbank
   * geh�rt.
   *
   * @return Connection-Objekt
   */
  public Connection getConnection() {
    int threadID = getThreadID(); 
    return verbindungen[threadID];
  }


  /**
   * Entsprechend dem Sigelton-Pattern liefert diese Methode eine Instanz der
   * <code>Datenbank</code>-Klasse.
   *
   * @return Instanz der <code>Datenbank</code>-Klasse
   */
  public static synchronized MysqlDatenbank getMysqlInstance() {
    if (datenbankInstanz == null) { 
      Datenbank datenbank = Datenbank.getInstance();
      if (datenbank instanceof MysqlDatenbank) {
        datenbankInstanz = (MysqlDatenbank) datenbank;
      } else {
	      MysqlDatenbankFactory mysqlDatenbankFactory =
	        new MysqlDatenbankFactory();
	      datenbankInstanz = (MysqlDatenbank) 
	        mysqlDatenbankFactory.erstelleDatenbank();
      }
    }
    return datenbankInstanz;
  }

  public MysqlDatenbank(String host, String port, String datenbankname,
    String user, String passwort) {

    
    try {
      configString =  "Host:          "+host+"\n";
      configString += "Port:          "+port+"\n";
      configString += "Datenbankname: "+datenbankname+"\n";
      configString += "User:          "+user+"\n";
      configString += "Passwort:      "+passwort;

      Class.forName("org.gjt.mm.mysql.Driver");
      
      connectionStatement = "jdbc:mysql://"+
      host+":"+port+"/"+datenbankname+"?user="+user+"&password="+passwort;
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Verbinden mit Datenbank schlug fehl! Folgende "+
       "Einstellungen wurden verwendet:\n\n"+configString, true);
    }

    verbindungen = new Connection[5];
    cache = new LinkedList[5];
    transaktionstiefe = new int[5];
    threads = new Thread[5];
    threadCount = 0;
  }

  /**
   * Erstellt eine neue Connection mit der Datenbank und liefert diese zur�ck.
   * @return die neu erstellte Connection
   */
  public synchronized Connection createConnection() {
    Connection connection = null;
    try {
      connection =
        (Connection) DriverManager.getConnection(connectionStatement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Verbinden mit Datenbank schlug fehl! Folgende "+
          "Einstellungen wurden verwendet:\n\n"+configString, true);
    }
    return connection;
  }
  
  private synchronized int getThreadID() {
    //zur Zeit benutzten Eintrag suchen
    Thread currentThread = Thread.currentThread();       
    for (int i = 0; i < threadCount; i++) {
      if (threads[i] == currentThread) return i;
    }
     
    //neuen Eintrag erstellen
    threadCount++;
    
    //Platz schaffen, falls keiner Verf�gbar ist
    if (threadCount > threads.length) {
      int neueArrayGroesse = threads.length*2;
      
      Connection[] neuVerbindungen = new Connection[neueArrayGroesse];
      LinkedList[] neuCache = new LinkedList[neueArrayGroesse];
      Thread[] neuThreads = new Thread[neueArrayGroesse];
      int[] neuTransaktionstiefe = new int[neueArrayGroesse];
      
      for (int i = 0; i < threads.length; i++) {
        neuVerbindungen[i] = verbindungen[i];
        neuCache[i] = cache[i];
        neuThreads[i] = threads[i];
        neuTransaktionstiefe[i] = transaktionstiefe[i];
      }
      
      verbindungen = neuVerbindungen;
      cache = neuCache;
      threads = neuThreads;
      transaktionstiefe = neuTransaktionstiefe;
    }
    
    int neuID = threadCount-1;
    try {
      verbindungen[neuID] = createConnection();
      verbindungen[neuID].setAutoCommit(false);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Verbinden mit Datenbank schlug fehl! Folgende "+
          "Einstellungen wurden verwendet:\n\n"+configString, true);
    }
    transaktionstiefe[neuID] = 0;
    cache[neuID] = new LinkedList();
    threads[neuID] = currentThread;
    
    return neuID;
  }
  
  /**
   * Beginnt eine Transaktion, d.h. das AutoCommit wird auf der Connection, 
   * die mittels getConnection abgefragt werden kann auf false gesetzt. 
   * Au�erdem wird der Z�hler transaktionstiefe um eins erh�ht.
   */
  public synchronized void beginTransaktion() throws SQLException {
    int threadID = getThreadID();
    transaktionstiefe[threadID]++;
  }
  
  /**
   * Beendet eine Transaktion, d.h. das AutoCommit wird auf der Connection, 
   * die mittels getConnection abgefragt werden kann auf true gesetzt und
   * ein commit ausgef�hrt. Au�erdem wird der Z�hler transaktionstiefe 
   * um eins erniedrigt.
   */
  public synchronized void endTransaktion() throws SQLException {
    int threadID = getThreadID();
    
    if (transaktionstiefe[threadID] <= 0)
      throw new IllegalStateException();
    transaktionstiefe[threadID]--;
    if (transaktionstiefe[threadID] == 0) {
      verbindungen[threadID].commit();
    }
  }

	protected BenutzerFactory erstelleBenutzerFactory() {
		return new MysqlBenutzerFactory();
	}

	protected MitarbeiterFactory erstelleMitarbeiterFactory() {
		return new MysqlMitarbeiterFactory();
	}

	protected VeranstaltungFactory erstelleVeranstaltungFactory() {
		return new MysqlVeranstaltungFactory();
	}

	protected MediumFactory erstelleMediumFactory() {
		return new MysqlMediumFactory();
	}

	protected AusleiheFactory erstelleAusleiheFactory() {
		return new MysqlAusleiheFactory();
	}

  protected VeranstaltungsteilnahmeFactory erstelleVeranstaltungsteilnahmeFactory() {
		return new MysqlVeranstaltungsteilnahmeFactory();
	}

  protected EinstellungFactory erstelleEinstellungFactory() {
		return new MysqlEinstellungFactory();
	}

  protected MahnungFactory erstelleMahnungFactory() {
		return new MysqlMahnungFactory();
	}

  protected MedientypFactory erstelleMedientypFactory() {
		return new MysqlMedientypFactory();
	}

  protected InternetfreigabeFactory erstelleInternetfreigabeFactory() {
		return new MysqlInternetfreigabeFactory();
	}

  protected ClientFactory erstelleClientFactory() {
		return new MysqlClientFactory();
	}

  protected SystematikFactory erstelleSystematikFactory() {
		return new MysqlSystematikFactory();
	}

  protected EANZuordnung erstelleEANZuordnung() {
		return new MysqlEANZuordnung();
	}

  protected VeranstaltungsgruppeFactory erstelleVeranstaltungsgruppeFactory() {
		return new MysqlVeranstaltungsgruppeFactory();
	}
}