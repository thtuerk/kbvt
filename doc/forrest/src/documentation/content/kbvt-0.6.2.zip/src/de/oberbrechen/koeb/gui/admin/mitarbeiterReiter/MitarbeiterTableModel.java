/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.mitarbeiterReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;

import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.MitarbeiterListe;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Einstellungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class MitarbeiterTableModel extends AbstractTableModel {

  private MitarbeiterListe daten;
  
  public MitarbeiterTableModel() {
    refresh();
  }
  
  public void refresh() {
    MitarbeiterFactory mitarbeiterFactory =
      Datenbank.getInstance().getMitarbeiterFactory();
    daten = mitarbeiterFactory.getAlleMitarbeiter();
    daten.setSortierung(MitarbeiterListe.NachnameVornameSortierung);
    fireTableDataChanged();
  }
      
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 6;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "ID";
    if (columnIndex == 1) return "Name";
    if (columnIndex == 2) return "Aktiv";
    if (columnIndex == 3) return "Bestand - Berechtigung";
    if (columnIndex == 4) return "Veranstaltungen - Berechtigung";
    if (columnIndex == 5) return "Administration - Berechtigung";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return Integer.class;
    if (columnIndex == 1) return String.class;
    if (columnIndex == 2) return Boolean.class;
    if (columnIndex == 3) return Boolean.class;
    if (columnIndex == 4) return Boolean.class;
    if (columnIndex == 5) return Boolean.class;
    
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Mitarbeiter gewaehlterMitarbeiter = getMitarbeiter(rowIndex);
    
    if (columnIndex == 0) return new Integer(gewaehlterMitarbeiter.
      getBenutzer().getId());
    if (columnIndex == 1) 
      return gewaehlterMitarbeiter.getBenutzer().getNameFormal();
    if (columnIndex == 2) 
      return new Boolean(gewaehlterMitarbeiter.istAktiv());
    if (columnIndex == 3) 
      return new Boolean(gewaehlterMitarbeiter.besitztBerechtigung(
          Mitarbeiter.BERECHTIGUNG_BESTAND_EINGABE));
    if (columnIndex == 4) 
      return new Boolean(gewaehlterMitarbeiter.besitztBerechtigung(
        Mitarbeiter.BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE));
    if (columnIndex == 5) 
      return new Boolean(gewaehlterMitarbeiter.besitztBerechtigung(
        Mitarbeiter.BERECHTIGUNG_ADMIN));
    return "nicht definierte Spalte";
  }

  public Mitarbeiter getMitarbeiter(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Mitarbeiter) daten.get(rowIndex);
  }

  public void addMitarbeiter(Mitarbeiter mitarbeiter) {
    daten.add(mitarbeiter);
    fireTableDataChanged();
  }

  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return columnIndex > 1;
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    Mitarbeiter gewaehlterMitarbeiter = getMitarbeiter(rowIndex);
    boolean value = ((Boolean) aValue).booleanValue();
    
    if (columnIndex == 2) 
      gewaehlterMitarbeiter.setAktiv(value);
    if (columnIndex == 3) 
      gewaehlterMitarbeiter.setBerechtigung(
          Mitarbeiter.BERECHTIGUNG_BESTAND_EINGABE, value);
    if (columnIndex == 4) 
      gewaehlterMitarbeiter.setBerechtigung(
        Mitarbeiter.BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE, value);
    if (columnIndex == 5) 
      gewaehlterMitarbeiter.setBerechtigung(
        Mitarbeiter.BERECHTIGUNG_ADMIN, value);
        
    gewaehlterMitarbeiter.save();
    fireTableRowsUpdated(rowIndex, rowIndex);
  }

}
