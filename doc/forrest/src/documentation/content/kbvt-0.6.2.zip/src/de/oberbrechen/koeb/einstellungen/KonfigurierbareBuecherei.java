/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import java.sql.*;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.mysql.MysqlDatenbank;
import de.oberbrechen.koeb.framework.ErrorHandler;
/**
 * Diese Klasse ist eine konfigurierbare Implementierung einer Buecherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.15 $
*/

public class KonfigurierbareBuecherei extends Buecherei {

  class MedientypEinstellung {
    Medientyp medientyp;
  	String MediennrPraefix;
  	boolean einstellungsjahrInMediennr;
  }
  
  private Vector medientypEinstellungen;
	private double internetKostenProEinheitInEuro;
  private int laengeInternetEinheitInSec;
  private int kulanzZeitInternetZugangInSec;
  private boolean[] istGeoeffnet;
  
  private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
  private Ausleihordnung ausleihordnung;

  public KonfigurierbareBuecherei() {
    EinstellungFactory einstellungFactory =
      Datenbank.getInstance().getEinstellungFactory();

    ausleihordnung = ((AusleihordnungFactory) einstellungFactory.
      getEinstellung(this.getClass().getName(), 
      "ausleihordnung").getWertObject(AusleihordnungFactory.class, 
      KonfigurierbareAusleihordnungFactory.class)).
      createAusleihordnung();
    
    kulanzZeitInternetZugangInSec = einstellungFactory.getEinstellung( 
      this.getClass().getName(), "kulanzZeitInternetZugangInSec").
      getWertInt(90);
    laengeInternetEinheitInSec = einstellungFactory.getEinstellung( 
      this.getClass().getName(), "laengeInternetEinheitInSec").getWertInt(900);
    internetKostenProEinheitInEuro = einstellungFactory.
      getEinstellung(this.getClass().getName(), 
      "internetKostenProEinheitInEuro").getWertDouble(0.5);
    
    istGeoeffnet = new boolean[8];
    istGeoeffnet[Calendar.MONDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Montag").
      getWertBoolean(false);
    istGeoeffnet[Calendar.TUESDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Dienstag").
      getWertBoolean(false);
    istGeoeffnet[Calendar.WEDNESDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Mittwoch").
      getWertBoolean(false);
    istGeoeffnet[Calendar.THURSDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Donnerstag").
      getWertBoolean(false);
    istGeoeffnet[Calendar.FRIDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Freitag").
      getWertBoolean(false);
    istGeoeffnet[Calendar.SATURDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Samstag").
      getWertBoolean(false);
    istGeoeffnet[Calendar.SUNDAY] = einstellungFactory.getEinstellung(
      this.getClass().getName(), "istGeoeffnet.Sonntag").
      getWertBoolean(false);

  	
    MedientypFactory medientypFactory = 
      Datenbank.getInstance().getMedientypFactory();
    medientypEinstellungen = new Vector();
  	Iterator medienTypIterator = 
      medientypFactory.getAlleMedientypen().iterator();
  	while (medienTypIterator.hasNext()) {
  	  Medientyp currentTyp = (Medientyp) medienTypIterator.next();
  	  
  	  MedientypEinstellung einstellung = new MedientypEinstellung();
      einstellung.MediennrPraefix = 
        einstellungFactory.getEinstellung( 
        this.getClass().getName(), "MediennrPraefix."+currentTyp.getName()).
        getWert(currentTyp.getName());
      if (einstellung.MediennrPraefix != null) {
        einstellung.MediennrPraefix = einstellung.MediennrPraefix.trim();
        if (einstellung.MediennrPraefix.equals("")) 
          einstellung.MediennrPraefix = null;
      } 
      einstellung.einstellungsjahrInMediennr = 
        einstellungFactory.getEinstellung(this.getClass().getName(),
        "EinstellungsjahrInMediennr."+currentTyp.getName()).getWertBoolean(true);
      einstellung.medientyp = currentTyp;
      medientypEinstellungen.add(einstellung);
  	}
  }

  // Doku siehe bitte Buecherei
  public Ausleihordnung getAusleihordnung() {
    return ausleihordnung;
  }

  // Doku siehe bitte Buecherei
  public boolean istGeoeffnet(Calendar datum) {
    return (istGeoeffnet[datum.get(Calendar.DAY_OF_WEEK)]);
  }

  // Doku siehe bitte Buecherei
  public double berechneInternetzugangsKosten(int dauer) {
    if (dauer < kulanzZeitInternetZugangInSec) return 0;
    int anzahlEinheiten = (dauer - kulanzZeitInternetZugangInSec) / laengeInternetEinheitInSec + 1;
    return anzahlEinheiten*internetKostenProEinheitInEuro;
  }

  public String getStandardMedienNr(Medientyp medientyp, Date einstellungsDatum) {
    if (medientyp == null || einstellungsDatum == null)
      throw new NullPointerException();
    
    MedientypEinstellung benoetigteEinstellung = null;
    Iterator it = medientypEinstellungen.iterator();
    while (it.hasNext() && benoetigteEinstellung == null) {
      MedientypEinstellung aktuelleEinstellung = 
        (MedientypEinstellung) it.next();
      if (aktuelleEinstellung.medientyp.equals(medientyp))
        benoetigteEinstellung = aktuelleEinstellung;          
    }
    if (benoetigteEinstellung == null) return "???";
    
    String jahr = dateFormat.format(einstellungsDatum);
    StringBuffer medienNr = new StringBuffer();
    if (benoetigteEinstellung.MediennrPraefix != null) {
      medienNr.append(benoetigteEinstellung.MediennrPraefix);
      medienNr.append(" ");
    }
    if (benoetigteEinstellung.einstellungsjahrInMediennr) {
      medienNr.append(jahr);
      medienNr.append("-");
    } 

    try {
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(substring(nr, "+(medienNr.length()+1)+")+1) from medium where nr like \""+
        medienNr.toString()+"%\"");
      result.next();
      int nr=result.getInt(1);
      if (nr == 0) nr=1;
      medienNr.append(nr);
      MysqlDatenbank.getMysqlInstance().releaseStatement((Statement) statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Bestimmen der Mediennr!", true);
    }
    
    return medienNr.toString();
  }

  /**
   * Liefert einen Comparator, der dazu dient, zwei Medien anhand ihrer 
   * Mediennummer miteinander zu vergleichen. 
   * Diese Klasse zerlegt die Nummer in 2-3 Teile, den Medientyp,
   * das Einstellungsjahr und die Einstellungsnummer im Jahr. Diese Teile
   * werden lexikographisch verglichen. Beispielsweise wird B 2002-20 in
   * B, 2002 und 20 verlegt. Es gilt B 2002-3 < B 2002-20 wegen 3 < 20. Man
   * beachte, dass dies ein Unterschied zum alphabetischen 
   * Vergleich der Mediennr als String darstellt.
   */
  protected Comparator erstelleMedienNrComparator() {
    return new Comparator() {

      private Collator collocator = Collator.getInstance();

      public int compare(Object a, Object b) {
        try {
          StringTokenizer stringTokenizerA = new StringTokenizer(((Medium) a).getMedienNr(), " -");
          StringTokenizer stringTokenizerB = new StringTokenizer(((Medium) b).getMedienNr(), " -");

          // Medientypvergleich
          if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
            String tokenA = stringTokenizerA.nextToken();
            String tokenB = stringTokenizerB.nextToken();

            int erg = collocator.compare(tokenA, tokenB);
            if (erg != 0) return erg;
          }

          // Jahresvergleich
          if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
            int tokenA = Integer.parseInt(stringTokenizerA.nextToken());
            int tokenB = Integer.parseInt(stringTokenizerB.nextToken());

            int erg = tokenA - tokenB;
            if (erg != 0) return erg;
          }

          // Nummernvergleich
          if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
            int tokenA = Integer.parseInt(stringTokenizerA.nextToken());
            int tokenB = Integer.parseInt(stringTokenizerB.nextToken());

            int erg = tokenA - tokenB;
            if (erg != 0) return erg;
          }

          if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
            throw new Exception("Unerwartetes Mediennummernformat");
          }
          if (!stringTokenizerA.hasMoreTokens()) return -1;
          if (!stringTokenizerB.hasMoreTokens()) return 1;
          return 0;
        } catch (Exception e) {
          // unerwartetes Medienformat
          return collocator.compare(((Medium) a).getMedienNr(), ((Medium) b).getMedienNr());
        }

      }
    };
  }

}
