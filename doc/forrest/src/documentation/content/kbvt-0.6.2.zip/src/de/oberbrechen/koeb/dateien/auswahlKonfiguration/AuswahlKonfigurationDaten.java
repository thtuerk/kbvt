/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;

import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse kapselt Daten, die aus der Auswertung 
 * einer AuswahlKonfiguration stammen.
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class AuswahlKonfigurationDaten {
  
   AusgabeAuswahl[] ausgaben= null;
   CheckAuswahl[] checks = null;
   Liste[] ausgabenResult;
   Liste[] checksResult;
   
   protected AuswahlKonfigurationDaten(AusgabeAuswahl[] ausgaben, 
       CheckAuswahl[] checks, Liste[] ausgabenResult, Liste[] checksResult) {
     this.ausgaben = ausgaben;
     this.checks = checks;
     this.ausgabenResult = ausgabenResult;
     this.checksResult = checksResult;
   }   
   
   protected AuswahlKonfigurationDaten(AuswahlKonfigurationDaten daten) {
     this.ausgaben = daten.ausgaben;
     this.checks = daten.checks;
     this.ausgabenResult = daten.ausgabenResult;
     this.checksResult = daten.checksResult;
   }   

   /**
    * Liefert die Ausgabe mit der entsprechenden Nummer.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return die Ausgabe
    */
   public AusgabeAuswahl getAusgabe(int i) {
     return ausgaben[i];
   }

   /**
    * Liefert die Treffer f�r die Ausgabe mit der entsprechenden Nummer,
    * d.h. die Objekte, die der Ausgabe entsprechen.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return die Treffer f�r die Ausgabe
    */
   public Liste getAusgabeTreffer(int i) {
     return ausgabenResult[i];
   }

   /**
    * Liefert die Treffer f�r den Check mit der entsprechenden Nummer,
    * d.h. die Objekte, die den Check verletzen.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return die Treffer f�r die Ausgabe
    */
   public Liste getCheckTreffer(int i) {
     return checksResult[i];
   }

   /**
    * Liefert die Anzahl der enthaltenen Ausgaben.
    * @return die Anzahl der Ausgaben
    */
   public int getAusgabenAnzahl() {
     return ausgaben.length;
   }

   /**
    * Liefert den eingelesenen Check mit der entsprechenden Nummer.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return den Check
    */
   public CheckAuswahl getCheck(int i) {
     return checks[i];
   }

   /**
    * Liefert die Anzahl der enthaltenen Checks.
    * @return die Anzahl der Checks
    */
   public int getChecksAnzahl() {
     return checks.length;
   }
   
   /**
    * �berpr�ft, ob alle Checks erf�llt sind.
    * Ist dies nicht der Fall, wird eine Warnung �ber den
    * ErrorHandler ausgegeben.
    * 
    * @return ob alle Checks erf�llt sind
    */
   public boolean ueberpruefeChecks() {
     boolean checksVerletzt = false;
     StringBuffer error = new StringBuffer();

     for (int i=0; i < getChecksAnzahl(); i++) {
       Liste liste = getCheckTreffer(i);
       
       if (liste.size() > 0) {
         CheckAuswahl currentCheck = getCheck(i);
         checksVerletzt = true;
         error.append("Check '");
         error.append(currentCheck.getTitel());
         error.append("' wird von verletzt durch:\n");
         for (int j=0; j < liste.size(); j++) {
           Object eintrag = liste.get(j);
           error.append(eintrag.toString());
           error.append("\n");
         }
         error.append("\n");
       }
     }
     if (checksVerletzt) {
       ErrorHandler.getInstance().handleError(error.toString(), false);
     }
     
     return checksVerletzt;
   }
}
