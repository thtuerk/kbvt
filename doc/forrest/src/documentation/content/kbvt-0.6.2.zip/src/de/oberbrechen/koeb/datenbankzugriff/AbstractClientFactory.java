/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.net.InetAddress;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.framework.KonfigurationsDatei;

/**
 * Dieses Klasse stellt einige grundlegende
 * Funktionen einer ClientFactory bereit. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public abstract class AbstractClientFactory 
  extends AbstractDatenbankzugriffFactory implements ClientFactory {

  protected static Client benutzerClient = null;

  public Client getBenutzenClient() {
    if (benutzerClient != null) return benutzerClient;

    String clientNrString = 
      KonfigurationsDatei.getStandardKonfigurationsdatei().
        getProperty("ClientNr");
    int clientNr = -1;
    try {
      clientNr = Integer.parseInt(clientNrString);
    } catch (NumberFormatException e) {
      //nichts zu tun, clientNr bleibt -1, Client wird nicht gefunden und neuer Client
      //erstellt
    }
    
    try {
      benutzerClient = (Client) get(clientNr);
    } catch (DatenNichtGefundenException e) {
      ErrorHandler.getInstance().handleError("Der benutzte Client " +        "konnte nicht bestimmt werden, da ein Client mit der Nummer '" +        clientNrString+"' nicht in der Datenbank eingetragen ist! Ein neuer " +        "Client wird erstellt!", false);
      try {
        benutzerClient = (Client) erstelleNeu();
        InetAddress inetAdress = InetAddress.getLocalHost();
        benutzerClient.setName(inetAdress.getHostName());
        benutzerClient.setIP(inetAdress.getHostAddress());
        benutzerClient.save();
        KonfigurationsDatei.getStandardKonfigurationsdatei().setProperty(
          "ClientNr", String.valueOf(benutzerClient.getId()));
      } catch (Exception f) {
        ErrorHandler.getInstance().handleException(f, "Der benutzte Client " +
          "konnte nicht in die Datenbank eingetragen werden!", true);
      }
    }
    return benutzerClient;
  }  
}
