/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMahnungsListe;

import java.text.DecimalFormat;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihe;
import de.oberbrechen.koeb.datenbankzugriff.Mahnung;
import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.einstellungen.Ausleihordnung;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell f�r die Internetstatistiken eines Monats
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
class MahnungTabellenModell extends TabellenModell {
  
  private Mahnung mahnung;
  private static DecimalFormat dauerFormat = new DecimalFormat("0.0");
  private static DecimalFormat kostenFormat = new DecimalFormat("0.00 EUR");
  
  public MahnungTabellenModell(Mahnung mahnung) {
    this.mahnung = mahnung;
    setSpaltenAusrichtung(3, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(4, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    
    setBreiteProzent(1, 15);    
    setBreiteProzent(2, 55);    
    setBreiteProzent(3, 15);    
    setBreiteProzent(4, 15);    
  }

  public int getSpaltenAnzahl() {
    return 4;
  }

  public int getZeilenAnzahl() {
    return mahnung.getAnzahlAusleihen()+1;
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "Mediennr.";
    if (spaltenNr == 2) return "Titel";
    if (spaltenNr == 3) return "�berzugsdauer";
    if (spaltenNr == 4) return "Mahngeb�hr";
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (zeilenNr == mahnung.getAnzahlAusleihen()+1) {
      if (spaltenNr == 4) {
        double mahngebuehr = mahnung.getMahngebuehren();
        return (mahngebuehr == 0)?"-":kostenFormat.format(mahngebuehr);
      }
      return null;
    } else {        
      Ausleihe aktuelleAusleihe = 
        (Ausleihe) mahnung.getAusleihenListe().get(zeilenNr-1);
      Medium aktuellesMedium = aktuelleAusleihe.getMedium();
      
      if (spaltenNr == 1)
        return aktuellesMedium==null?"":aktuellesMedium.getMedienNr();
      else if (spaltenNr == 2)
        return aktuellesMedium==null?"nicht eingestelltes Medium":aktuellesMedium.getTitel();
      else if (spaltenNr == 3) {
        double ueberzogeneWochen =
          ((double) ((aktuelleAusleihe.getUeberzogeneTage()*2)/7))/2;          
        return 
          ueberzogeneWochen>0?dauerFormat.format(ueberzogeneWochen)+" W.":"-";
      }
      else if (spaltenNr == 4) {    
        double mahngebuehr = Ausleihordnung.getInstance().
          berechneMahngebuehren(aktuelleAusleihe);
        return (mahngebuehr == 0)?"-":kostenFormat.format(mahngebuehr);
      }
      return "Fehler";
    }
  }
    
	public boolean getZeigeZeilenHintergrund(int modellZeile, int seitenZeile) {
    if (modellZeile == getZeilenAnzahl()) return false;
		return super.getZeigeZeilenHintergrund(modellZeile, seitenZeile);
	}

	public float getZellenRandOben(int modellZeile,int seitenZeile,int spalte) {
    if (modellZeile == 1 || modellZeile == getZeilenAnzahl()) return 1;
    return 0;		
	}
}