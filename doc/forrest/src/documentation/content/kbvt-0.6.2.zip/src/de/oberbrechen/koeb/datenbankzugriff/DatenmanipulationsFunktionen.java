/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Diese Klasse stellt einfache Funktionen bereit, die in vielen
 * Implementierungen von Datenbankzugriff ben�tigt werden. Bspw.
 * die Konvertierung zwischen java.sql.Date und java.util.Date.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */

public class DatenmanipulationsFunktionen {

	private static final long milliSekundenProTag = 1000*60*60*24;

  private static SimpleDateFormat datumsFormatierer = new
    SimpleDateFormat("dd.MM.yyyy");

  /**
   * Konvertiert ein java.util.Date-Objekt in ein
   * java.sql.Date-Objekt.
   * @param date das zu konvertierende Date
   * @return das sql-Date
   */
  public static java.sql.Date utilDate2sqlDate(java.util.Date date) {
    if (date == null) return null;
    return new java.sql.Date(date.getTime());
  }
  
	/**
	 * Konvertiert ein java.util.Date-Objekt in ein
	 * java.sql.Timestamp-Objekt.
	 * @param date das zu konvertierende Date
	 * @return das sql-Timestamp
	 */
	public static java.sql.Timestamp utilDate2sqlTimestamp(java.util.Date date) {
		if (date == null) return null;
		return new java.sql.Timestamp(date.getTime());
	}
	
	/**
	 * Liefert die Anzahl der Tage, die die �bergebene Anzahl in Millisekunden
	 * entspricht. Dabei wird jeweils abgerundet.
	 */
	public static int milliSekunden2Tage(long millis) {
		return (int) Math.floor(
			((double) millis) / milliSekundenProTag);	  
	}

	/**
	 * Liefert die Anzahl der Tage, die zwischen dem erten und dem zweiten 
	 * �bergebenen Datum liegen.
	 */
	public static int getDifferenzTage(java.util.Date beginn, java.util.Date ende) {
	  return milliSekunden2Tage(ende.getTime()-beginn.getTime());
	}

	/**
   * Formatiert den �bergebenen String. Es werden f�hrende und
   * beendende Leerzeichen entfernt und ein leerer String in eine
   * <code>null</code>-Referenz konvertiert.
   */
  public static String formatString(String string) {
    if (string == null) return null;
    
    String erg = string.trim();
    if (erg.length() == 0) return null;
    return erg;
  }
  
  public static String entferneNull(String string) {
    if (string == null) return "";
    return string;
  }
  
	public static String ersetzeNull(String string, String ersatz) {
		if (string == null) return ersatz;
		return string;
	}

	/**
   * Formatiert das �bergebene Datum im Format 'dd.MM.yyyy'. 
   * Wird <code>null</code> �bergeben, liefert die Methode '-'.
   * @param date das zu formatierende Datum
   * @return das formatierte Datum
   */
  public static String formatDate(Date date) {
    if (date == null) return "-";    
    return datumsFormatierer.format(date);
  }  
  
  /**
   * Clont ein Datum. D.h. wenn eine null-Referenz �bergeben wird,
   * wird null zur�ckgeliefert, ansonsten wird die Methode clone des Date-Objekts
   * aufgerufen und das Ergebnis zur�ckgeliefert.
   */
  public static Date cloneDate(Date date) {
    if (date == null) return null;
    return (Date) date.clone();
  }

  /**
   * Bestimmt, ob die beiden �bergebenen Zeitpunkte h�chstens 24 Stunden 
   * auseinanderliegen.
   */
  public static boolean entsprichtGleichemDatum(Date date, Date date2) {
		long milliSekundenDifferenz =	date.getTime() - date2.getTime(); 

		return (milliSekundenDifferenz < milliSekundenProTag &&
						milliSekundenDifferenz > -milliSekundenProTag);
  }

	/**
	 * Bestimmt, ob die der �bergebenen Zeitpunkte h�chstens 24 Stunden 
	 * vom jetzigen abweicht. Wird null �bergeben, so lautet das Ergebnis
   * false
	 */
	public static boolean entsprichtHeutigemDatum(Date date) {
	  if (date == null) return false;
    
    long milliSekundenDifferenz =	date.getTime() - System.currentTimeMillis(); 

		return (milliSekundenDifferenz < milliSekundenProTag &&
						milliSekundenDifferenz > -milliSekundenProTag);
	}
}