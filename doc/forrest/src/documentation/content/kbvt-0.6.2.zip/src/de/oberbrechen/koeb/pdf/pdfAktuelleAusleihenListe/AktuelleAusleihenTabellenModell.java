/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAktuelleAusleihenListe;

import java.text.SimpleDateFormat;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell aktuellen Ausleihen eines Benutzers
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
class AktuelleAusleihenTabellenModell extends TabellenModell {
  
  private AusleihenListe aktuelleAusleihen;
  private SimpleDateFormat dateFormat=new SimpleDateFormat("EE, d. MMM. yyyy");
  
  public AktuelleAusleihenTabellenModell(Benutzer benutzer) {
    aktuelleAusleihen = Datenbank.getInstance().getAusleiheFactory().
      getAlleNichtZurueckgegebenenAusleihenVon(benutzer);
    aktuelleAusleihen.setSortierung(AusleihenListe.MedienTitelSortierung, 
      false);
    
    setSpaltenAbstand(3);
    setBreiteProzent(1, 12.5f);    
    setBreiteProzent(2, 42.5f);    
    setBreiteProzent(3, 25);    
    setBreiteProzent(4, 20);    
  }

  public int getSpaltenAnzahl() {
    return 4;
  }

  public int getZeilenAnzahl() {
    if (aktuelleAusleihen.size() > 0) return aktuelleAusleihen.size();
    return 1;
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "Mediennr.";
    if (spaltenNr == 2) return "Titel";
    if (spaltenNr == 3) return "Autor";
    if (spaltenNr == 4) return "R�ckgabedatum";
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (aktuelleAusleihen.size() == 0) return "-";
    
    Ausleihe aktuelleAusleihe = 
      (Ausleihe) aktuelleAusleihen.get(zeilenNr-1);

    if (spaltenNr == 1)
      return aktuelleAusleihe.getMedium().getMedienNr();
    else if (spaltenNr == 2)
      return aktuelleAusleihe.getMedium().getTitel();
    else if (spaltenNr == 3)
      return aktuelleAusleihe.getMedium().getAutor();
    else if (spaltenNr == 4)
      return dateFormat.format(aktuelleAusleihe.getSollRueckgabedatum());    
    return "Fehler";
  }
    
	public boolean getZeigeZeilenHintergrund(int modellZeile, int seitenZeile) {
    if (aktuelleAusleihen.size() == 0) return false;
    Ausleihe aktuelleAusleihe = 
       (Ausleihe) aktuelleAusleihen.get(modellZeile-1);
    return aktuelleAusleihe.istUeberzogen();
	}
}