/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.EAN;

/**
 * Dieses Interface stellt Methoden zur Verf�gung, um Benutzer und Medien ihren
 * EAN 13-Nummern zuzuordnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public interface EANZuordnung {

  /**
   * Liefert das Objekt, auf das die EAN-Nr verweist. Dies kann ein
   * Benutzer, ein Medium oder null sein.
   *
   * @param ean die EAN
   * @return Objekt, auf das die EAN-Nr verweist
   */
  public Object getReferenz(EAN ean);

  /**
   * Liefert zu dem �bergebenen Benutzer seine Standard-EAN.
   * @param benutzer der Benutzer, dessen EAN bestimmt werden soll
   * @return die EAN des Benutzers
   */
  public EAN getBenutzerEAN(Benutzer benutzer);

  /**
   * Liefert zu dem �bergebenen Medium seine Standard-EAN.
   * @param medium das Medium, dessen EAN bestimmt werden soll
   * @return die EAN des Mediums
   */
  public EAN getMediumEAN(Medium medium);
  
  /**
   * Liefert zu der �bergebenen Medium-ID passende Standard-EAN.
   * @param medium das Medium, dessen EAN bestimmt werden soll
   * @return die EAN des Mediums
   * @deprecated
   */
  public EAN getMediumEAN(int mediumID);  
}