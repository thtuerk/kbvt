/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnpassendeEinstellungException;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.framework.KonfigurationsDatei;

/**
 * Diese Klasse bietet die grundlegenden Methoden des
 * Interfaces Einstellung. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public abstract class AbstractEinstellung extends AbstractDatenbankzugriff 
  implements Einstellung {
    
  protected String name;
  protected String wert;
  protected Client client;
  protected Mitarbeiter mitarbeiter;
  protected static boolean zeigeDebugInformationen;
    
  static {
    KonfigurationsDatei confDatei =
      KonfigurationsDatei.getStandardKonfigurationsdatei();
    zeigeDebugInformationen = false;
    
    String booleanString = confDatei.getProperty("zeigeDebug");
    if (booleanString != null && booleanString.equalsIgnoreCase("true"))
      zeigeDebugInformationen = true;
  }
    
    
  public String getName() {
    return name;
  }
  
  public String getWert() {
    return wert;
  }
   
  public Client getClient() {
    return client;
  }

  public Mitarbeiter getMitarbeiter() {
    return mitarbeiter;
  }

  public void setWert(String string) {
    setIstNichtGespeichert();
    wert = string;
  }
  
  public String toString() {
    return toDebugString();
  }
  
  public String toDebugString() {
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Client:      ");
    if (getClient() != null) {
      ausgabe.append(this.getClient().toDebugString());
    } else {
      ausgabe.append("-"); 
    }

    ausgabe.append("\nMitarbeiter: ");
    if (getMitarbeiter() != null) {
      ausgabe.append(getMitarbeiter().getBenutzer().getName());
    } else {
      ausgabe.append("-"); 
    }
    
    ausgabe.append("\nName:        ");
    ausgabe.append(getName());

    ausgabe.append("\nWert:        ");
    ausgabe.append(getWert());

    return ausgabe.toString();
  }
  
	public boolean getWertBoolean() throws UnpassendeEinstellungException {
    String booleanString = getWert();
    if (booleanString != null && booleanString.equalsIgnoreCase("true"))
      return true;
    if (booleanString != null && booleanString.equalsIgnoreCase("false"))
      return false;

    throw new UnpassendeEinstellungException(
      "Der Wert '" + booleanString + 
      "' kann nicht als boolscher Wert interpretiert werden!");
	}

	public double getWertDouble() throws UnpassendeEinstellungException {
    String doubleString = getWert();
    try {
      if (doubleString == null) throw new NumberFormatException();
      return Double.parseDouble(doubleString);
    } catch (NumberFormatException e) {
      throw new UnpassendeEinstellungException(
        "Der Wert '" + doubleString
          + "' kann nicht als Zahl interpretiert werden!");
    }
	}

	public int getWertInt() throws UnpassendeEinstellungException {
    try {      
      if (getWert() == null) throw new NumberFormatException();      
      return Integer.parseInt(getWert());
    } catch (NumberFormatException e) {
      throw new UnpassendeEinstellungException(
        "Der Wert '" + getWert() + 
        "' kann nicht als Zahl interpretiert werden!");
    }
	}

	public Object getWertObject(Class typ) throws UnpassendeEinstellungException {
    String className = getWert();

    Object retVal = getInstanz(className);
    if (retVal == null || !typ.isInstance(retVal)) {
      throw new UnpassendeEinstellungException(
        "Der Wert '" + className
          + "' kann nicht als Klassenname "
          + "einer Klasse mit paraterlosem Konstruktor vom Typ "
          + typ.getName()
          + " interpretiert werden!");
    }

    return retVal;
	}

  private Object getInstanz(String className) {
    if (className == null) return null;
    
    Object retVal = null;
    try {
      retVal = Class.forName(className).newInstance();
    } catch (ClassNotFoundException cnfe) {
    } catch (InstantiationException ie) {
    } catch (IllegalAccessException iae) {
    }

    return retVal;
  }

	public void setWertBoolean(boolean wert) {
    if (wert)
      setWert("TRUE");
    else
      setWert("FALSE");
	}

	public void setWertDouble(double wert) {
    setWert(Double.toString(wert));
	}

	public void setWertInt(int wert) {
    setWert(Integer.toString(wert));
	}
  
	public boolean getWertBoolean(boolean standard) {
    try {
      return getWertBoolean();
    } catch (UnpassendeEinstellungException e) {
      parseFehlerMeldung(e, ""+standard);
      setWertBoolean(standard);
      save();
      return standard;
    }
	}

	public double getWertDouble(double standard) {
    try {
      return getWertDouble();
    } catch (UnpassendeEinstellungException e) {
      parseFehlerMeldung(e, ""+standard);
      setWertDouble(standard);
      save();
      return standard;
    }
	}

	public int getWertInt(int standard) {
    try {
      return getWertInt();
    } catch (UnpassendeEinstellungException e) {
      parseFehlerMeldung(e, ""+standard);
      setWertInt(standard);
      save();
      return standard;
    }
	}

	public Object getWertObject(Class typ, Class standard)
		throws UnpassendeEinstellungException {
    try {
      return getWertObject(typ);
    } catch (UnpassendeEinstellungException e) {
      parseFehlerMeldung(e, ""+standard.getName());
      setWert(standard.getName());
      save();
    }

    try {
      return getWertObject(typ);
    } catch (UnpassendeEinstellungException e) {
      ErrorHandler.getInstance().handleException(
        e,
        "Probleme beim Laden der Einstellung\n"
          + toDebugString()
          + "\n\n"
          + "Auch der Standardwert '"
          + standard
          + "' kann nicht als Klassenname "
          + "einer Klasse mit paraterlosem Konstruktor interpretiert werden!",
          true);
       throw e;
    }
	}

  public String getWert(String standard) {
    String wert = getWert();
    if (wert == null) {
      parseFehlerMeldung(new UnpassendeEinstellungException(
        "Die Einstellung enthielt den Wert null!"), standard); 
      setWert(standard);
      save();
      wert = standard;
    }
    
    return wert;
  }
  
  /**
   * Zeigt die Standardfehlermeldung f�r eine UnpassendeEinstellungException
   * an.  
   * @param e die geworfene Exception
   * @param standard der Standardwert, der gesetzt werden soll
   */
  private void parseFehlerMeldung(Exception e, String standard) {    
    if (zeigeDebugInformationen) {
      ErrorHandler.getInstance().handleException(e,
          "Probleme beim Laden der Einstellung\n"
          + toDebugString()
          + "\n\n"
          + "Es wird versucht, den Standardwert '"
          + standard
          + "' zu setzen!",
          false);    
    }
  }  
}
