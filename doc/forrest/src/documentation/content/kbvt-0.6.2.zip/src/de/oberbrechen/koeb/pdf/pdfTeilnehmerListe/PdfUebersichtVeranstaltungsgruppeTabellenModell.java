/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltung;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltungsgruppe;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltungsteilnahme;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankzugriffException;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsteilnahmeListe;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

class PdfUebersichtVeranstaltungsgruppeTabellenModell 
  extends TabellenModell {

	String[] klassen;
	String[][] daten;
	
  public PdfUebersichtVeranstaltungsgruppeTabellenModell(
    Veranstaltungsgruppe veranstaltungsgruppe) throws DatenbankzugriffException {
    super(3, false);

    VeranstaltungsteilnahmeFactory teilnahmeFactory =
      Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();
    BenutzerListe teilnehmerListe = 
      teilnahmeFactory.getTeilnehmerListe(veranstaltungsgruppe);
    teilnehmerListe.setSortierung(BenutzerListe.NachnameVornameSortierung);
    
		Liste klassenListe = new Liste();
		Iterator iterator = teilnehmerListe.iterator();	
		while (iterator.hasNext()) {
			Benutzer benutzer = (Benutzer) iterator.next();
			String klasse = benutzer.getKlasse();
			if (klasse != null) klassenListe.add(klasse);
		}
		klassenListe.setSortierung(Liste.StringSortierung, false);

		klassen = (String[]) klassenListe.toArray(new String[klassenListe.size()]);

		//Daten Initialisieren
		VeranstaltungenListe veranstaltungenListe = 
      Datenbank.getInstance().getVeranstaltungFactory().
        getVeranstaltungenMitAnmeldung(veranstaltungsgruppe); 
      
		veranstaltungenListe.setSortierung(VeranstaltungenListe.AlphabetischeSortierung, false);
		daten = new String[veranstaltungenListe.size()][klassen.length+3];
		    
		for (int vNr = 0; vNr < veranstaltungenListe.size(); vNr++) {
			Veranstaltung veranstaltung = (Veranstaltung) veranstaltungenListe.get(vNr);
			daten[vNr][0] = veranstaltung.getTitel();

      int teilnehmerAnzahl = teilnahmeFactory.getTeilnehmerAnzahl(veranstaltung);
			if (teilnehmerAnzahl == 0) {
				daten[vNr][1] = "-";
			} else {
				daten[vNr][1] = Integer.toString(teilnehmerAnzahl);
			}
			
			if (veranstaltung.getMaximaleTeilnehmerAnzahl() > 0) {
				daten[vNr][1] += " / ";
				daten[vNr][1] += Integer.toString(veranstaltung.getMaximaleTeilnehmerAnzahl());						
			}
			
			int[] klassenAnzahl = new int[klassen.length+1];			
			VeranstaltungsteilnahmeListe teilnahmenListe = 
        teilnahmeFactory.getTeilnahmeListe(veranstaltung);
      teilnahmenListe.setSortierung(
          VeranstaltungsteilnahmeListe.AnmeldeNrSortierung);
			Iterator teilnahmenIt = teilnahmenListe.iterator();
			while (teilnahmenIt.hasNext()) {
				String currentKlasse = ((Veranstaltungsteilnahme) teilnahmenIt.next()).getBenutzer().getKlasse();
				int pos = 0;
				boolean gefunden = false;
				while (currentKlasse != null && !gefunden && pos < klassen.length) {
					if (currentKlasse.equals(klassen[pos])) {
						gefunden = true;
						klassenAnzahl[pos]++;
					}
					pos++;
				}
				if (!gefunden) klassenAnzahl[klassen.length]++;
			}

			for (int pos = 0; pos < klassenAnzahl.length; pos++) {
				if (klassenAnzahl[pos] == 0) {
					daten[vNr][2+pos] = "-";
				} else {
					daten[vNr][2+pos] = Integer.toString(klassenAnzahl[pos]);
				}
			}

		}
				
    //Spaltenmodell bauen
    init(getSpaltenAnzahl());
    for (int i=2;i<=getSpaltenAnzahl(); i++) {
    	setSpaltenAusrichtung(i, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);    	
    }
  	setZeigeSpaltenHintergrund(2, true);
  }

	public int getSpaltenAnzahl() {
    return daten[0].length;
  }

  public int getZeilenAnzahl() {
    return daten.length;
  }

  public String getSpaltenName(int spaltenNr) {
	  if (spaltenNr == 1) return "Veranstaltung";
  	if (spaltenNr == 2) return "Anzahl";
    if (spaltenNr > 2 && spaltenNr < 3+klassen.length) {
    	return klassen[spaltenNr-3];
    }
    return "-";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
  	return daten[zeilenNr-1][spaltenNr-1];
  }
}

