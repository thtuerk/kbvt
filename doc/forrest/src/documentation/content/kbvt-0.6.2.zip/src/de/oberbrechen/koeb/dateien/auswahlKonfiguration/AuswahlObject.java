/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihzeitraum;
import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenbankzugriff.Medium;


/**
 * Dummer-Datencontainer.
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
class AuswahlObject{
    
  Medium medium;
  Ausleihzeitraum zeitraum;
  Benutzer benutzer;

  public void setDaten(Ausleihzeitraum zeitraum) {
    this.zeitraum = zeitraum;
    this.medium = zeitraum.getAusleihe().getMedium();
    this.benutzer = zeitraum.getAusleihe().getBenutzer();
  }
  
  public Benutzer getBenutzer() {
    return benutzer;
  }

  public Medium getMedium() {
    return medium;
  }

  public Ausleihzeitraum getZeitraum() {
    return zeitraum;
  }

  public void setDaten(Medium medium) {
    this.zeitraum = null;
    this.medium = medium;
    this.benutzer = null;
  }
  
  public void setDaten(Benutzer benutzer) {
    this.zeitraum = null;
    this.medium = null;
    this.benutzer = benutzer;
  }
}