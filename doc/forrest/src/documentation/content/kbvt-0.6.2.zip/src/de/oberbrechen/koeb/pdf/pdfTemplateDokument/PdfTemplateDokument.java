/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTemplateDokument;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import de.oberbrechen.koeb.pdf.*;

/**
 * Ein PdfDokument, das die uebergebenen Templates alle nacheinander auf Seiten
 * verteilt.
 * @author Thomas T�rk (t_tuerk@gmx.de)
 */
public class PdfTemplateDokument
  extends ErweitertesPdfDokumentMitSeitenKopfFuss {

  private PdfTemplate[] templates = null;
  private float abstand = 10;
  
  /**
   * Setzt die anzuzeigenden Templates
   */
  public void setTemplates(PdfTemplate[] templates) {
    this.templates = templates;
  }
  
  public void setTemplateAbstand(float abstand) {
    this.abstand = abstand;
  }

  /**
   * Setzt den Seitenkopf f�r alle Seiten
   *
   * @param seitenKopf der Seitenkopf f�r alle anderen Seiten
   * @param seitenKopfErsteSeite der Seitenkopf f�r die erste Seite
   */
  public void setSeitenKopf(SeitenKopfFuss seitenKopf,
                            SeitenKopfFuss seitenKopfErsteSeite) {
    this.seitenKopf = seitenKopf;
    this.seitenKopfErsteSeite = seitenKopfErsteSeite;
  }

  /**
   * Setzt den Seitenkopf f�r alle Seiten
   * @param seitenKopf der Seitenkopf f�r alle Seiten
   */
  public void setSeitenKopf(SeitenKopfFuss seitenKopf) {
    this.seitenKopf = seitenKopf;
    this.seitenKopfErsteSeite = null;
  }

  /**
   * Setzt den Seitenfuss f�r alle Seiten
   * @param seitenFuss der Seitenfuss f�r alle Seiten
   */
  public void setSeitenFuss(SeitenKopfFuss seitenFuss) {
    this.seitenFuss = seitenFuss;
  }
  
  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter pdfWriter, Document doc) throws Exception {    
    int seitenNr = 1;
    PdfContentByte pdf = pdfWriter.getDirectContent();

    schreibeSeitenKopfFuss(seitenNr, pdf);
    if (templates == null) return;

    float yPos = getSeitenHoehe() - getSeitenRandObenMitKopf(seitenNr);
    for (int i = 0; i < templates.length; i++) {
      float platzTemplate = templates[i].getHeight();
      yPos -= platzTemplate;
      if (yPos < getSeitenRandUntenMitFuss(seitenNr)) {
        seitenNr++;
        doc.newPage();
        schreibeSeitenKopfFuss(seitenNr, pdf);
        yPos = getSeitenHoehe()- 
          getSeitenRandObenMitKopf(seitenNr);
        yPos -= platzTemplate;        
      }
      pdf.addTemplate(templates[i], 1, 0, 0, 1, 0, yPos);
      yPos -= abstand;
    }
    this.finalisiere(seitenNr);
  }
}
