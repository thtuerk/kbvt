/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;
import java.util.Iterator;

import com.mysql.jdbc.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.AbstractMedium;
import de.oberbrechen.koeb.datenbankzugriff.Medientyp;
import de.oberbrechen.koeb.datenbankzugriff.MedientypFactory;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.datenstrukturen.EAN;
import de.oberbrechen.koeb.datenstrukturen.EANListe;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlMedium extends AbstractMedium {

	boolean systematikenGeladen = false;
	boolean eansGeladen = false;

  public MysqlMedium(int id) {
	  load(id);
	}

  MysqlMedium(ResultSet result) throws SQLException {
    load(result);
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
  }
  
  public MysqlMedium() {
  }
  
  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    load(getId());
	}

	public void save() throws UnvollstaendigeDatenException, EindeutigerSchluesselSchonVergebenException {
	  if (istGespeichert()) return;
	  loadEANs();
    loadSystematiken();
    
	  if (this.getMedienNr() == null || this.getTitel() == null ||
				this.getMedientyp() == null)
			throw new UnvollstaendigeDatenException("Nummer, Titel und Typ jedes "+
				"Mediums m�ssen eingegeben sein.");

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      
			Statement normalStatement = 
				MysqlDatenbank.getMysqlInstance().getStatement();

			//Mediennr schon vergeben?
			ResultSet result = (ResultSet) normalStatement.executeQuery(
			    "select id from medium where Nr = \""+this.getMedienNr()+"\"");
			if (result.next() && 
			    (this.istNeu() || this.getId() != result.getInt("id"))) {
			  
			  MediumFactory mediumFactory = 
			  	MysqlDatenbank.getMysqlInstance().getMediumFactory();
			  Medium konfliktMedium = (Medium) mediumFactory.get(result.getInt("id"));
				throw new MedienNrSchonVergebenException(konfliktMedium);          
			}
			
      //EAN schon benutzt
			Iterator eanIt = getEANs().iterator();
			while (eanIt.hasNext()) {
			  EAN ean = (EAN) eanIt.next();
				result = (ResultSet) normalStatement.executeQuery(
						"select mediumid from medium_ean where ean = \""+ean+"\"");
				if (result.next() && 
						(this.istNeu() || this.getId() != result.getInt("mediumid"))) {
			  
					MediumFactory mediumFactory = 
						MysqlDatenbank.getMysqlInstance().getMediumFactory();
					Medium konfliktMedium = (Medium) mediumFactory.get(
					  result.getInt("mediumid"));
					throw new EANSchonVergebenException("Die EAN '"+ean.toString()+
					  "' wird schon von dem Medium "+konfliktMedium.toString()+" " +
					  "verwendet.", konfliktMedium);    
				}
			  
			}
      
      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      PreparedStatement statement = null;

      if (this.istNeu()) {
        statement = (PreparedStatement) connection.prepareStatement(
          "insert into medium "+
					"set Nr = ?, Titel = ?, "+
					"Autor = ?, Beschreibung = ?, MedientypID = ?, " +
					"Medienanzahl = ?, eingestellt_seit = ?, "+
					"aus_Bestand_entfernt = ?, ISBN = ?");
      } else {
        statement = (PreparedStatement) connection.prepareStatement(
          "update medium "+
					"set Nr = ?, Titel = ?, "+
					"Autor = ?, Beschreibung = ?, MedientypID = ?, " +
					"Medienanzahl = ?, eingestellt_seit = ?, "+
					"aus_Bestand_entfernt = ?, ISBN = ? "+
          "where id="+this.getId());
      }

			statement.setString(1, this.getMedienNr());
			statement.setString(2, this.getTitel());
			statement.setString(3, this.getAutor());
			statement.setString(4, this.getBeschreibung());
			statement.setInt(5, this.getMedientyp().getId());
			statement.setInt(6, this.getMedienAnzahl());
			statement.setDate(7, DatenmanipulationsFunktionen.utilDate2sqlDate(
					this.getEinstellungsdatum()));
			statement.setDate(8, DatenmanipulationsFunktionen.utilDate2sqlDate(
					this.getEntfernungsdatum()));
      statement.setString(9, isbn != null?isbn.getISBN():null);
      
      statement.execute();
      
      if (this.istNeu()) {
        result = (ResultSet) statement.getGeneratedKeys();
        result.next();
        id = result.getInt(1);
      }
      
      //Systematiken einf�gen
			normalStatement.execute("delete from medium_gehoert_zu_systematik " +
				  "where mediumid="+this.getId());
			PreparedStatement insertSystematikStatement = 
				(PreparedStatement) connection.prepareStatement(
            "insert into medium_gehoert_zu_systematik set "+
            "mediumid = ?, systematikID = ?");
			insertSystematikStatement.setInt(1, this.getId());
			Iterator it = getSystematiken().iterator();
			while (it.hasNext()) {
			  insertSystematikStatement.setInt(2, ((Systematik) it.next()).getId());
			  insertSystematikStatement.addBatch();
			}
			insertSystematikStatement.executeBatch();
			
			//EANs einf�gen
			normalStatement.execute("delete from medium_ean " +
				"where mediumid="+this.getId());
			PreparedStatement insertEANsStatement = 
				(PreparedStatement) connection.prepareStatement(
						"insert into medium_ean set "+
						"mediumid = ?, ean = ?");
			insertEANsStatement.setInt(1, this.getId());
			it = getEANs().iterator();
			while (it.hasNext()) {
				insertEANsStatement.setString(2, ((EAN) it.next()).getEAN());
				insertEANsStatement.addBatch();
			}
			insertEANsStatement.executeBatch();
			
      MysqlDatenbank.getMysqlInstance().releaseStatement(normalStatement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern " +        "des folgenden Mediums:\n\n"+this.toDebugString(), true);
    }

    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
	}

	public void loesche() throws DatenbankInkonsistenzException {
	  if (this.istNeu()) return;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      
      //Medien
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select count(*) from ausleihe where "+
				  "mediumID = "+this.getId());
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Das Medium '"+this.getTitel()+          "' ("+this.getMedienNr()+") kann nicht gel�scht werden, da noch " +
          "Medien dieses Typs existieren.");

      //l�schen
			statement.execute("delete from medium_gehoert_zu_systematik where "+
				"mediumid = "+this.getId());

			statement.execute("delete from medium_ean where "+
				"mediumid = "+this.getId());

			statement.execute("delete from medium where "+
				"id = "+this.getId());

      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);      
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des "+
        "Medientyps "+this.toDebugString(), true);
    }
	}
  
  void load(ResultSet result) throws SQLException {
    id = result.getInt("id");
		nr = result.getString("nr");
		titel = result.getString("titel");
		autor = result.getString("autor");
		beschreibung = result.getString("beschreibung");
		medienAnzahl = result.getInt("Medienanzahl");
		aus_Bestand_entfernt = result.getDate("aus_Bestand_entfernt");
    eingestellt_seit = result.getDate("eingestellt_seit");
    try {
      String isbnString = result.getString("isbn");
      isbnString = DatenmanipulationsFunktionen.formatString(isbnString);
      isbn = isbnString == null?null:new ISBN(isbnString);
    } catch (IllegalArgumentException exception) {
      throw new DatenbankInkonsistenzException("Das Medium "+id+" besitzt eine"+
          "ung�ltige ISBN-Nummer!");
    }
    
		MedientypFactory medientypFactory = 
			MysqlDatenbank.getMysqlInstance().getMedientypFactory();
		medientyp = (Medientyp) medientypFactory.get(result.getInt("MedientypID"));
  }

	void loadSystematiken() {
		if (systematikenGeladen) return;
		try {
			systematikenGeladen = true;
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			SystematikFactory systematikFactory = 
				MysqlDatenbank.getMysqlInstance().getSystematikFactory();
			systematiken = new SystematikListe();
			ResultSet systematikenResult = (ResultSet) statement.executeQuery(
					"select systematikid from medium_gehoert_zu_systematik "+ 
					"where mediumID = " + id);
			while (systematikenResult.next()) {
				systematiken.add(systematikFactory.get(systematikenResult.getInt(1)));
			}
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
				"Systematiken!", true);
		}
	}

	void loadEANs() {
		if (eansGeladen) return;
		try {
			eansGeladen = true;
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			eanListe = new EANListe();
			ResultSet eanResult = (ResultSet) statement.executeQuery(
					"select ean from medium_ean where mediumID = " + id);
			while (eanResult.next()) {
			  eanListe.add(new EAN(eanResult.getString(1)));
			}
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
				"Systematiken!", true);
		}
	}
  
  void load(int id) throws DatenNichtGefundenException {
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select * from medium where id = " + id);
      boolean mediumGefunden = result.next();
      if (!mediumGefunden) throw new DatenNichtGefundenException(
        "Ein Medium mit der ID "+id+" existiert nicht!");
  
      load(result);
  
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "des Mediums mit der ID "+id+"!", true);
    }
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
    
  }   

  public EANListe getEANs() {
		loadEANs();
    return super.getEANs();
  }

  public SystematikListe getSystematiken() {
		loadSystematiken();
    return super.getSystematiken();
  }

  public void setEANs(EANListe eanListe) {
		eansGeladen = true;
    super.setEANs(eanListe);
  }

  public void setSystematiken(SystematikListe systematiken) {
		systematikenGeladen = true;
    super.setSystematiken(systematiken);
  }
}