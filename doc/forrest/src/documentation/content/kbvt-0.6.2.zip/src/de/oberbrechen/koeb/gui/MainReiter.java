/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui;

import javax.swing.JMenu;

/**
 * Dieses Interface repr�sentiert einen beliebigen Reiter, der
 * in Main eingebunden werden kann.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public interface MainReiter {

  /**
   * Aktualisiert den Reiter, d.h. alle Daten werden erneut aus der Datenbank
   * geladen und die Anzeige aktualisiert.
   */
  public void aktualisiere();

  /**
   * Teilt dem Reiter mit, dass er jetzt angezeigt wird, und seine Daten
   * aktualisieren soll. Im Gegensatz zu aktualisiere sollen daf�r nicht
   * alle Daten erneut aus der Datenbank gelesen werden.
   */
  public void refresh();
  
  /**
   * Teilt dem Reiter mit, dass er jetzt nicht mehr angezeigt wird, und 
   * abschlie�ende Aktionen ausf�hren soll.
   */
  public void focusLost();

  /**
   * Liefert ein Menue, dass nur f�r diesen Reiter angezeigt werden soll
   * @return
   */
  public JMenu getMenu();
}