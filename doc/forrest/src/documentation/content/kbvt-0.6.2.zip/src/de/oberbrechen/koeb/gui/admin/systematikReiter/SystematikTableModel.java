/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.systematikReiter;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManager;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManagerListenDaten;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class SystematikTableModel extends AbstractTableModel 
  implements KeyListener, ListenKeySelectionManagerListenDaten {
  
  private SystematikListe daten;
  private JTable tabelle;
  private ListenKeySelectionManager keySelectionManager;  
  
  /**
   * Erstellt ein neues Modell ohne Daten, das nach dem Sollr�ckgabedatum
   * der Ausleihen sortiert ist
   */
  public SystematikTableModel(JTable tabelle) {
    daten = new SystematikListe();
    daten.setSortierung(SystematikListe.alphabetischeSortierung);
    
    this.tabelle = tabelle;
    keySelectionManager = new ListenKeySelectionManager(this);    
  }

  /**
   * Setzt die �bergebenen Daten und die darin enthaltene Sortierung
   * @param daten die zu setzenden Daten
   */
  public void setDaten(SystematikListe daten) {
    this.daten.clear();
    this.daten.addAll(daten);
    fireTableDataChanged();
  }

  /**
   * Liefert die aktuellen Daten des Modells als SortedSet. Dieses
   * wird intern verwendet, weswegen das SortedSet nicht
   * ver�ndert werden sollte.
   * @return die aktuellen Daten
   */
  public SystematikListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Systematik";
    if (columnIndex == 1) return "Beschreibung";
    if (columnIndex == 2) return "Obersystematik";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public int getDefaultColumnWidth(int column) {
    switch (column) { 
    case 0: return 80;
    case 1: return 250;
    case 2: return 80;
    }
    
    return 100;
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    Systematik gewaehlteSystematik = (Systematik) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehlteSystematik.getName();
    if (columnIndex == 1) return gewaehlteSystematik.getBeschreibung();
    if (columnIndex == 2) {
      Systematik systematik = gewaehlteSystematik.getDirekteObersystematik();
      return systematik==null?"-":systematik.getName();    
    }
    
    return "nicht definierte Spalte";
  }

  public void keyPressed(KeyEvent e) {
    char aKey = e.getKeyChar();
    int zuSelektierendeZeile = keySelectionManager.selectionForKey(aKey);
    if (zuSelektierendeZeile == -1) return;
    
    tabelle.setRowSelectionInterval(zuSelektierendeZeile, zuSelektierendeZeile);
    tabelle.scrollRectToVisible(tabelle.getCellRect(zuSelektierendeZeile, 0, true));
  }

  public void keyReleased(KeyEvent arg0) {}
  public void keyTyped(KeyEvent arg0) {}

  public String getKeySelectionValue(int row) {
    return getValueAt(row, 0).toString();
  }

  public int size() {
    return getRowCount();
  }

  public Systematik getSystematiken(int gewaehlteReihe) {    
    return (Systematik) daten.get(gewaehlteReihe);
  }

  /**
   * F�gt die Systematik zum Modell hinzu
   * @param systematik
   */
  public void add(Systematik systematik) {
    daten.add(systematik);
    fireTableDataChanged();
  }
}
