/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;
import java.util.Date;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlInternetfreigabe extends AbstractInternetfreigabe {

	public MysqlInternetfreigabe(int id) {
    load(id);
	}

	MysqlInternetfreigabe(Benutzer benutzer, Client client, 
												Mitarbeiter mitarbeiter, Date beginn) {
	  this.client = client;
	  this.benutzer = benutzer;
	  this.mitarbeiter = mitarbeiter;
	  this.von = beginn;
	}

	MysqlInternetfreigabe(ResultSet result) throws SQLException {
    load(result);
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
  }

  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    load(getId());
	}

	public void save() throws UnvollstaendigeDatenException, EindeutigerSchluesselSchonVergebenException {
    if (istGespeichert()) return;

    if (this.getClient() == null || this.getMitarbeiter() == null ||
        this.getBenutzer() == null || this.getStartZeitpunkt() == null) {
      throw new UnvollstaendigeDatenException("Client, Benutzer, Mitarbeiter" +
        "und Beginn jeder Internetfreigabe muss eingegeben sein.");
    }

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      PreparedStatement statement = null;

      if (this.istNeu()) {
        statement = (PreparedStatement) connection.prepareStatement(
          "insert into internet_zugang " +
          "set ClientID = ?, MitarbeiterID = ?, BenutzerID = ?," +
          "Von = ?, Bis = ?");
      } else {
        statement = (PreparedStatement) connection.prepareStatement(
          "update internet_zugang "+
  				"set ClientID = ?, MitarbeiterID = ?, BenutzerID = ?," +
	  			"Von = ?, Bis = ? "+
          "where id="+this.getId());
      }
			statement.setInt(1, this.getClient().getId());
			statement.setInt(2, this.getMitarbeiter().getId());
			statement.setInt(3, this.getBenutzer().getId());
			statement.setTimestamp(4, 
			    DatenmanipulationsFunktionen.utilDate2sqlTimestamp(this.getStartZeitpunkt()));
			statement.setTimestamp(5, 
			    DatenmanipulationsFunktionen.utilDate2sqlTimestamp(this.getEndZeitpunkt()));

      statement.execute();
      
      if (this.istNeu()) {
        ResultSet result = (ResultSet) statement.getGeneratedKeys();
        result.next();
        id = result.getInt(1);
      }
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern " +        "des folgenden Internetzugangs:\n\n"+this.toDebugString(), true);
    }

    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
	}

  public void loesche() throws DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      
      statement.execute("delete from internet_zugang where "+
        "id = "+this.getId());
        
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);      
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen der "+
        "Internetfreigabe "+this.toDebugString(), true);
    }
	}
  

  void load(ResultSet result) throws SQLException {
    id = result.getInt("id");
    von = result.getTimestamp("Von");
    bis = result.getTimestamp("Bis");
    
		ClientFactory clientFactory = 
			MysqlDatenbank.getMysqlInstance().getClientFactory();
		client = (Client) clientFactory.get(result.getInt("ClientID"));
		
		MitarbeiterFactory mitarbeiterFactory = 
			MysqlDatenbank.getMysqlInstance().getMitarbeiterFactory();
		mitarbeiter = (Mitarbeiter) mitarbeiterFactory.get(result.getInt("MitarbeiterID"));

		BenutzerFactory benutzerFactory = 
			MysqlDatenbank.getMysqlInstance().getBenutzerFactory();
		benutzer = (Benutzer) benutzerFactory.get(result.getInt("BenutzerID"));		
  }

  void load(int id) throws DatenNichtGefundenException {
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select * from internet_zugang where id = " + id);
      boolean gefunden = result.next();
      if (!gefunden) throw new DatenNichtGefundenException(
        "Eine Internetfreigabe mit der ID "+id+" existiert nicht!");
  
      load(result);
  
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "der Internetfreigabe mit der ID "+id+"!", true);
    }
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();    
  }  
}