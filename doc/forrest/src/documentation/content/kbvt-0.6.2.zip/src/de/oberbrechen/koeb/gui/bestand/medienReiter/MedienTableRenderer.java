/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand.medienReiter;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.Date;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import de.oberbrechen.koeb.datenbankzugriff.Medium;

/**
 * Diese Klasse ist ein TableCellRenderer f�r eine Liste von
 * Medien. Er ist eng mit dem MedienTableModel verbunden und darf
 * nur zusammen mit diesem eingesetzt werden, d.h. jede Tabelle, die diesen
 * Renderer benutzt muss ein MedienTableModel benutzen.
 */
public class MedienTableRenderer implements TableCellRenderer {

  private DefaultTableCellRenderer renderer;
  private Font standardFont;
  private Font entferntFont;
  private Font neuFont;
  private Font neuEntferntFont;

  private static final Color sortiertBackgroundAuswahl = new Color(0,0,0, 60);
  private static final Color sortiertBackground = new Color(0,0,0,30);
  private static final Color standardBackground = new Color(255,255,255,0);
  private static final Color standardBackgroundAuswahl = new Color(0,0,0,30);

  public MedienTableRenderer() {
    renderer = new DefaultTableCellRenderer();
    renderer.setOpaque(true);

    Font bisherigeFont = renderer.getFont();
    standardFont = bisherigeFont.deriveFont(Font.PLAIN);
    neuFont = bisherigeFont.deriveFont(Font.BOLD);
    entferntFont = bisherigeFont.deriveFont(Font.ITALIC);
    neuEntferntFont = bisherigeFont.deriveFont(Font.ITALIC+Font.BOLD);
  }

  public Component getTableCellRendererComponent(
    JTable table, Object value, boolean isSelected,
    boolean hasFocus, int row, int column) {

    MedienTableModel model = (MedienTableModel) table.getModel();
    Medium medium = model.getMedium(row);
    renderer.setText(value.toString());

    column = table.convertColumnIndexToModel(column);
    if ( isSelected &&  model.istSortiertNach(column)) 
      renderer.setBackground(sortiertBackgroundAuswahl);
    if (!isSelected &&  model.istSortiertNach(column)) 
      renderer.setBackground(sortiertBackground);
    if ( isSelected && !model.istSortiertNach(column)) 
      renderer.setBackground(standardBackgroundAuswahl);
    if (!isSelected && !model.istSortiertNach(column)) 
      renderer.setBackground(standardBackground);

    boolean mediumNeu = (medium != null) && 
      (medium.getEinstellungsdatum() != null) &&
      medium.getEinstellungsdatum().after(new Date(
      System.currentTimeMillis()-1000*60*60*24*21));
    
    if (!medium.istNochInBestand() && mediumNeu) {
      renderer.setFont(neuEntferntFont);
    } else if (mediumNeu) {
      renderer.setFont(neuFont);
    } else if (!medium.istNochInBestand()) {
      renderer.setFont(entferntFont);
    } else {
      renderer.setFont(standardFont);      
    }
    return renderer;
  }


}