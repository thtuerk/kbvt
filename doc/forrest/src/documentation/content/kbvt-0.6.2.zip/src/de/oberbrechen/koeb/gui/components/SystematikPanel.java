/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.Systematik;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;

/**
 * Diese Klasse stellt ein Panel dar, mit dem Systematik-Daten angezeigt und
 * bearbeitet werden k�nnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public class SystematikPanel extends JPanel {

  private JFrame hauptFenster;
  private Systematik currentSystematik;
  private Systematik oldSystematik;

  
  // die Datenfelder
  private JTextField nameFeld = new JTextField();
  private SortiertComboBox spezialisiertFeld = new SortiertComboBox();
  private JTextArea beschreibungFeld = new JTextArea();
  private JButton resetButton;
  
  /**
   * Zeigt die �bergebenen Systematik an.
   * @param systematik die anzuzeigende Systematik
   */
  public void setSystematik(Systematik systematik) {
    currentSystematik = systematik;
    if (systematik == null) {
      nameFeld.setText(null);
      spezialisiertFeld.setSelectedItem(null);
      beschreibungFeld.setText(null);
      return;
    }
    
    if (!systematik.istNeu()) {
      oldSystematik = systematik;
    }

    nameFeld.setText(systematik.getName());
    spezialisiertFeld.setSelectedItem(systematik.getDirekteObersystematik());
    beschreibungFeld.setText(systematik.getBeschreibung());
  }

  /**
   * L�scht die aktuellen Systematik nach einer Sicherheitsabfrage.
   * @return <code>true</code> gdw das L�schen stattfand war
   */
  public boolean loescheSystematik() {
    try {
      int erg = JOptionPane.showConfirmDialog(hauptFenster, "Soll die "+
      "Systematik " +currentSystematik.getName()+ " wirklich gel�scht werden?",
      "Systematik l�schen?", JOptionPane.YES_NO_OPTION);
      if (erg != JOptionPane.YES_OPTION) return false;

      currentSystematik.loesche();
    } catch (DatenbankInkonsistenzException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Datenbank Inkonsistenz!", JOptionPane.ERROR_MESSAGE);
      return false;
    }
    return true;
  }

  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  public void setVeraenderbar(boolean veraenderbar) {
    //Eingabefelder
    nameFeld.setEditable(veraenderbar);
    spezialisiertFeld.setEnabled(veraenderbar);
    beschreibungFeld.setEditable(veraenderbar);
    resetButton.setEnabled(veraenderbar);
    
    if (veraenderbar) nameFeld.grabFocus();
  }

  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public SystematikPanel(JFrame hauptFenster) {
    this.hauptFenster=hauptFenster;
    currentSystematik = null;
    oldSystematik = null;
    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  // erzeugt die GUI
  void jbInit() throws Exception {
    JLabel jLabel1 = new JLabel("Systematik:");
    JLabel jLabel2 = new JLabel("Obersystematik:");
    JLabel jLabel3 = new JLabel("Beschreibung:");

    this.setLayout(new GridBagLayout());

    JScrollPane jScrollPane = new JScrollPane();
    jScrollPane.setMinimumSize(new Dimension(0, 40));
    jScrollPane.setPreferredSize(new Dimension(0, 40));
    beschreibungFeld.setLineWrap(true);
    beschreibungFeld.setWrapStyleWord(true);
    spezialisiertFeld.setEditable(false);

    resetButton = new JButton("Zur�cksetzen");
    resetButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent arg0) {
        spezialisiertFeld.setSelectedItem(null);
      }
    });
    
    this.add(jLabel1,    new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 10), 0, 0));
    this.add(jLabel2,    new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(10, 0, 0, 10), 0, 0));
    this.add(jLabel3,    new GridBagConstraints(0, 5, 2, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(10, 0, 0, 10), 0, 0));
    this.add(nameFeld,    new GridBagConstraints(0, 1, 2, 1, 1.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(spezialisiertFeld,     new GridBagConstraints(0, 3, 2, 1, 1.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(resetButton,     new GridBagConstraints(0, 4, 2, 1, 1.0, 0.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jScrollPane,        new GridBagConstraints(0, 6, 2, 1, 1.0, 1.0
            ,GridBagConstraints.EAST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    jScrollPane.getViewport().add(beschreibungFeld, null);
  }

  public void aktualisiere() {
    SystematikListe systematiken =
      Datenbank.getInstance().getSystematikFactory().getAlleSystematiken();
    systematiken.setSortierung(SystematikListe.alphabetischeSortierung);
    spezialisiertFeld.setDaten(systematiken);
    
    if (currentSystematik != null) {
      currentSystematik.reload();
      this.setSystematik(currentSystematik);            
    }
  }

  /**
   * Liefert die aktuell angezeigte Systematik
   */
  public Systematik getSystematik() {
    return currentSystematik;
  }

  /**
   * Speichert die gemachten �nderungen an der Systematik, falls dies m�glich ist. Ist
   * dies nicht m�glich, weil bspw. nicht alle Daten angegeben sind, wird eine
   * entsprechende Fehlermeldung angezeigt.
   *
   * @return <code>true</code> gdw die �nderungen gespeichert werden konnten
   */
  public boolean saveChanges() {
    try {
      currentSystematik.setName(nameFeld.getText());
      currentSystematik.setBeschreibung(beschreibungFeld.getText());
      currentSystematik.setDirekteObersystematik((Systematik) spezialisiertFeld.getSelectedItem());
      currentSystematik.save();
      return true;

    } catch (UnvollstaendigeDatenException e) {
      JOptionPane.showMessageDialog(hauptFenster, "Die Systematik konnte nicht "+
        "gespeichert\nwerden, da nicht alle n�tigen Daten eingegeben wurden!"+
        "\nEs muss mindestens der Name der Systematik angegeben "+
        "werden.", "Unvollst�ndige Daten!",
        JOptionPane.ERROR_MESSAGE);
    } catch (UnpassendeObersystematikException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(), 
          "Unpassende Obersystematik!",
          JOptionPane.ERROR_MESSAGE);
    }
    return false;
  }

  /**
   * Verwirft die aktuellen �nderungen. Dies kann eventuell nicht m�glich sein.
   *
   * @return <code>true</code> gdw die Aenderungen rueckgaengig
   *   gemacht werden konnten.
   */
  public boolean aenderungenVerwerfen() {
    try {
      if (oldSystematik != null) oldSystematik.reload();
      setSystematik(oldSystematik);
      setVeraenderbar(false);
    } catch (DatenNichtGefundenException e) {
      return false;
    }
    return true;
  }

  public void addSpezialisiertListe(Systematik systematik) {
    ((SortiertMutableComboBoxModel) spezialisiertFeld.getModel()).
      addElement(systematik);
  }

  public void removeSpezialisiertListe(Systematik systematik) {
    ((SortiertMutableComboBoxModel) spezialisiertFeld.getModel()).
      removeElement(systematik);
  } 
}