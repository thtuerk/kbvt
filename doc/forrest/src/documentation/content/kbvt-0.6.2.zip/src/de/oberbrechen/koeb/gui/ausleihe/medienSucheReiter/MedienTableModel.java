/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.medienSucheReiter;

import java.text.SimpleDateFormat;
import java.util.Collection;

import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Medien.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class MedienTableModel extends AbstractTableModel {

  private SimpleDateFormat datumsformat = new SimpleDateFormat("dd.MM.yyyy");

  MedienListe daten;
  
	public MedienTableModel() {
    daten = new MedienListe();
	}
  
  public void setDaten(Collection daten) {
    this.daten.clear();
    this.daten.addAllNoDuplicate(daten);
    fireTableDataChanged();
  }

	public int getColumnCount() {
    return 4;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Nr";
    if (columnIndex == 1) return "Titel";
    if (columnIndex == 2) return "Autor";
    if (columnIndex == 3) return "Einstellungsdatum";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    Medium gewaehltesMedium = (Medium) daten.get(rowIndex);
    switch (columnIndex) {
      case 0:
        return gewaehltesMedium.getMedienNr();
      case 1:
        return gewaehltesMedium.getTitel();
      case 2:
        return gewaehltesMedium.getAutor();
      case 3:
        return gewaehltesMedium.getEinstellungsdatum() == null?"-":
               datumsformat.format(gewaehltesMedium.getEinstellungsdatum());
    }
    return "nicht definierte Spalte";
  }
  
  public int getDefaultColumnWidth(int columnIndex) {
    switch (columnIndex) {
      case 0: return 85;
      case 1: return 300;
      case 2: return 170;
      case 3: return 100;
    }

    return 500;
  }    

	protected void sortiereNachSpalte(int spalte, boolean umgekehrteSortierung) {
    if (spalte == 0) daten.setSortierung(
      MedienListe.MedienNummerSortierung, umgekehrteSortierung);
    else if (spalte == 1) daten.setSortierung(
      MedienListe.TitelAutorSortierung, umgekehrteSortierung);
    else if (spalte == 2) daten.setSortierung(
      MedienListe.AutorTitelSortierung, umgekehrteSortierung);
    else if (spalte == 3) daten.setSortierung(
      MedienListe.EinstellungsdatumSortierung, umgekehrteSortierung);
    else return;
	}

  public int getRowCount() {
    return daten.size();
  }

  public Medium get(int row) {
    return (Medium) daten.get(row);
  }
}
