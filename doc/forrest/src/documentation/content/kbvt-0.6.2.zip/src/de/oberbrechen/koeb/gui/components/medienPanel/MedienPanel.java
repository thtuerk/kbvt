/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.medienPanel;

import java.awt.*;
import java.awt.event.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.ISBN;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.einstellungen.Buecherei;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.components.SortiertComboBox;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.ListenAuswahlPanel;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.systematikListenAuswahlPanel.SystematikListenAuswahlPanel;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse stellt ein Panel dar, mit dem Medien-Daten 
 * angezeigt und bearbeitet werden k�nnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.24 $
 */

public class MedienPanel extends JPanel {

  private boolean istVeraenderbar;
  private String altesAusBestandEntferntDatum;
  private JFrame hauptFenster;
  private Medium currentMedium;
  private Medium oldMedium;

  //Datumsformatierung
  private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

  // die Datenfelder
  private JTextField nrFeld;
  private JTextField titelFeld;
  private JTextField autorFeld;
  private SortiertComboBox medientypFeld;
  private JTextField eingestelltSeitFeld;
  private JTextField medienAnzahlFeld;
  private JTextField ausBestandEntferntFeld;
  private JTextField isbnFeld;
  private JTextArea beschreibungFeld;
  private JButton ausBestandEntfernenButton;
  private JButton medienNrButton;
  private JButton eanButton;
  private JTable eanTable;
  private EANTableModel eanTableModel;
  private ListenAuswahlPanel listenAuswahlPanel;
  
  /**
   * Zeigt das �bergebene Medium an.
   * @param medium das anzuzeigende Medium
   */
  public void setMedium(Medium medium) {
    currentMedium = medium;
    if (medium == null) {
      nrFeld.setText(null);
      medientypFeld.setSelectedItem(null);
      titelFeld.setText(null);
      autorFeld.setText(null);
      eingestelltSeitFeld.setText(null);
      ausBestandEntferntFeld.setText(null);
      medienAnzahlFeld.setText(null);
      isbnFeld.setText(null);
      beschreibungFeld.setText(null);
      eanTableModel.setDaten(null);

      listenAuswahlPanel.setAuswahl(new SystematikListe());
      altesAusBestandEntferntDatum = null;
      return;
    }


    if (!medium.istNeu()) {
      oldMedium = medium;
    }

    nrFeld.setText(medium.getMedienNr());
    medientypFeld.setSelectedItem(medium.getMedientyp());
    titelFeld.setText(medium.getTitel());
    autorFeld.setText(medium.getAutor());

    if (medium.getEinstellungsdatum() != null) {
      eingestelltSeitFeld.setText(dateFormat.format(medium.getEinstellungsdatum()));
    } else {
      eingestelltSeitFeld.setText("");
    }

    if (medium.getEntfernungsdatum() != null) {
      ausBestandEntferntFeld.setText(dateFormat.format(medium.getEntfernungsdatum()));
    } else {
      ausBestandEntferntFeld.setText("");
    }

    medienAnzahlFeld.setText(Integer.toString(medium.getMedienAnzahl()));
    isbnFeld.setText(null);
    if (medium.getISBN() != null) isbnFeld.setText(medium.getISBN().getISBN());
    beschreibungFeld.setText(medium.getBeschreibung());

    listenAuswahlPanel.setAuswahl(medium.getSystematiken());
    eanTableModel.setDaten(medium.getEANs());
    altesAusBestandEntferntDatum = null;
    initButtons();
  }
  
  /**
   * L�scht das aktuelle Medium nach einer Sicherheitsabfrage.
   * @return <code>true</code> gdw das L�schen erfolgreich war
   */
  public boolean loescheMedium() {
    try {
      int erg = JOptionPane.showConfirmDialog(hauptFenster, "Soll das Medium "+
        currentMedium.getTitel() + " ("+currentMedium.getMedienNr()+") " +
        "wirklich gel�scht werden?\nEs ist meist sinnvoller, das Medium nur\n" +
        "aus dem Bestand zu entfernen!",
        "Medium l�schen?", JOptionPane.YES_NO_OPTION);
      if (erg != JOptionPane.YES_OPTION) return false;

      currentMedium.loesche();
    } catch (DatenbankInkonsistenzException e) {
      ErrorHandler.getInstance().handleException(e,
        "Beim L�schen des Mediums wurde eine Datenbank-Inkonsistenz bemerkt.", 
        false);
      return false;
    }
    return true;
  }

  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  public void setVeraenderbar(boolean veraenderbar) {
    //Eingabefelder
    this.istVeraenderbar = veraenderbar;
    nrFeld.setEditable(veraenderbar);
    autorFeld.setEditable(veraenderbar);
    titelFeld.setEditable(veraenderbar);
    medienAnzahlFeld.setEditable(veraenderbar);
    medientypFeld.setEnabled(veraenderbar);
    eingestelltSeitFeld.setEditable(veraenderbar);
    ausBestandEntferntFeld.setEditable(veraenderbar);
    isbnFeld.setEditable(veraenderbar);
    beschreibungFeld.setEditable(veraenderbar);
    
    listenAuswahlPanel.setVeraenderbar(veraenderbar);
    eanTable.setEnabled(veraenderbar);
    eanTableModel.showNewItem(veraenderbar);
    
    if (veraenderbar) {
      nrFeld.grabFocus();      
    }
    
    initButtons();
  }


  /**
   * Formatiert ein Datum als String.
   * @param datum das zu formatierende Datum
   */
  private String formatDatum(Date datum) {
    if (datum != null) {
      return(dateFormat.format(datum));
    } else {
      return null;
    }
  }

  /**
   * Erzeugt ein MedienPanel, das im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem das Panel geh�rt
   */
  public MedienPanel(JFrame hauptFenster) {
    this.hauptFenster=hauptFenster;
    currentMedium = null;
    oldMedium = null;
    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void initButtons() {
    if (ausBestandEntferntFeld.getText() == null || ausBestandEntferntFeld.getText().equals("")) {
      ausBestandEntfernenButton.setText("Entfernen");
    } else {
      ausBestandEntfernenButton.setText("Einstellen");
    }
    ausBestandEntfernenButton.setEnabled(istVeraenderbar);
        
    eanButton.setEnabled(false);      
    if (istVeraenderbar) {
      String isbnString = isbnFeld.getText();
      if (isbnString != null && !isbnString.equals("")) {
        ISBN isbn = new ISBN(isbnString);
        if (!eanTableModel.getDaten().contains(isbn.convertToEAN()))
          eanButton.setEnabled(true);
      }
    } 
        
    if (istVeraenderbar && 
      eingestelltSeitFeld.getText() != null && 
      !eingestelltSeitFeld.getText().equals("") && 
      medientypFeld.getSelectedItem() != null &&
      (nrFeld.getText() == null || nrFeld.getText().equals(""))) { 
        medienNrButton.setEnabled(true);
    } else {
      medienNrButton.setEnabled(false);
    }    
  }
  
  /**
   * Entfernt das aktuelle Medium aus dem Bestand. Dazu wird
   * das aktuelle Datum im Feld aus_Bestand_entfernt eingetragen.
   */
  void entferneAusBestand() {
    if (altesAusBestandEntferntDatum == null) {
      ausBestandEntferntFeld.setText(dateFormat.format(new Date()));
    } else {
      ausBestandEntferntFeld.setText(altesAusBestandEntferntDatum);  
    }
    initButtons();
  }

  /**
   * Stellt das aktuelle Medium wieder ein.
   */
  void stelleWiederInBestandEin() {
    if (ausBestandEntferntFeld.getText() == null || ausBestandEntferntFeld.getText().equals("")) {
      altesAusBestandEntferntDatum = null;
    } else {
      altesAusBestandEntferntDatum = ausBestandEntferntFeld.getText();
    }
    ausBestandEntferntFeld.setText(null);
    initButtons();
  }

  // erzeugt die GUI
  void jbInit() throws Exception {
    listenAuswahlPanel = new SystematikListenAuswahlPanel();
    listenAuswahlPanel.setMinimumSize(new Dimension(200, 50));
    
    //Alle wichtigen Objeke initialisieren
    nrFeld = new JTextField();
    titelFeld = new JTextField();
    autorFeld = new JTextField();
    medientypFeld = new SortiertComboBox();
    eingestelltSeitFeld = new JTextField();
    medienAnzahlFeld = new JTextField();
    ausBestandEntferntFeld = new JTextField();
    isbnFeld = new JTextField();
    beschreibungFeld = new JTextArea();

    ausBestandEntfernenButton = new JButton("Entfernen");
    medienNrButton = new JButton("Vorschlagen");
    eanButton = new JButton("EAN");
    
    //EANTablelle
    eanTableModel = new EANTableModel(hauptFenster);
    eanTable = new JTable(eanTableModel);
    eanTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    eanTable.registerKeyboardAction( new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeEAN();
      }}, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), JComponent.WHEN_FOCUSED);
    
    JScrollPane eanScrollPane = new JScrollPane();
    eanScrollPane.setMinimumSize(new Dimension(100, 40));
    eanScrollPane.setPreferredSize(new Dimension(100, 40));
    eanScrollPane.getViewport().add(eanTable, null);
    
    //Labels
    JLabel jLabel1 = new JLabel("Medien-Nr:");
    JLabel jLabel2 = new JLabel("Titel:");
    JLabel jLabel4 = new JLabel("Autor:");
    JLabel jLabel6 = new JLabel("Medientyp:");
    JLabel jLabel7 = new JLabel("eingestellt seit:");
    JLabel jLabel8 = new JLabel("Medienanzahl:");
    JLabel jLabel11 = new JLabel("aus Bestand entfernt:");
    JLabel jLabel12 = new JLabel("ISBN:");
    JLabel jLabel15 = new JLabel("Beschreibung:");

    autorFeld.setNextFocusableComponent(beschreibungFeld);


    //Format-Checks
    eingestelltSeitFeld.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        checkDatum(eingestelltSeitFeld);
        initButtons();
      }
    });
    ausBestandEntferntFeld.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        checkDatum(ausBestandEntferntFeld);
        initButtons();
      }
    });
    medienAnzahlFeld.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        checkMedienAnzahl();
      }
    });
    isbnFeld.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        checkISBN();
      }
    });
    nrFeld.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        initButtons();
      }
    });
    medientypFeld.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        initButtons();
      }
    });
    
    
    //Buttons
    ausBestandEntfernenButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (ausBestandEntferntFeld.getText() == null || ausBestandEntferntFeld.getText().equals("")) {
          entferneAusBestand();
        } else {
          stelleWiederInBestandEin();
        }
      }
    });
    medienNrButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        medienNrZuweisen();
      }
    });        
    eanButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        eanAusISBNerstellen();
      }
    });        
    
    //Formatierungen       
    this.setLayout(new GridBagLayout());
    nrFeld.setOpaque(true);
    MedientypFactory medientypFactory = 
      Datenbank.getInstance().getMedientypFactory();
    medientypFeld.setDaten(medientypFactory.getAlleMedientypen());

    int buttonWidth = Math.max(eanButton.getPreferredSize().width,
      Math.max(medienNrButton.getPreferredSize().width,
      ausBestandEntfernenButton.getPreferredSize().width));
    int buttonHeight = isbnFeld.getPreferredSize().height;
    Dimension buttonDimension = new Dimension(buttonWidth, buttonHeight);
    JComponentFormatierer.setDimension(eanButton, buttonDimension);
    JComponentFormatierer.setDimension(medienNrButton, buttonDimension);
    JComponentFormatierer.setDimension(ausBestandEntfernenButton, buttonDimension);
    JComponentFormatierer.setDimension(medientypFeld, buttonDimension);

    beschreibungFeld.setLineWrap(true);
    beschreibungFeld.setWrapStyleWord(true);
    beschreibungFeld.setNextFocusableComponent(listenAuswahlPanel);
    JScrollPane beschreibungScrollPane = new JScrollPane();
    beschreibungScrollPane.setMinimumSize(new Dimension(0, 40));
    beschreibungScrollPane.setPreferredSize(new Dimension(0, 40));
    beschreibungScrollPane.getViewport().add(beschreibungFeld, null);

    JSplitPane systematikEANSplitPane = new JSplitPane();
    systematikEANSplitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    systematikEANSplitPane.setBorder(BorderFactory.createEmptyBorder());
    listenAuswahlPanel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
    eanScrollPane.setBorder(BorderFactory.createCompoundBorder(
       BorderFactory.createEmptyBorder(0,10,0,0), eanScrollPane.getBorder()));
    systematikEANSplitPane.add(listenAuswahlPanel, JSplitPane.LEFT);
    systematikEANSplitPane.add(eanScrollPane, JSplitPane.RIGHT);
    systematikEANSplitPane.setResizeWeight(0.8);
    
    
    this.add(jLabel1,           new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    this.add(nrFeld,                   new GridBagConstraints(1, 0, 1, 1, 2.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel6,              new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 20, 5, 10), 0, 0));
    this.add(medientypFeld,              new GridBagConstraints(4, 0, 2, 1, 2.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel2,           new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    this.add(titelFeld,              new GridBagConstraints(1, 1, 5, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(isbnFeld,                new GridBagConstraints(4, 4, 1, 1, 1.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(eanButton,          new GridBagConstraints(5, 4, 1, 1, 0.0, 0.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 0), 0, 0));
    this.add(jLabel4,           new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel8,              new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    this.add(autorFeld,              new GridBagConstraints(1, 2, 5, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel7,            new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 10), 0, 0));
    this.add(eingestelltSeitFeld,                new GridBagConstraints(1, 3, 2, 1, 2.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel11,                 new GridBagConstraints(3, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 20, 5, 10), 0, 0));
    this.add(ausBestandEntferntFeld,               new GridBagConstraints(4, 3, 1, 1, 1.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(medienAnzahlFeld,                new GridBagConstraints(1, 4, 2, 1, 2.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    this.add(jLabel12,                new GridBagConstraints(3, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 20, 5, 0), 0, 0));
    this.add(jLabel15,               new GridBagConstraints(0, 5, 1, 1, 0.0, 1.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    this.add(beschreibungScrollPane,                new GridBagConstraints(1, 5, 5, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    this.add(systematikEANSplitPane,           new GridBagConstraints(0, 6, 6, 1, 0.0, 15.0
        ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(15, 0, 0, 0), 0, 0));
    this.add(ausBestandEntfernenButton,          new GridBagConstraints(5, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 0), 0, 0));
    this.add(medienNrButton,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 0), 0, 0));
  }

  /**
   * Weist dem Medium eine neue Mediennr zu.
   */
  void medienNrZuweisen() {
    try {
      nrFeld.setText(Buecherei.getInstance().getStandardMedienNr(
        (Medientyp) medientypFeld.getSelectedItem(), 
        (Date) dateFormat.parse(eingestelltSeitFeld.getText())));
    } catch (ParseException e) {
      //darf nie auftreten, da beim �ndern der Inhalts von eingestelltSeitFeld
      //Format gecheckt wird
      e.printStackTrace();
      System.exit(1);
    }
    initButtons();
  }

  /**
   * L�d das Medium neu aus der Datenbank
   */
  public void aktualisiere() {
    if (currentMedium != null) {
      currentMedium.reload();
      this.setMedium(currentMedium);
    }
  }

  /**
   * �berpr�ft, ob der �bergebene String wirklich ein g�ltiges
   * Datum repr�sentiert. Ist dies nicht der Fall wird eine Fehlermeldung
   * angezeigt
   *
   * @param eintrag das Feld, in dem der zu testende Eintrag steht
   * @return das gepaarste Datum, falls das Anmeldedatum OK ist; null sonst
   */
  Date checkDatum(JTextField eintrag) {
    String datumString = eintrag.getText();
    if (datumString == null || datumString.equals("")) return null;

    Date neuDatum;
    try {
      neuDatum = dateFormat.parse(datumString);
    } catch (ParseException e) {
      neuDatum = null;
      eintrag.setText(null);
      JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
        datumString + "' kann\nnicht als Datum interpretiert\n"+
        "werden!\n\nDatumseingaben m�ssen in der\nForm 'tt.mm.jjjj' erfolgen.",
        "Ung�ltiges Datum!",
        JOptionPane.ERROR_MESSAGE);
    }
    eintrag.setText(formatDatum(neuDatum));
    return neuDatum;
  }


  void checkMedienAnzahl() {
    String anzahlString = medienAnzahlFeld.getText();
    
    boolean anzahlOK = true;
    if (anzahlString == null || anzahlString.equals("")) anzahlOK = false;
    
    if (anzahlOK) {
      int anzahl = 1;
      try {
        anzahl = Integer.parseInt(anzahlString);
        if (anzahl <= 0) anzahlOK = false;
      } catch (NumberFormatException e) {
        anzahlOK = false;
      }
    }

    if (!anzahlOK) {
      medienAnzahlFeld.setText("1");
      JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
        anzahlString + "' kann\nnicht als positive Zahl interpretiert\n"+
        "werden!",
        "Ung�ltige Medienanzahl!",
        JOptionPane.ERROR_MESSAGE);
    }
  }

  void checkISBN() {
    String isbn = isbnFeld.getText();
    if (isbn == null || isbn.equals("")) return;
    
    String neuISBN = ISBN.checkISBN(isbn);
    if (neuISBN == null) {
      isbnFeld.setText(null);
      JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
        isbn + "' kann\nnicht als ISBN interpretiert\n"+
        "werden!",
        "Ung�ltige ISBN!",
        JOptionPane.ERROR_MESSAGE);
    } else {
      isbnFeld.setText(neuISBN);      
    }
    initButtons();
  }

  /**
   * Liefert das aktuell angezeigte Medium
   */
  public Medium getMedium() {
    return currentMedium;
  }

  /**
   * Speichert die gemachten �nderungen am Benutzer, falls dies m�glich ist. Ist
   * dies nicht m�glich, weil bspw. nicht alle Daten angegeben sind, wird eine
   * entsprechende Fehlermeldung angezeigt.
   *
   * @return <code>true</code> gdw die �nderungen gespeichert werden konnten
   */
  public boolean saveChanges() {
    if (currentMedium == null) throw new NullPointerException();
    
    try {
      currentMedium.setMediennr(nrFeld.getText());
      currentMedium.setAutor(autorFeld.getText());
      currentMedium.setTitel(titelFeld.getText());
      currentMedium.setMedientyp((Medientyp) medientypFeld.getSelectedItem());
      currentMedium.setBeschreibung(beschreibungFeld.getText());
      currentMedium.setMedienAnzahl(Integer.parseInt(medienAnzahlFeld.getText()));
      currentMedium.setEANs(eanTableModel.getDaten());
      
      if (isbnFeld.getText() != null && !isbnFeld.getText().equals("")) {
        ISBN isbn = new ISBN(isbnFeld.getText());
        currentMedium.setISBN(isbn);
      } else {
        currentMedium.setISBN(null);
      }
            
      if (eingestelltSeitFeld.getText() != null && !eingestelltSeitFeld.getText().equals("")) {
        currentMedium.setEinstellungsdatum(dateFormat.parse(eingestelltSeitFeld.getText()));
      } else {
        currentMedium.setEinstellungsdatum(null);        
      }
      
      if (ausBestandEntferntFeld.getText() != null && !ausBestandEntferntFeld.getText().equals("")) {
        currentMedium.setEntfernungsdatum(dateFormat.parse(ausBestandEntferntFeld.getText()));
      } else {
        currentMedium.setEntfernungsdatum(null);
      }
      
      currentMedium.setSystematiken(
        (SystematikListe) listenAuswahlPanel.getAuswahl());      
      currentMedium.save();
      return true;
    } catch (MedienNrSchonVergebenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Ung�ltige Mediennr.!",
        JOptionPane.ERROR_MESSAGE);
    } catch (EANSchonVergebenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Ung�ltige EAN!",
        JOptionPane.ERROR_MESSAGE);
    } catch (UnvollstaendigeDatenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(), 
        "Unvollst�ndige Daten!",
        JOptionPane.ERROR_MESSAGE);
    } catch (ParseException e) {
      //Sollte nie auftreten
      e.printStackTrace();
      System.exit(1);
    }
    return false;
  }

  /**
   * Verwirft die aktuellen �nderungen. Dies kann eventuell nicht m�glich sein.
   *
   * @return <code>true</code> gdw die Aenderungen rueckgaengig
   *   gemacht werden konnten.
   */
  public boolean aenderungenVerwerfen() {
    try {
      if (oldMedium != null) oldMedium.reload();
      setMedium(oldMedium);
      setVeraenderbar(false);
    } catch (DatenNichtGefundenException e) {
      return false;
    }
    return true;
  }
  
  /**
   * L�scht die in der Tabelle markierte EAN 
   */
  protected void removeEAN() {
    int selectedRow = eanTable.getSelectedRow();
    if (selectedRow != -1) { 
      eanTableModel.remove(selectedRow);  
      initButtons();
    }
  }
  
  private void eanAusISBNerstellen() {  
    String isbnString = isbnFeld.getText();
    ISBN isbn = new ISBN(isbnString); 
    eanTableModel.add(isbn.convertToEAN());
    initButtons();
  }
}