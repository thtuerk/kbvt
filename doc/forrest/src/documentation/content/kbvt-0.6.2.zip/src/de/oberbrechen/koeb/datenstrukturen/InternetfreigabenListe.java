/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import de.oberbrechen.koeb.datenbankzugriff.*;

import java.util.Comparator;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von Internetfreigaben. Eine 
* Internetfreigabe
* ist eindeutig �ber ihre Nummer identifiziert und wird nur einmal in
* die Liste aufgenommen. 
* 
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $
*/

public class InternetfreigabenListe extends Liste {

  /**
   * InternetFreigaben werden zuerst nach dem Datum, dann nach dem Client
   * und schlie�lich nach dem Benutzer sortiert.
   * Autor ihres Mediums sortiert
   */
  public static final int DatumSortierung = 2;

  protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;

    switch (sortierung) {
      case DatumSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            Internetfreigabe internetfreigabeA = (Internetfreigabe) a;
            Internetfreigabe internetfreigabeB = (Internetfreigabe) b;            
            
            int erg = internetfreigabeA.getStartZeitpunkt().compareTo(
                        internetfreigabeB.getStartZeitpunkt());
            if (erg != 0) return erg;
            erg = nullCompare(internetfreigabeA.getClient().getName(),
                              internetfreigabeB.getClient().getName());
            if (erg != 0) return erg;
            erg = nullCompare(internetfreigabeA.getBenutzer().getNameFormal(),
                              internetfreigabeB.getBenutzer().getNameFormal());
            if (erg != 0) return erg;
                           
            return internetfreigabeA.getId()-internetfreigabeB.getId();
        }};
        break;
      }

      default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }
}
