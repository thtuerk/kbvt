/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTabelle;

import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfTemplate;

import de.oberbrechen.koeb.pdf.ErweitertesPdfDokument;
import de.oberbrechen.koeb.pdf.PdfDokument;
import de.oberbrechen.koeb.pdf.SeitenKopfFuss;

/**
 * Der Standard-Seitenkopf f�r jede Seite.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public class TabellenKopf implements SeitenKopfFuss{

  private final BaseFont schrift = PdfDokument.schriftFettKursiv;
  private final float schriftGroesse = 10;

  private TabellenModell tabellenModell;
  private int[] spaltenAusrichtung;
  private float maximalHoehe = 150;
  private float skalierungVertikal;

  public TabellenKopf(TabellenModell tabellenModell) {

    this.tabellenModell = tabellenModell;

    spaltenAusrichtung = new int[tabellenModell.getSpaltenAnzahl()];
    for (int i=0; i < spaltenAusrichtung.length; i++) {
      spaltenAusrichtung[i] = tabellenModell.getSpaltenAusrichtung(i+1);
    }
  }

  //Doku siehe bitte Interace
  public float getHoehe(int seitenNr) {
    float maxHoehe = 10;
    for(int i=1; i <= tabellenModell.getSpaltenAnzahl(); i++) {
      if (spaltenAusrichtung[i-1] ==
          TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL) {
        float hoehe = schrift.getWidthPoint(tabellenModell.getSpaltenName(i),
          schriftGroesse);
        if (hoehe > maxHoehe) maxHoehe = hoehe;
      }
    }

    maxHoehe+=5;
    if (maximalHoehe < maxHoehe) return maximalHoehe;
    return maxHoehe;
  }
  
  /**
   * Liefert das TabellenModell des TabellenKopfs
   * @return das TabellenModell des TabellenKopfs
   */
  public TabellenModell getTabellenModell() {
    return tabellenModell;
  }
  
  /**
   * Setzt die Maximalh�he, die der Seitenkopf einnehmen darf.
   * @param maxHoehe die maximale H�he in Points
   */
  public void setMaximalHoehe(float maxHoehe) {
    this.maximalHoehe = maxHoehe;
  }

  /**
   * Liefert die Maximalh�he, die der Seitenkopf einnehmen darf.
   * @return die Maximalh�he, die der Seitenkopf einnehmen darf
   */
  public float getMaximalHoehe() {
    return this.maximalHoehe;
  }
  
  /**
   * Gibt den Spaltentitel f�r die �bergebene Spalte
   * an der �bergebenen y-Position im �bergebenen PdfContentByte aus.
   *
   * @param spaltenNr die auszugebenende Spaltennummer
   * @param yPos die y-Position f�r die Ausgabe in Points
   * @param pdfDokument das Dokument in dem ausgegeben werden soll
   */
  protected void schreibeSpalte(int spaltenNr, float yPos,
    ErweitertesPdfDokument pdfDokument,
    PdfTemplate template) {

    String text = tabellenModell.getSpaltenName(spaltenNr);
    if (text == null) return;

    //einige Grundlegende Paramter bestimmen
    float linkerRand = pdfDokument.getSeitenRandLinks()+
                       tabellenModell.getSpaltenPositionLinks(spaltenNr);
    float rechterRand = linkerRand + tabellenModell.getBreite(spaltenNr);
    float breite = tabellenModell.getBreite(spaltenNr);
    float mitte = (rechterRand + linkerRand) / 2;

    int ausrichtung = spaltenAusrichtung[spaltenNr - 1];
    float textBreite = schrift.getWidthPoint(text, schriftGroesse);
    float skalierung = 1;
    if (((ausrichtung == TabellenModell.SPALTEN_AUSRICHTUNG_LINKS ||
          ausrichtung == TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS ||
          ausrichtung == TabellenModell.SPALTEN_AUSRICHTUNG_ZENTRIERT) &&
          (textBreite > breite)) ||
          ausrichtung == TabellenModell.SPALTEN_AUSRICHTUNG_BLOCKSATZ) {
       skalierung = breite / textBreite;
       textBreite *= skalierung;
    }
    if (ausrichtung == TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL) {
      skalierung = skalierungVertikal;
    }

    //Text ausgeben
    template.beginText();
    template.setFontAndSize(schrift, schriftGroesse);
    template.setHorizontalScaling(skalierung*100);

    switch (ausrichtung) {
      case TabellenModell.SPALTEN_AUSRICHTUNG_BLOCKSATZ:
      case TabellenModell.SPALTEN_AUSRICHTUNG_LINKS:
        template.setTextMatrix(linkerRand, yPos);
        template.showText(text);
        break;
      case TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS:
        template.setTextMatrix(rechterRand - textBreite, yPos);
        template.showText(text);
        break;
      case TabellenModell.SPALTEN_AUSRICHTUNG_ZENTRIERT:
        template.setTextMatrix(mitte - textBreite / 2, yPos);
        template.showText(text);
        break;
      case TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL:
        template.setTextMatrix(0, 1, -1, 0, mitte+3, yPos);
        template.showText(text);
        break;
    }
    template.endText();
  }

  /**
   * Liefert die Breite, die der SeitenKopfFuss optimalerweise f�r die
   * �bergebene Spalte ben�tigt.
   *
   * @param spaltenNr die Nummer der Spalte, deren optimale Breite geliefert
   *   werden soll
   * @return die optimale Breite der Spalte
   */
  public float getBenoetigeSpaltenBreite(int spaltenNr) {
    if (spaltenNr < 1 || spaltenNr > spaltenAusrichtung.length)
      throw new IllegalArgumentException("Es existiert keine Spalte mit der "+
                                     "Nummer "+spaltenNr+"!");
    if (spaltenAusrichtung[spaltenNr - 1] ==
        TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL) return 10;

    String text = tabellenModell.getSpaltenName(spaltenNr);
    if (text == null) return 0;
    return schrift.getWidthPoint(text, 10);
  }

  //Doku siehe bitte Interface
  public PdfTemplate getSeitenKopfFuss(
    ErweitertesPdfDokument pdfDokument, 
    PdfContentByte pdf, int seitenNr) {
      
    float hoehe = this.getHoehe(seitenNr);
    PdfTemplate template = pdf.createTemplate(pdfDokument.getSeitenBreite(),
      hoehe);      

    //Vertikale Skalierung bestimmen
    skalierungVertikal = 1;
    for (int i=0; i < tabellenModell.getSpaltenAnzahl(); i++) {
      if (spaltenAusrichtung[i] == TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL){
        float textBreite=schrift.getWidthPoint(
          tabellenModell.getSpaltenName(i+1), 10);
        if (textBreite*skalierungVertikal + 5 > maximalHoehe) {
          skalierungVertikal = (maximalHoehe-5) / textBreite;
        }
      }
    }

    //Beschriftungen
    for (int i=1; i <= tabellenModell.getSpaltenAnzahl(); i++) {
      schreibeSpalte(i, 5, pdfDokument, template);
    }

    //zeichne Trennlinie
    float linkerRand = pdfDokument.getSeitenRandLinks();
    float rechterRand = pdfDokument.getSeitenBreite()-
                        pdfDokument.getSeitenRandRechts();

    template.moveTo(linkerRand, 0);
    template.lineTo(rechterRand, 0);
    template.stroke();
    
    return template;
  }

  /**
   * Setzt die Ausrichtung der �bergebenen Spalte. Die verf�gbaren Ausrichtungen
   * sind als �ffentliche Konstanten der Klasse SpaltenModell ansprechbar.
   *
   * @param spaltenNr die Nummer der Spalte, deren Ausrichtung gesetzt werden
   *   soll
   * @param int ausrichtung
   * @see SpaltenModell
   */
  public void setSpaltenAusrichtung(int spaltenNr, int ausrichtung) {
    if (spaltenNr < 1 || spaltenNr > spaltenAusrichtung.length)
      throw new IllegalArgumentException("Es existiert keine Spalte mit der "+
                                     "Nummer "+spaltenNr+"!");
    spaltenAusrichtung[spaltenNr - 1] = ausrichtung;
  }

  //Doku siehe bitte Interface
  public void finalisiere(int gesamtseitenAnzahl) {
  }
}