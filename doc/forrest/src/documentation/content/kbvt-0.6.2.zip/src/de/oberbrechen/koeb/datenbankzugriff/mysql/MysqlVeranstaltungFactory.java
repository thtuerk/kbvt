/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlVeranstaltungFactory extends AbstractVeranstaltungFactory {
    
  public Veranstaltung erstelleNeu() {
    return new MysqlVeranstaltung();
	}

	public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
    return new MysqlVeranstaltung(id);
	}

	public VeranstaltungenListe getVeranstaltungen(
	    Veranstaltungsgruppe veranstaltungsgruppe) {
		return getVeranstaltungen(veranstaltungsgruppe, false);
	}
	
	private VeranstaltungenListe getVeranstaltungen(
	  Veranstaltungsgruppe veranstaltungsgruppe, 
		boolean anmeldung_erforderlich) {
		String sqlStatement = "select * from veranstaltung " +
				"where veranstaltungsgruppeid = "+veranstaltungsgruppe.getId();
			if (anmeldung_erforderlich)
			  sqlStatement = sqlStatement + " and anmeldung_erforderlich > 0";
		return ladeAusVeranstaltungTabelle(sqlStatement);
	}

  private VeranstaltungenListe ladeAusVeranstaltungTabelle(
      String sqlStatement) {
    VeranstaltungenListe liste = new VeranstaltungenListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      
      ResultSet result = (ResultSet) statement.executeQuery(sqlStatement);
      while (result.next()) {
        
        int id = result.getInt("id");
        Veranstaltung veranstaltung = (Veranstaltung) ladeAusCache(id);
        
        if (veranstaltung == null) { 
          veranstaltung = new MysqlVeranstaltung(result);
          cache.put(new Integer(veranstaltung.getId()), veranstaltung);
        }
        
        liste.addNoDuplicate(veranstaltung);
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Veranstaltungenliste!\n"+sqlStatement, true);
    }

    return liste;
  }
  
  public VeranstaltungenListe getVeranstaltungenMitAnmeldung(
	    Veranstaltungsgruppe veranstaltungsgruppe) {
		return getVeranstaltungen(veranstaltungsgruppe, true);
	}

  public VeranstaltungenListe getAlleVeranstaltungenInZeitraum(Zeitraum zeitraum) {
    StringBuffer sqlStament = new StringBuffer();
    sqlStament.append("select DISTINCT v.* from veranstaltung v, termin t " +
        "where (t.veranstaltungid = v.id) and (t.beginn >= '");
    sqlStament.append(MysqlDatenbank.sqldateFormat.format(zeitraum.getBeginn()));
    sqlStament.append("' AND t.beginn < '");
    sqlStament.append(MysqlDatenbank.sqldateFormat.format(zeitraum.getEnde()));
    sqlStament.append("')");
    return ladeAusVeranstaltungTabelle(sqlStament.toString());
  }
}
