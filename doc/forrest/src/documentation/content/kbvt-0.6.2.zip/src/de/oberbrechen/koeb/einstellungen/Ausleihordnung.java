/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import java.util.Date;
import java.util.Iterator;

/**
* Diese Klasse repr�sentiert eine Ausleihordnung einer B�cherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.7 $
*/

public abstract class Ausleihordnung {

  /**
   * Liefert eine Instanz der aktuell konfigurierten Ausleihordnung.
   * @return eine Instanz der aktuell konfigurierten Ausleihordnung
   */
  public static Ausleihordnung getInstance() {
    return Buecherei.getInstance().getAusleihordnung();
  }

  /**
   * Berechnet die Mahngeb�hren f�r die �bergebene Liste von Ausleihen
   * zum aktuellen Zeitpunkt
   * @param liste die AusleihenListe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public double berechneMahngebuehren(AusleihenListe liste) {
    double summe = 0;

    Iterator it = liste.iterator();
    while (it.hasNext()) {
      summe += berechneMahngebuehren((Ausleihe) it.next());
    }

    return summe;
  }
  
  /**
   * Berechnet die Mahngeb�hren f�r die uebergebene Ausleihe zum
   * aktuellen Zeitpunkt
   * @param ausleihe die Ausleihe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public double berechneMahngebuehren(Ausleihe ausleihe) {
    AusleihenListe liste = new AusleihenListe();
    liste.add(ausleihe);
    return berechneMahngebuehren(liste);
  }  
  
  /**
   * Liefert Informationen, ob und wie die �bergebene Ausleihe am 
   * �bergebenen Datum verl�ngert werden kann.
   * @param datum das Datum, an dem die Verl�ngerung get�tigt werden soll   
   * @param ausleihe die zu verlaengernde Ausleihe
	 */
  public VerlaengerungsInformationen getVerlaengerungsInformationen(
      Ausleihe ausleihe, Date datum) {
    Date von = ausleihe.getSollRueckgabedatum();
		if (von != null && datum.after(von)) von = datum;

    if (von == null)
      return new VerlaengerungsInformationen(false, "Noch nicht ausgeliehen", null, null);
      
		Date bis = getAusleihenBisDatum(ausleihe.getMedium(), von);
		return new VerlaengerungsInformationen(true, null, von, bis);    
  }

  /**
   * Bestimmt das Sollr�ckgabedatum f�r das �bergebene Medium vorausgesetzt,
   * dass es am �bergebenen Datum ausgeliehen wird.
   *
   * @param medium das Medium, das ausgeliehen werden soll
   * @param datum das Datum, ab dem das Medium ausgeliehen werden soll,
   *   null wird als das heutige Datum interpretiert
   * @return das Sollr�ckgabedatum
   */
  public abstract Date getAusleihenBisDatum(Medium medium, Date datum);
}