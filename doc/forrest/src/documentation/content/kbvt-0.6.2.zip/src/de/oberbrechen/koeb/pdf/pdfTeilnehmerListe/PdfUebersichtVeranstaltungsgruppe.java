/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltungsgruppe;
import de.oberbrechen.koeb.pdf.PdfDokument;
import de.oberbrechen.koeb.pdf.SeitenKopfFuss;
import de.oberbrechen.koeb.pdf.StandardSeitenKopfErsteSeite;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelleDokument;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

public class PdfUebersichtVeranstaltungsgruppe extends PdfDokument {

  private Veranstaltungsgruppe veranstaltungsgruppe;

  public PdfUebersichtVeranstaltungsgruppe() {
    veranstaltungsgruppe = null;
  }
  
  /**
   * Setzt die Veranstaltungsgruppe, deren Teilnehmerliste
   * angezeigt werden soll.
   *
   * @param veranstaltungsgruppe die neue Veranstaltungsgruppe
   */
  public void setVeranstaltungsgruppe(Veranstaltungsgruppe veranstaltungsgruppe) {
  	this.veranstaltungsgruppe = veranstaltungsgruppe;
  }  
  
  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter pdfWriter, Document doc) throws Exception {

    //Modell bauen
    TabellenModell modell = new PdfUebersichtVeranstaltungsgruppeTabellenModell(
        veranstaltungsgruppe);

    //Seitenkopf / -fuss bauen
		String teilnehmerAnzahl;
    int teilnehmerAnzahlInt = Datenbank.getInstance().
      getVeranstaltungsteilnahmeFactory().getTeilnehmerAnzahl(
      veranstaltungsgruppe);
		if (teilnehmerAnzahlInt == 0)
		  teilnehmerAnzahl = "keine Teilnehmer";
		else
		  teilnehmerAnzahl = teilnehmerAnzahlInt+" Teilnehmer";
		
		SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
		  veranstaltungsgruppe.getName(), null, teilnehmerAnzahl, null);

    //alles zusammenbauen
    PdfTabelle tabelle = new PdfTabelle(modell);
    PdfTabelleDokument tabelleDoc = new PdfTabelleDokument(
    	veranstaltungsgruppe.getName(),
      tabelle, seitenKopfErsteSeite, null, null, true, true);

    tabelleDoc.schreibeInDokument(pdfWriter, doc);
  }
}
