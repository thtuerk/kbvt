/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin;


import java.awt.event.*;

import javax.swing.*;

import de.oberbrechen.koeb.datenbankzugriff.Einstellung;

/**
 * Diese Klasse dient dazu String-Einstellung an eine 
 * JTextField zu binden. Initial wird dem JTextField der Wert der 
 * Einstellung zugewiesen. Bei �nderung des JTextFields wird automatisch
 * der Einstellungswert in der Datenbank aktualisiert.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */

public class JTextFieldIntEinstellungBindung 
  implements JComponentEinstellungBindung {
    
  final int standard;
  final JTextField jTextField;
  final Einstellung einstellung;  
  final JFrame hauptFenster;
    
  /**
   * Erstellt eine neue JTextFieldIntEinstellungBindung, die
   * das �bergebene JTextField an die beschriebene Einstellung 
   * bindet und als Standardwert standard verwendet.
   * @param jCheckBox
   * @param einstellung
   * @param standard
   */
  public JTextFieldIntEinstellungBindung(JFrame hauptFenster, 
    JTextField jTextField, Einstellung einstellung, 
    int standard) {

    this.hauptFenster = hauptFenster;
    this.standard = standard;
    this.jTextField = jTextField;
    this.einstellung = einstellung;

    init();
    refresh();
  }
  
  private void init() {
    final javax.swing.Timer timer = new javax.swing.Timer(500, 
      new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setzeWert(false);
      }
    });
    timer.setRepeats(false);
    
    jTextField.addKeyListener(new KeyListener() {

      public void keyTyped(KeyEvent e) {}
      public void keyReleased(KeyEvent e) {}

      public void keyPressed(KeyEvent e) {
        timer.restart();        
      }

    });
    jTextField.addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
      }
  
      public void focusLost(FocusEvent e) {
        setzeWert(true);
      }
    });
    jTextField.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        setzeWert(true);
      }    
    });
  }

  //Doku siehe bitte Interface
  public void refresh() {
    jTextField.setText(Integer.toString(einstellung.getWertInt(
      standard)));        
  }

  /**
   * Speichert den im Feld gespeicherten Wert in der Datenbank.
   * @param zeigeFehler sollen Fehler beim Speichern gemeldet oder
   *  ignoriert werden
   */
  void setzeWert(boolean zeigeFehler) {
    String value = jTextField.getText();
    try {
      int intValue = Integer.parseInt(value);
      einstellung.setWertInt(intValue);
      einstellung.save();       
    } catch (NumberFormatException e) {
      if (zeigeFehler) {
        refresh();
        JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
          value + "' kann\nnicht als positive Zahl interpretiert\n"+
          "werden!",
          "Ung�ltige Eingabe!",
          JOptionPane.ERROR_MESSAGE);
      }
    }    
    
  }
}