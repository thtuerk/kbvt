/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand;

import java.util.Date;

import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.Medientyp;
import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.einstellungen.Buecherei;

/**
 * Dieses Klasse kapselt Standardwerte, die bei der Erstellung einen neuen
 * Mediums benutzt werden.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class Standardwerte {

  public Medientyp medientyp;
  public int nr, medienanzahl;
  public String autor, titel, beschreibung;
  public boolean mediennrVorschlagen;
  public Date einstellungsDatum;
  public SystematikListe systematiken;
  
  public Standardwerte() {
    nr = 1;
    medienanzahl = 1;
    autor = null;
    titel = null;
    beschreibung = null;
    mediennrVorschlagen = false;
    einstellungsDatum = new Date();
    systematiken = new SystematikListe();
    
    medientyp = Datenbank.getInstance().
      getMedientypFactory().getMeistBenutztenMedientyp();
  }

  /**
   * Weist dem Medium die gespeicherten Standardwerte zu.
   */
  public void initialisiereMedium(Medium medium) {
    medium.setMedienAnzahl(medienanzahl);
    medium.setAutor(bestimmmeText(autor));
    medium.setTitel(bestimmmeText(titel));
    medium.setBeschreibung(bestimmmeText(beschreibung));
    medium.setEinstellungsdatum(einstellungsDatum);
    medium.setSystematiken(systematiken);
    medium.setMedientyp(medientyp);
    
    if (mediennrVorschlagen) {
      medium.setMediennr(Buecherei.getInstance().getStandardMedienNr(
          medientyp, einstellungsDatum));       
    }    
    
    nr++;
  }
  
  private String bestimmmeText(String string) {
    if (string == null) return null;
    
    
    StringBuffer erg = new StringBuffer();
    
    int i = 0;
    while (i < string.length()) {
      char currentChar = string.charAt(i);
      
      //n�chstes Zeichen einfach �bernehmen
      if (currentChar == '\\') {
        erg.append((i < string.length() - 1)?string.charAt(i+1):' ');
        i+=2;
      } else if (currentChar == '$' && i < string.length() -2 &&
          (string.charAt(i+1) == 'n' || string.charAt(i+1) == 'N') &&
          (string.charAt(i+2) == 'r' || string.charAt(i+2) == 'R')) {
        erg.append(nr);
        i+=3;
      } else {
        erg.append(currentChar);
        i++;
      }
    }
    return erg.toString();
  }
}