/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import de.oberbrechen.koeb.datenstrukturen.InternetfreigabenListe;

/**
 * Dieses Klasse stellt einige grundlegende 
 * Funktionen einer InternetfreigabeFactory bereit. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public abstract class AbstractInternetfreigabeFactory 
  extends AbstractDatenbankzugriffFactory
  implements InternetfreigabeFactory {

  private Hashtable clientCache = new Hashtable();
  private Hashtable clientTimeCache = new Hashtable();
  
  /**
   * Liefert eine unsortierte Liste aller Internetfreigaben, die im �bergebenen
   * Monat get�tigt wurden.
   * 
   * @param monat die Nr des Monats von 1 bis 12
   * @param jahr das Jahr
   */
  public InternetfreigabenListe 
    getAlleInternetFreigabenInMonat(int monat, int jahr) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(jahr, monat-1, 1);
    java.util.Date von = calendar.getTime();
    
    calendar.set(jahr, monat, 1);
    calendar.add(Calendar.DATE, -1);
    java.util.Date bis = calendar.getTime();    
    
    return getAlleInternetfreigabenInZeitraum(von, bis);
  }  

  /**
   * Das eigentliche Laden der aktuellen Freigabe aus der Datenbank
   */
  protected abstract Internetfreigabe ladeAktuelleInternetfreigabe(Client client);   

  public Internetfreigabe getAktuelleInternetfreigabe(Client client) {   
    //Ergebnisse 5 sek cachen    
    Long ladeZeitpunkt = (Long) clientTimeCache.get(client);
    if (ladeZeitpunkt == null || 
        System.currentTimeMillis()-ladeZeitpunkt.longValue() > 15000) {
      Internetfreigabe freigabe = ladeAktuelleInternetfreigabe(client);
      ladeZeitpunkt = new Long(System.currentTimeMillis());
      entferneAusClientCache(client);
      if (freigabe != null) {
        clientCache.put(client, freigabe);
        clientTimeCache.put(client, ladeZeitpunkt);
      }
      return freigabe;
    } else {
      return (Internetfreigabe) clientCache.get(client);
    }
  }
  
  protected void entferneAusClientCache(Client client) {
    clientCache.remove(client);
    clientTimeCache.remove(client);
  }  
  
  public boolean istInternetzugangFreigegeben(Client client) {
    Internetfreigabe aktuelleFreigabe = 
      getAktuelleInternetfreigabe(client);
		if (aktuelleFreigabe == null) return false;
    
    return aktuelleFreigabe.istFreigegeben();
	}

  public Internetfreigabe freigeben(
      Benutzer benutzer, Client client, Mitarbeiter mitarbeiter) {
    return freigeben(benutzer, client, mitarbeiter, new Date());
  }

  public Internetfreigabe freigeben(Benutzer benutzer, Client client) {
		return freigeben(benutzer, client, Datenbank.getInstance().
		    getMitarbeiterFactory().getAktuellenMitarbeiter(), new Date());
  }
}