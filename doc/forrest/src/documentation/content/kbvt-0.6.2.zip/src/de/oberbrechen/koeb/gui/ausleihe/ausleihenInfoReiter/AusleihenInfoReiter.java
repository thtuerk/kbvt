/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.ausleihenInfoReiter;

import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.gui.ausleihe.*;
import de.oberbrechen.koeb.gui.components.medienDetails.*;
import de.oberbrechen.koeb.gui.framework.*;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;

/**
 * Diese Klasse repr�sentiert den Reiter, der Informationen �ber ein Medium
 * erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.8 $
 */

public class AusleihenInfoReiter extends JPanel implements AusleiheMainReiter {

	Main hauptFenster;
	MedienDetailsPanel mediumDetailsPanel;
	AusleiheTableModel ausleihen;
	JTable ausleihenTabelle;
  AusleiheFactory ausleiheFactory;

	public AusleihenInfoReiter(Main parentFrame) {
		hauptFenster = parentFrame;
    ausleiheFactory = Datenbank.getInstance().getAusleiheFactory();
		try {
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		aktualisiere();
	}

	private void jbInit() throws Exception {
		//Ausleihen-Tabelle
		JScrollPane ausleihenScrollPane = new JScrollPane();
		ausleihenScrollPane.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createEmptyBorder(10, 10, 10, 10),
				BorderFactory.createEtchedBorder(
					Color.white,
					new Color(148, 145, 140))));
		JComponentFormatierer.setDimension(
			ausleihenScrollPane,
			new Dimension(100, 40));
		ausleihenScrollPane.setPreferredSize(new Dimension(500, 40));
		ausleihenTabelle = new JTable();
		ausleihen = new AusleiheTableModel();
		ausleihenTabelle.setModel(ausleihen);
		ausleihenScrollPane.getViewport().add(ausleihenTabelle);

		ausleihenTabelle.getTableHeader().addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int spalteView =
					ausleihenTabelle.getColumnModel().getColumnIndexAtX(e.getX());
				int spalte = ausleihenTabelle.convertColumnIndexToModel(spalteView);

				boolean umgekehrteSortierung =
					(e.getModifiers() & InputEvent.SHIFT_MASK) != 0;
				if (spalte == 0)
					ausleihen.getDaten().setSortierung(
						AusleihenListe.MedienNrSortierung,
						umgekehrteSortierung);
				if (spalte == 1)
					ausleihen.getDaten().setSortierung(
						AusleihenListe.MedienTitelSortierung,
						umgekehrteSortierung);
				if (spalte == 2 || spalte == 3)
					ausleihen.getDaten().setSortierung(
						AusleihenListe.AusleihdatumSortierung,
						umgekehrteSortierung);
			}
		});
		ausleihenTabelle
			.getSelectionModel()
			.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				int gewaehlteReihe = ausleihenTabelle.getSelectedRow();
				if (gewaehlteReihe != -1) {
					Ausleihe gewaehlteAusleihe = ausleihen.getAusleihe(gewaehlteReihe);
					mediumDetailsPanel.setMedium(gewaehlteAusleihe.getMedium());
				} else {
					mediumDetailsPanel.setMedium(null);
				}
			}
		});

		mediumDetailsPanel = new MedienDetailsPanel();
		mediumDetailsPanel.setVeraenderbar(false);
		mediumDetailsPanel.setBorder(
			BorderFactory.createEmptyBorder(10, 10, 10, 10));

		//Splitpanel
		JSplitPane jSplitPane1 = new JSplitPane();
		jSplitPane1.setBorder(BorderFactory.createEmptyBorder());
		jSplitPane1.add(ausleihenScrollPane, JSplitPane.LEFT);
		jSplitPane1.add(mediumDetailsPanel, JSplitPane.RIGHT);

		//alles zusammenbauen
		this.setLayout(new BorderLayout());
		this.add(jSplitPane1, BorderLayout.CENTER);
	}

	//Doku siehe bitte Interface
	public void aktualisiere() {
		this.refresh();
		mediumDetailsPanel.aktualisiere();
	}

	//Doku siehe bitte Interface
	public void setBenutzer(Benutzer benutzer) {
		if (benutzer == null)
			return;

		AusleihenListe liste = ausleiheFactory.getAlleAusleihenVon(benutzer);
		ausleihen.setDaten(liste);

		if (liste.size() > 0)
			ausleihenTabelle.getSelectionModel().addSelectionInterval(0, 0);
	}

	// Doku siehe bitte Interface
	public void mediumEANGelesen(Medium medium) {
	}

	//Doku siehe bitte Interface
	public void refresh() {
		setBenutzer(hauptFenster.getAktivenBenutzer());
		mediumDetailsPanel.refresh();
	}
  
  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}