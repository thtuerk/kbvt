/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import com.lowagie.text.*;

/**
 * Diese Klasse dient dazu eine Tabelle einfach als PDF-Datei auszugeben. Die
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public abstract class ErweitertesPdfDokument extends PdfDokument {

  protected String titel = null;

  protected float seitenBreite = PageSize.A4.width();
  protected float seitenHoehe  = PageSize.A4.height();

  protected float randLinks = 57;
  protected float randRechts = 57;
  protected float randOben = 57;
  protected float randUnten = 42;

  /**
   * Liefert die Seitenbreite in Points
   * @return die Seitenbreite in Points
   */
  public float getSeitenBreite() {
    return seitenBreite;
  }

  /**
   * Liefert die Seitenh�he in Points
   * @return die Seitenh�he in Points
   */
  public float getSeitenHoehe() {
    return seitenHoehe;
  }

  /**
   * Liefert den linken Seitenrand in Points
   * @return den linken Seitenrand in Points
   */
  public float getSeitenRandLinks() {
    return randLinks;
  }

  /**
   * Liefert den rechten Seitenrand in Points
   * @return den rechten Seitenrand in Points
   */
  public float getSeitenRandRechts() {
    return randRechts;
  }

  /**
   * Liefert den unteren Seitenrand in Points
   * @return den unteren Seitenrand in Points
   */
  public float getSeitenRandUnten() {
    return randUnten;
  }

  /**
   * Liefert den oberen Seitenrand in Points
   * @return den oberen Seitenrand in Points
   */
  public float getSeitenRandOben() {
    return randOben;
  }

  /**
   * Setzt die Seitenbreite in Points
   * @param seitenBreite die neue Seitenbreite in Points
   */
  public void setSeitenBreite(float seitenBreite) {
    this.seitenBreite = seitenBreite;
  }

  /**
   * Setzt die Seitenh�he in Points
   * @param seitenHoehe die neue Seitenh�he in Points
   */
  public void setSeitenHoehe(float seitenHoehe) {
    this.seitenHoehe = seitenHoehe;
  }

  /**
   * Setzt den linken Seitenrand in Points
   * @param randLinks der neue linke Seitenrand in Points
   */
  public void setSeitenRandLinks(float randLinks) {
    this.randLinks = randLinks;
  }

  /**
   * Setzt den rechten Seitenrand in Points
   * @param randRechts der neue rechte Seitenrand in Points
   */
  public void setSeitenRandRechts(float randRechts) {
    this.randRechts = randRechts;
  }

  /**
   * Setzt den unteren Seitenrand in Points
   * @param randUnten der neue untere Seitenrand in Points
   */
  public void getSeitenRandUnten(float randUnten) {
    this.randUnten = randUnten;
  }

  /**
   * Setzt den oberen Seitenrand in Points
   * @param randOben der neue obere Seitenrand in Points
   */
  public void setSeitenRandOben(float randOben) {
    this.randOben = randOben;
  }
}