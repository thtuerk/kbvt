/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;

/**
 * Dieses Interface beinhaltet Standard-Methoden f�r
 * Objekte die Datenbankzugriffe kapseln. Mittels dieser
 * Methoden k�nnen Daten geladen und gespeichert werden. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public interface Datenbankzugriff extends Comparable {
  
	/**
	 * Bestimmt, ob es sich um eine neues Datenbankzugriffobjekt 
   * handelt, d.h. um ein Objekt, das gerade neu angelegt wird 
   * und noch nicht in der Datenbank gespeichert ist.
	 *
	 * @return <code>true</code> gdw das Object neu ist
	 */
	public abstract boolean istNeu();
  
	/**
	 * L�d alle Daten erneut aus der Datenbank. Ist das
	 * Objekt noch nicht gespeichert, wird keine Aktion ausgef�hrt.
	 *
	 * @throws DatenNichtGefundenException falls das Objekt inzwischen aus der
	 *   Datenbank entfernt wurde
	 * @throws DatenbankInkonsistenzException falls beim Laden eine
   *  Inkonsistenz entdeckt wird
	 */
	public abstract void reload()
		throws DatenNichtGefundenException;
	
  /**
	 * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
	 * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
	 *         <code>FALSE</code> sonst
	 */
	public abstract boolean istGespeichert();

	/**
	 * Speichert das Objekt bzw die gemachten �nderungen in der
	 * Datenbank
	 *
	 * @throws UnvollstaendigeDatenException falls nicht alle
   *   n�tigen Daten angegeben sind
	 */
	public abstract void save() throws UnvollstaendigeDatenException,
    EindeutigerSchluesselSchonVergebenException;
      
	/**
	 * L�scht das Objekt aus der Datenbank.
   * 
   * @throws DatenbankInkonsistenzException falls das Objekt nicht
   * gel�scht werden kann, weil ansonsten eine Datenbankinkonsitenz
   * entstehen w�rde.
	 */
	public abstract void loesche() throws DatenbankInkonsistenzException;

	/**
	 * Liefert eine Textdarstellung des Objektes mit allen Informationen,
	 * die vor allem zum Debuggen gedacht ist.
	 *
	 * @return die Textdarstellung
	 */
	public abstract String toDebugString();
  
	/**
	 * Liefert die ID des Objekts.
	 * @return die ID des Objekts
	 */
	public abstract int getId();
}