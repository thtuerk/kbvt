/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;

import java.io.*;
import java.util.Hashtable;
import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihzeitraum;
import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;

/**
 * Diese Klasse repr�sentiert eine AuswahlKonfiguration.
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public class AuswahlKonfiguration {
  
   AusgabeAuswahl[] ausgaben= null;
   CheckAuswahl[] checks = null;
   
   //Cache
   AuswahlObject cacheObject = null;
   Hashtable cacheHash = new Hashtable();
   
   public AuswahlKonfiguration(Reader reader) {
      AuswahlKonfigurationParser parser =
         new AuswahlKonfigurationParser(reader);
      parser.parseWithExceptions();
      
      init((AusgabeAuswahl[]) 
        parser.ausgaben.toArray(new AusgabeAuswahl[parser.ausgaben.size()]),
        (CheckAuswahl[]) 
        parser.checks.toArray(new CheckAuswahl[parser.checks.size()]));
   }

   public AuswahlKonfiguration(AusgabeAuswahl[] ausgaben, 
       CheckAuswahl[] checks) {
     init(ausgaben, checks);
   }
   
   private void init(AusgabeAuswahl[] ausgaben, 
       CheckAuswahl[] checks) {
     
     this.ausgaben = ausgaben;
     this.checks = checks;
          
   }
   
   public AuswahlKonfiguration(File file) throws FileNotFoundException {
     this(new FileReader(file));
   }

   public AuswahlKonfiguration(String file) throws FileNotFoundException {
     this(new FileReader(file));
   }      
   
   /**
    * Liefert die eingelesene Ausgabe mit der entsprechenden Nummer.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return die Ausgabe
    */
   public AusgabeAuswahl getAusgabe(int i) {
     return ausgaben[i];
   }

   /**
    * Liefert die Anzahl der enthaltenen Ausgaben.
    * @return die Anzahl der Checks
    */
   public int getAusgabeAnzahl() {
     return ausgaben.length;
   }

   /**
    * Liefert den eingelesenen Check mit der entsprechenden Nummer.
    * Die Nummerierung beginnt bei 0.
    * @param die Nummer
    * @return den Check
    */
   public CheckAuswahl getCheck(int i) {
     return checks[i];
   }

   /**
    * Liefert die Anzahl der enthaltenen Checks.
    * @return die Anzahl der Checks
    */
   public int getCheckAnzahl() {
     return checks.length;
   }

   protected boolean istInAuswahl(AuswahlObject o, Auswahl a) {
     if (o != cacheObject) {
       cacheObject = o;
       cacheHash.clear();
     }
     
     Boolean erg = (Boolean) cacheHash.get(a);
     if (erg != null) return erg.booleanValue();
     
     boolean ergBoolean = a.istInAuswahl(o, this);
     cacheHash.put(a, new Boolean(ergBoolean));
     
     return ergBoolean;
   }
      
   /**
    * Bewertet die �bergebene Liste
    * @param liste
    * @return
    */
   public AuswahlKonfigurationDaten bewerte(AusleihzeitraumListe liste) {
     //richtiger Typ?
     for (int i = 0; i < ausgaben.length;i++) {
       if (!ausgaben[i].getAuswahl().istAusleihzeitraumAuswahl())
         throw new IllegalArgumentException("Ausgabe "+ausgaben[i].getTitel()+
             " ist keine Ausleihzeitraum-Ausgabe!");
     }
     for (int i = 0; i < checks.length;i++) {
       if (!checks[i].getAuswahl().istAusleihzeitraumAuswahl())
         throw new IllegalArgumentException("Check "+checks[i].getTitel()+
         " ist kein Ausleihzeitraum-Check!");
     }
     
     //Speicher initialisieren     
     AusleihzeitraumListe[] ausgabenResult = 
       new AusleihzeitraumListe[ausgaben.length];
     for (int i = 0; i < ausgaben.length;i++) 
       ausgabenResult[i] = new AusleihzeitraumListe();
     
     AusleihzeitraumListe[] checksResult = 
       new AusleihzeitraumListe[checks.length]; 
     for (int i = 0; i < checks.length;i++) 
       checksResult[i] = new AusleihzeitraumListe();
       
     //eigentliche Bewertung
     Iterator it = liste.iterator();
     while (it.hasNext()) {
       Ausleihzeitraum zeitraum = (Ausleihzeitraum) it.next();
       AuswahlObject eintrag = new AuswahlObject();
       eintrag.setDaten(zeitraum);

       for (int i = 0; i < ausgaben.length;i++) {
         if (ausgaben[i].getAuswahl().istInAuswahl(eintrag, this))
           ausgabenResult[i].addNoDuplicate(zeitraum);
       }
       for (int i = 0; i < checks.length;i++) {
         if (!checks[i].getAuswahl().istInAuswahl(eintrag, this))
           checksResult[i].addNoDuplicate(zeitraum);
       }              
     }

     //Ergebnis
     return new AuswahlKonfigurationDaten(ausgaben, checks, 
         ausgabenResult, checksResult);
   }

   /**
    * Bewertet die �bergebene Liste
    * @param liste
    * @return
    */
   public AuswahlKonfigurationDaten bewerte(MedienListe liste) {
     //richtiger Typ?
     for (int i = 0; i < ausgaben.length;i++) {
       if (!ausgaben[i].getAuswahl().istMediumAuswahl())
         throw new IllegalArgumentException("Ausgabe "+ausgaben[i].getTitel()+
         " ist keine Medien-Ausgabe!");
     }
     for (int i = 0; i < checks.length;i++) {
       if (!checks[i].getAuswahl().istMediumAuswahl())
         throw new IllegalArgumentException("Check "+checks[i].getTitel()+
         " ist kein Medien-Check!");
     }
     
     //Speicher initialisieren     
     MedienListe[] ausgabenResult = 
       new MedienListe[ausgaben.length];
     for (int i = 0; i < ausgaben.length;i++) 
       ausgabenResult[i] = new MedienListe();
     
     MedienListe[] checksResult = 
       new MedienListe[checks.length]; 
     for (int i = 0; i < checks.length;i++) 
       checksResult[i] = new MedienListe();
     
     //eigentliche Bewertung
     Iterator it = liste.iterator();
     while (it.hasNext()) {
       Medium medium  = (Medium) it.next();
       AuswahlObject eintrag = new AuswahlObject();
       eintrag.setDaten(medium);

       for (int i = 0; i < ausgaben.length;i++) {
         if (ausgaben[i].getAuswahl().istInAuswahl(eintrag, this))
           ausgabenResult[i].addNoDuplicate(medium);
       }
       for (int i = 0; i < checks.length;i++) {
         if (!checks[i].getAuswahl().istInAuswahl(eintrag, this))
           checksResult[i].addNoDuplicate(medium);
       }              
     }

     //Ergebnis
     return new AuswahlKonfigurationDaten(ausgaben, checks, 
         ausgabenResult, checksResult);
   }   
}
