/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMedienListe;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;
import de.oberbrechen.koeb.pdf.*;

public class PdfMedienListe extends PdfDokument {

  private int sortierung;
  private boolean umgekehrteSortierung;
  private MedienListe daten;
  private String titel;
  private boolean zeigeSortierteSpalteHintergrund;
  private boolean zeigeZeilenHintergrund;

  public PdfMedienListe(String titel, MedienListe daten,
    int sortierung, boolean umgekehrteSortierung) {
    this.sortierung = sortierung;
    this.umgekehrteSortierung = umgekehrteSortierung;
    this.titel = titel;
    this.daten = daten;
    zeigeSortierteSpalteHintergrund = true;
    zeigeZeilenHintergrund = true;
  }

  public PdfMedienListe(String titel, MedienListe daten,
    int sortierung) {
    this(titel, daten, sortierung, false);
  }
    
  /**
   * Bestimmt, ob jede die Spalte nach der sortiert wird, grau hinterlegt
   * werden soll.
   * @param zeigeSortierteSpalteHintergrund <code>true</code> gdw. die
   *   Spalte grau hinterlegt werden soll
   */
  public void setZeigeSortierteSpalteHintergrund(
    boolean zeigeSortierteSpalteHintergrund) {
    this.zeigeSortierteSpalteHintergrund = zeigeSortierteSpalteHintergrund;
  }
    
  /**
   * Bestimmt, ob jede zweite Zeile grau hinterlegt werden soll
   * @param zeigeZeilenHintergrund <code>true</code> gdw. jede
   *   zweite Zeile grau hinterlegt werden soll
   */
  public void setZeigeZeilenHintergrund(
      boolean zeigeZeilenHintergrund) {
    this.zeigeZeilenHintergrund = zeigeZeilenHintergrund;
  }

  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter writer, Document doc) throws Exception {
    //Modell bauen
    TabellenModell modell = new PdfMedienListeTabellenModell(
        daten, sortierung, umgekehrteSortierung);

    if (zeigeSortierteSpalteHintergrund) {
      switch (sortierung) {
        case MedienListe.AutorTitelSortierung:
          modell.setZeigeSpaltenHintergrund(3, true);
          break;
        case MedienListe.TitelAutorSortierung:
          modell.setZeigeSpaltenHintergrund(2, true);
          break;
        case MedienListe.MedienNummerSortierung:
          modell.setZeigeSpaltenHintergrund(1, true);
          break;
      }
    }
    modell.setZeigeZeilenHintergrund(zeigeZeilenHintergrund);

    //Seitenkopf / -fuss bauen
    SeitenKopfFuss seitenKopfErsteSeite =
      new StandardSeitenKopfErsteSeite(titel, null, daten.size()+" Medien", null);

    //alles zusammenbauen
    PdfTabelle tabelle = new PdfTabelle(modell);
    PdfTabelleDokument tabelleDoc = new PdfTabelleDokument(titel, tabelle,
      seitenKopfErsteSeite, null, null, true, true);

    tabelleDoc.schreibeInDokument(writer, doc);
  }
}