/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankzugriffException;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;

import java.util.Date;
import java.text.DecimalFormat;

class PdfTeilnehmerListeVeranstaltungsgruppeTabellenModell 
  extends TabellenModell {

  private Benutzer[] daten;
  private Veranstaltung[] veranstaltungen;
  private boolean[][] teilnahmenArray;
  private DecimalFormat alterFormat = new DecimalFormat("0.0");

  public PdfTeilnehmerListeVeranstaltungsgruppeTabellenModell(
    Veranstaltungsgruppe veranstaltungsgruppe) throws DatenbankzugriffException{
    super(10, false);

    VeranstaltungsteilnahmeFactory veranstaltungsteilnahmeFactory =
      Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();
    BenutzerListe teilnehmerListe =
      veranstaltungsteilnahmeFactory.getTeilnehmerListe(
      veranstaltungsgruppe);
    teilnehmerListe.setSortierung(BenutzerListe.NachnameVornameSortierung);
    this.daten = new Benutzer[teilnehmerListe.size()];
    teilnehmerListe.toArray(this.daten);

    VeranstaltungFactory veranstaltungFactory =
      Datenbank.getInstance().getVeranstaltungFactory();
    VeranstaltungenListe veranstaltungenListe =
      veranstaltungFactory.getVeranstaltungenMitAnmeldung(veranstaltungsgruppe);
    veranstaltungenListe.setSortierung(VeranstaltungenListe.AlphabetischeSortierung);
    this.veranstaltungen = new Veranstaltung[veranstaltungenListe.size()];
    veranstaltungenListe.toArray(this.veranstaltungen);
    
    teilnahmenArray = Datenbank.getInstance().
      getVeranstaltungsteilnahmeFactory().
      getTeilnahmeArray(veranstaltungenListe, teilnehmerListe);
    

    //Spaltenmodell bauen
    init(getSpaltenAnzahl());
    setSpaltenAusrichtung(3, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(4, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    for (int i=5; i <= getSpaltenAnzahl(); i++) {
      setSpaltenAusrichtung(i,
      TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL);
      setFesteBreite(i, 9);
      setZeigeSpaltenHintergrund(i, (i - 5) % 2 == 0);
    }
    setSpaltenAbstand(0);
    setSpaltenAbstand(1, 5);
    setSpaltenAbstand(3, 5);
    setSpaltenAbstand(4, 10);
    setSpaltenAbstandHintergrund(4, 1);
  }

	public int getSpaltenAnzahl() {
    return 4+veranstaltungen.length;
  }

  public int getZeilenAnzahl() {
    return daten.length;
  }

  public String getSpaltenName(int spaltenNr) {
    switch (spaltenNr) {
      case 1: return "Name";
      case 2: return "Tel.";
      case 3: return null;
      case 4: return "Alter";
    }
    return ((Veranstaltung) veranstaltungen[spaltenNr-5]).getTitel();
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    Benutzer benutzer =
      (Benutzer) daten[zeilenNr - 1];

    switch (spaltenNr) {
      case 1: return benutzer.getNameFormal();
      case 2: return benutzer.getTel();
      case 3:
        boolean eMailGesetzt = (benutzer.getEMail() != null);
        boolean faxGesetzt = (benutzer.getEMail() != null);
        if (!eMailGesetzt && !faxGesetzt) return null;
        String eintrag = "(";
        if (eMailGesetzt) eintrag += "E";
        if (eMailGesetzt) eintrag += "F";
        return eintrag+")";
      case 4:
        if (benutzer.getGeburtsdatum() != null) {
          double alter = benutzer.getAlter(new Date());
          return alterFormat.format(alter)+" J.";
        } else {
          return null;
        }
    }

    if (teilnahmenArray[spaltenNr-5][zeilenNr-1])
      return "X";
    else
      return null;
  }
}

