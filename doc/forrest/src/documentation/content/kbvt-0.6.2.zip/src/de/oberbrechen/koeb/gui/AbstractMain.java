/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentEvent;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.framework.KonfigurationsDatei;
import de.oberbrechen.koeb.gui.standarddialoge.*;

/**
 * Diese Klasse ist eine abstrakte Hauptklasse f�r die 
 * verschiedenen graphischen Oberfl�chen. Sie bietet die allgemeine
 * Funktionalit�t an, muss aber noch konkretisiert werden.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.14 $
 */
public abstract class AbstractMain extends JFrame {

  protected JMenu[] reiterMenus;
  
  private static int instanceCount = 0;
  protected Mitarbeiter currentMitarbeiter;
  
  protected JTabbedPane reiter;
  protected MainReiter currentReiter;
  protected MitarbeiterAuswahlDialog mitarbeiterAuswahlDialog;

  protected Dimension minDimension;
  protected boolean erlaubeAenderungen;
  protected int noetigeMitarbeiterBerechtigung;

  public AbstractMain(boolean isMain, 
    final String titel, int noetigeMitarbeiterBerechtigung, String icon,
    Mitarbeiter paramMitarbeiter) {
    AbstractMain.instanceCount++;      
    this.noetigeMitarbeiterBerechtigung = noetigeMitarbeiterBerechtigung;
    
    ladeIcon(icon);
    if (isMain) {
      ErrorHandler.setInstance(new StandardGUIErrorHandler(this));
      setLookAndFeel();
      ErrorHandler.setInstance(new StandardGUIErrorHandler(this));
    } else {
      currentMitarbeiter = paramMitarbeiter;
    }

    /*
     * Hintergrundthread bauen. Dieser Thread initialisiert w�hrend
     * der Passworteingabe bereits die GUI und beschleunigt so den
     * Start erheblich
     */
    final AbstractMain abstractMain = this;
    Thread hintergrundThread = new Thread(new Runnable(){
			public synchronized void run() {
        // GUI-Initialisieren
        try {
          jbInit(titel);
          reiterHinzufuegen();
          initMenue();
        }
        catch(Exception e) {
          e.printStackTrace();
        }

        erlaubeAenderungen(true);
        initDaten();
        abstractMain.pack();
        minDimension = abstractMain.getSize();
        SwingUtilities.updateComponentTreeUI(abstractMain);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((dim.width - abstractMain.getWidth())/2, 
          (dim.height - abstractMain.getHeight())/2);
			}});
    hintergrundThread.setPriority(Thread.MIN_PRIORITY);

    if (currentMitarbeiter == null || 
        !currentMitarbeiter.besitztBerechtigung(noetigeMitarbeiterBerechtigung)) {
      mitarbeiterAuswahlDialog = new MitarbeiterAuswahlDialog(this);
      hintergrundThread.start();
      boolean wechselOK = mitarbeiterWechseln();
      if (!wechselOK) {
        hintergrundThread.stop();
        dispose();
        return;
      } //Abbruch, wenn kein Mitarbeiter gew�hlt
    } else {
      hintergrundThread.start();      
    }

    //Wartedialog anzeigen, bis hintergundThread alles initialisiert hat    
    if (hintergrundThread.isAlive()) {
      hintergrundThread.setPriority(Thread.MAX_PRIORITY);
      WarteDialog warteDialog = null;
      
      if (isMain) {
        warteDialog = new WarteDialog();
        warteDialog.setVisible(true);
      } else {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      }
      Thread.yield();


      try {
        hintergrundThread.join();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
  
      if (isMain) {
        warteDialog.dispose();
      } else {
        setCursor(Cursor.getDefaultCursor());
      }
    }

    setMitarbeiter(currentMitarbeiter);
    this.setVisible(true);
  }

  /**
   * Initialisiert das Menue
   */
  protected void initMenue() {
    JMenuBar menue = new JMenuBar();     
    addMenue(menue);
    this.setJMenuBar(menue);        
  }
  
  /**
   * F�gt das Men� hinzu
   */
  protected void addMenue(JMenuBar menue) {
    menue.add(getDateiMenue(false));
    addReiterMenues(menue);
    menue.add(getInfoMenue());
  }      
    
  /**
   * Liefert ein Info-Menue, das Informationen �ber KBVT anzeigt.
   * @return das erzeugte Info-Menue
   */
  protected JMenu getInfoMenue() {
    JMenu infoMenue = new JMenu("Hilfe");

    JMenuItem ueberButton = new JMenuItem("�ber");
    ueberButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        new InfoDialog().show();
      }
    });
    
    infoMenue.add(ueberButton);
    
    return infoMenue;
  }
    
  /**
   * Liefert ein Datei-Menue, das die Standardoperationen, wie Ausgabe,
   * Mitarbeiter-Wechseln und Exit anbietet.
   * @param mininal bestimmt, ob das Menue minimal ist
   * @return das erzeugte Datei-Menue
   */
  protected JMenu getDateiMenue(boolean minimal) {
    // Men� bauen
    JMenu dateiMenue = new JMenu("Datei");
    
    if (!minimal) {
      JMenuItem mitarbeiterAendernButton = new JMenuItem("Mitarbeiter wechseln");
      mitarbeiterAendernButton.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
          mitarbeiterWechseln();
        }
      });
      JMenuItem mitarbeiterPasswortAendern = new JMenuItem("Mitarbeiterpasswort �ndern");
      mitarbeiterPasswortAendern.setToolTipText("�ndern des Passwortes des aktuellen Mitarbeiters");
      mitarbeiterPasswortAendern.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
          mitarbeiterPasswortAendern();
        }
      });
      JMenuItem ausgabenButton = new JMenuItem("Ausgabe");
      ausgabenButton.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e) {
          ausgabeStarten();
        }
      });
      
      dateiMenue.add(mitarbeiterAendernButton);
      dateiMenue.add(mitarbeiterPasswortAendern);
      dateiMenue.addSeparator();
      dateiMenue.add(ausgabenButton);
      dateiMenue.addSeparator();
    }
    
    JMenuItem exitButton = new JMenuItem("Exit");
    exitButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
      }
    });
    
    dateiMenue.add(exitButton);
    
    return dateiMenue;
  }

  /**
   * Wird aufgerufen, wenn ein anderer Reiter gew�hlt wurde
   */
  public void refresh() {
    this.setCursor(new Cursor(Cursor.WAIT_CURSOR));    
    if (currentReiter != null) {
      currentReiter.focusLost();
    }
    if (reiter != null) {
      currentReiter = (MainReiter) reiter.getSelectedComponent();
      if (currentReiter != null) currentReiter.refresh();
      if (reiterMenus == null) 
        reiterMenus = new JMenu[reiter.getComponentCount()];

      for (int i=0; i < reiter.getComponentCount(); i++) {
        if (reiterMenus[i] != null) {
          reiterMenus[i].setVisible(i == reiter.getSelectedIndex());
        }        
      }      
    }
    this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }
  
  protected void addReiterMenues(JMenuBar menue) {
    reiterMenus = new JMenu[reiter.getComponentCount()];
    for (int i=0; i < reiter.getComponentCount(); i++) {
      MainReiter currentReiter = (MainReiter) reiter.getComponent(i);
      reiterMenus[i] = currentReiter.getMenu();
      if (reiterMenus[i] != null) {
        menue.add(reiterMenus[i]);
        reiterMenus[i].setVisible(false);
      }
    }    
  }
  
  protected void ausgabeStarten() {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    new de.oberbrechen.koeb.gui.ausgaben.Main(false, currentMitarbeiter);
    setCursor(Cursor.getDefaultCursor());
  }  

  public void dispose() {
    super.dispose();
    AbstractMain.instanceCount--;
    if (AbstractMain.instanceCount <= 0) System.exit(0);
  }
  
  /**
   * Initialisiert n�tige Daten
   */
  protected abstract void initDaten();

  /**
   * Wechselt den aktuell angemeldeten Mitarbeiter.
   * @return true gdw ein Wechsel erfolgte
   */
  protected boolean mitarbeiterWechseln() {
    Mitarbeiter gewaehlterMitarbeiter = mitarbeiterAuswahlDialog.waehleMitarbeiter(
      noetigeMitarbeiterBerechtigung);
    if (gewaehlterMitarbeiter != null) setMitarbeiter(gewaehlterMitarbeiter);
    return gewaehlterMitarbeiter != null;
  }

  /**
   * F�gt die Reiter hinzu. 
   */
  protected abstract void reiterHinzufuegen();

  /**
   * Setzt das aktuelle Look & Feel.
   */
  protected void setLookAndFeel() {
    String lookAndFeel = null; 
      try {
      
      EinstellungFactory einstellungFactory =
          Datenbank.getInstance().getEinstellungFactory();
      Client benutzterClient = Datenbank.getInstance().getClientFactory().getBenutzenClient();
      lookAndFeel = einstellungFactory.getEinstellung(
          benutzterClient, null, "de.oberbrechen.koeb.gui",
          "LookAndFeel").getWert(
          "com.incors.plaf.kunststoff.KunststoffLookAndFeel");

      UIManager.setLookAndFeel(lookAndFeel);
      SwingUtilities.updateComponentTreeUI(this);
    } catch (Exception e) {
      JOptionPane.showMessageDialog( this,
        "Das Look&Feel \""+lookAndFeel+"\" konnte nicht geladen werden!", "Ladefehler",
        JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * L�d und setzt das Icon des Fensters.
   */
  protected void ladeIcon(String icon) {
    java.net.URL iconURL = ClassLoader.getSystemResource(
      icon);
    if (iconURL != null)
      this.setIconImage(getToolkit().getImage(iconURL));
    else {
       JOptionPane.showMessageDialog( this,
         "Das Icon '"+icon+"' konnte nicht "+
         "geladen werden!", "Ladefehler",
         JOptionPane.ERROR_MESSAGE);
    }

  }


  /**
   * Wechselt den aktuell angemeldeten Mitarbeiter
   * @param mitarbeiter der Mitarbeiter, zu dem gewechselt werden soll
   */
  public void setMitarbeiter(Mitarbeiter mitarbeiter) {
    currentMitarbeiter = mitarbeiter;
    Datenbank.getInstance().getMitarbeiterFactory().
      setAktuellenMitarbeiter(mitarbeiter);
  }

  /**
   * Erlaubt / verbietet �ndern der angezeigten Umgebung, d.h. es wird z.B. 
   * das Wechseln des Reiters verboten. Ein solches Verbot
   * ist n�tig, damit w�hrend der Dateneingabe in einem unsauberen Zustand nicht
   * die aktuelle Eingabe verlassen werden kann.
   *
   * @param erlaubt bestimmt, ob �nderungen erlaubt sind
   */
  public void erlaubeAenderungen(boolean erlaubt) {
    erlaubeAenderungen = erlaubt;
    reiter.setEnabled(erlaubt);
    
    JMenuBar menuBar = getJMenuBar();
    if (menuBar != null) {
      int menueAnzahl = menuBar.getMenuCount();
      for (int i=0; i < menueAnzahl; i++) 
        menuBar.getMenu(i).setEnabled(erlaubt);
    }
  }

  /**
   * F�hrt einige Initialisierungen durch.
   */
  public static void init() {
    UIManager.put("OptionPane.yesButtonText", "Ja");
    UIManager.put("OptionPane.noButtonText", "Nein");
    UIManager.put("OptionPane.cancelButtonText", "Abbrechen");

    java.io.File file = new java.io.File("einstellungen.conf");
    KonfigurationsDatei.setStandardDatei(file);   
  }
  
  protected void jbInit(String titel) throws Exception {
    //allgemeinPanel bauen
    JPanel allgemeinPanel = getAllgemeinPanel();
    if (allgemeinPanel != null) allgemeinPanel.setBorder(BorderFactory.createEmptyBorder(10,10,0,10));

    // Reiter bauen
    reiter = new JTabbedPane();
    reiter.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    reiter.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        refresh();
      }
    });


    // Alles zusammenbauen
    this.setTitle(titel);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setLocale(new java.util.Locale("de", "DE", "EURO"));

    this.addComponentListener(new java.awt.event.ComponentAdapter() {
      public void componentResized(ComponentEvent e) {
        kontrolliereNeueGroesse();
      }
    });

    this.getContentPane().setLayout(new BorderLayout(10, 5));
    if (allgemeinPanel != null)
      this.getContentPane().add(allgemeinPanel, BorderLayout.NORTH);
    this.getContentPane().add(reiter, BorderLayout.CENTER);
  }

  /**
   * Liefert ein Panel, dass �ber den Reitern angezeigt wird und
   * das so eine Anpassung der GUI erm�glicht.
   * @return
   */
  protected JPanel getAllgemeinPanel() throws Exception {
    return null;
  }

  /**
   * Liefert den aktuell angemeldeten Mitarbeiter
   * @return den aktuell angemeldeten Mitarbeiter
   */
  public Mitarbeiter getAktuellenMitarbeiter() {
    return currentMitarbeiter;
  }

  /**
   * Zeigt das Dialogfeld zum �ndern des Mitarbeiterpasswortes an und speichert
   * das ver�nderte Passwort.
   */
  protected void mitarbeiterPasswortAendern() {
    Mitarbeiter aktuellerMitarbeiter = this.getAktuellenMitarbeiter();
    new PasswortAendernDialog(this).changeMitarbeiterPasswort(
      aktuellerMitarbeiter, true);
    aktuellerMitarbeiter.save();
  }

  /**
   * �berpr�ft nach einem Resize, ob das Fenster noch die Mindestgr��e besitzt.
   * Ist dies nicht der Fall, wird es vergr��ert.
   */
  protected void kontrolliereNeueGroesse() {
    if (minDimension == null) return;
    Dimension currentDimension = this.getSize();
    if (currentDimension.width < minDimension.width ||
        currentDimension.height < minDimension.height) {

      Dimension newDimension = new Dimension(
        Math.max(minDimension.width, currentDimension.width),
        Math.max(minDimension.height, currentDimension.height));

      this.setSize(newDimension);
    }
  }
}