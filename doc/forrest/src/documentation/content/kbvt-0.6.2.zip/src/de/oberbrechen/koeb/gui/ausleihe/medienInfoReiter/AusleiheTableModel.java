/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.medienInfoReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import java.util.*;
import javax.swing.table.AbstractTableModel;
import java.text.SimpleDateFormat;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Ausleihen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/

public class AusleiheTableModel extends AbstractTableModel {

  private AusleihenListe daten;
  private static SimpleDateFormat dateFormat =
    new SimpleDateFormat("EE, dd. MMM yyyy");

  /**
   * Erstellt ein neues Modell ohne Daten, das nach dem Sollr�ckgabedatum
   * der Ausleihen sortiert ist
   */
  public AusleiheTableModel() {
    AusleihenListe liste = new AusleihenListe();
    liste.setSortierung(AusleihenListe.AusleihdatumSortierung, true);
    this.daten = liste;
  }

  /**
   * Erstellt ein neues Modell mit den �bergebenen Daten in der dort angegebenen
   * Sortierung
   *
   * @param daten die enthaltenen Ausleihen
   */
  public AusleiheTableModel(AusleihenListe daten) {
    this.daten = daten;
  }

  /**
   * Setzt die �bergebenen Daten und die darin enthaltene Sortierung
   * @param daten die zu setzenden Daten
   */
  public void setDaten(AusleihenListe daten) {
    this.daten = daten;
    fireTableDataChanged();
  }

  /**
   * Liefert die aktuellen Daten des Modells als SortedSet. Dieses
   * wird intern verwendet, weswegen das SortedSet nicht
   * ver�ndert werden sollte.
   * @return die aktuellen Daten
   */
  public AusleihenListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Benutzer";
    if (columnIndex == 1) return "von";
    if (columnIndex == 2) return "bis";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Ausleihe gewaehlteAusleihe = (Ausleihe) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehlteAusleihe.getBenutzer().getName();
    if (columnIndex == 1)
      return dateFormat.format(gewaehlteAusleihe.getAusleihdatum());
    if (columnIndex == 2) {
      Date rueckgabeDatum = gewaehlteAusleihe.getRueckgabedatum();
      if (rueckgabeDatum == null) return "-";
      return dateFormat.format(rueckgabeDatum);
    }
    return "nicht definierte Spalte";
  }

  /**
   * Liefert die Ausleihe die in der angebenen Zeile dargestellt wird
   * @param rowIndex die Zeile
   */
  public Ausleihe getAusleihe(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    return (Ausleihe) daten.get(rowIndex);
  }

  /**
   * F�gt eine Ausleihe zum Modell hinzu.
   * @param ausleihe die hinzuzuf�gende Ausleihe
   */
  public void add(Ausleihe ausleihe) {
    if (ausleihe == null) return;
    daten.add(ausleihe);
    fireTableDataChanged();
  }

  /**
   * Entfernt eine Ausleihe aus dem Modell.
   * @param ausleihe die zu entfernende Ausleihe
   */
  public void remove(Ausleihe ausleihe) {
    if (ausleihe == null) return;
    daten.remove(ausleihe);
    fireTableDataChanged();
  }
}
