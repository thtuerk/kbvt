/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.benutzerAusgabeWrapper;

import javax.swing.JFrame;

import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.ausgaben.BenutzerAusgabe;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse bildet einen Wrapper um eine BenutzerAusgabe. Bei
 * Aufruf dieser Ausgabe wird ein Dialogfeld angezeigt, �ber das
 * die auszugebenden Benutzer ausgew�hlt und die Ausgabe konfiguriert
 * werden kann.
 */
public class BenutzerAusgabeWrapper implements Ausgabe {

  AuswahlDialog dialog;
  BenutzerAusgabe benutzerAusgabe;
  AuswahlKonfiguration konfiguration;
  
  /**
   * Erstellt einen neuen Wrapper f�r die �bergebene BenutzerAusgabe
   * @param benutzerAusgabe
   */
  public BenutzerAusgabeWrapper(BenutzerAusgabe benutzerAusgabe) {
    this(benutzerAusgabe, null);
  }

  /**
   * Erstellt einen neuen Wrapper f�r die �bergebene BenutzerAusgabe
   * und benutzt als Auswahlm�glichkeiten die �bergebene AuswahlKonfiguration.
   * @param medienAusgabe
   * @param konfiguration
   */
  public BenutzerAusgabeWrapper(BenutzerAusgabe benutzerAusgabe,
    AuswahlKonfiguration konfiguration) {
    this.benutzerAusgabe = benutzerAusgabe;
  }
  
  public void run(JFrame hauptFenster) throws Exception {   
    if (hauptFenster == null) { 
      ErrorHandler.getInstance().handleError(
          "Diese Ausgabe ben�tigt eine graphische Schnittstelle!", false);
      return;
    }
    
    if (dialog == null || dialog.hauptFenster != hauptFenster)
      dialog = new AuswahlDialog(hauptFenster, benutzerAusgabe, konfiguration);
    
    dialog.show();
  }

  public String getName() {
    return benutzerAusgabe.getName();
  }

  public String getBeschreibung() {
    return benutzerAusgabe.getBeschreibung();
  }
}

