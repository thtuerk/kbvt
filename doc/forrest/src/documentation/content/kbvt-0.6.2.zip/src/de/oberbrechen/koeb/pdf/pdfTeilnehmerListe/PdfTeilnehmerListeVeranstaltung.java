/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;
import de.oberbrechen.koeb.pdf.*;

public class PdfTeilnehmerListeVeranstaltung extends PdfDokument {

  private int sortierung;
  private boolean zeigeSortierteSpalteHintergrund;
  private Veranstaltung veranstaltung;

  public PdfTeilnehmerListeVeranstaltung() {
    sortierung = VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung;
    zeigeSortierteSpalteHintergrund = true;
    veranstaltung = null;
  }

  /**
   * Bestimmt, ob jede die Spalte nach der sortiert wird, grau hinterlegt
   * werden soll.
   * @param zeigeSortierteSpalteHintergrund <code>true</code> gdw. jede
   *   zweite Zeile grau hinterlegt werden soll
   */
  public void setZeigeSortierteSpalteHintergrund(
    boolean zeigeSortierteSpalteHintergrund) {
    this.zeigeSortierteSpalteHintergrund = zeigeSortierteSpalteHintergrund;
  }

  /**
   * Setzt die anzuwendende Sortierungd der Liste. Die zur Verf�gung stehenden
   * Sortierungen sind als �ffentliche Konstanten der Klasse
   * VeranstaltungsteilnahmeListe verf�gbar.
   */
  public void setSortierung(int sortierung) {
    this.sortierung = sortierung;
  }

  /**
   * Setzt die Veranstaltung, deren Teilnehmerliste
   * angezeigt werden soll.
   *
   * @param veranstaltung die neue Veranstaltung
   */
  public void setVeranstaltung(Veranstaltung veranstaltung) {
    this.veranstaltung = veranstaltung;
  }

  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter pdfWriter, Document doc) throws Exception {

    //Initialisierungen
    VeranstaltungsteilnahmeFactory veranstaltungsteilnahmeFactory =
      Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();
    final VeranstaltungsteilnahmeListe teilnahmeListe =
      veranstaltungsteilnahmeFactory.getTeilnahmeListe(veranstaltung);
    teilnahmeListe.setSortierung(sortierung);      

    //Modell bauen
    TabellenModell modell = new PdfTeilnehmerListeVeranstaltungTabellenModell(
        teilnahmeListe, sortierung);

    if (zeigeSortierteSpalteHintergrund) {
      switch (sortierung) {
        case VeranstaltungsteilnahmeListe.AnmeldeNrSortierung:
          modell.setZeigeSpaltenHintergrund(5, true);
          break;
        case VeranstaltungsteilnahmeListe.BenutzerKlasseSortierung:
          modell.setZeigeSpaltenHintergrund(4, true);
          break;
        case VeranstaltungsteilnahmeListe.BemerkungenSortierung:
          modell.setZeigeSpaltenHintergrund(6, true);
          break;
        case VeranstaltungsteilnahmeListe.BenutzerVornameNachnameSortierung:
        case VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung:
          modell.setZeigeSpaltenHintergrund(1, true);
          break;
      }
    }

    //Seitenkopf / -fuss bauen
    PdfTeilnehmerListeVeranstaltungSeitenKopfErsteSeite seitenKopfErsteSeite =
      new PdfTeilnehmerListeVeranstaltungSeitenKopfErsteSeite(
      veranstaltung);

    //alles zusammenbauen
    PdfTabelle tabelle = new PdfTabelle(modell);
    PdfTabelleDokument tabelleDoc = new PdfTabelleDokument(veranstaltung.getTitel(),
      tabelle, seitenKopfErsteSeite, null, null, true, true);

    tabelleDoc.schreibeInDokument(pdfWriter, doc);
  }
}
