/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMedienListe;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;

class PdfMedienListeTabellenModell extends TabellenModell {

  private MedienListe daten;

  public PdfMedienListeTabellenModell(
    MedienListe daten, int sortierung) {
    this(daten, sortierung, false);
  }

  public PdfMedienListeTabellenModell(
    MedienListe daten, int sortierung, boolean umgekehrteSortierung) {
    daten.setSortierung(sortierung, umgekehrteSortierung);
    this.daten = daten;
  }


  public int getSpaltenAnzahl() {
    return 3;
  }

  public int getZeilenAnzahl() {
    return daten.size();
  }

  public String getSpaltenName(int spaltenNr) {
    switch (spaltenNr) {
      case 1: return "Nr.";
      case 2: return "Titel";
      case 3: return "Autor";
    }
    return null;
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    Medium medium = (Medium) daten.get(zeilenNr - 1);

    switch (spaltenNr) {
      case 1: return medium.getMedienNr();
      case 2: return medium.getTitel();
      case 3: return medium.getAutor();
    }
    return null;
  }
}
