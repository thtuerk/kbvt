/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;

/**
 * Diese Klasse repr�sentiert einen Check, der auf einer Auswahl
 * basiert. Dabei handelt es sich um eine Auswahl mit einem Titel. 
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class CheckAuswahl {
    
  String titel;
  Auswahl auswahl;
  
  public CheckAuswahl(String titel, Auswahl auswahl) {
    this.titel = titel;
    this.auswahl = auswahl;
  }
  
  protected Auswahl getAuswahl() {
    return auswahl;
  }

  public String getTitel() {
    return titel;
  }
  
  public String toString() {
    return toDebugString();
  }
  
  public String toDebugString() {
    StringBuffer buffer = new StringBuffer();
    buffer.append(titel+"\n");
    buffer.append(auswahl.toDebugString());
    return buffer.toString();
  }
}
