/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

/**
 * Dieses Interface repr�sentiert einen Benutzer der B�cherei.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.18 $
 */

public interface Mitarbeiter extends Datenbankzugriff {

  public static final int BERECHTIGUNG_STANDARD = 0;
  public static final int BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE = 1;
  public static final int BERECHTIGUNG_BESTAND_EINGABE = 2;
  public static final int BERECHTIGUNG_ADMIN = 4;
  static final int EHEMALIGER_MITARBEITER = 8;
  
  /**
   * Setzt den Mitarbeiterbenutzernamen des Benutzers f�r die elektronische
   * Anmeldung
   * @param benutzername Mitarbeiterbenutzername des Benutzers
   */
  public void setMitarbeiterBenutzername(String benutzername);

  /**
   * Setzt das Mitarbeiter-Passwort des Mitarbeiters f�r die elektronische
   * Anmeldung. Beachten
   * Sie bitte, dass nicht das Passwort selbst, sondern die zugeh�rige
   * Pr�fziffer nach dem MD5-Algorithmus gespeichert wird.
   * @param Passwort Passwort des Benutzers
   * @see #checkMitarbeiterPasswort
   */
  public void setMitarbeiterPasswort(String passwort);

  /**
   * Liefert den Mitarbeiterbenutzernamen des Mitarbeiters f�r die
   * elektronische Anmeldung
   * @return Mitarbeiterbenutzername des Benutzers
   */
  public String getMitarbeiterBenutzername();

  /**
   * �berpr�ft, ob das �bergebene Passwort dem Mitarbeiter-Passwort des
   * Mitarbeiters entspricht
   * @param passwort das zu testende Passwort
   * @return <code>TRUE</code> gdw das Passwort g�ltig ist
   */
  public boolean checkMitarbeiterPasswort(String passwort);

  /**
   * �berpr�ft, ob dieser Mitarbeiter ein Mitarbeiter-Passwort verwendet
   * @return <code>TRUE</code> gdw der Mitarbeiter ein Mitarbeiter-Passwort
   *   verwendet
   */
  public boolean istMitarbeiterPasswortGesetzt();

  /**
   * Bestimmt, ob der Benutzer die �bergebene Berechtigung besitzt. Die zur
   * Verf�gung stehenden Berechtigungen sind �ber statische Konstanten dieser
   * Klasse festgelegt.
   *
   * @param berechtigung die Berechtigung, von der �berpr�ft werden soll, ob
   *   dieser Benutzer sie besitzt
   * @return <code>TRUE</code> gdw. der Benutzer die �bergebene Berechtigung
   *   besitzt
   */
  public boolean besitztBerechtigung(int berechtigung);

  /**
   * Liefert den Benutzer, dem der Mitarbeiter entspricht. �ber den Benutzer 
   * k�nnen Name, Anschrift, Telefonnr usw. des Benutzer abgefragt werden.
   * @return den Benutzer, dem der Mitarbeiter entspricht
   */
  public Benutzer getBenutzer();
  
  /**
   * Setzt oder entfernt die �bergebene Berechtigung.
   * @param berechtigung die zu �ndernde Berechtigung
   * @param wert <code>true</code>, wenn die Berechtigung erteilt werden soll<br>
   * <code>false</code>, wenn die Berechtigung entzogen werden sol
   */
  public void setBerechtigung(int berechtigung, boolean wert);
  
  /**
   * Setzt, ob der Mitarbeiter ein ehemaliger Mitarbeiter oder noch
   * aktiv ist.
   * @param aktiv gibt an ob der Mitarbeiter noch aktiv ist
   */
  public void setAktiv(boolean aktiv);
  
  /**
   * Bestimmt, ob der Mitarbeiter ein ehemaliger Mitarbeiter oder noch
   * aktiv ist.
   * @return ob der Mitarbeiter noch aktiv ist
   */
  public boolean istAktiv();
  
}