/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfKoeBOberbrechen;

import javax.swing.JFrame;

import de.oberbrechen.koeb.ausgaben.AbstractMedienAusgabe;
import de.oberbrechen.koeb.ausgaben.KonfigurierbareAusgabe;
import de.oberbrechen.koeb.pdf.pdfAufkleber.AbstractPdfAufkleber;

class PdfMedienaufkleberMedienAusgabe extends AbstractMedienAusgabe 
  implements KonfigurierbareAusgabe {  
    protected boolean klein;
    protected PdfMedienaufkleberMedienAusgabeKonfigDialog konfigDialog;

    public PdfMedienaufkleberMedienAusgabe(boolean klein) {
      this.klein = klein;
      
      int aufkleberAnzahl;
      if (klein)
        aufkleberAnzahl = 48;
      else
        aufkleberAnzahl = 24;
      
      konfigDialog = new PdfMedienaufkleberMedienAusgabeKonfigDialog(aufkleberAnzahl);
    }
    
    public String getName() {
      String erg = klein?" - Klein":"";
      return "Medienaufkleber"+erg;
    }

    public String getBeschreibung() {
      return "Erm�glicht die Ausgabe von Medienaufklebern.";
    }

    public void run(JFrame hauptFenster) throws Exception {      
      AbstractPdfAufkleber pdfAufkleber;
      if (klein) { 
        pdfAufkleber = new PdfMedienaufkleberKlein(getSortierteMedienliste());
      } else {
        pdfAufkleber = new PdfMedienaufkleber(getSortierteMedienliste());
      }
      pdfAufkleber.setStartPos(konfigDialog.getStartPos());
      pdfAufkleber.zeige(false);      
    }    
    
    public void konfiguriere(JFrame main) {
      konfigDialog.show(main);
      setSortierung(konfigDialog.getSortierung(), konfigDialog.umgekehrteSortierung);
    }    
}
