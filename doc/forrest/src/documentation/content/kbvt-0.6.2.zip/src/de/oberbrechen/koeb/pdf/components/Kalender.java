/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.components;

import com.lowagie.text.pdf.*;
import de.oberbrechen.koeb.pdf.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 * Diese Klasse stellt die n�tige Funktionalit�t bereit, um einen Monat als
 * Kalender in eine Pdf-Datei auszugeben.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class Kalender {

  private static final SimpleDateFormat ueberschriftFormat =
    new SimpleDateFormat("MMMM yyyy");
  private static final SimpleDateFormat hashtableFormat =
    new SimpleDateFormat("yyyy-MM-dd");

  private float schriftGroesse;
  private float breite;
  private PdfContentByte pdf;
  private Hashtable hashtable;

  public Kalender(PdfContentByte pdf, float breite, float schriftGroesse) {
    this.schriftGroesse = schriftGroesse;
    this.breite = breite;
    this.pdf = pdf;
    hashtable = new Hashtable();
  }

  /**
   * Setzt einen String, der im Kalender am �bergebenen angezeigt
   * werden soll.
   *
   * @param tag der Tag im Monat, in dem der Eintrag angezeigt werden soll
   * @param monat der Monat, in dem der Eintrag angezeigt werden soll
   * @param jahr das Jahr, in dem der Eintrag angezeigt werden soll
   * @param eintrag der Eintrag
   */
  public void setEintrag(int tag, int monat, int jahr, String eintrag) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(jahr, monat-1, tag);
    setEintrag(calendar.getTime(), eintrag);
  }

  /**
   * Setzt einen String, der im Kalender am �bergebenen Datum angezeigt
   * werden soll.
   *
   * @param datum das Datum, an dem der Eintrag angezeigt werden soll
   * @param eintrag der Eintrag
   */
  public void setEintrag(Date datum, String eintrag) {
    String key = hashtableFormat.format(datum);
    if (eintrag != null)
      hashtable.put(key, eintrag);
    else
      hashtable.remove(key);
  }

  /**
   * Liefert ein Template, in dem der Kalender f�r den �bergebenen Monat und
   * das �bergebene Jahr dargestellt wird.
   */
  public PdfTemplate getKalenderTemplate(int monat, int jahr) {
    float zellenBreite = breite / 7;
    Calendar kalender = Calendar.getInstance();
    kalender.set(jahr, monat-1, 1);
    int ersterWochentag = (kalender.get(Calendar.DAY_OF_WEEK) - 2) % 7;
    if (ersterWochentag < 0) ersterWochentag += 7;

    int tageInMonat = kalender.getActualMaximum(Calendar.DAY_OF_MONTH);
    int zeilen = (int) (Math.ceil(((double) (ersterWochentag+tageInMonat)) / 7));
    float hoehe = (float) (zellenBreite*zeilen+schriftGroesse*3.5);

    PdfTemplate template = pdf.createTemplate(breite, hoehe);

    String ueberschrift = ueberschriftFormat.format(kalender.getTime());
    float ueberschriftBreite = PdfDokument.schriftFett.
      getWidthPoint(ueberschrift, (int) (schriftGroesse*1.5));

    template.beginText();
    template.setFontAndSize(PdfDokument.schriftFett, (int)(schriftGroesse*1.5));
    template.setTextMatrix((breite - ueberschriftBreite)/2,
                           (float) (hoehe-schriftGroesse*1.4));
    template.showText(ueberschrift);
    template.endText();

    //Male Hintergrund
    template.rectangle(0, (float) (hoehe-schriftGroesse*3.5), breite,
                       (float) (schriftGroesse*1.5));
    template.setGrayFill(0.7f);
    template.fill();

    template.rectangle(zellenBreite*ersterWochentag, zellenBreite*(zeilen-1),
      breite-zellenBreite*ersterWochentag, zellenBreite);
    template.rectangle(0, zellenBreite, breite, (zeilen-2)*zellenBreite);
    template.rectangle(0, 0,
      zellenBreite*(7-zeilen*7+ersterWochentag+tageInMonat), zellenBreite);
    template.setGrayFill(0.9f);
    template.fill();


    //Tage im Monat
    int zeile = zeilen;
    int spalte = ersterWochentag;
    for (int i=1; i <= tageInMonat; i++) {
      kalender.set(Calendar.DAY_OF_MONTH, i);
      if (hashtable.containsKey(hashtableFormat.format(kalender.getTime()))) {
      template.rectangle(spalte*zellenBreite, zeile*zellenBreite,
        zellenBreite, -zellenBreite);
      }
      spalte++; if (spalte == 7) {spalte = 0; zeile--;}
    }
    template.setGrayFill(0.7f);
    template.fill();

    zeile = zeilen;
    spalte = ersterWochentag;
    for (int i=1; i <= tageInMonat; i++) {
      template.rectangle(spalte*zellenBreite, zeile*zellenBreite,
        zellenBreite/3, -zellenBreite/3);
      spalte++; if (spalte == 7) {spalte = 0; zeile--;}
    }
    template.setGrayFill(1);
    template.setLineWidth(0.2f);
    template.fillStroke();

    //Male Linien
    template.setGrayFill(0);
    template.setLineWidth(1);

    template.moveTo(0,0);
    template.lineTo(breite, 0);
    template.moveTo(0, (float) (hoehe-schriftGroesse*3.5));
    template.lineTo(breite, (float) (hoehe-schriftGroesse*3.5));
    template.moveTo(0, hoehe-schriftGroesse*2);
    template.lineTo(breite, hoehe-schriftGroesse*2);

    template.moveTo(0,0);
    template.lineTo(0,hoehe-schriftGroesse*2);
    template.moveTo(breite,0);
    template.lineTo(breite,hoehe-schriftGroesse*2);
    template.stroke();

    template.setLineWidth(0.2f);
    for (int i=1; i < 7; i++) {
      template.moveTo(i*zellenBreite,0);
      template.lineTo(i*zellenBreite,hoehe-schriftGroesse*2);
    }

    for (int i=1; i < zeilen; i++) {
      template.moveTo(0, i*zellenBreite);
      template.lineTo(breite,i*zellenBreite);
    }
    template.stroke();


    //Text

    //Wochentage
    String[] wochenTage = {"Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"};
    template.beginText();
    template.setFontAndSize(PdfDokument.schriftFettKursiv, schriftGroesse);
    for (int i=0; i < 7; i++) {
      float textBreite = PdfDokument.schriftFettKursiv.getWidthPoint(
        wochenTage[i], schriftGroesse);
      template.setTextMatrix((float) (zellenBreite*(i+0.5)-textBreite/2),
                             (float) (hoehe-schriftGroesse*3.1));
      template.showText(wochenTage[i]);
    }

    //Tage im Monat
    zeile = zeilen;
    spalte = ersterWochentag;
    for (int i=1; i <= tageInMonat; i++) {
      String text = Integer.toString(i);
      float textBreite =
        PdfDokument.schriftNormal.getWidthPoint(text, schriftGroesse / 2);

      template.setFontAndSize(PdfDokument.schriftNormal, schriftGroesse / 2);
      template.setTextMatrix((spalte+1f/6f)*zellenBreite-textBreite/2,
        (zeile-1f/6f)*zellenBreite-schriftGroesse/4+schriftGroesse/16);
      template.showText(text);

      kalender.set(Calendar.DAY_OF_MONTH, i);
      text = (String) hashtable.get(hashtableFormat.format(kalender.getTime()));
      if (text != null) {
        textBreite =
          PdfDokument.schriftNormal.getWidthPoint(text, schriftGroesse);
        float skalierung = 1;
        if (textBreite > zellenBreite-4) {
          skalierung = (zellenBreite-4) / textBreite;
          textBreite *= skalierung;
        }

        template.setHorizontalScaling(skalierung*100);
        template.setFontAndSize(PdfDokument.schriftNormal, schriftGroesse);
        template.setTextMatrix((spalte+0.5f)*zellenBreite-textBreite/2,
          (zeile-1)*zellenBreite+3);
        template.showText(text);
        template.setHorizontalScaling(100);
      }

      spalte++; if (spalte == 7) {spalte = 0; zeile--;}
    }
    template.endText();

    return template;
  }
}