/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.MitarbeiterListe;

/**
 * Dieses Interface repr�sentiert eine Factory f�r Benutzer.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public interface MitarbeiterFactory extends DatenbankzugriffFactory {

  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Mitarbeiter-Objekt
   * 
   * @param benutzer der Benutzer, der zu einem Mitarbeiter gemacht werden soll
   * @return das neue Mitarbeiter-Objekt
   */
  public Mitarbeiter erstelleNeu(Benutzer benutzer); 

  /**
   * Liefert eine Liste aller Mitarbeiter, die in der Datenbank
   * eingetragen sind
   */
  public MitarbeiterListe getAlleMitarbeiter();

  /**
   * Liefert eine Liste aller Mitarbeiter, die die �bergebene Berechtigung
   * besitzen 
   * @param berechtigung die n�tige Berechtigung
   */
  public MitarbeiterListe getAlleMitarbeiterMitBerechtigung(int berechtigung);
  
  /**
   * Liefert eine Liste aller Mitarbeiter, die die �bergebene Berechtigung
   * besitzen und noch aktiv sind
   * @param berechtigung die n�tige Berechtigung
   */
  public MitarbeiterListe getAktiveMitarbeiterMitBerechtigung(int berechtigung);
  
  /**
   * Liefert den aktuellen Mitarbeiter
   * @return den aktuellen Mitarbeiter
   */
  public Mitarbeiter getAktuellenMitarbeiter();
  
  /**
   * Setzt den aktuellen Mitarbeiter
   * @param mitarbeiter der neue aktuelle Mitarbeiter
   */
  public void setAktuellenMitarbeiter(Mitarbeiter mitarbeiter);

  /**
   * Bestimmt die Mitarbeiterid, die zu der �bergebenen
   * Benutzerid geh�rt.
   *
   * @param benutzerid die Benutzerid
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit dieser Benutzerid existiert
   * @return die zugeh�rige Mitarbeiterid
   */
  public int sucheBenutzer(int id) throws DatenNichtGefundenException;

  /**
   * Bestimmt die Mitarbeiternr, die zu dem �bergebenen
   * Mitarbeiter-Benutzernamen geh�rt.
   *
   * @param benutzername der Mitarbeiter-Benutzername
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit diesem Mitarbeiter-Benutzernamen existiert
   * @return die zugeh�rige Mitarbeiter
   */
  public int sucheMitarbeiterBenutzername(String benutzername) 
    throws DatenNichtGefundenException;
}