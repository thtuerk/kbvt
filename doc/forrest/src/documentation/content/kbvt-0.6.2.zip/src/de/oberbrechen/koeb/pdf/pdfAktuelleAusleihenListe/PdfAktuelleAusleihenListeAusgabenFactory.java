/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAktuelleAusleihenListe;

import java.awt.BorderLayout;

import javax.swing.*;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.datenbankzugriff.BenutzerFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.benutzerListenAuswahlPanel.BenutzerListenAuswahlPanel;

/**
* Diese Factory erstellt eine Ausgabe, die eine PDF-Liste aller 
* Mahnungen ausgibt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class PdfAktuelleAusleihenListeAusgabenFactory implements 
  AktuelleAusleihenListeAusgabenFactory, AusgabenFactory {

  private Ausgabe createAktuelleAusgabenListeAusgabe(
    final BenutzerListe benutzerListe) {
    return new Ausgabe() {
      public java.lang.String getName() {
        return "Aktuelle Ausleihen";
      }

      public java.lang.String getBeschreibung() {
        return "Liefert eine Liste der aktuellen Ausleihen ausw�hlbarer "+
          "Benutzer!";
      }

      public void run(javax.swing.JFrame hauptFenster) throws Exception {
        BenutzerListe liste = benutzerListe;
        if (liste == null) {
          if (hauptFenster != null) { 
            JPanel panel = new JPanel(new BorderLayout(10, 10));
            BenutzerListenAuswahlPanel auswahlPanel = 
              new BenutzerListenAuswahlPanel();
            panel.add(auswahlPanel, BorderLayout.CENTER);
            panel.add(new JLabel("Bitte w�hlen Sie die Benutzer aus, deren " +
              "aktuelle Ausleihen gedruckt werden sollen:"), BorderLayout.NORTH);
            auswahlPanel.sortiereNachSpalte(1, false);
            auswahlPanel.setVeraenderbar(true);
            int erg = JOptionPane.showConfirmDialog(hauptFenster, panel,
              "Benutzerauswahl", JOptionPane.OK_CANCEL_OPTION, 
              JOptionPane.PLAIN_MESSAGE);
  
            if (erg != JOptionPane.OK_OPTION) return; 
            liste = (BenutzerListe) auswahlPanel.getAuswahl();         
          } else {
            BenutzerFactory benutzerFactory =
              Datenbank.getInstance().getBenutzerFactory();
            liste = benutzerFactory.getAlleBenutzer();          
          }
        }
        liste.setSortierung(BenutzerListe.NachnameVornameSortierung);        
        new PdfAktuelleAusleihenListe(liste).zeige(false);
      }
    };
  }
      
  public String getName() {
    return "Aktuelle Ausleihen - Ausgabe";
  }

  public String getBeschreibung() {
    return null;
  }

  public void setParameter(String name, String wert) throws ParameterException {
    throw new ParameterException("Diese Factory unterst�tzt keine Parameter!");
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) {
    knoten.addAusgabe(createAktuelleAusgabenListeAusgabe(null));
  }

	public Ausgabe createAktuelleAusleihenListeAusgabe(
    BenutzerListe benutzerliste) {
		return createAktuelleAusgabenListeAusgabe(benutzerliste);
	}
}