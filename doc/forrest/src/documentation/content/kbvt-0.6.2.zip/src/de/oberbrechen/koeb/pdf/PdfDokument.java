/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import java.io.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse repr�sentiert ein allgemeines PDF-Dokument und bietet allgemeine
 * Methoden zur Bearbeitung desselben an.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.10 $
 */
public abstract class PdfDokument {

  public static BaseFont schriftNormal;
  public static BaseFont schriftFettKursiv;
  public static BaseFont schriftFett;

  static {
    try {
      schriftNormal = BaseFont.createFont(BaseFont.HELVETICA,
        BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
      schriftFett = BaseFont.createFont(BaseFont.HELVETICA_BOLD,
        BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
      schriftFettKursiv = BaseFont.createFont(BaseFont.HELVETICA_BOLDOBLIQUE,
        BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Initialisieren der Klasse PdfDokument!", true);
    }
  }

  /**
   * Schreibt das Dokument in die �bergebene Datei
   *
   * @param datei die Datei, in die das Dokument geschrieben werden soll
   * @throws Exception falls Probleme auftreten
   */
  public void schreibeInDatei(File datei) throws Exception {
    Document doc = new Document(PageSize.A4);
    PdfWriter pdfWriter = PdfWriter.getInstance(doc, new FileOutputStream(datei));
    doc.open();

    schreibeInDokument(pdfWriter, doc);

    doc.close();
  }

  /**
   * Gibt das Dokument im �bergebenen PdfWriter und dem �bergebenen Dokument
   * aus. Dieser Befehl kann benutzt werden, um verschiedene Dokumente
   * hintereinander in einer Datei auszugeben.
   *
   * @param writer der PdfWriter, in dem Ausgegebn werden soll
   * @throws Exception bei Problemen
   */
  public abstract void schreibeInDokument(PdfWriter writer, Document document)
    throws Exception;

  /**
   * Schreibt das Dokument in eine tempor�re Datei
   *
   * @return die Datei, in die das Dokument geschrieben wurde
   * @throws Exception bei Problemen
   */
  public File schreibeInTempDatei() throws Exception {
    File ausgabeDatei = File.createTempFile("temp", ".pdf");
    ausgabeDatei.deleteOnExit();
    schreibeInDatei(ausgabeDatei);
    return ausgabeDatei;
  }

  /**
   * Zeigt das �bergebene PDF-Dokument mit dem in der Konfigurationsdatei
   * eingestellten PDF-Viewer an
   *
   * @param pdf die Datei, die angezeigt werden soll
   * @param warten bestimmt, ob auf das Beenden des PDF-Viewers gewartet werden soll
   * @throws Exception falls ein Fehler beim Anzeigen auftritt
   */
  public static void zeigePdfDatei(File pdf, 
    boolean warten) throws Exception {
    MitarbeiterFactory mitarbeiterFactory =
      Datenbank.getInstance().getMitarbeiterFactory();
    ClientFactory clientFactory = Datenbank.getInstance().getClientFactory();
    EinstellungFactory einstellungFactory = 
      Datenbank.getInstance().getEinstellungFactory();
        
    Client benutzterClient = clientFactory.getBenutzenClient();
    Mitarbeiter mitarbeiter = mitarbeiterFactory.getAktuellenMitarbeiter();
    String befehl = einstellungFactory.getEinstellung(benutzterClient, mitarbeiter, 
        "de.oberbrechen.koeb.pdf.PdfDokument", 
        "PDFViewer").getWert(null);
    
    if (befehl == null || befehl.equals("")) {
      ErrorHandler.getInstance().handleError("Es ist kein PDF-Viewer konfiguriert. Daher " +        "kann keine PDF-Datei angezeigt werden!", false); 
      return;
    }

    Process zeigeProcess = Runtime.getRuntime().exec(befehl+" " + pdf);
    if (warten) zeigeProcess.waitFor();
  }

  /**
   * Schreibt das Dokument in eine tempor�re PDF-Datei und zeigt diese an.
   * Die tempor�re PDF-Datei wird sofort nach Programmende gel�scht. Erfolgt
   * das Anzeigen gegen Ende des Programms, kann es passieren, dass die
   * tempor�re Datei gel�scht wird, bevor der PDF-Viewer sie �ffnen kann.
   * In einem solchen Fall sollte die Warte-Option verwendet werden.
   *
   * @param Mitarbeiter der Mitarbeiter
   * @param warten bestimmt, ob auf das Beenden des PDF-Viewers gewartet werden soll
   * @throws IOException bei Problemen beim Zugriff aus die tempor�re Datei
   * @throws Exception falls ein Fehler beim Anzeigen auftritt
   */
  public void zeige(boolean warten) throws Exception {
    File ausgabeDatei = schreibeInTempDatei();
    zeigePdfDatei(ausgabeDatei, warten);
  }
    
}