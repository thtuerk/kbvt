/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenstrukturen.EANListe;
import de.oberbrechen.koeb.datenstrukturen.ISBN;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;

/**
 * Dieses Interface repr�sentiert ein Medium der B�cherei. 
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.18 $
 */
public interface Medium extends Datenbankzugriff {

  /**
   * Liefert den Titel des Medium
   * @return Titel des Mediums
   */
  public String getTitel();

  /**
   * Setzt den Titel des Medium
   * @param titel der neue Titel des Mediums
   */
  public void setTitel(String titel);

  /**
   * Liefert die ISBN-Nummer des Medium
   * @return ISDN-Nummer des Mediums
   */
  public ISBN getISBN();

  /**
   * Setzt die ISDN-Nummer des Medium
   * @param isdn die neue ISDN-Nummer des Mediums
   */
  public void setISBN(ISBN isbn);

  /**
   * Liefert den Autor des Medium
   * @return Autor des Mediums
   */
  public String getAutor();

  /**
   * Setzt den Autor des Medium
   * @param autor der neue Autor des Mediums
   */
  public void setAutor(String autor);

  /**
   * Liefert die Beschreibung des Medium
   * @return Beschreibung des Mediums
   */
  public String getBeschreibung();

  /**
   * Setzt die Beschreibung des Medium
   * @param beschreibung die neue Beschreibung des Mediums
   */
  public void setBeschreibung(String beschreibung);

  /**
   * Liefert den Typ des Medium
   * @return Typ des Mediums
   */
  public Medientyp getMedientyp();

  /**
   * Setzt den Typ des Medium
   * @param typ der neue Typ des Mediums
   */
  public void setMedientyp(Medientyp typ);

  /**
   * Liefert die Nr des Medium
   * @return Nr des Mediums
   */
  public String getMedienNr();

  /**
   * Setzt die Nr des Medium
   * @param nr die neue Nr des Mediums
   */
  public void setMediennr(String nr);
    
  /**
   * Liefert die zus�tzlichen EAN-Nummern des Medium. Ein Medium besitzt 
   * generell zwei Arten von EAN-Nummern: einerseits besitzt jedes Medium eine
   * automatisch aus seiner ID genierte EAN und evtl. zus�tzliche, explizit
   * angegebene EANs. Hier werden nur die explizit gesetzten EANs geliefert.
   * @return eine Liste der EAN-Nummern des Mediums
   */
  public EANListe getEANs();

	/**
   * Setzt die zus�tzlichen EAN-Nummern des Medium. Ein Medium besitzt 
   * generell zwei Arten von EAN-Nummern: einerseits besitzt jedes Medium eine
   * automatisch aus seiner ID genierte EAN und evtl. zus�tzliche, explizit
   * angegebene EANs. Hier werden die explizit gesetzten EANs gesetzt.
   * @param ean die neue EAN-Nr des Mediums
   */
  public void setEANs(EANListe ean);

  /**
   * Liefert die Medienanzahl des Mediums
   * @return die Medienanzahl des Mediums
   */
  public int getMedienAnzahl();

  /**
   * Setzt die Medienanzahl des Mediums
   * @param anzahl die neue Medienanzahl des Mediums
   */
  public void setMedienAnzahl(int anzahl);

  /**
   * Liefert das Einstellungsdatum des Mediums
   * @return Einstellungsdatum des Mediums
   */
  public Date getEinstellungsdatum();
  
  /**
   * Setzt das Einstellungsdatum des Mediums
   * @param datum das neue Einstellungsdatum des Mediums
   */
  public void setEinstellungsdatum(Date datum);

  /**
   * Liefert das Datum, an dem das Medium aus dem Bestand entfernt wurde.
   * <code>null</code> wird f�r noch im Bestand befindliche Medien
   * zur�ckgeliefert.
   * @return das Datum, an dem das Medium aus dem Bestand entfernt wurde
   */
  public Date getEntfernungsdatum();

  /**
   * Setzt das Datum, an dem das Medium aus dem Bestand entfernt wurde.
   * @param datum das neue Entfernungsdatum des Mediums
   */
  public void setEntfernungsdatum(Date datum);

  /**
   * Liefert die Systematiken, zu denen das Medium direkt geh�rt
   * @return eine Liste aller Systematiken, zu denen das Medium direkt geh�rt
   */
  public SystematikListe getSystematiken();

  /**
   * Liefert die Systematiken, zu denen das Medium direkt oder indirekt geh�rt
   * @return eine Liste aller Systematiken, zu denen das Medium geh�rt
   */
  public SystematikListe getSystematikenMitUntersystematiken();

  /**
   * Liefert die Systematiken, zu denen das Medium direkt geh�rt.
   * Diese werden - durch Kommata getrennt - in einem String zur�ckgegeben.
   * @return eine kommatagetrennten String aller Systematiken, 
   *   zu denen das Medium direkt geh�rt
   */
  public String getSystematikenString();

  /**
   * Setzt die Systematiken, zu denen das Medium direkt geh�rt
   * @param systematiken die neue Liste aller Systematiken, 
   *   zu denen das Medium direkt geh�rt
   */
  public void setSystematiken(SystematikListe systematiken);

  /**
   * Pr�ft, ob das Medium zur �bergebenen Systematik geh�rt. Dabei wird nicht
   * nur getestet, ob das Medium direkt zur �bergebenen Systematik geh�rt, 
   * sondern es werden auch alle Untersystematiken �berpr�ft.
   * 
   * @param systematik die zu testenden Systematiken
   * @return <code>TRUE</code> gdw. das Medium zur �bergebenen Systematik
   *   geh�rt.
   */
  public boolean gehoertZuSystematik(Systematik systematik) 
    throws DatenbankInkonsistenzException;

  /**
   * Pr�ft, ob das Medium zur einer der �bergebenen Systematiken geh�rt. 
   * Dabei wird nicht nur getestet, ob das Medium direkt zu einer der
   * �bergebenen Systematiken geh�rt, 
   * sondern es werden auch alle Untersystematiken �berpr�ft.
   * 
   * @param systematiken die zu testenden Systematiken
   * @return <code>TRUE</code> gdw. das Medium zur �bergebenen Systematik
   *   geh�rt.
   */
  public boolean gehoertZuSystematik(SystematikListe systematiken); 
  
  /**
   * �berpr�ft, ob das Medium noch im Bestand ist
   * @return <code>TRUE</code> falls das Medium noch im Bestand ist<br>
   * <code>FALSE</code> falls es bereits aus dem Bestand entfernt wurde
   */
  public boolean istNochInBestand();

  /**
   * Liefert die Anzahl der Tage, vor denen das Medium eingestellt wurde.
   * @return die Anzahl der Tage, vor denen das Medium eingestellt wurde.
   */
  public int getEinstellungsdauerInTagen();
}