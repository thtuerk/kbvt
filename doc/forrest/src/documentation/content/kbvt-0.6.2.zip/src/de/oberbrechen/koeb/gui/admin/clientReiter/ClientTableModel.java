/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.clientReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnvollstaendigeDatenException;

import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.ClientListe;
import de.oberbrechen.koeb.gui.admin.Main;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Clients.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $
*/

public class ClientTableModel extends AbstractTableModel {

  private Main hauptFenster;
	private ClientListe daten;
  
  public ClientTableModel(Main hauptFenster) {
    this.hauptFenster = hauptFenster;
  }
  
  public void refresh() {
    ClientFactory clientFactory =
      Datenbank.getInstance().getClientFactory();
    daten = clientFactory.getAlleClients();
    daten.setSortierung(ClientListe.NameSortierung);
    fireTableDataChanged();
  }
  
  public ClientListe getDaten() {
    return daten;
  } 
    
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "ID";
    if (columnIndex == 1) return "Name";
    if (columnIndex == 2) return "IP";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return Integer.class;
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Client gewaehlterClient = (Client) daten.get(rowIndex);
    
    if (columnIndex == 0) {
      return new Integer(gewaehlterClient.getId());
    } else if (columnIndex == 1) {
      return gewaehlterClient.getName();
    } else if (columnIndex == 2) {
      return gewaehlterClient.getIP();
    }
    
    return "nicht definierte Spalte";
  }

  public Client getClient(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Client) daten.get(rowIndex);
  }
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return columnIndex > 0;
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    String oldValue = null;
    Client client = getClient(rowIndex);
    try {      
      if (columnIndex == 1) {
        oldValue = client.getName();
        client.setName(aValue.toString());         
        client.save();
      } else if (columnIndex == 2) {
        oldValue = client.getIP();
        client.setIP(aValue.toString());
        client.save();          
      } else {
        throw new IndexOutOfBoundsException();
      }
      this.fireTableDataChanged();
      return;
    } catch (UnvollstaendigeDatenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Unvollst�ndige Daten!",
        JOptionPane.ERROR_MESSAGE);      
    }

    if (columnIndex == 1) {
      client.setName(oldValue);         
    } else if (columnIndex == 2) {
      client.setIP(oldValue);
    }
    this.fireTableDataChanged();
  }

}
