/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import java.text.Collator;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
* Diese Klasse repr�sentiert die Einstellungen, die abh�ngig von der
* jeweiligen B�cherei sind. Dies sind die Ausleihordnung,
* Standardwohnort der Benutzer u.�.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.12 $
*/

public abstract class Buecherei {

  private static Buecherei instance;
  protected Comparator medienNrComparator = null;
  
  static {
    EinstellungFactory einstellungFactory = 
      Datenbank.getInstance().getEinstellungFactory();
      
    Einstellung buechereiEinstellung = einstellungFactory.getEinstellung(
      "de.oberbrechen.koeb.einstellungen.Buecherei","instanz");
      
    BuechereiFactory buechereiFactory = (BuechereiFactory)
      buechereiEinstellung.getWertObject(BuechereiFactory.class, 
      KonfigurierbareBuechereiFactory.class);
   
    instance = buechereiFactory.createBuecherei();
  }
    
  
  /**
   * Liefert eine Instanz der aktuell konfigurierten Buecherei.
   * @return eine Instanz der aktuell konfigurierten Buecherei
   */
  public static Buecherei getInstance() {
    return instance;
  }

  /**
   * Liefert die Ausleihordnung der Buecherei.
   * @return die Ausleihordnung der Buecherei
   */
  public abstract Ausleihordnung getAusleihordnung();

  /**
   * Bestimmt, ob die B�cherei am �bergebenen Datum ge�ffnet hat
   * @param datum das Datum, das �berpr�ft werden soll
   * @return <code>true</code> gdw. die B�cherei am �bergebenen Datum ge�ffnet
   *   hat
   */
  public abstract boolean istGeoeffnet(Calendar datum);

  /**
   * Bestimmt, ob die B�cherei am �bergebenen Datum ge�ffnet hat
   * @param datum das Datum, das �berpr�ft werden soll
   * @return <code>true</code> gdw. die B�cherei am �bergebenen Datum ge�ffnet
   *   hat
   */
  public boolean istGeoeffnet(Date datum) {
    Calendar neuerCalendar = Calendar.getInstance();
    neuerCalendar.setTime(datum);
    return istGeoeffnet(neuerCalendar);
  }
  
  /**
   * Liefert das erste Datum nach dem �bergebenen Datum, an dem
   * die B�cherei ge�ffnet hat.
   * @param beginn das Datum, ab dem gesucht wird
   * @return das erste �ffnungsdatum nach dem �bergebenen Datum
   */
  public Date getNaechstesOeffnungsdatum(Date beginn) {
    Calendar neuerCalendar = Calendar.getInstance();
    neuerCalendar.setTime(beginn);
    
    while (!istGeoeffnet(neuerCalendar)) {
      neuerCalendar.add(Calendar.DATE, 1);
    }
    
    return neuerCalendar.getTime();    
  }

  /**
   * Liefert das n�chste Datum, an dem
   * die B�cherei ge�ffnet hat.
   * @return das erste �ffnungsdatum nach dem �bergebenen Datum
   */
  public Date getNaechstesOeffnungsdatum() {
    return getNaechstesOeffnungsdatum(new Date());
  }

  /**
   * Berechnet die Kosten f�r einen Internetzugang der �bergebenen Dauer.
   * @param dauer die Dauer des Internetzugangs in Sekunden
   * @return die Kosten f�r diesen Internetzugang
   */
  public abstract double berechneInternetzugangsKosten(int dauer);

  /**
   * Liefert in Abh�ngigkeit vom Einstellungsdatum und vom Medientyp
   * eines Mediums einen Vorschlag f�r eine Mediennr.
   * @param medientyp der Medientyp des Mediums
   * @param einstellungsDatum das Einstellungsdatum des Mediums
   * @return die vorgeschlagene Mediennr.
   */
  public abstract String getStandardMedienNr(Medientyp medientyp, Date einstellungsDatum);
  
  /**
   * Liefert einen Comparator, der in der Lage ist, zwei Medien anhand ihrer
   * Mediennummer miteinander zu vergleichen
   * @return den Comparator
   */
  public Comparator getMedienNrComparator() {
    if (medienNrComparator == null) 
      medienNrComparator = erstelleMedienNrComparator();
    
    return medienNrComparator;
  }

  /**
   * Erstellt einen neuen Comparator, der in der Lage ist, zwei Medien anhand ihrer 
   * Mediennummer miteinander zu vergleichen. Dieser wird zwischengespeichert 
   * und kann mittels getMedienNrComparator abgefragt werden. 
   * @return den Comparator
   */  
  protected Comparator erstelleMedienNrComparator() {
    return Collator.getInstance();
  }
  
}