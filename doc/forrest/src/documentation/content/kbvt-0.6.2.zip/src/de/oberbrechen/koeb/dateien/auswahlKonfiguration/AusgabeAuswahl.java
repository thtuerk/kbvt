/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;

import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;

/**
 * Diese Klasse repr�sentiert eine Ausgabe, die auf einer
 * Auswahl basiert. Dies ist eine Auswahl mit zus�tzlichen Informationen. 
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public class AusgabeAuswahl {
    
  String titel;
  int level;
  Auswahl auswahl;
  
  public AusgabeAuswahl(String titel, int level, Auswahl auswahl) {
    this.titel = titel;
    this.level = level;
    this.auswahl = auswahl;
  }
  
  /**
   * Liefert die Auswahl
   * @return die Auswahl
   */
  protected Auswahl getAuswahl() {
    return auswahl;
  }

  /**
   * Liefert den Level der Ausgabe. Dabei handelt es sich um
   * einen speziellen Parameter, der f�r verschiedene 
   * Zwecke genutzt werden kann, je nachdem in welchem Zusammenhang
   * die Ausgabe ausgewertet wird.
   * @return den Level
   */
  public int getLevel() {
    return level;
  }
  
  /**
   * Liefert den Titel der Ausgabe
   * @return den Titel
   */
  public String getTitel() {
    return titel;
  }
  
  public String toString() {
    return toDebugString();
  }
  
  public String toDebugString() {
    StringBuffer buffer = new StringBuffer();
    buffer.append(titel+" ("+level+")\n");
    buffer.append(auswahl.toDebugString());
    return buffer.toString();
  }
  
  public boolean istAusleihzeitraumAuswahl() {
    return auswahl.istAusleihzeitraumAuswahl();
  }

  public boolean istMediumAuswahl() {
    return auswahl.istMediumAuswahl();
  }
  
  public boolean istBenutzerAuswahl() {
    return auswahl.istBenutzerAuswahl();
  }
  
  public MedienListe bewerte(MedienListe eingabe) {
    if (!istMediumAuswahl()) 
      throw new IllegalArgumentException("Ausgabe '"+getTitel()+"' ist keine "+
          "Medien-Ausgabe!");
    
    return getAuswahl().bewerte(eingabe);
  }
  
  /**
   * Bestimmt, ob das �bergebene Medium in der Ausgabe enthalten ist.
   * @param medium
   * @return ob das �bergebene Medium in der Ausgabe enthalten ist
   */
  public boolean bewerte(Medium medium) {
    AuswahlObject auswahlObject = new AuswahlObject();
    auswahlObject.setDaten(medium);
    return getAuswahl().istInAuswahl(auswahlObject);
  }

  /**
   * Bestimmt, ob der �bergebene Benutzer in der Ausgabe enthalten ist.
   * @param benutzer
   * @return ob der �bergebene Benutzer in der Ausgabe enthalten ist
   */
  public boolean bewerte(Benutzer benutzer) {
    AuswahlObject auswahlObject = new AuswahlObject();
    auswahlObject.setDaten(benutzer);
    return getAuswahl().istInAuswahl(auswahlObject);
  }  
}
