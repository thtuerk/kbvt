/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTabelle;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import de.oberbrechen.koeb.pdf.*;

/**
 * Diese Klasse dient dazu eine Tabelle einfach als PDF-Datei auszugeben. Die
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class PdfTabelleDokument extends ErweitertesPdfDokumentMitSeitenKopfFuss {

  private PdfTabelle tabelle;
  private boolean zeigeSpaltenUeberschriftenErsteSeite;
  private boolean zeigeSpaltenUeberschriften;

  public PdfTabelleDokument(String titel, PdfTabelle tabelle) {
    this(titel, tabelle, null, null, null, true, true);
  }
  
  public PdfTabelleDokument(String titel, PdfTabelle tabelle,
                    SeitenKopfFuss seitenKopfErsteSeite,
                    SeitenKopfFuss seitenKopf, SeitenKopfFuss seitenFuss,
                    boolean zeigeSpaltenUeberschriftenErsteSeite,
                    boolean zeigeSpaltenUeberschriften) {
    this.titel = titel;
    this.tabelle = tabelle;
    this.seitenKopf = seitenKopf;

    if (seitenFuss != null) {
      this.seitenFuss = seitenFuss;  
    } else {
      this.seitenFuss = 
        new StandardSeitenFuss(StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    }
    
    if (seitenKopfErsteSeite != null) {
      this.seitenKopfErsteSeite = seitenKopfErsteSeite;
    } else {
      this.seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
        titel, null, null, this.seitenKopf);      
    }

    this.zeigeSpaltenUeberschriften = zeigeSpaltenUeberschriften;
    this.zeigeSpaltenUeberschriftenErsteSeite = zeigeSpaltenUeberschriftenErsteSeite;
  }  

  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter writer, Document doc) 
    throws Exception {

    PdfContentByte pdf =  writer.getDirectContent();
    int aktuelleSeitenNr = 1;
    
    tabelle.init(this);
    while (tabelle.hasNextTemplate()) {
      float verfuegbarerPlatz = this.getSeitenHoehe()-
        this.getSeitenRandObenMitKopf(aktuelleSeitenNr)-
        this.getSeitenRandUntenMitFuss(aktuelleSeitenNr)+7;
      
      boolean zeigeSpaltenUeberschriftenAufAktuellerSeite;
      if (aktuelleSeitenNr == 1) {
        zeigeSpaltenUeberschriftenAufAktuellerSeite = zeigeSpaltenUeberschriftenErsteSeite;
      } else {
        zeigeSpaltenUeberschriftenAufAktuellerSeite = zeigeSpaltenUeberschriften;        
      }

      PdfTemplate template = tabelle.getNextTemplate(zeigeSpaltenUeberschriftenAufAktuellerSeite, verfuegbarerPlatz, this, pdf);
      
      float verschiebung = verfuegbarerPlatz - template.getHeight() - 7;
      if (verschiebung > 10) verschiebung = 0; 
      if (aktuelleSeitenNr == 1) {
        seitenKopfPositionErsteSeite = verschiebung;
      } else {
        seitenKopfPosition = verschiebung;
      }        
      
      schreibeSeitenKopfFuss(aktuelleSeitenNr, pdf);
      pdf.addTemplate(template, 0, this.getSeitenHoehe()-
        getSeitenRandObenMitKopf(aktuelleSeitenNr)-verschiebung-template.getHeight());
      
      if (tabelle.hasNextTemplate()) {
        doc.newPage();
        aktuelleSeitenNr++;
      }
    }
    
    finalisiere(aktuelleSeitenNr);
  }
}