/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.mahnungenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import javax.swing.table.AbstractTableModel;
import java.text.DecimalFormat;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Mahnungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class MahnungenTableModel extends AbstractTableModel {

  private static DecimalFormat kostenFormat = new DecimalFormat("0.00 EUR");
  private MahnungenListe daten;

  /**
   * Erstellt ein neues Modell
   */
  public MahnungenTableModel() {
    daten = new MahnungenListe();
    daten.setSortierung(MahnungenListe.BenutzerSortierung);    
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 5;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Benutzer";
    if (columnIndex == 1) return "Tel.-Nr.";
    if (columnIndex == 2) return "Anzahl";
    if (columnIndex == 3) return "max. �berziehung";
    if (columnIndex == 4) return "Kosten";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Mahnung gewaehlteMahnung = (Mahnung) daten.get(rowIndex);

    switch (columnIndex) {
      case 0:
        return gewaehlteMahnung.getBenutzer().getNameFormal();
      case 1:
        return gewaehlteMahnung.getBenutzer().getTel();
      case 2:
        return Integer.toString(gewaehlteMahnung.getAnzahlGemahnteAusleihen());
      case 3:
        int ueberzogeneTage = gewaehlteMahnung.getMaxUeberzogeneTage();
        int wertZumRunden = (ueberzogeneTage+1)*2/7;
        double erg = (double) wertZumRunden / 2;
        return erg+" W.";
      case 4:
        return kostenFormat.format(gewaehlteMahnung.getMahngebuehren());
    }
    return "nicht definierte Spalte";
  }

  /**
   * Liefert die Mahnungung, die in der angebenen
   * Zeile dargestellt wird
   * @param rowIndex die Zeile
   */
  public Mahnung getMahnung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    return (Mahnung) daten.get(rowIndex);
  }

  /**
   * Liefert die Daten des Modells
   */
  public MahnungenListe getDaten() {
    return daten;
  }

  /**
   * L�d erneut die aktuellen Mahnungen
   */
  public void reload() {
    MahnungFactory mahnungFactory =
      Datenbank.getInstance().getMahnungFactory();
    BenutzerListe benutzer = mahnungFactory.getAlleBenutzerMitMahnung();

    daten.clear();
    for (int i=0; i < benutzer.size(); i++) {
      daten.add(mahnungFactory.erstelleMahnungFuerBenutzer(
        (Benutzer) benutzer.get(i)));
    }

    fireTableDataChanged();
  }
}
