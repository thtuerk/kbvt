/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.medientypReiter;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.MedientypSchonVergebenException;
import de.oberbrechen.koeb.gui.admin.AdminMainReiter;
import de.oberbrechen.koeb.gui.admin.Main;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Medientypen in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.7 $
 */

public class MedientypReiter extends JPanel
  implements AdminMainReiter {
  
  private MedientypTableModel medientypTableModel;
  private JTable medientypTable;
  private Main hauptFenster;
  
  public MedientypReiter(Main parentFrame) {
    hauptFenster = parentFrame;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Medienliste
    medientypTable = new JTable();
    medientypTableModel = new MedientypTableModel(hauptFenster);
    medientypTable.setModel(medientypTableModel);
    medientypTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    medientypTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    medientypTable.registerKeyboardAction( new ActionListener() {
       public void actionPerformed(ActionEvent e) {
         removeMedientyp();
      }}, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), JComponent.WHEN_FOCUSED);
    TableColumnModel columnModel = medientypTable.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(50);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(250);

    JScrollPane jScrollPane1 = new JScrollPane(medientypTable);
    jScrollPane1.setMinimumSize(new Dimension(150,150));
    jScrollPane1.setPreferredSize(new Dimension(150,150));
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));
  
    //Buttonpanel
    JPanel buttonPanel = new JPanel();
    JButton neuButton = new JButton("Neuen Medientyp anlegen");
    neuButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        neuenMedientyp();
      }});
    JButton loeschenButton = new JButton("Medientyp l�schen");
    loeschenButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        removeMedientyp();
      }});
    
    buttonPanel.setLayout(new GridLayout(1, 2, 10, 0));
    buttonPanel.add(neuButton);
    buttonPanel.add(loeschenButton);
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));    
     
    //Alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(jScrollPane1, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));    
  }

  
  protected void neuenMedientyp() {
    String erg = JOptionPane.showInputDialog(hauptFenster, 
      "Bitte den Namen des neuen Medientyps angeben:",
      "Neuen Medientyp anlegen", JOptionPane.OK_CANCEL_OPTION);
    if (erg == null) return;
    if (erg.equals("")) return;
    try {
      MedientypFactory medientypFactory =
        Datenbank.getInstance().getMedientypFactory();
      Medientyp medientyp = medientypFactory.erstelleNeu();
      medientyp.setName(erg);
      medientyp.save();
      medientypTableModel.getDaten().add(medientyp);
      medientypTableModel.fireTableDataChanged();
    } catch (MedientypSchonVergebenException e) {
      JOptionPane.showMessageDialog(hauptFenster, "Ein Medientyp mit dem Namen '"+
        erg+"' existiert bereits!",
        "Medientyp bereits vergeben!", JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * L�scht den in der Tabelle markierte Medientyp 
   * nach einer Sicherheitsabfrage aus der Datenbank.  
   */
  protected void removeMedientyp() {
    int selectedRow = medientypTable.getSelectedRow();
    if (selectedRow != -1) {
      Medientyp medientyp = medientypTableModel.getMedientyp(selectedRow);
      try {
        int erg = JOptionPane.showConfirmDialog(hauptFenster, 
          "Soll der Medientyp '"+medientyp.getName()+
          "' wirklich gel�scht werden?",
          "Medientyp l�schen?", JOptionPane.YES_NO_OPTION);
        if (erg != JOptionPane.YES_OPTION) return;
  
        medientyp.loesche();
        medientypTable.clearSelection();
        medientypTableModel.getDaten().remove(selectedRow);
        medientypTableModel.fireTableDataChanged();
      } catch (DatenbankInkonsistenzException e) {
        JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
          "Datenbank Inkonsistenz!", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void aktualisiere() {
    refresh();
  }

  public void refresh() {
    medientypTableModel.refresh();
    medientypTable.doLayout();
  }
  
  public JMenu getMenu() {
    return null;
  }  
  
  public void focusLost() {
  }
}