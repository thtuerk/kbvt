/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben;

import javax.swing.JFrame;
import de.oberbrechen.koeb.ausgaben.Ausgabe;

/**
* Diese Klasse ist eine AusgabenFactory, es erm�glicht Ausgaben per
* Reflektion zu erstellen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class AllgemeineAusgabenFactory implements AusgabenFactory {

  String name = null;
  String ausgabe = null;
  
  public String getName() {
    return "Ausgabe";
  }

  public String getBeschreibung() {
    return "Wrapper, die eine beliebige Ausgabe mit parameterlosem Konstruktor erzeugt."; 
  }

  public void setParameter(String name, String wert) throws
    ParameterException { 
    if (name == null) throw new ParameterException("Parametername darf nicht NULL sein!");
    if (name.equals("name")) {
      this.name = wert;
    } else if (name.equals("ausgabe")) {
      this.ausgabe = wert;
    } else {
      throw new ParameterException("Unbekannter Paramter '"+name+"'!");
    }
  }
    
  public void addToKnoten(AusgabenTreeKnoten knoten) 
    throws ParameterException {
    if (ausgabe == null) throw new ParameterException(
      "Der Parameter 'ausgabe' mu� gesetzt werden!");
      
    final Ausgabe neueAusgabe;
    try {
      neueAusgabe = (Ausgabe) Class.forName(ausgabe).newInstance();
    } catch (Exception e) {
      throw new ParameterException("'"+ausgabe+"' kann nicht als Name " +        "einer Ausgabe mit parameterlosem Konstruktor interpretiert werden!\n\n"+e.getMessage());
    }
    
    knoten.addAusgabe(new Ausgabe() {

      public String getName() {
        if (name != null) return name;
        return neueAusgabe.getName();
      }

      public String getBeschreibung() {
        return neueAusgabe.getBeschreibung();
      }

      public void run(JFrame hauptFenster) throws Exception {
        neueAusgabe.run(hauptFenster);
      }
    });    
  }
}