/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAusleihStatistik;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfigurationAusleihzeitraumTagesDaten;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfigurationDaten;
import de.oberbrechen.koeb.datenbankzugriff.AusleiheFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Diese Klasse erstellt eine StatistikTabellenModell, das Ausleihstatistiken
 * f�r ein Jahr oder einen Monat repr�sentiert.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class AusleihStatistikTabellenModell extends TabellenModell {

  private static SimpleDateFormat dateFormat = new SimpleDateFormat("EE, d. MMM. yyyy");
  private static SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM");  
  
  Vector daten;
  Vector zeilenTitel;
  AuswahlKonfigurationAusleihzeitraumTagesDaten statistik;
  
  /**
   * Erstellt ein neues StatistikTabellenModell f�r
   * das �bergebene Jahr. Die n�tigen Daten werden im
   * Gegensatz zum Entsprechenden Konstruktor vorher aus der Datenbank
   * geladen und bewertet.
   */
  public static AusleihStatistikTabellenModell createStatistikTabellenModell(
      AuswahlKonfiguration statistik, 
      int jahr, PdfTemplateDokument dokument) {
    if (statistik == null)
      throw new NullPointerException("Es muss eine Statistik �bergeben werden!");
    
    AusleiheFactory ausleiheFactory =
      Datenbank.getInstance().getAusleiheFactory();
    AusleihzeitraumListe liste = ausleiheFactory.getGetaetigteAusleihzeitraeumeInZeitraum(
        new Zeitraum(jahr));
    AuswahlKonfigurationDaten daten = statistik.bewerte(liste);    
    daten.ueberpruefeChecks();    
    AuswahlKonfigurationAusleihzeitraumTagesDaten tagesDaten =
      new AuswahlKonfigurationAusleihzeitraumTagesDaten(daten);        
    
    return new AusleihStatistikTabellenModell(tagesDaten, jahr, dokument);
  }
  
  /**
   * Erstellt ein neues StatistikTabellenModell f�r den �bergebenen
   * Monat und das �bergebene Jahr. Die n�tigen Daten werden im
   * Gegensatz zum Entsprechenden Konstruktor vorher aus der Datenbank
   * geladen und bewertet.
   * @param statistik
   * @param monat
   * @param jahr
   * @param dokument
   * @return
   */
  public static AusleihStatistikTabellenModell createStatistikTabellenModell(
      AuswahlKonfiguration statistik, 
      int monat, int jahr, PdfTemplateDokument dokument) {
    
    AusleiheFactory ausleiheFactory =
      Datenbank.getInstance().getAusleiheFactory();
    AusleihzeitraumListe liste = ausleiheFactory.getGetaetigteAusleihzeitraeumeInZeitraum(
        new Zeitraum(monat, jahr));
    AuswahlKonfigurationDaten daten = statistik.bewerte(liste);    
    AuswahlKonfigurationAusleihzeitraumTagesDaten tagesDaten =
      new AuswahlKonfigurationAusleihzeitraumTagesDaten(daten);
    
    daten.ueberpruefeChecks();        
    return new AusleihStatistikTabellenModell(tagesDaten, monat, jahr, dokument);
  }

  /**
   * Erstellt ein TabellenModell f�r die �bergebene Statistik und das �bergebene
   * Jahr. Es werden f�r jeden Monat alle Daten aufsummiert sowie eine 
   * Gesamtsumme ausgegeben. Das �bergebene Dokument wird gen�tigt, um die
   * zur Verf�gung stehende Seitenbreite zu bestimmen und die Spalten 
   * dementsprechend zu initialisieren. Soll das Spaltenmodell f�r Ausgaben
   * in mehreren Dokumenten mit unterschiedlicher Breite benutzt werden, so
   * kann diese Initialisierung mittels initSpalten wiederholt werden.
   * @param statistik
   * @param jahr
   * @param dokument
   */
  public AusleihStatistikTabellenModell(
      AuswahlKonfigurationAusleihzeitraumTagesDaten statistik, 
      int jahr,
      PdfTemplateDokument dokument) {
    super(statistik.getAusgabenAnzahl()+1, true);
    
    Calendar calendar = Calendar.getInstance();
    int[] summe = new int[statistik.getAusgabenAnzahl()];
    int[][] monatDaten = new int[12][statistik.getAusgabenAnzahl()];    
    for (int i = 0; i < statistik.getTageAnzahl(); i++) {
      calendar.setTime(statistik.getTag(i));
      if (calendar.get(Calendar.YEAR) == jahr) {
        int monat = calendar.get(Calendar.MONTH);
        for (int j=0; j < statistik.getAusgabenAnzahl(); j++) {
          monatDaten[monat][j] += statistik.getWert(i, j);
          summe[j] += statistik.getWert(i, j);            
        }
      }
    }
    
    zeilenTitel = new Vector();
    daten = new Vector();
    int startMonat=1;
    int endMonat=12;
    if (!arrayLeer(summe)) {
      while (arrayLeer(monatDaten[startMonat-1]))
        startMonat++;
      while (arrayLeer(monatDaten[endMonat-1]))
        endMonat--;
    }
    
    for (int i=startMonat-1; i < endMonat; i++) {      
      zeilenTitel.add(getMonatName(i+1));
      daten.add(monatDaten[i]);
    }    
    zeilenTitel.add("Summe");
    daten.add(summe);

    this.statistik = statistik;            
    initSpalten(dokument);
  }
  
  /**
   * Bestimmt, ob alle Werte des Arrays 0 sind.
   * @return
   */
  private boolean arrayLeer(int[] array) {
    for (int i=0; i < array.length; i++) 
      if (array[i] != 0) return false;
      
    return true;
  }
  
  /**
   * Erstellt ein TabellenModell f�r die �bergebene Statistik und den �bergebenen 
   * Monat und das �bergebene Jahr. Das �bergebene Dokument wird gen�tigt, um die
   * zur Verf�gung stehende Seitenbreite zu bestimmen und die Spalten 
   * dementsprechend zu initialisieren. Soll das Spaltenmodell f�r Ausgaben
   * in mehreren Dokumenten mit unterschiedlicher Breite benutzt werden, so
   * kann diese Initialisierung mittels initSpalten wiederholt werden.
   * @param statistik
   * @param monat
   * @param jahr
   * @param dokument
   */
  public AusleihStatistikTabellenModell(
      AuswahlKonfigurationAusleihzeitraumTagesDaten statistik, 
      int monat, int jahr,
      PdfTemplateDokument dokument) {
    super(statistik.getAusgabenAnzahl()+1, true);
    
    Calendar calendar = Calendar.getInstance();
    zeilenTitel = new Vector();
    daten = new Vector();
    int[] summe = new int[statistik.getAusgabenAnzahl()];
    for (int i = 0; i < statistik.getTageAnzahl(); i++) {
      calendar.setTime(statistik.getTag(i));
      if (calendar.get(Calendar.MONTH) == monat-1 && calendar.get(Calendar.YEAR) == jahr) {
        int[] aktuelleDaten = new int[statistik.getAusgabenAnzahl()];
        for (int j=0; j < statistik.getAusgabenAnzahl(); j++) {
          aktuelleDaten[j] = statistik.getWert(i, j);
          summe[j] += statistik.getWert(i, j);            
        }
        zeilenTitel.add(dateFormat.format(statistik.getTag(i)));          
        daten.add(aktuelleDaten);
      }
    }
    zeilenTitel.add("Summe");
    daten.add(summe);

    this.statistik = statistik;        
    
    initSpalten(dokument);
  }
  
  private String getMonatName(int monat) {
    Calendar monatKalender = Calendar.getInstance();
    monatKalender.set(2000, monat-1, 1);
    return monatDateFormat.format(monatKalender.getTime());    
  }
    
  private void initSpalten(PdfTemplateDokument dokument) {    
    float verfuegbareBreite = dokument.getSeitenBreite()-dokument.getSeitenRandLinks()-
    dokument.getSeitenRandRechts();
    float benoetigteBreite = 25*statistik.getAusgabenAnzahl()+125;
    float spaltenBreite = 25*(verfuegbareBreite/benoetigteBreite);
    
    for (int i = 2; i < statistik.getAusgabenAnzahl() +2; i++) {
      setSpaltenAusrichtung(i, TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL);        
      setFesteBreite(i, spaltenBreite);        
      
      if (statistik.getAusgabe(i-2).getLevel() > 0)
        setZeigeSpaltenHintergrund(i, true);        
    }
    setSpaltenAbstand(1);
    setSpaltenAbstand(1, 5);      
    setSpaltenAbstandHintergrund(1, 1);      
  }
  
  public int getSpaltenAnzahl() {
    return statistik.getAusgabenAnzahl()+1;
  }
  
  public int getZeilenAnzahl() {
    return daten.size();
  }
  
  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "";
    return statistik.getAusgabe(spaltenNr-2).getTitel();
  }
  
  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (spaltenNr == 1) {
      return zeilenTitel.get(zeilenNr-1).toString();
    }
    int anzahl = ((int[]) daten.get(zeilenNr-1))[spaltenNr-2];
    return (anzahl == 0)?"-":Integer.toString(anzahl);
  }
  
  public boolean getZeigeZeilenHintergrund(int modellZeile, int seitenZeile) {
    if (modellZeile == getZeilenAnzahl()) return false;
    return super.getZeigeZeilenHintergrund(modellZeile, seitenZeile);
  }

  public float getZellenRandOben(int modellZeile,int seitenZeile,int spalte) {
    if (modellZeile == 1 || modellZeile == getZeilenAnzahl()) return 1;
    return 0;
  }      
}