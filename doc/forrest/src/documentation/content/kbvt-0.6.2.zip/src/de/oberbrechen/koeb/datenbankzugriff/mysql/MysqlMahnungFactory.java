/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.AbstractMahnungFactory;
import de.oberbrechen.koeb.datenbankzugriff.BenutzerFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.framework.ErrorHandler;


public class MysqlMahnungFactory extends AbstractMahnungFactory {

  public BenutzerListe getAlleBenutzerMitMahnung() {
    BenutzerFactory benutzerFactory = Datenbank.getInstance().getBenutzerFactory();
    
    BenutzerListe liste = new BenutzerListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
        "select DISTINCT b.id from ausleihzeitraum z, ausleihe a, benutzer b " +
        "where z.ausleiheID = a.id and a.benutzerId = b.id and " +
        "isNull(a.rueckgabedatum) group by a.id " +
        "having to_days(max(Ende)) < to_days(now());");
      while (result.next()) {
        int id = result.getInt("id");
        liste.addNoDuplicate(benutzerFactory.get(id));
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Benutzerliste!", true);
    }

    return liste;
  }
}
