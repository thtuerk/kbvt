/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.auswahlKonfiguration;


/**
 * Diese Klasse repr�sentiert eine konkreten Wert, der in
 * einer Auswahl verwendet wird.
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
class AuswahlWert {
    
  public static final int ZAHL = 1;
  public static final int STRING = 2;

  public static final int AUSLEIHE_BENUTZERALTER = 30;
  public static final int MEDIUM_EINSTELLUNGSDAUER_TAGE = 31;
  public static final int BENUTZER_ANMELDEDAUER_TAGE = 32;  
  public static final int BENUTZER_ANMELDEDAUER_JAHRE = 33;  
  public static final int BENUTZER_BENUTZERALTER = 34;    
  
  int typ;
  Object value;
  
  public AuswahlWert(int typ, Object value) {
    this.typ = typ;
    this.value= value;
  }
        
  public AuswahlWert(int typ) {
    this(typ, null);
  }
  
  protected int getWertTyp() {
    switch (typ) {
      case ZAHL:
      case STRING:
        return Auswahl.AUSWAHL_ALLE_TYPEN;
      case AUSLEIHE_BENUTZERALTER:
        return Auswahl.AUSWAHL_TYP_AUSLEIHZEITRAUM;
      case MEDIUM_EINSTELLUNGSDAUER_TAGE:
        return Auswahl.AUSWAHL_TYP_AUSLEIHZEITRAUM+Auswahl.AUSWAHL_TYP_MEDIUM;
      case BENUTZER_BENUTZERALTER:
      case BENUTZER_ANMELDEDAUER_JAHRE:
      case BENUTZER_ANMELDEDAUER_TAGE:
        return Auswahl.AUSWAHL_TYP_BENUTZER;
      default:
        throw new RuntimeException("Unbeachteter Fall "+typ);        
    }
  }
  
  public Object getValue(AuswahlObject o) {
    switch (typ) {
      case ZAHL:
      case STRING:
        return value;
      case AUSLEIHE_BENUTZERALTER:
        if (o.getBenutzer() == null || 
            o.getBenutzer().getGeburtsdatum() == null)
          return null;
        
        return new Double(o.getBenutzer().getAlter(o.getZeitraum().getBeginn()));
      case BENUTZER_BENUTZERALTER:
        if (o.getBenutzer() == null || 
            o.getBenutzer().getGeburtsdatum() == null)
          return null;
        
        return new Double(o.getBenutzer().getAlter());
      case BENUTZER_ANMELDEDAUER_TAGE:
        if (o.getBenutzer() == null || 
            o.getBenutzer().getAnmeldedatum() == null)
          return null;
          
        return new Double(o.getBenutzer().getAnmeldeDauer());
      case BENUTZER_ANMELDEDAUER_JAHRE:
        if (o.getBenutzer() == null || 
            o.getBenutzer().getAnmeldedatum() == null)
          return null;
        
        return new Double(o.getBenutzer().getAnmeldeDauer());
      case MEDIUM_EINSTELLUNGSDAUER_TAGE:
        if (o.getMedium() == null ||
            o.getMedium().getEinstellungsdatum() == null)
          return null;
        
        return new Double(o.getMedium().getEinstellungsdauerInTagen());
      default:
        throw new RuntimeException("Unbeachteter Fall "+typ);        
    }    
  }
}