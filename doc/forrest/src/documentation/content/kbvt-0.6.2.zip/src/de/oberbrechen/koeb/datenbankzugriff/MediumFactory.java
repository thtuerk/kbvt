/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;

/**
 * Dieses Interface repr�sentiert eine Factory f�r Medientypen.
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public interface MediumFactory extends DatenbankzugriffFactory {

  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Medium-Objekt
   * 
   * @return das neue Medium-Objekt
   */
  public Medium erstelleNeu(); 
  
  /**
   * Liefert eine unsortierte Liste aller Medien, die in der Datenbank
   * eingetragen sind und noch nicht aus dem Bestand entfernt wurden.
   * Es wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
   * wird.
   *
   * @see MedienListe
   */
  public MedienListe getAlleMedien();
  
  /**
   * Liefert eine unsortierte Liste aller Medien, die in der Datenbank
   * eingetragen sind (inklusive derer, die bereits 
   * aus dem Bestand entfernt wurden).
   * Es wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
   * wird.
   *
   * @see MedienListe
   */
  public MedienListe getAlleMedienInklusiveEntfernte();

  /**
	 * Liefert eine nach dem Titel sortierte Liste aller Medien, die in der 
	 * Datenbank eingetragen sind und noch nicht aus dem Bestand entfernt wurden.
	 * Diese Methode cacht das Ergebnis und dient zu Beschleunigung. 
	 * Daher wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
	 * wird. Sollte dies n�tig sein, so ist die Methode getAlleMedien() mit
	 * anschlie�endem Sortieren zu verwenden.
	 *
	 * @see MedienListe
	 */
	public MedienListe getAlleMedienTitelSortierung();

	/**
	 * Liefert eine nach der Mediennummer sortierte Liste aller Medien, die in der 
	 * Datenbank eingetragen sind und noch nicht aus dem Bestand entfernt wurden.
	 * Diese Methode cacht das Ergebnis und dient zu Beschleunigung. 
	 * Daher wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
	 * wird. Sollte dies n�tig sein, so ist die Methode getAlleMedien() mit
	 * anschlie�endem Sortieren zu verwenden.
	 *
	 * @see MedienListe
	 */
	public MedienListe getAlleMedienMediennrSortierung();

	/**
   * Liefert eine Liste aller Medien, die in der Datenbank
   * eingetragen sind und dem uebergebenen Medientyp sowie der uebergebenen 
   * Systematik angehoeren.
   * Sollen alle Medientypen bzw alle Systematiken ausgegeben werden, so
   * ist <code>null</code> zu uebergeben.
   * Der Paramater <code>ausBestandEntfernt</code> bestimmt, ob nur Medien,
   * die sich noch im Bestand befinden, oder nur Medien, die bereits aus dem
   * Bestand entfernt wurden, zur�ckgeliefert werden sollen.
   *
   * @param typ der auszugebende Medientyp
   * @param ausBestandEntfernt in welchen medien soll gesucht werden?
   * @param systematik die auszugebende Systematik
   * @see MedienListe
   */
  public MedienListe getMedienListe(Medientyp typ, 
      Systematik systematik, boolean ausBestandEntfernt);
  
  /**
   * Liefert eine Liste aller Medien, die in der Datenbank
   * eingetragen sind und dem uebergebenen Medientyp sowie der uebergebenen 
   * Systematik angehoeren.
   * Sollen alle Medientypen bzw alle Systematiken ausgegeben werden, so
   * ist <code>null</code> zu uebergeben.
   * Der Paramater <code>ausBestandEntfernt</code> bestimmt, ob nur Medien,
   * die sich noch im Bestand befinden, oder nur Medien, die bereits aus dem
   * Bestand entfernt wurden, zur�ckgeliefert werden sollen. Bei �bergabe von
   * <code>null</code> werden alle Medien zur�ckgeliefert.
   *
   * @param typ der auszugebende Medientyp
   * @param ausBestandEntfernt in welchen medien soll gesucht werden?
   * @param systematik die auszugebende Systematik
   * @see MedienListe
   */
  public MedienListe getMedienListe(Medientyp typ, 
      Systematik systematik, Boolean ausBestandEntfernt);
  
  /**
   * Liefert eine unsortierte Liste aller Autoren. 
   * @return eine unsortierte Liste aller Autoren
   */
  public Liste getAlleAutoren();

  /**
   * Sucht die Medien mit den angegebenen Eigenschaften, d.h. die Medien des 
   * angegebenen Medientyps, die
   * das Stichwort irgendwo in Titel, Autor oder Beschreibung enthalten, 
   * deren Autor mit der Zeichenfolge autor beginnt und deren Titel 
   * mit der Zeichenfolge titel beginnt. Das Zeichen '%' kann als Platzhalter
   * f�r beliebige Zeichenfolgen verwendet werden.  
   * @param stichwort
   * @param autor
   * @param titel
   * @param medientyp
   * @return
   */
  public MedienListe sucheMedien(String stichwort, String autor, String titel, Medientyp medientyp);

  /**
   * Liefert eine unsortierte Liste aller Medien, die in der Datenbank
   * eingetragen sind und die zum �bergebenen Zeitpunkt im Bestand waren.
   *
   * @see MedienListe
   */
  public MedienListe getAlleMedien(Date date);

  /**
   * Liefert eine unsortierte Liste aller Medien, die im �bergebenen
   * Zeitraum neu eingestellt wurden.
   */
  public MedienListe getEingestellteMedienInZeitraum(Zeitraum zeitraum);

  /**
   * Liefert eine unsortierte Liste aller Medien, die im �bergebenen
   * Zeitraum aus dem Bestand entfernt wurden.
   */
  public MedienListe getEntfernteMedienInZeitraum(Zeitraum zeitraum);
}