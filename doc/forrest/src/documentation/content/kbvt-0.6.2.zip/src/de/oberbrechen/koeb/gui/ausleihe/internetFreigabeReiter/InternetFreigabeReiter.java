/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.internetFreigabeReiter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import de.oberbrechen.koeb.gui.ausleihe.*;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse repr�sentiert den Reiter, der die Internetfreigabe
 * erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.14 $
 */

public class InternetFreigabeReiter extends JPanel implements AusleiheMainReiter {

  private Main hauptFenster;

  private InternetfreigabeFactory internetfreigabeFactory;
  private Client aktuellerClient;
  private JButton freigabeButton;
  private JButton sperrenButton;

  public InternetFreigabeReiter(Main parentFrame) {
    internetfreigabeFactory = 
      Datenbank.getInstance().getInternetfreigabeFactory();
    hauptFenster = parentFrame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    //Buttons bauen
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    buttonPanel.setLayout(new GridLayout(1, 2, 15, 5));
    freigabeButton = new JButton("Internetzugang freischalten");
    sperrenButton = new JButton("Internetzugang sperren");

    freigabeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        freigeben();
      }
    });
    sperrenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        sperren();
      }
    });
    buttonPanel.add(freigabeButton, null);
    buttonPanel.add(sperrenButton, null);

    //Tabelle bauen
    final JTable freigabeTable = new JTable();
    final InternetFreigabeTableModel model = new InternetFreigabeTableModel();
    freigabeTable.setModel(model);
    freigabeTable.setDefaultRenderer(Object.class, new InternetFreigabeTableRenderer());
    freigabeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    freigabeTable.getSelectionModel().addListSelectionListener(
      new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        int gewaehlteZeile = freigabeTable.getSelectedRow();
        Client gewaehlterRechner =
            model.getClient(gewaehlteZeile);
        setRechner(gewaehlterRechner);
      }
    });
    freigabeTable.setRowSelectionInterval(0, 0);
    freigabeTable.scrollRectToVisible(freigabeTable.getCellRect(0, 0, true));
    

    new Timer(500, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        int markierung = freigabeTable.getSelectedRow();
        model.fireTableDataChanged();
        freigabeTable.setRowSelectionInterval(markierung, markierung);
      }
    }).start();

    JScrollPane freigabeScrollPane = new JScrollPane();
    JComponentFormatierer.setDimension(
      freigabeScrollPane, new Dimension(0, 40));
    freigabeScrollPane.setBorder(BorderFactory.createCompoundBorder(
      BorderFactory.createEmptyBorder(10,10,10,10),
      BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140))));
    freigabeScrollPane.getViewport().add(freigabeTable, null);

    //alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(freigabeScrollPane, BorderLayout.CENTER);
  }

  //Doku siehe bitte Interface
  public void aktualisiere() {
  }

  //Doku siehe bitte Interface
  public void setBenutzer(Benutzer benutzer) {
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }

  //Doku siehe bitte Interface
  public void refresh() {
  }

  /**
   * Setzt den �bergebenen Rechner als aktuell bearbeitete, d.h. die
   * Buttons sollen die Internetfreigabe dieses Rechners sperren bzw. freigeben.
   */
  public void setRechner(Client client) {
    if (client == null) return;
    aktuellerClient = client;
    freigabeButton.setText(client.getName()+" freigeben");
    sperrenButton.setText(client.getName()+" sperren");

    freigabeButton.setEnabled(
      !internetfreigabeFactory.istInternetzugangFreigegeben(client));
    sperrenButton.setEnabled(
      internetfreigabeFactory.istInternetzugangFreigegeben(client));
  }

  /**
   * Gibt den Internetzugang f�r die aktuelleInternetfreigabe frei.
   */
  void freigeben() {
    Benutzer aktuellerBenutzer = hauptFenster.getAktivenBenutzer();
    Mitarbeiter aktuellerMitarbeiter = hauptFenster.getAktuellenMitarbeiter();
    internetfreigabeFactory.freigeben(aktuellerBenutzer, 
      aktuellerClient, aktuellerMitarbeiter);
  }

  /**
   * Sperrt den Internetzugang f�r die aktuelleInternetfreigabe.
   */
  void sperren() {
    internetfreigabeFactory.sperren(aktuellerClient);
  }
  
  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}