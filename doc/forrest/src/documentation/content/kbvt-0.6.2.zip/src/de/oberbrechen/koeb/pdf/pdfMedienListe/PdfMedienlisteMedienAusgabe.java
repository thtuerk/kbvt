/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMedienListe;

import javax.swing.JFrame;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;

class PdfMedienlisteMedienAusgabe extends AbstractMedienAusgabe 
  implements KonfigurierbareAusgabe {

  PdfMedienlisteMedienAusgabeKonfigDialog konfigDialog;
  
  public PdfMedienlisteMedienAusgabe() {
    konfigDialog = new PdfMedienlisteMedienAusgabeKonfigDialog();
  }
    
  public String getName() {
    return "PDF-Medienliste";
  }

  public String getBeschreibung() {
    return "Gibt die Medien als Tabelle in eine PDF-Datei aus!";
  }

  public void run(JFrame hauptFenster) throws Exception {
    if (daten == null) daten = new MedienListe();
    
    PdfMedienListe pdfMedienListe = 
      new PdfMedienListe(datenTitel, daten, datenSortierung, datenUmgekehrteSortierung);   
    
    pdfMedienListe.setZeigeSortierteSpalteHintergrund(konfigDialog.getZeigeSpaltenHintergrund());
    pdfMedienListe.setZeigeZeilenHintergrund(konfigDialog.getZeigeZeilenHintergrund());
    pdfMedienListe.zeige(false);    
  }        

  public void konfiguriere(JFrame main) {
    konfigDialog.show(main);
    this.setSortierung(
        konfigDialog.getSortierung(), konfigDialog.getUmgekehrteSortierung());
    this.setTitel(konfigDialog.getTitel());
  }
}
