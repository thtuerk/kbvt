/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
* Diese Klasse repr�sentiert eine Internetfreigabe der B�cherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public abstract class AbstractInternetfreigabe extends AbstractDatenbankzugriff
  implements Internetfreigabe {

  // Die Attribute der Internetfreigabe
  protected Client client;
  protected Benutzer benutzer;
  protected Mitarbeiter mitarbeiter;
  protected Date von, bis;
    
  public String toString() {
    return "Internetfreigabe f�r "+client.getName();
  }

  public String toDebugString() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Internetfreigabe ").append(getId()).append("\n");
    ausgabe.append("-------------------------------\n");
    ausgabe.append("Rechner    : ").append(getClient().getName()).append("\n");
    ausgabe.append("Benutzer   : ").append(getBenutzer().getName()).append("\n");
    ausgabe.append("Mitarbeiter: ").append(getMitarbeiter().
      getBenutzer().getName()).append("\n");
    ausgabe.append("Startzeit  : ").append(dateFormat.format(von)).append("\n");
    ausgabe.append("Stoppzeit  : ").append(dateFormat.format(bis)).append("\n");
    return ausgabe.toString();
  }

  public int getDauer() {
    if (von == null) return 0;

    long freigabeVon = von.getTime();

    long freigabeBis;
    if (bis != null)
      freigabeBis = bis.getTime();
    else
      freigabeBis = System.currentTimeMillis();

    long dauerInMillisekunden = freigabeBis - freigabeVon;
    long dauerInSekunden = dauerInMillisekunden / 1000;

    return (int) dauerInSekunden;
  }
  
  public Date getStartZeitpunkt() {
    if (von == null) return null;
    return new Date(von.getTime());
  }

  public Date getEndZeitpunkt() {
    if (bis == null) return null;
    return new Date(bis.getTime());
  }

  public Client getClient() {
    return client;
  }


  public boolean istAktuell() {
    //Freigabe l�uft noch
    if (bis == null) return true;

    long beendetSeitMillisekunden = System.currentTimeMillis() - bis.getTime();
    return (beendetSeitMillisekunden < 1000*60*60*3);
  }

  public Benutzer getBenutzer() {
    return benutzer;
  }

  public Mitarbeiter getMitarbeiter() {
    return mitarbeiter;
  }

  public boolean istFreigegeben() {
    return (bis == null);
  }
  
	public void sperren() {
		Datenbank.getInstance().getInternetfreigabeFactory().
			sperren(this.getClient());
		this.reload();
	}  
}