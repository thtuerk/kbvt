/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import de.oberbrechen.koeb.einstellungen.Ausleihordnung;

/**
 * Diese Klasse stellt die grundlegende Functionalit�t einer Mahnung
 * zur Verf�gung.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class AbstractMahnung implements Mahnung {
  
  protected AusleihenListe ausleihen;
  protected AusleihenListe gemahnteAusleihen;
  protected Benutzer benutzer;

  public AbstractMahnung(Benutzer benutzer) {
    this.benutzer = benutzer;
    this.ausleihen = null;
    this.gemahnteAusleihen = null;
  }
  
  public AusleihenListe getGemahnteAusleihenListe() {
    if (gemahnteAusleihen != null) return gemahnteAusleihen;
    
    this.gemahnteAusleihen = new AusleihenListe();
    
    Iterator it = getAusleihenListe().iterator();
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      if (aktuelleAusleihe.istUeberzogen()) {
        gemahnteAusleihen.add(aktuelleAusleihe);
      }
    }    
    return gemahnteAusleihen;
  }
  
  public AusleihenListe getAusleihenListe() {
    if (this.ausleihen != null) return ausleihen;
    
    this.ausleihen = Datenbank.getInstance().getAusleiheFactory().
      getAlleNichtZurueckgegebenenAusleihenVon(benutzer);
    return ausleihen;
  }

  public int getAnzahlGemahnteAusleihen() {
    return getGemahnteAusleihenListe().size();
  }

  public Benutzer getBenutzer() {
    return benutzer;
  }

  public double getMahngebuehren() {
    return Ausleihordnung.getInstance().berechneMahngebuehren(
        getAusleihenListe());
  }

  public int getMaxUeberzogeneTage() {
    int max = 0;

    Iterator it = getGemahnteAusleihenListe().iterator();
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      int aktuelleUeberziehung = aktuelleAusleihe.getUeberzogeneTage();
      if (aktuelleUeberziehung > max)
        max = aktuelleUeberziehung;
    }

    return max;
  }

  public int getAnzahlAusleihen() {
    return getAusleihenListe().size();
  }
}