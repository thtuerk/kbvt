/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsteilnahmeListe;


/**
 * Dieses Interface repr�sentiert eine Factory f�r Veranstaltungsteilnahmen..
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public interface VeranstaltungsteilnahmeFactory extends DatenbankzugriffFactory{

  /**
   * Erstellt ein neues Veranstaltungsteilnahme-Objekt f�r die �bergebene 
   * Veranstaltung und den �bergebenen Benutzer.
   */
  public Veranstaltungsteilnahme erstelleNeu(Benutzer benutzer, 
    Veranstaltung veranstaltung);
    
  /**
   * Bestimmt, ob der �bergebene Benutzer f�r der �bergebene Veranstaltung
   * angemeldet ist.
   *
   * @param benutzer der zu �berpr�fende Benutzer
   * @param veranstaltung die zu �berpr�fende Veranstaltung
   * @return <code>true</code> gdw der �bergebene Benutzer f�r der �bergebene Veranstaltung
   * angemeldet ist
   */
  public boolean istAngemeldet(Benutzer benutzer, Veranstaltung veranstaltung);

  /**
   * Liefert ein Array, in dem eingetragen ist, ob die �bergebenen Benutzer
   * an den �bergebenen Veranstaltungen teilnehmen. Der erste Array-Index
   * gibt die Veranstaltung, der zweite den Benutzer an.
   *
   * @param veranstaltungen die zu pr�fenden Veranstaltungen
   * @param benutzer die zu pr�fenden Benutzer
   * @return das Array
   */
  public boolean[][] getTeilnahmeArray(VeranstaltungenListe veranstaltungen,
    BenutzerListe benutzer);
    
  /**
   * Sucht die Veranstaltungsteilnahme, die den �bergebenen Benutzers f�r die
   * �bergebene Veranstaltung anmeldet.
   *
   * @param benutzer der zu �berpr�fende Benutzer
   * @param veranstaltung die zu �berpr�fende Veranstaltung
   * @return die Veranstaltungsteilnahme, die den �bergebenen Benutzers f�r die
   * �bergebene Veranstaltung anmeldet, oder <code>null</code> falls keine
   * solche existiert
   */
  public Veranstaltungsteilnahme getVeranstaltungsteilnahme(
    Benutzer benutzer, Veranstaltung veranstaltung);    
    
  /**
   * Liefert eine Liste aller Teilnahmen an der Veranstaltung.
   * @param veranstaltung die Veranstaltung
   * @return eine Liste aller Teilnahmen an der Veranstaltung
   */
  public VeranstaltungsteilnahmeListe getTeilnahmeListe(
    Veranstaltung veranstaltung);    
    
  /**
   * Bestimmt die Anzahl der Teilnehmer, die sich f�r eine Veranstaltung
   * bisher angemeldet haben.
   * @param veranstaltung die Veranstaltung, deren Teilnehmeranzahl bestimmt 
   *  werden soll
   * @return die Anzahl der Teilnehmer, die sich f�r diese Veranstaltung
   *   bisher angemeldet haben
   */
  public int getTeilnehmerAnzahl(Veranstaltung veranstaltung);
  
  /**
   * Bestimmt die Anzahl der Teilnehmer, die sich f�r Veranstaltungen dieser
   * Veranstaltungsgruppe bisher angemeldet haben. Nimmt ein Benutzer an
   * mehreren Veranstaltungen der Gruppe teil, wird er nur einfach gez�hlt.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe
   * @return die Anzahl der Teilnehmer, die sich f�r Veranstaltungen dieser
   *   Veranstaltungsgruppe bisher angemeldet haben
   */
  public int getTeilnehmerAnzahl(Veranstaltungsgruppe veranstaltungsgruppe);

  /**
   * Bestimmt die Anzahl der Teilnehmer, die sich die Veranstaltungen in
   * der �bergebenen Liste bisher angemeldet haben.
   * @param veranstaltungen die Veranstaltungen, deren Teilnehmeranzahl bestimmt 
   *  werden soll
   * @return die Anzahl der Teilnehmer, die sich f�r diese Veranstaltungen
   *   bisher angemeldet haben, in der gleichen Reihenfolge wie die 
   *   Veranstaltungen in der Liste
   */
  public int[] getTeilnehmerAnzahl(VeranstaltungenListe veranstaltungen);

  /**
   * Liefert eine Liste aller Benutzer die sich f�r Veranstaltungen
   * der Veranstaltungsgruppe bisher angemeldet haben. Nimmt ein Benutzer an
   * mehreren Veranstaltungen der Gruppe teil, wird er nur einmal aufgenommen.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe
   * @return eine Liste aller Teilnehmer an der Veranstaltungsgruppe
   */
  public BenutzerListe getTeilnehmerListe(
      Veranstaltungsgruppe veranstaltungsgruppe);
  
  /**
   * Liefert eine Liste aller Benutzer die sich die Veranstaltung
   * angemeldet haben. Nimmt ein Benutzer an
   * @param veranstaltung die Veranstaltung
   * @return eine Liste aller Teilnehmer an der Veranstaltung
   */
  public BenutzerListe getTeilnehmerListe(Veranstaltung veranstaltung);  
}