/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.exceptions;

import de.oberbrechen.koeb.datenbankzugriff.Medium;

/**
* Diese Exception wird geworfen, wenn versucht wird, ein Medium zu
* speichern, dessen Mediennr. schon verwendet wird.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $

*/
public class MedienNrSchonVergebenException extends
  EindeutigerSchluesselSchonVergebenException {

	/**
   * Erstellt eine neue MedienNrSchonVergebenException mit
   * der �bergebenen Fehlermeldung und dem �bergebenen Medium, der den
   * eindeutigen Schl�ssel schon verwendet.
   *
   * @param meldung die Beschreibung der aufgetretenen Ausnahme
   * @param konfliktBenutzer der Benutzer, der den Benutzernamen
   *   schon verwendet
   */
  public MedienNrSchonVergebenException(String meldung,
    Medium konfliktMedium) {

    super(meldung, konfliktMedium);
  }

  /**
   * Erstellt eine neue MedienNrSchonVergebenException mit
   * einer Standardfehlermeldung und dem �bergebenen Medium, 
   * das den eindeutigen Schl�ssel schon verwendet.
   *
   * @param konfliktMedium das Medium, das das Medium
   *   schon verwendet
   */
  public MedienNrSchonVergebenException(Medium konfliktMedium) {
   super("Die Medien-Nr. '"+konfliktMedium.getMedienNr()+"' wird "+
        "bereits verwendet.", konfliktMedium);
  }

  /**
   * Liefert das Medium, das die Mediennr. bereits verwendet.
   * @return das Medium, das die Mediennr. bereits verwendet
   */
  public Medium getKonfliktMedium() {
    return (Medium) super.getKonfliktDatensatz();
  }

}
