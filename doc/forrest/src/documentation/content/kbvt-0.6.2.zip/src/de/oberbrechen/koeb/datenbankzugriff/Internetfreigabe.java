/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

/**
* Dieses Interface repr�sentiert eine Internetfreigabe der B�cherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.11 $
*/

public interface Internetfreigabe extends Datenbankzugriff {

  /**
   * Liefert die Dauer in Sekunden die der letzte Internetzugang f�r den
   * Rechner freigeschaltet war. Ist der Zugang noch freigeschaltet, wird die
   * Dauer bis zum aktuellen Zeitpunkt geliefert. War der Rechner noch nie
   * freigeschaltet wird 0 geliefert.
   *
   * @return die Dauer in Sekunden die der letzte Internetzugang f�r den
   *   Rechner freigeschaltet war
   */
  public int getDauer();
      
  /**
   * Liefert den Zeitpunkt, an dem der Internetzugang freigeschaltet wurde
   * @return den Zeitpunkt, an dem der Internetzugang freigeschaltet wurde
   */
  public Date getStartZeitpunkt();

  /**
   * Liefert den Zeitpunkt, bis zu dem der Internetzugang freigeschaltet wurde
   * @return den Zeitpunkt, bis zu dem Internetzugang freigeschaltet wurde
   */
  public Date getEndZeitpunkt();

  /**
   * Liefert den Client dieser Internetfreigabe.
   * @return den Client dieser Internetfreigabe
   */
  public Client getClient();

  /**
   * Bestimmt, ob die Freigabe aktuell ist. Eine Freigabe ist aktuell, wenn
   * sie nicht vor mehr als 3 Stunden beendet wurde.
   *
   * @return <code>true</code> gdw. die Freigabe aktuell ist
   */
  public boolean istAktuell();

  /**
   * Liefert den Benutzer der Internetfreigabe, d.h. den Benutzer, f�r den der
   * Internetzugang freigeschaltet war bzw. ist.
   * @return den Benutzer der Internetfreigabe
   */
  public Benutzer getBenutzer();

  /**
   * Liefert den Mitarbeiter der Internetfreigabe, d.h. den Mitarbeiter, der
   * die Freigabe t�tigte.
   * @return den Benutzer der Internetfreigabe
   */
  public Mitarbeiter getMitarbeiter();

  /**
   * Bestimmt, ob die Freigabe noch aktiv ist, d.h. ob der Internetzugang
   * zur Zeit noch freigeschaltet ist.
   * @return <code>true</code> gdw. der Internetzugang freigeschaltet ist.
   */
  public boolean istFreigegeben();
  
	/**
	 * Sperrt den Internetzugang f�r den Client, den die aktuelle Freigabe 
	 * freigibt und aktualisiert die Freigabe.
	 */
	public void sperren();  
}