/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.ausleiheReiter;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankzugriffException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.MediumBereitsVerliehenException;
import de.oberbrechen.koeb.einstellungen.Ausleihordnung;
import de.oberbrechen.koeb.einstellungen.Buecherei;
import de.oberbrechen.koeb.einstellungen.VerlaengerungsInformationen;
import de.oberbrechen.koeb.gui.ausleihe.AusleiheMainReiter;
import de.oberbrechen.koeb.gui.ausleihe.Main;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse repr�sentiert den Reiter, der die Ausleihe und R�ckgabe
 * erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.19 $
 */
public class AusleiheReiter extends JPanel implements AusleiheMainReiter {

  //Konstanten f�r die bearbeitenButtonFunktion
  private static final int SPEICHERN = 0;
  private static final int BEARBEITEN = 1;

  //Konstanten f�r die verwerfenButtonFunktion
  private static final int AENDERUNGEN_VERWERFEN = 0;
  private static final int AUSLEIHE_LOESCHEN = 1;
  private static final int VERLAENGERN_RUECKGAENGIG = 2;
  private static final int RUECKGABE_RUECKGAENGIG = 3;

  Main hauptFenster;
  JButton bearbeitenButton = new JButton();
  int bearbeitenButtonFunktion;
  JButton verlaengernButton = new JButton();
  JButton verwerfenButton = new JButton();
  int verwerfenButtonFunktion;
  JButton zurueckgebenButton = new JButton();

  private AusleihenTabelle ausleihenTabelle;
  private AusleiheDetails ausleiheDetails;
  private Ausleihordnung ausleihordnung;
  private Ausleihe aktuelleAusleihe;
  private boolean erlaubeAenderungen;

  private static SimpleDateFormat dateFormat =
      new SimpleDateFormat("dd. MMMM yyyy");
  private AusleiheFactory ausleiheFactory =
    Datenbank.getInstance().getAusleiheFactory();


  public AusleiheReiter(Main parentFrame) {
    ausleihordnung = Buecherei.getInstance().getAusleihordnung();
    hauptFenster = parentFrame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    //Buttonpanel
    bearbeitenButton.setText("Ausleihe bearbeiten");
    bearbeitenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switch (bearbeitenButtonFunktion) {
          case BEARBEITEN:   bearbeiteAusleihe(); break;
          case SPEICHERN:    speichereAenderungen(); break;
        }
      }
    });
    verwerfenButton.setText("�nderungen verwerfen");
    verwerfenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        switch (verwerfenButtonFunktion) {
          case AENDERUNGEN_VERWERFEN:    verwerfeAenderungen(); break;
          case RUECKGABE_RUECKGAENGIG:   macheRueckgabeRueckgaengig(); break;
          case VERLAENGERN_RUECKGAENGIG: macheVerlaengernRueckgaengig(); break;
          case AUSLEIHE_LOESCHEN:        loescheAusleihe(); break;
        }
      }
    });
    verlaengernButton.setText("Ausleihe verl�ngern (3)");
    JComponentFormatierer.setDimension(verlaengernButton,
        verlaengernButton.getPreferredSize());
    verlaengernButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        verlaengereAusleihe();
      }
    });
    zurueckgebenButton.setText("Medium zur�ckgeben");
    zurueckgebenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mediumZurueckgeben();
      }
    });

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1,4,15,0));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(15,10,10,10));
    buttonPanel.add(bearbeitenButton, null);
    buttonPanel.add(verwerfenButton, null);
    buttonPanel.add(zurueckgebenButton, null);
    buttonPanel.add(verlaengernButton, null);

    ausleiheDetails = new AusleiheDetails(hauptFenster);
    ausleihenTabelle = new AusleihenTabelle(this, hauptFenster);
    ausleihenTabelle.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    ausleiheDetails.setBorder(BorderFactory.createEmptyBorder(10,10,0,10));

    //Splitpanel
    JSplitPane jSplitPane1 = new JSplitPane();
    jSplitPane1.setBorder(BorderFactory.createEmptyBorder());
    jSplitPane1.add(ausleiheDetails, JSplitPane.LEFT);
    jSplitPane1.add(ausleihenTabelle, JSplitPane.RIGHT);

    //alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(jSplitPane1, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
  }

  //Doku siehe bitte Interface
  public void aktualisiere() {
    ausleiheDetails.aktualisiere();
  }

  //Doku siehe bitte Interface
  public void setBenutzer(Benutzer benutzer) {
    if (benutzer == null) return;

    erlaubeAenderungen(false);
    ausleihenTabelle.ladeAusleihenVon(benutzer);
  }

  //Doku siehe bitte Interface
  public void refresh() {
    setBenutzer(hauptFenster.getAktivenBenutzer());
  }

  /**
   * Zeigt die �bergebene Ausleihe an. D.h. es wird der zur Ausleihe
   * geh�rende Benutzer gesetzt und der Ausleihe-Reiter aktiviert. Dort wird,
   * falls m�glich, die �bergebene Ausleihe ausgew�hlt.
   *
   * @param ausleihe die anzuzeigende Ausleihe
   */
  public void zeigeAusleihe(Ausleihe ausleihe) {
    ausleihenTabelle.markiereAusleihe(ausleihe);
  }


  /**
   * �ber diese Methode wird dem Reiter mitgeteilt, dass sich
   * die in der Liste ausgew�hlte Ausleihe ge�ndert hat.
   *
   * @param neueAusleihe die neu gew�hlte Ausleihe
   */
  protected void ausleiheGewechselt(Ausleihe neueAusleihe) {
    aktuelleAusleihe = neueAusleihe;
    initButtons(false);
    ausleiheDetails.setAusleihe(neueAusleihe);
  }

  /**
   * Erstellt eine neue Ausleihe und zeigt sie zum Bearbeiten an
   */
  public void neueAusleiheErstellen() {
    aktuelleAusleihe = ausleiheFactory.erstelleNeu();
    aktuelleAusleihe.setBenutzer(hauptFenster.getAktivenBenutzer());
    aktuelleAusleihe.setMitarbeiterAusleihe(hauptFenster.getAktuellenMitarbeiter());
    ausleiheDetails.setAusleihe(aktuelleAusleihe);
    bearbeiteAusleihe();
  }

  /**
   * Erlaubt / verbietet das �ndern der angezeigten Ausleihe.
   *
   * @param erlaubt bestimmt, ob �nderungen erlaubt sind
   */
  public void erlaubeAenderungen(boolean erlaubt) {
    ausleiheDetails.erlaubeAenderungen(erlaubt);
    ausleihenTabelle.erlaubeAenderungen(!erlaubt);
    hauptFenster.erlaubeAenderungen(!erlaubt);
    erlaubeAenderungen = erlaubt;
  }

  /**
   * Verwirft die an der aktuellen Ausleihe gemachten �nderungen
   */
  void verwerfeAenderungen() {
    ausleiheDetails.verwerfeAenderungen();

    //wenn die Ausleihe noch nicht gespeichert ist, verwerfe sie komplett
    if (aktuelleAusleihe.istNeu())
      ausleihenTabelle.markiereErsteAusleihe();

    erlaubeAenderungen(false);
    initButtons(false);
    ausleihenTabelle.grabFocus();
  }

  /**
   * Diese Methode dient dazu, MediumBereitsVerliehenExceptions, die beim
   * Speichern einer Ausleihe auftreten zu behandeln.
   *
   * @return <code>true</code> wenn das Speichern trotz Exception
   *   erfolgreich verlief
   */
  private boolean behandleMediumBereitsVerliehenException
    (MediumBereitsVerliehenException e) {

    boolean speichernOK = false;
    if (e.getVerursachendeAusleihe().istZurueckgegeben()) throw e;

    if (e.getKonfliktAusleihe().getBenutzer().equals(
        e.getVerursachendeAusleihe().getBenutzer())) {

      if (e.getKonfliktAusleihe().heuteZurueckgegeben()) {
        JOptionPane.showMessageDialog(hauptFenster,
          "Das Medium '"+e.getKonfliktAusleihe().getMedium().getTitel()+
          "' ("+e.getKonfliktAusleihe().getMedium().getMedienNr() + ")\n"+
          "war seit dem "+
          dateFormat.format(e.getKonfliktAusleihe().getAusleihdatum()) +
          " bis heute von "+e.getKonfliktAusleihe().getBenutzer().getName()+
          " ausgeliehen!\n\nVerl�ngern Sie gegebenenfalls diese Ausleihe!",
          "Ausleihe nicht m�glich!",
          JOptionPane.ERROR_MESSAGE);
      } else {
        JOptionPane.showMessageDialog(hauptFenster,
          "Das Medium '"+e.getKonfliktAusleihe().getMedium().getTitel()+
          "' ("+e.getKonfliktAusleihe().getMedium().getMedienNr() + ")\n"+
          "ist bereits seit dem "+
          dateFormat.format(e.getKonfliktAusleihe().getAusleihdatum()) +
          " von "+e.getKonfliktAusleihe().getBenutzer().getName()+
          " ausgeliehen!\n\nVerl�ngern Sie gegebenenfalls diese Ausleihe!",
          "Ausleihe nicht m�glich!",
          JOptionPane.ERROR_MESSAGE);
      }
    } else {
      int erg = JOptionPane.showConfirmDialog(hauptFenster,
        "Das Medium '"+e.getKonfliktAusleihe().getMedium().getTitel()+
        "' ("+e.getKonfliktAusleihe().getMedium().getMedienNr() + ")\n"+
        "ist seit dem "+
        dateFormat.format(e.getKonfliktAusleihe().getAusleihdatum())+" von "+
        e.getKonfliktAusleihe().getBenutzer().getName()+" ausgeliehen!\n\n"+
        "Wollen Sie wirklich diese Ausleihe beenden und das "+
        "Medium\nneu an "+e.getVerursachendeAusleihe().getBenutzer().getName()+
        " ausleihen?",
        "Ausleihe-Konflikt!", JOptionPane.YES_NO_OPTION,
        JOptionPane.ERROR_MESSAGE);
      if (erg == JOptionPane.YES_OPTION) {
        Ausleihe konfliktAusleihe = e.getKonfliktAusleihe();
        Date rueckgabeDatum = konfliktAusleihe.getSollRueckgabedatum();
        if (aktuelleAusleihe.getAusleihdatum().before(rueckgabeDatum))
          rueckgabeDatum = aktuelleAusleihe.getAusleihdatum();

        konfliktAusleihe.setRueckgabedatum(rueckgabeDatum);
        konfliktAusleihe.setBemerkungen("Ausleihe irregul�r zur�ckgegeben!");
        konfliktAusleihe.setMitarbeiterRueckgabe(
          hauptFenster.getAktuellenMitarbeiter());
        konfliktAusleihe.save();

        speichernOK = true;
      }
    }
    return speichernOK;
  }

  /**
   * Speichere die an der aktuellen Ausleihe gemachten �nderungen
   */
  void speichereAenderungen() {
    boolean speichernOK = true;
    try {
      ausleiheDetails.save();
    } catch (MediumBereitsVerliehenException e) {
      speichernOK = behandleMediumBereitsVerliehenException(e);
      if (speichernOK) {
        speichereAenderungen();
        return;      
      }
    } catch (DatenbankzugriffException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
                                    "Ausleihe konnte nicht gespeichert werden!",
                                    JOptionPane.ERROR_MESSAGE);
      speichernOK = false;
    }
    if (speichernOK) {
      Ausleihe geaenderteAusleihe = aktuelleAusleihe;
      ausleihenTabelle.add(geaenderteAusleihe);
      ausleihenTabelle.refresh();
      ausleihenTabelle.markiereAusleihe(geaenderteAusleihe);
      erlaubeAenderungen(false);
      initButtons(false);
      ausleihenTabelle.grabFocus();
    }
  }

  /**
   * Erlaubt das Bearbeiten der aktuellen Ausleihe
   */
  public void bearbeiteAusleihe() {
    erlaubeAenderungen(true);
    initButtons(true);
    ausleiheDetails.grabFocus();
  }

  /**
   * Setzt die Buttons passend zur aktuellen Ausleihe und abh�ngig davon,
   * ob sie gerade bearbeitet wird oder nicht
   *
   * @param wirdBearbeitet gibt an, ob die aktuelle Ausleihe gerade bearbeitet
   *   wird
   */
  public void initButtons(boolean wirdBearbeitet) {

    bearbeitenButton.setText("Ausleihe bearbeiten");
    bearbeitenButtonFunktion = BEARBEITEN;
    bearbeitenButton.setEnabled(false);
    verwerfenButton.setText("Ausleihe l�schen");
    verwerfenButton.setEnabled(false);
    verlaengernButton.setText("Ausleihe verl�ngern");
    verlaengernButton.setEnabled(false);
    zurueckgebenButton.setEnabled(false);

    if (aktuelleAusleihe == null) return;
    String verlaengernText = "Ausleihe verl�ngern";
    int anzahlVerlaengerungen = aktuelleAusleihe.getAnzahlVerlaengerungen();
    if (anzahlVerlaengerungen > 0) {
      verlaengernText += " ("+(anzahlVerlaengerungen+1)+")";
      verlaengernButton.setText(verlaengernText);
    }


    if (aktuelleAusleihe.heuteZurueckgegeben()) {
      verwerfenButton.setText("R�ckgabe r�ckg�ngig");
      verwerfenButtonFunktion = RUECKGABE_RUECKGAENGIG;
      verwerfenButton.setEnabled(true);
      bearbeitenButton.setEnabled(true);
    } else if (aktuelleAusleihe.istAktuellVerlaengert()) {
      verwerfenButton.setText("Verl�ngern r�ckg�ngig");
      verwerfenButtonFunktion = VERLAENGERN_RUECKGAENGIG;
      verwerfenButton.setEnabled(true);
      bearbeitenButton.setEnabled(true);
      verlaengernButton.setEnabled(true);
    } else if (aktuelleAusleihe.heuteGetaetigt()) {
      bearbeitenButton.setEnabled(true);
      verwerfenButton.setText("Ausleihe l�schen");
      verwerfenButtonFunktion = AUSLEIHE_LOESCHEN;
      verwerfenButton.setEnabled(true);
      zurueckgebenButton.setEnabled(true);
      verlaengernButton.setEnabled(true);
    } else {
      verlaengernButton.setEnabled(true);
      zurueckgebenButton.setEnabled(true);
    }

		if (verlaengernButton.isEnabled()) {
		  VerlaengerungsInformationen infos =
		  	ausleihordnung.getVerlaengerungsInformationen(aktuelleAusleihe, new Date());
	    if (!infos.istErlaubt()) {
	      verlaengernButton.setEnabled(false);
	      verlaengernButton.setToolTipText(infos.getBemerkungen());
	    }
    }

    if (wirdBearbeitet) {
      bearbeitenButton.setText("Speichern");
      bearbeitenButtonFunktion = SPEICHERN;
      verwerfenButton.setText("�nderungen verwerfen");
      verwerfenButtonFunktion = AENDERUNGEN_VERWERFEN;

      bearbeitenButton.setEnabled(true);
      verwerfenButton.setEnabled(true);
      verlaengernButton.setEnabled(false);
      zurueckgebenButton.setEnabled(false);
    }
  }


  /**
   * Gibt das aktuelle Medium zur�ck.
   */
  void mediumZurueckgeben() {
    aktuelleAusleihe.zurueckgeben(hauptFenster.getAktuellenMitarbeiter());
    aktuelleAusleihe.save();
    ausleihenTabelle.aktualisiere();
    ausleihenTabelle.markiereAusleihe(aktuelleAusleihe);
  }

  /**
   * Verl�ngert die aktuelle Ausleihe;
   */
  void verlaengereAusleihe() {
    aktuelleAusleihe.verlaengere(hauptFenster.getAktuellenMitarbeiter());
    aktuelleAusleihe.save();
    ausleihenTabelle.aktualisiere();
    ausleihenTabelle.markiereAusleihe(aktuelleAusleihe);
  }

  /**
   * Macht das Verl�ngeren der aktuellen Ausleihe r�ckg�ngig
   */
  void macheVerlaengernRueckgaengig() {
    aktuelleAusleihe.verlaengernRueckgaengig();
    aktuelleAusleihe.save();
    ausleihenTabelle.aktualisiere();
    ausleihenTabelle.markiereAusleihe(aktuelleAusleihe);
  }

  /**
   * L�scht die aktuelle Ausleihe
   */
  void loescheAusleihe() {
    int erg = JOptionPane.showConfirmDialog(hauptFenster,"Soll die Ausleihe "+
      "wirklich gel�scht werden?", "L�schbest�tigung",
      JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

    if (erg == JOptionPane.YES_OPTION) {
      Ausleihe alteAusleihe = aktuelleAusleihe;
      ausleihenTabelle.remove(alteAusleihe);
      alteAusleihe.loesche();
      ausleihenTabelle.markiereErsteAusleihe();
    }
  }

  /**
   * Macht die R�ckgabe der aktuellen Ausleihe r�ckg�ngig.
   */
  void macheRueckgabeRueckgaengig() {
    try {
      aktuelleAusleihe.setRueckgabedatum(null);
      aktuelleAusleihe.save();
      ausleihenTabelle.aktualisiere();
    } catch (MediumBereitsVerliehenException e) {
      aktuelleAusleihe.reload();
      JOptionPane.showMessageDialog(hauptFenster,
        "Das Zur�ckgeben des Mediums kann nicht r�ckg�ngig gemacht "+
        "werden, da \n"+
        "das Medium '"+e.getKonfliktAusleihe().getMedium().getTitel()+
        "' ("+e.getKonfliktAusleihe().getMedium().getMedienNr() + ")\n"+
        "inzwischen von "+e.getKonfliktAusleihe().getBenutzer().getName()+
        " ausgeliehen wurde.\n\nMachen Sie bitte zuerst diese Ausleihe "+
        "r�ckg�ngig!", "R�ckg�ngig machen der R�ckgabe nicht m�glich!",
        JOptionPane.ERROR_MESSAGE);
    }
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
    if (erlaubeAenderungen) {
      ausleiheDetails.mediumEANGelesen(medium);
    } else {
      Ausleihe alteAusleihe = aktuelleAusleihe;
      boolean speichernOK = true;
      try {
        aktuelleAusleihe = ausleiheFactory.erstelleNeu();
        aktuelleAusleihe.setMedium(medium);
        aktuelleAusleihe.setBenutzer(hauptFenster.getAktivenBenutzer());
        aktuelleAusleihe.setMitarbeiterAusleihe(hauptFenster.getAktuellenMitarbeiter());
        aktuelleAusleihe.save();
      } catch (MediumBereitsVerliehenException e) {
        speichernOK = behandleMediumBereitsVerliehenException(e);
        if (speichernOK) {
          mediumEANGelesen(medium);
          return;      
        }
      } catch (DatenbankzugriffException e) {
        JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
          "Ausleihe konnte nicht gespeichert werden!", 
          JOptionPane.ERROR_MESSAGE);
        speichernOK = false;
      }
      if (speichernOK) {
        Ausleihe geaenderteAusleihe = aktuelleAusleihe;
        ausleihenTabelle.add(geaenderteAusleihe);
        ausleihenTabelle.aktualisiere();
        ausleihenTabelle.markiereAusleihe(geaenderteAusleihe);
        erlaubeAenderungen(false);
        initButtons(false);
        ausleihenTabelle.grabFocus();
      } else {
        aktuelleAusleihe = alteAusleihe;
      }
    }
  }

  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}