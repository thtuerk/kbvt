/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import java.util.Comparator;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von Mahnungen. Eine Mahnung
* ist eindeutig �ber ihren Benutzer identifiziert und wird nur einmal in
* die Liste aufgenommen. Es ist zu
* beachten, dass �berall nur Mahnung-Objekte statt allgemeiner Objekte als
* Parameter �bergeben werden d�rfen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class MahnungenListe extends Liste {

  /**
   * Mahnungen werden alphabtisch nach dem Nachnamen und dann nach dem
   * Vornamen ihres Benutzers sortiert
   */
  public static final int BenutzerSortierung = 2;

  /**
   * Ausleihen werden nach ihrer maximalen Ueberziehdauer sortiert
   */
  public static final int UeberziehdauerSortierung = 3;

  /**
   * Mahnungen werden nach den Mahngeb�hren sortiert
   */
  public static final int MahngebuehrSortierung = 4;

  /**
   * Mahnungen werden nach der Anzahl der ueberzogenen Medien sortiert
   */
  public static final int MedienAnzahlSortierung = 5;

  protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;

    switch (sortierung) {
      case BenutzerSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Mahnung ma = (Mahnung) a;
              Mahnung mb = (Mahnung) b;
              int erg = nullCompare(ma.getBenutzer().getNameFormal(),
                                    mb.getBenutzer().getNameFormal());
              if (erg == 0) erg = mb.getBenutzer().getId() -
                                  ma.getBenutzer().getId();
              return erg;
            }};
        break;
      }

      case UeberziehdauerSortierung: {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Mahnung ma = (Mahnung) a;
              Mahnung mb = (Mahnung) b;
              int erg = mb.getMaxUeberzogeneTage() -
                        ma.getMaxUeberzogeneTage();
              if (erg == 0) erg = nullCompare(ma.getBenutzer().getNameFormal(),
                                              mb.getBenutzer().getNameFormal());
              if (erg == 0) erg = mb.getBenutzer().getId() -
                                  ma.getBenutzer().getId();
              return erg;
            }};
        break;
      }

      case MahngebuehrSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            Mahnung ma = (Mahnung) a;
            Mahnung mb = (Mahnung) b;
            int erg = 0;
            if (mb.getMahngebuehren() - ma.getMahngebuehren() < 0) {
              erg = -1;
            } else {
              erg = 1;
            }
            if (erg == 0) erg = nullCompare(ma.getBenutzer().getNameFormal(),
                                            mb.getBenutzer().getNameFormal());
            if (erg == 0) erg = mb.getBenutzer().getId() -
                                ma.getBenutzer().getId();
            return erg;
        }};
        break;
      }

      //Nummer Sortierung
      case MedienAnzahlSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            Mahnung ma = (Mahnung) a;
            Mahnung mb = (Mahnung) b;
            int erg = mb.getAnzahlGemahnteAusleihen() - ma.getAnzahlGemahnteAusleihen();
            if (erg == 0) erg = nullCompare(ma.getBenutzer().getNameFormal(),
                                            mb.getBenutzer().getNameFormal());
            if (erg == 0) erg = mb.getBenutzer().getId() -
                                ma.getBenutzer().getId();
            return erg;
        }};
        break;
      }

      default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }
}
