/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;


/**
 * Dieses Interface repr�sentiert eine Factory f�r Veranstaltungen..
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public interface VeranstaltungFactory extends DatenbankzugriffFactory {

  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Veranstaltung-Objekt
   * 
   * @return das neue Veranstaltung-Objekt
   */
  public Veranstaltung erstelleNeu(); 

  /**
   * Liefert eine unsortierte Liste aller
   * Veranstaltungen der Gruppe, die in der Datenbank eingetragen sind.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe, deren 
   *   Veranstaltungen geladen werden sollen
   *
   * @return eine Liste aller Veranstaltungen der Gruppe
   */
  public VeranstaltungenListe getVeranstaltungen(
    Veranstaltungsgruppe veranstaltungsgruppe);

  /**
   * Liefert unsortierte Liste aller
   * Veranstaltungen der Gruppe, f�r die eine Anmeldung erforderlich ist.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe, deren 
   *   Veranstaltungen geladen werden sollen
   *
   * @return eine unsortierte Liste der Veranstaltungen der Gruppe
   */
  public VeranstaltungenListe getVeranstaltungenMitAnmeldung(
    Veranstaltungsgruppe veranstaltungsgruppe);

  /**
   * Liefert eine unsortierte Liste aller Veranstaltungen, von denen
   * mindestens ein Termin im �bergebenen
   * Zeitraum liegt 
   * @param zeitraum der Zeitraum
   * @return die unsortierte Liste
   */
  public VeranstaltungenListe getAlleVeranstaltungenInZeitraum(Zeitraum zeitraum);
}