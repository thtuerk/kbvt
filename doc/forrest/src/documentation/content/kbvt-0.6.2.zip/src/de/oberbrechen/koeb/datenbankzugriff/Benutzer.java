/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

/**
 * Dieses Interface repr�sentiert einen Benutzer der B�cherei.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.26 $
 */
public interface Benutzer extends Datenbankzugriff {

	/**
	 * �berpr�ft, ob dieser Benutzer einen Benutzernamen verwendet.
	 * @return <code>TRUE</code> gdw. der Benutzer einen Benutzernamen verwendet
	 */
	public boolean istBenutzernameGesetzt();
  
  /**
	 * �berpr�ft, ob der Benutzername des Benutzers schon von einem
	 * anderen Benutzer verwendet wird.
	 * @return <code>TRUE</code> gdw der Benutzername schon von einem anderen
	 * Benutzer verwendet wird
	 */
	public boolean istBenutzernameSchonVergeben();

  /**
   * �berpr�ft, ob der �bergebene Benutzername schon von einem anderen
   * Benutzer verwendet wird.
   * @param benutzername der zu testende Benutzername
   * @return <code>TRUE</code> gdw der Benutzername schon von einem anderen
   * Benutzer verwendet wird
   */
  public boolean istBenutzernameSchonVergeben(String benutzername);

	/**
	 * Liefert den vollst�ndigen Namen des Benutzers in der Form
	 * "Vorname Nachname".
	 * @return Name des Benutzers
	 */
	public String getName();

	/**
	 * Liefert den vollst�ndigen Namen des Benutzers in der Form
	 * "Nachname, Vorname".
	 * @return Name des Benutzers
	 */
	public String getNameFormal();

	/**
	 * Liefert den Vornamen des Benutzers
	 * @return Vorname des Benutzers
	 */
	public String getVorname();

	/**
	 * Liefert den Nachnamen des Benutzers
	 * @return Nachname des Benutzers
	 */
	public String getNachname();

  /**
   * Liefert, ob der Benutzer ein B�cherei-VIP ist 
   * @return <code>true</code> gwd. der Benutzer ein B�cherei-VIP ist
   */
  public boolean istVIP();

  /**
   * Setzt, ob der Benutzer ein B�cherei-VIP ist 
   * @param vip <code>true</code> gwd. der Benutzer ein B�cherei-VIP ist
   */
  public void setVIP(boolean vip);

  /**
	 * Liefert die Adresse des Benutzers
	 * @return Adresse des Benutzers
	 */
	public String getAdresse();

	/**
	 * Liefert den Ort des Benutzers
	 * @return Ort des Benutzers
	 */
	public String getOrt();

	/**
	 * Liefert die Klasse des Benutzers
	 * @return Klasse des Benutzers
	 */
	public String getKlasse();

	/**
	 * Liefert die Telefonnummer des Benutzers
	 * @return Telefonnummer des Benutzers
	 */
	public String getTel();

	/**
	 * Liefert Faxnummer zum Benutzers
	 * @return Faxnummer des Benutzers
	 */
	public String getFax();

	/**
	 * Liefert eMail-Adresse zum Benutzers
	 * @return eMail-Adresse des Benutzers
	 */
	public String getEMail();

	/**
	 * Liefert den Benutzernamen des Benutzers f�r die elektronische Anmeldung
	 * @return Benutzernamen des Benutzers
	 */
	public String getBenutzername();

	/**
	 * Liefert die Bemerkungen zum Benutzer
	 * @return Bemerkungen zum Benutzer
	 */
	public String getBemerkungen();

	/**
	 * Liefert das Anmeldedatum des Benutzers
	 * @return Anmeldedatum des Benutzers
	 */
	public Date getAnmeldedatum();

	/**
	 * Liefert das Geburtsdatum des Benutzers
	 * @return Geburtsdatum des Benutzer
	 */
	public Date getGeburtsdatum();

	/**
	 * Setzt den Vornamen des Benutzers
	 * @param vorname Vorname des Benutzers
	 */
	public void setVorname(String vorname);

	/**
	 * Setzt den Nachnamen des Benutzers
	 * @param nachname Nachname des Benutzers
	 */
	public void setNachname(String nachname);

	/**
	 * Setzt die Adresse des Benutzers
	 * @param adresse Adresse des Benutzers
	 */
	public void setAdresse(String adresse);

	/**
	 * Setzt den Ort des Benutzers
	 * @param ort des Benutzers
	 */
	public void setOrt(String ort);

	/**
	 * Setzt die Klasse des Benutzers
	 * @param klasse des Benutzers
	 */
	public void setKlasse(String klasse);

	/**
	 * Setzt die Telefonnummer des Benutzers
	 * @param telefonnummer des Benutzers
	 */
	public void setTel(String tel);

	/**
	 * Setzt Faxnummer zum Benutzers
	 * @param fax Faxnummer des Benutzers
	 */
	public void setFax(String fax);

	/**
	 * Setzt eMail-Adresse des Benutzers
	 * @param eMail eMail-Adresse des Benutzers
	 */
	public void setEMail(String eMail);

	/**
	 * Setzt den Benutzernamen des Benutzers f�r die elektronische Anmeldung
	 * @param benutzername Benutzernamen des Benutzers
	 */
	public void setBenutzername(String benutzername);

	/**
	 * Setzt das Passwort des Benutzers f�r die elektronische Anmeldung. Beachten
	 * Sie bitte, dass nicht das Passwort selbst, sondern die zugeh�rige
	 * Pr�fziffer nach dem MD5-Algorithmus
	 * @param passwort Passwort des Benutzers
	 */
	public void setPasswort(String passwort);

	/**
	 * �berpr�ft, ob das �bergebene Passwort dem Passwort des Benutzer entspricht
	 * @param passwort das zu testende Passwort
	 * @return <code>TRUE</code> gdw das Passwort g�ltig ist
	 */
	public boolean checkPasswort(String passwort);

	/**
	 * �berpr�ft, ob dieser Benutzer ein Passwort verwendet
	 * @return <code>TRUE</code> gdw der Benutzer ein Passwort verwendet
	 */
	public boolean istPasswortGesetzt();

	/**
	 * Setzt die Bemerkungen zum Benutzer
	 * @param Bemerkungen Bemerkungen zum Benutzer
	 */
	public void setBemerkungen(String Bemerkungen);

	/**
	 * Setzt das Anmeldedatum des Benutzers
	 * @param anmeldedatum Anmeldedatum des Benutzers
	 */
	public void setAnmeldedatum(Date anmeldedatum);

	/**
	 * Setzt das Geburtsdatum des Benutzers
	 * @param geburtsdatum Geburtsdatum des Benutzer
	 */
	public void setGeburtsdatum(Date geburtsdatum);

	/**
	 * Berechnet das Alter des Benutzers aus dem Geburtsdatum und dem aktuellen
	 * Datum. Falls kein Geburtsdatum angeben ist, wird eine NullPointerException
   * geworfen.
	 *
	 * @return Alter in Jahren
	 */
	public double getAlter();
  
	/**
   * Berechnet das Alter des Benutzers zum �bergebenen Zeitpunkt. Falls kein
 	 * Zeitpunkt �bergeben wird, wird eine NullPointerException geworfen.
	 *
	 * @param zeitpunkt der Zeitpunkt, zu dem das Alter berechnet werden soll
	 * @return Alter in Jahren
	 */
	public double getAlter(Date zeitpunkt);

  /**
   * Berechnet die Dauer, seit der der Benutzers angemeldet ist, aus dem 
   * Anmeldedatum und dem aktuellen
   * Datum. Falls kein Anmeldedatum angeben ist, wird eine NullPointerException
   * geworfen.
   *
   * @return Anmeldedauer in Tagen
   */
  public int getAnmeldeDauer();
  
  /**
	 * Weist dem Benutzer einen neuen, eindeutigen Benutzernamen zu. Dieser
	 * Benutzername setzt sich aus den ersten beiden Buchstaben des Vornamens,
	 * sowie den ersten 6 (soweit vorhanden) Buchstaben des Nachnamens zusammen.
	 * Dabei werden nur Kleinbuchstaben verwendet und Umlaute durch die
	 * jeweiligen Umschreibungen ersetzt. <br>
	 * Ist dieser Standardname schon vergeben, wird noch eine eindeutige Nummer
	 * angeh�ngt. Der Benutzer "Thomas T�rk" erhielte beispielsweise den
	 * Benutzernamen "thtuerk".
	 */
	public void setStandardBenutzername();
}