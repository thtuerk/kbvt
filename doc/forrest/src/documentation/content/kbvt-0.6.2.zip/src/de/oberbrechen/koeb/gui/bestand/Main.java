/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.EAN;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.gui.AbstractMain;
import de.oberbrechen.koeb.gui.bestand.ausgabenReiter.AusgabenReiter;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeGelesenEventHandler;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeReaderKeyAdapter;
import de.oberbrechen.koeb.gui.bestand.medienReiter.MedienReiter;
import de.oberbrechen.koeb.gui.bestand.standardwertReiter.StandardwertReiter;

/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die zur
 * Verwaltung und Eingabe von Medien dient.
 *
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.12 $
 */
public class Main extends AbstractMain implements BarcodeGelesenEventHandler {

  protected Standardwerte standardwerte;
  protected MedienListe alleMedien;
  
  private EANZuordnung eanZuordnung = 
    Datenbank.getInstance().getEANZuordnung();
    
  public Main(boolean isMain, Mitarbeiter mitarbeiter) {
    super(isMain, "Bestandsverwaltung", Mitarbeiter.BERECHTIGUNG_BESTAND_EINGABE,
          "de/oberbrechen/koeb/gui/icon-bestand.png", mitarbeiter);
    this.addKeyListener(new BarcodeReaderKeyAdapter("\5", "\12", this));
  }
  
  public MedienListe getAlleMedien() {
    if (alleMedien == null)
      alleMedien = Datenbank.getInstance().getMediumFactory().
        getAlleMedienInklusiveEntfernte();
    
    return alleMedien;    
  }
  /**
   * Liefert die Standardwerte, die zum erzeugen neuer Medien benutzt werden 
   * sollen.
   * @return die Standardwerte
   */
  public Standardwerte getStandardwerte() {
    if (standardwerte == null)
      standardwerte = new Standardwerte();
    return standardwerte;
  }
  
  public static void main(String[] args) {
    init();
    new Main(true, null);
  }

  //Doku siehe bitte Interface
  public void barcodeGelesen(String barcode) {
    EAN ean = new EAN(barcode);
    
    Object referenz = eanZuordnung.getReferenz(ean);
    if (referenz == null || !(referenz instanceof Medium)) return;

    ((BestandMainReiter) reiter.getSelectedComponent()).mediumEANGelesen(
      (Medium) referenz);
  }

  //Doku siehe bitte Interface
  public void barcodeStartGelesen() {
    reiter.grabFocus();
  }

  protected void initDaten() {
  }

  protected void reiterHinzufuegen() {
    reiter.add(new MedienReiter(this), "Bestand");
    reiter.add(new StandardwertReiter(this), "Standardwerte");
    reiter.add(new AusgabenReiter(this), "Ausgaben");
  }
}