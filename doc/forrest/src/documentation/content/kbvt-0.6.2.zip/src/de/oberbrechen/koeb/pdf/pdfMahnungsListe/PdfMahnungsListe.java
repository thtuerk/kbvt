/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMahnungsListe;

import java.util.Collection;
import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt ein PdfDokument, das eine Liste aller aktuellen Mahnungen
 * enthaelt.
 */
public class PdfMahnungsListe extends PdfDokument {

  private PdfTemplateDokument pdfDokument; 
  private int mindestTageUebergzogen;

  public PdfMahnungsListe(int mindestTageUeberzogen, String titel) {
    this.mindestTageUebergzogen = mindestTageUeberzogen;

    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(20);
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) throws Exception {
    Vector templates = new Vector();

    MahnungFactory mahnungFactory = Datenbank.getInstance().getMahnungFactory();
    BenutzerListe benutzerListe = mahnungFactory.getAlleBenutzerMitMahnung();
    benutzerListe.setSortierung(BenutzerListe.NachnameVornameSortierung);
    for (int i = 0; i < benutzerListe.size(); i++) {
      Mahnung mahnung = mahnungFactory.erstelleMahnungFuerBenutzer(
        (Benutzer) benutzerListe.get(i));
      if (mahnung.getMaxUeberzogeneTage() > mindestTageUebergzogen) {
        templates.addAll(erstelleMahnungsTemplates(mahnung, writer));
      }
    }

    pdfDokument.setTemplates((PdfTemplate[]) templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }

  private Collection erstelleMahnungsTemplates(Mahnung mahnung, 
    PdfWriter writer) throws Exception {
    Vector erg = new Vector();  
    
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1)-20;

    MahnungTabellenModell tabellenModell = new MahnungTabellenModell(mahnung);      
    PdfTabelle tabelle = new PdfTabelle(tabellenModell);
    while (tabelle.hasNextTemplate()) {
      PdfTemplate tabellenTemplate = 
        tabelle.getNextTemplate(false, maximaleHoehe, pdfDokument, 
        writer.getDirectContent());

      PdfTemplate neuesTemplate = 
        writer.getDirectContent().createTemplate(
        tabellenTemplate.getWidth(), tabellenTemplate.getHeight()+20);
      neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
                
      //Ueberschrift
      String name = "";
      if (mahnung.getBenutzer().getTel() != null) {
        name = "Tel.: "+mahnung.getBenutzer().getTel();
        if (mahnung.getBenutzer().getEMail() != null) {
          name = name + ", ";
        }
      }
      if (mahnung.getBenutzer().getEMail() != null) {
        name = name + "eMail: "+mahnung.getBenutzer().getEMail();
      }
      if (name != "") name = " ("+name+")";
      name = mahnung.getBenutzer().getNameFormal()+name;

      neuesTemplate.beginText();
      neuesTemplate.setFontAndSize(schriftFettKursiv, 12);    
      float breite = neuesTemplate.getWidth()-pdfDokument.getSeitenRandLinks()-
        pdfDokument.getSeitenRandRechts();
      float nameBreite = schriftFettKursiv.getWidthPoint(name, 12);
      if (nameBreite > breite) {
        neuesTemplate.setHorizontalScaling((breite/nameBreite)*100);
      } else {
        neuesTemplate.setHorizontalScaling(100);
      }
      neuesTemplate.setTextMatrix(pdfDokument.getSeitenRandLinks(), 
        neuesTemplate.getHeight()-12);
      neuesTemplate.showText(name);
      neuesTemplate.endText();      

      erg.add(neuesTemplate);
    }
    return erg;
  }
}
