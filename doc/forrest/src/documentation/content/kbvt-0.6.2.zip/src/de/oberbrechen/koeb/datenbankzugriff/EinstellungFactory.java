/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.EinstellungenListe;

/**
 * Diese Klasse kapselt Methoden zum Zugriff auf Einstellungen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public interface EinstellungFactory {

	/**
	 * Liefert eine unsortierte Liste aller in der Datenbank gespeicherten
	 * Einstellungen
	 * @return die Einstellungenliste
	 */
	public EinstellungenListe getAlleEinstellungen();

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * gleich dem �bergebenen Namen ist. Soll eine Einstellung f�r alle Clients
   * oder alle Mitarbeiter gesucht werden, so ist <code>null</code> f�r das 
   * entsprechende Attribut zu verwenden. Wird keine passende Einstellung 
   * gefunden, so wird eine neue erzeugt und mit dem �bergebenen Standardwert 
   * initialisiert.
	 * @param client
	 * @param mitarbeiter
	 * @param name
	 * @return die gesuchte Einstelltung
	 */
	public Einstellung getEinstellung(
		Client client, Mitarbeiter mitarbeiter, String name);


  /**
   * Liefert die Einstellung f�r den
   * �bergebenen Client und Mitarbeiter, deren Name
   * gleich dem �bergebenen Namen ist. Soll eine Einstellung f�r alle Clients
   * oder alle Mitarbeiter gesucht werden, so ist <code>null</code> f�r das 
   * entsprechende Attribut zu verwenden. Wird keine passende Einstellung 
   * gefunden, so wird eine neue erzeugt und mit dem �bergebenen Standardwert 
   * initialisiert.
   * @param client
   * @param mitarbeiter
   * @param name
   * @param namespace 
   * @return die gesuchte Einstelltung
   */
  public Einstellung getEinstellung(Client client, Mitarbeiter mitarbeiter, 
    String namespace, String name);

  /**
   * Liefert die Einstellung f�r alle Clients und Mitarbeiter, deren Name
   * gleich dem �bergebenen Namen ist. Wird keine passende Einstellung 
   * gefunden, so wird eine neue erzeugt. 
   * @param name
   * @param namespace 
   * @return die gesuchte Einstelltung
   */
  public Einstellung getEinstellung(String namespace, String name);
}