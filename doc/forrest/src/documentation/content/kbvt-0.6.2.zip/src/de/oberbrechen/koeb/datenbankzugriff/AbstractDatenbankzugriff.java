/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Observable;

/**
 * Diese Klasse ist eine unvollst�ndige
 * Standard-Implementierung des
 * Interfaces Datenbankzugriff.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public abstract class AbstractDatenbankzugriff extends Observable 
  implements Datenbankzugriff {
  
  protected int id;
  protected boolean istGespeichert;
  
  public AbstractDatenbankzugriff() {
    id = 0;
    istGespeichert = false;
  }
  
	/**
   * Interne Methode, die nur von Subklassen verwendet werden sollte.
   * Mit Hilfe dieser Methode kann die Information, dass
   * das Datenbankzugriff-Objekt nicht gespeichert ist, gesetzt werden.
   * Dies sollte immer geschehen, wenn Attribute ge�ndert werden.
	 */
  protected void setIstNichtGespeichert() {
    istGespeichert = false;
	}
  
  /**
   * Interne Methode, die nur von Subklassen verwendet werden sollte.
   * Mit Hilfe dieser Methode kann die Information, dass
   * das Datenbankzugriff-Objekt gespeichert ist, gesetzt werden.
   */
  protected void setIstGespeichert() {
    istGespeichert = true;
  }
    
  public boolean istNeu() {
    return (id == 0);
  }
  	
	public boolean istGespeichert() {
    return istGespeichert;
	}

	public String toDebugString() {
    return toString();
	}
  
	public int getId() {
    return id;
	}
  
  public boolean equals(Object object) {
    if (object == null) return false;
    if (object.getClass() != this.getClass()) return false;

    return (this.getId() == ((Datenbankzugriff) object).getId());
  }    
  
	public int hashCode() {
		return getId();
	}
  
  public String toString() {
    return this.getClass()+": "+getId();
  } 
  
  public int compareTo(Object o) {
    return this.toString().compareTo(o.toString());
  }  
}