/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.AbstractEinstellung;
import de.oberbrechen.koeb.datenbankzugriff.Client;
import de.oberbrechen.koeb.datenbankzugriff.Mitarbeiter;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlEinstellung extends AbstractEinstellung {

	public MysqlEinstellung(int id) {
    load(id);
	}

  MysqlEinstellung(ResultSet result) throws SQLException {
    load(result);
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
  }
  
  public MysqlEinstellung(Client client, Mitarbeiter mitarbeiter, String name) {
    this.client = client;
    this.mitarbeiter = mitarbeiter;
    this.name = name;
    this.wert = null;
  }
  
  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    load(getId());
	}

	public void save() throws UnvollstaendigeDatenException, EindeutigerSchluesselSchonVergebenException {
    if (istGespeichert()) return;

    if (this.getName() == null || this.getName().trim().equals("")) {
      throw new UnvollstaendigeDatenException("Jede Einstellung muss einen "+
        "Namen besitzen!");
    }

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      PreparedStatement statement = null;

      if (this.istNeu()) {
        statement = (PreparedStatement) connection.prepareStatement(
          "insert into einstellung " +
          "set ClientID = ?, MitarbeiterID = ?," +
          "Name = ?, Wert = ?");
      } else {
        statement = (PreparedStatement) connection.prepareStatement(
          "update einstellung "+
					"set ClientID = ?, MitarbeiterID = ?," +
					"Name = ?, Wert = ? "+
				  "where id="+this.getId());
      }
      
      if (getClient() == null) {
				statement.setString(1, null);
      } else {
				statement.setInt(1, this.getClient().getId());        
      }
			if (getMitarbeiter() == null) {
				statement.setString(2, null);
			} else {
				statement.setInt(2, this.getMitarbeiter().getId());        
			}
      statement.setString(3, this.getName());
      statement.setString(4, this.getWert());
      statement.execute();
      
			if (this.istNeu()) {
				ResultSet result = (ResultSet) statement.getGeneratedKeys();
				result.next();
				id = result.getInt(1);
			}
      
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern " +        "der folgenden Einstellung:\n\n"+this.toDebugString(), true);
    }

    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
	}

	public void loesche() throws DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      
			statement.execute("delete from einstellung where id = "+this.getId());
        
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);      
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen der "+
        "folgenden Einstellung: "+this.toDebugString(), true);
    }
	}
  
  void load(ResultSet result) throws SQLException {
    id = result.getInt("id");
    name = result.getString("name");
    wert = result.getString("wert");
    
    if (result.getString("clientID") != null) {
	    client = (Client) MysqlDatenbank.getMysqlInstance().
	    	getClientFactory().get(result.getInt("clientID"));
    } else {
      client = null;
    }
		if (result.getString("mitarbeiterID") != null) {
			mitarbeiter = (Mitarbeiter) MysqlDatenbank.getMysqlInstance().
				getMitarbeiterFactory().get(result.getInt("mitarbeiterID"));
		} else {
			mitarbeiter = null;
		}
  }

  void load(int id) throws DatenNichtGefundenException {
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select * from einstellung where id = " + id);
      boolean gefunden = result.next();
      if (!gefunden) throw new DatenNichtGefundenException(
        "Eine Einstellung mit der ID "+id+" existiert nicht!");
  
      load(result);
  
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "der Einstellung mit der ID "+id+"!", true);
    }
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
    
  }
}