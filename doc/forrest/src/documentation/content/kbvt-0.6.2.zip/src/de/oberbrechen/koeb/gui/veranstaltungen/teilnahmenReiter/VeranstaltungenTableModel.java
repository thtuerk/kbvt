/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.teilnahmenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import java.util.*;
import javax.swing.table.AbstractTableModel;
import java.text.DecimalFormat;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Ausleihen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/

public class VeranstaltungenTableModel extends AbstractTableModel {

  class tabellenZeile {
    Boolean nimmtAnVeranstaltungTeil;
    Benutzer benutzer;
    Veranstaltung veranstaltung;
    Veranstaltungsteilnahme veranstaltungsteilnahme;
    String bemerkungen;

    public tabellenZeile(Veranstaltung veranstaltung, Benutzer benutzer) {
      veranstaltungsteilnahme = Datenbank.getInstance().
        getVeranstaltungsteilnahmeFactory().
        getVeranstaltungsteilnahme(benutzer, veranstaltung);
      nimmtAnVeranstaltungTeil = new Boolean(veranstaltungsteilnahme != null);
      this.veranstaltung = veranstaltung;
      this.benutzer = benutzer;
      bemerkungen = null;
      if (veranstaltungsteilnahme != null) {
        bemerkungen = veranstaltungsteilnahme.getBemerkungen();
      }
    }

    public void save() {
      if (nimmtAnVeranstaltungTeil.booleanValue()) {
        if (veranstaltungsteilnahme == null) {
          veranstaltungsteilnahme = Datenbank.getInstance().
            getVeranstaltungsteilnahmeFactory().erstelleNeu(benutzer,
            veranstaltung);
        }
        veranstaltungsteilnahme.setBemerkungen(bemerkungen);
        veranstaltungsteilnahme.save();
      } else {
        if (veranstaltungsteilnahme != null) {
          veranstaltungsteilnahme.loesche();
          veranstaltungsteilnahme = null;
        }
      }
    }
  }
  
  private static DecimalFormat waehrungsFormat = new DecimalFormat("0.00");

  private TeilnahmenReiterInterface teilnahmenReiter;

  private tabellenZeile[] daten;

  public VeranstaltungenTableModel(TeilnahmenReiterInterface teilnahmenReiter,
    Benutzer benutzer, Veranstaltungsgruppe veranstaltungsgruppe) {
    this.teilnahmenReiter = teilnahmenReiter;
    init(benutzer, veranstaltungsgruppe);
  }

  /**
   * Initialisiert das Modell neu f�r den �bergebenen Benutzer und die
   * �bergebene Veranstaltungsgruppe
   *
   * @param benutzer der Benutzer
   * @param veranstaltungsgruppe die Veranstaltungsgruppe
   */
  public void init(Benutzer benutzer,Veranstaltungsgruppe veranstaltungsgruppe){
    if (veranstaltungsgruppe == null) {
      daten = null;
    } else {
      VeranstaltungenListe veranstaltungenListe =
        Datenbank.getInstance().getVeranstaltungFactory().
          getVeranstaltungenMitAnmeldung(veranstaltungsgruppe);
      veranstaltungenListe.setSortierung(VeranstaltungenListe.AlphabetischeSortierung);
      daten = new tabellenZeile[veranstaltungenListe.size()];
      Iterator it = veranstaltungenListe.iterator();

      int pos = 0;
      while (it.hasNext()) {
        daten[pos] = new tabellenZeile((Veranstaltung) it.next(), benutzer);
        pos++;
      }
    }
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.length;
  }

  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex == 0 || (columnIndex == 4 &&
      daten[rowIndex].nimmtAnVeranstaltungTeil.booleanValue()));
  }

  public int getColumnCount() {
    return 6;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "";
    if (columnIndex == 1) return "Veranstaltung";
    if (columnIndex == 2) return "Teilnehmeranzahl";
    if (columnIndex == 3) return "Bezugsgruppe";
    if (columnIndex == 4) return "Kosten";
    if (columnIndex == 5) return "Bemerkungen";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return Boolean.class;
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.length) return null;
    tabellenZeile gewaehlteZeile = daten[rowIndex];
    if (columnIndex == 0) return gewaehlteZeile.nimmtAnVeranstaltungTeil;
    if (columnIndex == 1) return gewaehlteZeile.veranstaltung.getTitel();
    if (columnIndex == 2) {
      VeranstaltungsteilnahmeFactory teilnahmeFactory =
        Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();
      if (gewaehlteZeile.veranstaltung.getMaximaleTeilnehmerAnzahl() == 0)
        return Integer.toString(teilnahmeFactory.getTeilnehmerAnzahl(
                gewaehlteZeile.veranstaltung));
      else
        return teilnahmeFactory.
          getTeilnehmerAnzahl(gewaehlteZeile.veranstaltung)+ "/"+
          gewaehlteZeile.veranstaltung.getMaximaleTeilnehmerAnzahl();
    }
    if (columnIndex == 3) return gewaehlteZeile.veranstaltung.getBezugsgruppe();
    if (columnIndex == 4) return gewaehlteZeile.veranstaltung.getKostenFormatiert();
    if (columnIndex == 5) return gewaehlteZeile.bemerkungen;
    return "nicht definierte Spalte";
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.length) return;
    tabellenZeile gewaehlteZeile = daten[rowIndex];
    if (columnIndex == 0) {
      gewaehlteZeile.nimmtAnVeranstaltungTeil = (Boolean) aValue;
      teilnahmenReiter.setzeKosten(this.berechneKosten());
    }
    if (columnIndex == 4) {
      gewaehlteZeile.bemerkungen = (String) aValue;
    }
    fireTableCellUpdated(rowIndex, columnIndex);
  }

  /**
   * Liefert die Veranstaltung, die in der �bergebenen Zeile des Models
   * dargestellt wird
   */
  public Veranstaltung getVeranstaltung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.length) return null;
    return daten[rowIndex].veranstaltung;
  }

  public void save() {
    if (daten == null) return;
    for (int i = 0; i < daten.length; i++) {
      daten[i].save();
    }
  }

  public String berechneKosten() {
    if (daten == null || daten.length == 0) return "-";

    String waehrung = null;
    double kosten = 0;
    for (int i = 0; i < daten.length; i++) {
      if (daten[i] != null && daten[i].nimmtAnVeranstaltungTeil.booleanValue() &&
          daten[i].veranstaltung.getKosten() != 0) {
        kosten += daten[i].veranstaltung.getKosten();
        if (waehrung == null)
          waehrung = daten[i].veranstaltung.getWaehrung();
        else
          if (!waehrung.equals(daten[i].veranstaltung.getWaehrung()))
            return "???";
      }
    }

    if (kosten == 0) {
      return "-";
    } else {
      return waehrungsFormat.format(kosten)+" "+waehrung;
    }
  }

  public void fireTableDataChanged() {
    teilnahmenReiter.setzeKosten(this.berechneKosten());
    super.fireTableDataChanged();
  }
}
