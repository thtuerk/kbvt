/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.ausleiheReiter;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
 * Diese Klasse ist ein TableCellRenderer f�r eine Liste von
 * Ausleihzeitr�umen.
 */
public class ZeitraumTableRenderer implements TableCellRenderer {

  private DefaultTableCellRenderer renderer;

  private static final Color ueberzogenForeground = new Color(255,0,0);
  private static final Color ueberzogenBackground = new Color(255,0,0,30);
  private static final Color standardForeground = new Color(0,0,0);
  private static final Color standardBackground = new Color(0,0,0,30);

  public ZeitraumTableRenderer() {
    renderer = new DefaultTableCellRenderer();
    renderer.setOpaque(true);
    
    renderer.setFont(renderer.getFont().deriveFont(Font.PLAIN));
  }

  public Component getTableCellRendererComponent(
    JTable table, Object value, boolean isSelected,
    boolean hasFocus, int row, int column) {

    Ausleihzeitraum ausleihzeitraum = ((ZeitraumTableModel) table.getModel()).
      getAusleihzeitraum(row);

    renderer.setText(value.toString());

    if (ausleihzeitraum.istUeberzogen()) {
      renderer.setForeground(ueberzogenForeground);
      renderer.setBackground(ueberzogenBackground);
    } else {
      renderer.setForeground(standardForeground);
      renderer.setBackground(standardBackground);
    }
    if (!isSelected) renderer.setBackground(Color.white);

    return renderer;
  }


}