/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;

/**
 * Dieses Interface repr�sentiert eine Factory f�r Ausleihen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public interface AusleiheFactory extends DatenbankzugriffFactory {
  
  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Ausleihe-Objekt
   * 
   * @return das neue Ausleihe-Objekt
   */
  public abstract Ausleihe erstelleNeu(); 

  /**
   * Liefert eine unsortierte Liste aller Ausleihen.
   *
   * @see AusleihenListe
   */
  public AusleihenListe getAlleAusleihen();

  /**
   * Liefert eine unsortierte Liste aller Ausleihzeitr�ume.
   *
   * @see AusleihenListe
   */
  public AusleihzeitraumListe getAlleAusleihzeitraeume();

  /**
   * Liefert eine unsortierte Liste aller Ausleihzeitr�ume, die im �bergebenen
   * Zeitraum get�tigt wurden.
   */
  public AusleihzeitraumListe getGetaetigteAusleihzeitraeumeInZeitraum(Zeitraum zeitraum);

  /**
   * Liefert die Anzahl aller Ausleihzeitr�ume, die im �bergebenen
   * Monat f�r Ausleihen get�tigt wurden.
   */
  public int getAnzahlGetaetigteAusleihzeitraeumeInZeitraum(Zeitraum zeitraum);

  /**
   * Liefert eine unsortierte Liste aller aktuellen Ausleihen des �bergebenen
   * Benutzers.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public AusleihenListe getAlleAktuellenAusleihenVon(Benutzer benutzer);

  /**
   * Liefert eine unsortierte Liste aller zum �bergebenen Zeitpunkt aktuellen
   * Ausleihen des �bergebenen Benutzers, d.h. aller Ausleihen, 
   * die zu dem angegebenen Zeitpunkt zwar ausgeliehen aber noch
   * nicht zur�ckgegeben waren. Ausleihen, die am uebergebenen Datum
   * zurueckgegeben wurden, werden als ebenfalls zurueckgeliefert.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @param datum das Datum an dem die Ausleihen zwar get�tigt, aber noch
   *   nicht zur�ckgegeben waren
   * @see AusleihenListe
   */
  public AusleihenListe getAlleAktuellenAusleihenVon(
    Benutzer benutzer, Date datum);

  /**
   * Liefert eine unsortierte Liste aller zum �bergebenen Zeitpunkt nicht 
   * zur�ckgegebenen Ausleihen des �bergebenen Benutzers, d.h. aller Ausleihen, 
   * die zu dem angegebenen Zeitpunkt zwar ausgeliehen aber noch
   * nicht zur�ckgegeben waren. Ausleihen, die am uebergebenen Datum
   * zurueckgegeben wurden, werden als ebenfalls zurueckgeliefert.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @param datum das Datum an dem die Ausleihen zwar get�tigt, aber noch
   *   nicht zur�ckgegeben waren
   * @see AusleihenListe
   */
  public AusleihenListe getAlleNichtZurueckgegebenenAusleihenVon(
      Benutzer benutzer, Date datum);
  
  /**
   * Liefert eine unsortierte Liste aller zum aktuellen Zeitpunkt nicht 
   * zur�ckgegebenen Ausleihen des �bergebenen Benutzers, d.h. aller Ausleihen, 
   * die zu dem angegebenen Zeitpunkt zwar ausgeliehen aber noch
   * nicht zur�ckgegeben waren. Ausleihen, die am uebergebenen Datum
   * zurueckgegeben wurden, werden als ebenfalls zurueckgeliefert.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @param datum das Datum an dem die Ausleihen zwar get�tigt, aber noch
   *   nicht zur�ckgegeben waren
   * @see AusleihenListe
   */
  public AusleihenListe getAlleNichtZurueckgegebenenAusleihenVon(
      Benutzer benutzer);

  /**
   * Liefert eine unsortierte Liste aller Ausleihen des Benutzers.
   *
   * @param benutzer der Benutzer, dessen Ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public AusleihenListe getAlleAusleihenVon(Benutzer benutzer);

  /**
   * Liefert eine unsortierte Liste aller Ausleihen des �bergebenen
   * Mediums.
   *
   * @param medium das Medium, dessen Ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public AusleihenListe getAlleAusleihenVon(Medium medium);
  
  /**
   * Liefert das erste und das letzte Jahr, in dem eine Ausleihe
   * get�tigt wurde.
   * @return das erste und letzte Jahr
   */
  public int[] getErstesLetztesJahrEinerAusleihe();
  
  
}