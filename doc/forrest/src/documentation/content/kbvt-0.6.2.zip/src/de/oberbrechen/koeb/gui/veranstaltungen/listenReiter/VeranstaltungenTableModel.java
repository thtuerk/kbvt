/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.listenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Veranstaltungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.9 $
*/

public class VeranstaltungenTableModel extends AbstractTableModel {

  private Veranstaltungsgruppe veranstaltungsgruppe;
  private VeranstaltungenListe daten;
  private VeranstaltungsteilnahmeFactory veranstaltungsteilnahmeFactory =
    Datenbank.getInstance().getVeranstaltungsteilnahmeFactory();

  public VeranstaltungenTableModel(Veranstaltungsgruppe gruppe) {
    this.daten = new VeranstaltungenListe();
    daten.setSortierung(VeranstaltungenListe.AlphabetischeSortierung);
    setVeranstaltungsgruppe(gruppe);
  }

  /**
   * Zeigt die zur �bergebenen Veranstaltungsgruppe geh�renden
   * Veranstaltungen in der Tabelle an.
   * @param neueGruppe die Veranstaltungsgruppe, deren Veranstaltungen angezeigt
   *   werden sollen.
   */
  public void setVeranstaltungsgruppe(Veranstaltungsgruppe neueGruppe) {
    veranstaltungsgruppe = neueGruppe;
    
    VeranstaltungFactory veranstaltungFactory =
      Datenbank.getInstance().getVeranstaltungFactory();
    
    VeranstaltungenListe neueDaten = null;    
    if (veranstaltungsgruppe != null)
      neueDaten = veranstaltungFactory.getVeranstaltungenMitAnmeldung(
      veranstaltungsgruppe);

    daten.clear();
    if (neueDaten != null) {
      daten.addAllNoDuplicate(neueDaten);
    }
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null || daten.size() == 0) return 0;
    return daten.size()+1;
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Titel";
    if (columnIndex == 1) return "Teilnehmeranzahl";
    if (columnIndex == 2) return "Kosten";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex > daten.size()) return null;

    if (rowIndex == 0) {
      if (columnIndex == 0) return "Gesamt";
      if (columnIndex == 1) return
        Integer.toString(veranstaltungsteilnahmeFactory.
        getTeilnehmerAnzahl(veranstaltungsgruppe));
      if (columnIndex > 1) return "-";
    } else {
      Veranstaltung gewaehlteVeranstaltung = getVeranstaltung(rowIndex);
      if (columnIndex == 0) return gewaehlteVeranstaltung.getTitel();
      if (columnIndex == 1)
        if (gewaehlteVeranstaltung.getMaximaleTeilnehmerAnzahl() == 0)
          return Integer.toString(veranstaltungsteilnahmeFactory.
            getTeilnehmerAnzahl(gewaehlteVeranstaltung));
        else
          return veranstaltungsteilnahmeFactory.getTeilnehmerAnzahl(
            gewaehlteVeranstaltung) + "/"+
            gewaehlteVeranstaltung.getMaximaleTeilnehmerAnzahl();
      if (columnIndex == 2) return gewaehlteVeranstaltung.getKostenFormatiert();
    }
    return "nicht definierte Spalte";
  }

  /**
   * Liefert die Veranstaltung, die in der �bergebenen Zeile des Models
   * dargestellt wird
   */
  public Veranstaltung getVeranstaltung(int rowIndex) {
    if (rowIndex < 1 || rowIndex > daten.size()) return null;
    return (Veranstaltung) daten.get(rowIndex-1);
  }
}
