/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;
import de.oberbrechen.koeb.datenstrukturen.InternetfreigabenListe;

/**
 * Dieses Interface repr�sentiert eine Factory f�r Benutzer.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public interface InternetfreigabeFactory extends DatenbankzugriffFactory {
    
  /**
   * Erstellt eine neue Internetfreigabe, die den �bergebenen Client
   * f�r den �bergebenen Benutzer ab dem angegebenen Zeitpunkt freigibt und
   * vom �bergebenen Mitarbeiter get�tigt wird.
   *
   * @param benutzer der Benutzer, f�r den der Internetzugang freigeschaltet
   *   werden soll
   * @param Client der Client, an dem der Internetzugang freigeschaltet werden
   *   soll
   * @param mitarbeiter der Mitarbeiter, der die Freigabe t�tigt
   */
  public Internetfreigabe freigeben(Benutzer benutzer, Client client,
    Mitarbeiter mitarbeiter, Date beginn);
    
	/**
	 * Erstellt eine neue Internetfreigabe, die den �bergebenen Client
	 * f�r den �bergebenen Benutzer ab dem aktuellen Zeitpunkt freigibt und
	 * vom �bergebenen Mitarbeiter get�tigt wird.
	 *
	 * @param benutzer der Benutzer, f�r den der Internetzugang freigeschaltet
	 *   werden soll
	 * @param Client der Client, an dem der Internetzugang freigeschaltet werden
	 *   soll
	 * @param mitarbeiter der Mitarbeiter, der die Freigabe t�tigt
	 */
	public Internetfreigabe freigeben(Benutzer benutzer, Client client,
		Mitarbeiter mitarbeiter);


	/**
	 * Erstellt eine neue Internetfreigabe, die den �bergebenen Client
	 * f�r den �bergebenen Benutzer ab dem aktuellen Zeitpunkt freigibt und
	 * vom aktuellen Mitarbeiter get�tigt wird.
	 *
	 * @param benutzer der Benutzer, f�r den der Internetzugang freigeschaltet
	 *   werden soll
	 * @param Client der Client, an dem der Internetzugang freigeschaltet werden
	 *   soll
	 */
	public Internetfreigabe freigeben(Benutzer benutzer, Client client);
	
	/**
   * Bestimmt, ob der Internetzugang f�r den �bergebenen Client zu Zeit
   * freigegeben ist.
   * @param client
   * @return <code>TRUE</code> gdw. der Internetzugang f�r den �bergebenen
   *  Client zur Zeit freigegeben ist
   */
  public boolean istInternetzugangFreigegeben(Client client);
  
  /**
   * Liefert die zeitlich letzte Freigabe f�r den �bergebenen Client. Wurde
   * der Client noch nie freigegeben wird <code>null</code> geliefert.
   * @param client der Client, dessen letzte Freigabe geliefert werden soll
   * @return die letzte Freigabe
   */
  public Internetfreigabe getAktuelleInternetfreigabe(Client client);
  
  /**
   * Liefert eine unsortierte Liste aller Internetfreigaben, die im �bergebenen
   * Monat get�tigt wurden.
   * 
   * @param monat die Nr des Monats von 1 bis 12
   * @param jahr das Jahr
   */
  public InternetfreigabenListe 
    getAlleInternetFreigabenInMonat(int monat, int jahr);

  /**
   * Liefert eine unsortierte Liste aller Internetfreigaben, 
   * die zwischen den beiden �bergebenen
   * Zeitpunkten get�tigt wurden.
   * 
   * @param von der Startzeitpunkt
   * @param bis der Entzeitpunkt
   */
  public InternetfreigabenListe getAlleInternetfreigabenInZeitraum(
    Date von, Date bis);

  /**
   * Sperrt den Internetzugang f�r den �bergebenen Client
   * @param client
   */
  public void sperren(Client client);

  /**
   * Liefert das erste und das letzte Jahr, in dem eine Internetfreigabe
   * get�tigt wurde.
   * @return das erste und letzte Jahr
   */
  public int[] getErstesLetztesJahrEinerInternetfreigabe();
}