/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class MysqlMitarbeiter extends AbstractMitarbeiter {

	public MysqlMitarbeiter(int id) {
    load(id);    
  }

	public MysqlMitarbeiter(Benutzer benutzer) {
    this.benutzer = benutzer;
	}
  
  MysqlMitarbeiter(ResultSet result) throws SQLException {
    load(result);
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
  }

	public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    this.load(this.getId());
	}
  
  void load(int id) {
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select * from mitarbeiter where id = " + id);
      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit der id "+id+" existiert nicht!");

      load(result);

      MysqlDatenbank.getMysqlInstance().endTransaktion();
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "des Mitarbeiters mit der ID "+id, true);
    }
  }  

	void load(ResultSet result) throws SQLException {
    this.id = result.getInt("id");
    mitarbeiterBenutzername = result.getString("benutzername");
    mitarbeiterPasswortPruefziffer = result.getString("Passwort");
    berechtigungen = result.getInt("Berechtigungen");

    int benutzerId = result.getInt("BenutzerID");
    try {
      benutzer = (Benutzer) MysqlDatenbank.getMysqlInstance().
        getBenutzerFactory().get(benutzerId);
    } catch (DatenNichtGefundenException e) {
      MysqlDatenbank.getMysqlInstance().endTransaktion();
      throw new DatenbankInkonsistenzException("Der Mitarbeiter mit der "+
        "ID "+id+" verweist auf die nicht existierende "+
        "BenutzerID "+benutzerId+"!");
    }
	}
  
	public void save() throws UnvollstaendigeDatenException, EindeutigerSchluesselSchonVergebenException {
    if (istGespeichert()) return;

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      
      //ist Benutzer schon Mitarbeiter unter anderem Namen
      try {
        MitarbeiterFactory mitarbeiterFactory =
          MysqlDatenbank.getMysqlInstance().getMitarbeiterFactory();
        int zugehoerigeMitarbeiterId =
          mitarbeiterFactory.sucheBenutzer(getBenutzer().getId());
  
        if (zugehoerigeMitarbeiterId != this.getId()) {
          MysqlDatenbank.getMysqlInstance().endTransaktion();
          throw new BenutzerSchonMitarbeiterException((Mitarbeiter)
              mitarbeiterFactory.get(zugehoerigeMitarbeiterId));       
        }
      } catch (DatenNichtGefundenException e) {
        //alles OK
      }    
      
      //ist Mitarbeiterbenutzername eindeutig?
      if (mitarbeiterBenutzername != null) {
        try {
          MitarbeiterFactory mitarbeiterFactory =
            MysqlDatenbank.getMysqlInstance().getMitarbeiterFactory();
          int zugehoerigeMitarbeiterId =
            mitarbeiterFactory.sucheMitarbeiterBenutzername(
              getMitarbeiterBenutzername());
      
          if (zugehoerigeMitarbeiterId != this.getId()) {
            MysqlDatenbank.getMysqlInstance().endTransaktion();
            throw new MitarbeiterbenutzernameSchonVergebenException
              ((Mitarbeiter) mitarbeiterFactory.get(zugehoerigeMitarbeiterId));       
          }
        } catch (DatenNichtGefundenException e) {
          //alles OK
        }    
      }

      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      PreparedStatement statement = null;
      if (this.istNeu()) {
        statement = (PreparedStatement) connection.prepareStatement(
          "insert into mitarbeiter set BenutzerID = ?, "+
          "Benutzername = ?, Passwort = ?, Berechtigungen = ?");
      } else {
        statement = (PreparedStatement) connection.prepareStatement(
          "update mitarbeiter set BenutzerID = ?, "+
          "Benutzername = ?, Passwort = ?, Berechtigungen = ? "+
          "where ID="+getId());
      }
      statement.setInt(1, this.getBenutzer().getId());
      statement.setString(2, this.getMitarbeiterBenutzername());
      statement.setString(3, mitarbeiterPasswortPruefziffer);
      statement.setInt(4, berechtigungen);

      statement.execute();
      if (this.istNeu()) {
        ResultSet result = (ResultSet) statement.getGeneratedKeys();
        result.next();
        id = result.getInt(1);
      }
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des folgenden "+
        "Mitarbeiters:\n\n"+this.toDebugString(), true);
    }

    setIstGespeichert();
    setChanged();
    notifyObservers();    
	}

	public void loesche() throws DatenbankInkonsistenzException {
    if (this.istNeu()) return;

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();

      //Ausleihen
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select count(id) from ausleihe where "+
				  "MitarbeiterIdRueckgabe="+this.getId());
      result.next();
      boolean ausleiheVorhanden = result.getInt(1) > 0;
      if (!ausleiheVorhanden) {
        result = (ResultSet) statement.executeQuery(
            "select count(*) from ausleihzeitraum where "+
            "MitarbeiterId="+this.getId());
        result.next();        
        ausleiheVorhanden = result.getInt(1) > 0;
      }
      
      if (ausleiheVorhanden) {
        MysqlDatenbank.getMysqlInstance().endTransaktion();
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+
        this.getBenutzer().getName()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Mitarbeiters "+
        "existieren.");
      }

      // Internet
      result = (ResultSet) statement.executeQuery(
        "select count(id) from internet_zugang where "+
        "MitarbeiterId="+this.getId());
      result.next();
      if (result.getInt(1) > 0) {
        MysqlDatenbank.getMysqlInstance().endTransaktion();
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+
        this.getBenutzer().getName()+
        " kann nicht gel�scht werden, da noch Internetfreigaben dieses "+
        "Mitarbeiters existieren.");
      }

      // Mitarbeiter l�schen
      statement.execute("delete from einstellung where "+
        "MitarbeiterId=\""+this.getId()+"\"");
      statement.execute("delete from mitarbeiter where "+
        "id=\""+this.getId()+"\"");

      MysqlDatenbank.getMysqlInstance().endTransaktion();
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Mitarbeiters:\n\n"+this.toDebugString(), true);
    }
	}

}