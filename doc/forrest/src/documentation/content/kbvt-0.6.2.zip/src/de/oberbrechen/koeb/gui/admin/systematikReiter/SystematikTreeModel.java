/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.systematikReiter;

import java.text.Collator;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import de.oberbrechen.koeb.datenbankzugriff.Systematik;

/**
* Diese Klasse ist ein Tabellenmodell f�r einen Baum von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/
public class SystematikTreeModel extends DefaultTreeModel {
  
  protected Hashtable cache;
  
  public SystematikTreeModel() {
    super(new DefaultMutableTreeNode());
  }
  
  public void initCache(SystematikTreeNode node) {
    Enumeration children = node.children();
    while (children.hasMoreElements()) {
      SystematikTreeNode nextNode = (SystematikTreeNode) children.nextElement();
      
      cache.put(nextNode.getSystematik(), nextNode);
      initCache(nextNode);
    }
  }
  
  public SystematikTreeNode getTreeNode(Systematik systematik) {
    if (systematik == null) return (SystematikTreeNode) this.getRoot();
    
    return (SystematikTreeNode) cache.get(systematik);
  }

  public void addSystematik(Systematik systematik) {
    SystematikTreeNode parent = getTreeNode(systematik.getDirekteObersystematik());
    SystematikTreeNode newNode = new SystematikTreeNode(systematik, this);
    addOrdered(parent, newNode);
    cache.put(systematik, newNode);
  }

  public void removeSystematik(Systematik systematik) {
    SystematikTreeNode node = getTreeNode(systematik);
    removeNodeFromParent(node);
    cache.remove(systematik);
  }  

  public void updateSystematik(Systematik systematik) {
    SystematikTreeNode node = getTreeNode(systematik);
    removeNodeFromParent(node);
    
    SystematikTreeNode parent = getTreeNode(systematik.getDirekteObersystematik());
    addOrdered(parent,node);
  }
  
  private void addOrdered(SystematikTreeNode parent, SystematikTreeNode newNode) {
    Collator collator = Collator.getInstance();
    int i = parent.getChildCount();
    
    
    while(i > 0 && collator.compare(parent.getChildAt(i-1).toString(), newNode.toString()) > 0) {
      i--;
    }
    
    insertNodeInto(newNode, parent, i);
  }

  /**
   * Initialisiert die Daten des Modells
   */
  public void init() {
    SystematikTreeNode root = new SystematikTreeNode(null, this);
    this.setRoot(root);      

    cache = new Hashtable();    
    initCache((SystematikTreeNode) getRoot());
  }  
}
