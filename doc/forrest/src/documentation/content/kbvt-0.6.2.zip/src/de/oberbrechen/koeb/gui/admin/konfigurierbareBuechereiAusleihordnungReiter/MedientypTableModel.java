/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.konfigurierbareBuechereiAusleihordnungReiter;

import java.util.Vector;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.MedientypSchonVergebenException;
import de.oberbrechen.koeb.datenstrukturen.MedientypListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import java.util.Iterator;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von 
* Medientyp-Einstellungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.9 $
*/

public class MedientypTableModel extends AbstractTableModel {
  
  class MedientypDaten {
    Medientyp medientyp;
    Einstellung mindestAusleihDauerEinstellung;
    Einstellung medienNrPraefixEinstellung;
    Einstellung langesMedienNrFormatEinstellung;
    int mediennr;
    
    public MedientypDaten(Medientyp medientyp) {
      MedientypFactory medientypFactory =
        Datenbank.getInstance().getMedientypFactory();
      this.medientyp = (Medientyp) medientypFactory.ladeAusDatenbank(
        medientyp.getId());
      mediennr = (int) (Math.random()*200);  
      
      initEinstellungen();       
    }
    
    private void initEinstellungen() {
      EinstellungFactory einstellungFactory = 
        Datenbank.getInstance().getEinstellungFactory();

      mindestAusleihDauerEinstellung = 
        einstellungFactory.getEinstellung(
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareAusleihordnung", 
        "mindestAusleihdauerInTagen."+getMedientyp());
      
      medienNrPraefixEinstellung = 
        einstellungFactory.getEinstellung( 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "MediennrPraefix."+getMedientyp());

      langesMedienNrFormatEinstellung = 
        einstellungFactory.getEinstellung( 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "EinstellungsjahrInMediennr."+getMedientyp());      
    }
    
    public boolean isLangesMedienNrFormat() {
      return langesMedienNrFormatEinstellung.getWertBoolean(true);
    }

    public String getMedienNrPraefix() {
      return medienNrPraefixEinstellung.getWert(getMedientyp());
    }

    public String getMedientyp() {
      return medientyp.getName();
    }

    public int getMindestAusleihDauer() {
      return mindestAusleihDauerEinstellung.getWertInt(21);
    }

    public String getPlural() {
      return medientyp.getPlural();
    }

    public void setLangesMedienNrFormat(boolean b) {
      langesMedienNrFormatEinstellung.setWertBoolean(b);
      langesMedienNrFormatEinstellung.save();
    }

    public void setMedienNrPraefix(String string) {      
      medienNrPraefixEinstellung.setWert(string);
      medienNrPraefixEinstellung.save();
    }

    public void setMedientyp(String string) {
      int oldMedientypId = medientyp.getId();
      try {
        medientyp.setName(string);
        medientyp.save();

        //Einstellungen anpassen
        int mindestAusleihdauer = mindestAusleihDauerEinstellung.getWertInt(21);
        String medienNrPraefix = medienNrPraefixEinstellung.getWert("01");
        boolean langesMedienNrFormat = 
          langesMedienNrFormatEinstellung.getWertBoolean(true);

        mindestAusleihDauerEinstellung.loesche();
        medienNrPraefixEinstellung.loesche();
        langesMedienNrFormatEinstellung.loesche();
        
        initEinstellungen();
        
        mindestAusleihDauerEinstellung.setWertInt(mindestAusleihdauer);
        mindestAusleihDauerEinstellung.save();
        medienNrPraefixEinstellung.setWert(medienNrPraefix);
        medienNrPraefixEinstellung.save();
        langesMedienNrFormatEinstellung.setWertBoolean(langesMedienNrFormat);
        langesMedienNrFormatEinstellung.save();
      } catch (MedientypSchonVergebenException e) {
        JOptionPane.showMessageDialog(hauptFenster, "Der Medientyp '" +
          string+"' existiert bereits!",
          "Ung�ltige Eingabe!", JOptionPane.ERROR_MESSAGE);
        
        MedientypFactory medientypFactory = 
          Datenbank.getInstance().getMedientypFactory();        
        medientyp = (Medientyp) 
          medientypFactory.ladeAusDatenbank(oldMedientypId);
        fireTableDataChanged();                
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des Medientyps "+medientyp.toDebugString()+"!", false);        
      }
    }

    public void setPlural(String string) {
      try {
        medientyp.setPlural(string);
        medientyp.save();
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des Medientyps "+medientyp.toDebugString()+"!", false);        
      }
    }

    public void setMindestAusleihDauer(int i) {
      mindestAusleihDauerEinstellung.setWertInt(i);
      mindestAusleihDauerEinstellung.save();
    }

    public String getBeispiel() {
      StringBuffer buffer = new StringBuffer();
      if (medienNrPraefixEinstellung.getWert() != null && 
        !medienNrPraefixEinstellung.getWert().trim().equals("") )
        buffer.append(medienNrPraefixEinstellung.getWert()).append(" ");
      if (isLangesMedienNrFormat()) buffer.append("2003-");
      buffer.append(mediennr);
      return buffer.toString();
    }

  }
  
  Vector daten;
  final JFrame hauptFenster;
  
  public MedientypTableModel(JFrame hauptFenster) {
    this.hauptFenster = hauptFenster;
    init();
  }
  
  public void init() {
    MedientypFactory medientypFactory =
      Datenbank.getInstance().getMedientypFactory();
    MedientypListe medientypListe = 
      medientypFactory.getAlleMedientypen();
    medientypListe.setSortierung(MedientypListe.StringSortierung);
    
    daten = new Vector();
    Iterator it = medientypListe.iterator();
    while (it.hasNext()) {
      daten.add(new MedientypDaten((Medientyp) it.next()));
    }
  }
      
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 6;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Medientyp";
    if (columnIndex == 1) return "Plural";
    if (columnIndex == 2) return "Mindestausleihdauer";
    if (columnIndex == 3) return "Mediennr.-Pr�fix";
    if (columnIndex == 4) return "langes Mediennr.-Format";
    if (columnIndex == 5) return "Beispiel";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return String.class;
    if (columnIndex == 1) return String.class;
    if (columnIndex == 2) return Integer.class;
    if (columnIndex == 3) return String.class;
    if (columnIndex == 4) return Boolean.class;
    if (columnIndex == 5) return String.class;
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    MedientypDaten gewaehlteDaten = (MedientypDaten) daten.get(rowIndex);
    
    if (columnIndex == 0) return gewaehlteDaten.getMedientyp();
    if (columnIndex == 1) return gewaehlteDaten.getPlural();
    if (columnIndex == 2) return new Integer(gewaehlteDaten.getMindestAusleihDauer());
    if (columnIndex == 3) return gewaehlteDaten.getMedienNrPraefix();
    if (columnIndex == 4) return new Boolean(gewaehlteDaten.isLangesMedienNrFormat());
    if (columnIndex == 5) return gewaehlteDaten.getBeispiel();
    return "nicht definierte Spalte";
  }

  public Einstellung getEinstellung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Einstellung) daten.get(rowIndex);
  }
  
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex < 5);
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (columnIndex >= 5) return;
    
    MedientypDaten gewaehlteDaten = (MedientypDaten) daten.get(rowIndex);
    
    if (columnIndex == 0) gewaehlteDaten.setMedientyp((String) aValue);
    if (columnIndex == 1) gewaehlteDaten.setPlural((String) aValue);
    if (columnIndex == 2) gewaehlteDaten.setMindestAusleihDauer(((Integer) aValue).intValue());
    if (columnIndex == 3) gewaehlteDaten.setMedienNrPraefix((String) aValue);
    if (columnIndex == 4) gewaehlteDaten.setLangesMedienNrFormat(((Boolean) aValue).booleanValue());

    fireTableRowsUpdated(rowIndex, rowIndex);
  }

  public void refresh() {
    init();
  }

}
