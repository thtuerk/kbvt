/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben;

import java.util.Collection;

/**
* Dieses Interface repr�sentiert eine Ausgabe f�r Benutzer.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/
public interface BenutzerAusgabe extends Ausgabe{

  /**
   * Setzt die von der Ausgabe anzuzeigenden Benutzer.
   * @param daten die neuen Daten
   */
  public void setDaten(Collection daten);
  
  /**
   * Setzt die von der Ausgabe zu verwendenden Titel f�r die Benutzerliste.
   * @param titel der neue Titel
   */
  public void setTitel(String titel);
    
  /**
   * Setzt die von der Ausgabe zu verwendende Sortierung.
   * @param sortierung Konstante aus BenutzerListe, die die Sortierung bestimmt
   * @param umgekehrteSortierung bestimmt, ob die Sortierung umgekehrt werden soll
   */
  public void setSortierung(int Sortierung, boolean umgekehrteSortierung);
}