/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Date;

import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;

/**
* Dieses Interface repr�sentiert eine Ausleihe.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.25 $
*/
public interface Ausleihe extends Datenbankzugriff {
  
 	/**
	 * Bestimmt, ob die Ausleihe �berzogen ist, d.h. das Sollr�ckgabedatum
	 * bereits verstrichen ist
	 *
	 * @return <code>true</code> gdw. die Ausleihe �berzogen ist
	 */
	public boolean istUeberzogen();

	/**
	 * Liefert die Anzahl der Tage, die die Ausleihe �berzogen ist.
	 * @return die Anzahl der Tage, die die Ausleihe �berzogen ist
	 */
	public int getUeberzogeneTage();

	/**
	 * Bestimmt, ob die Ausleihe schon zur�ckgegeben ist.
	 * @return <code>true</code> gdw. die Ausleihe zur�ckgegeben ist
	 */
	public boolean istZurueckgegeben();

	/**
	 * Bestimmt, ob es sich um eine aktuelle Ausleihe handelt. Eine Ausleihe ist
	 * aktuell, wenn sie noch nicht oder heute zur�ckgegeben wurde.
	 *
	 * @return <code>true</code> gwd. es sich um eine aktuelle Ausleihe handelt
	 */
	public boolean istAktuell();

	/**
	 * Bestimmt, ob die Ausleihe heute zur�ckgegeben wurde; d.h. ob das
	 * Rueckgabedatum dem aktuellen Datum entspricht und diese
	 * Ausleihe von keiner anderen Ausleihe verl�ngert wird.
	 *
	 * @return <code>true</code> gdw. die Ausleihe heute zur�ckgegeben wurde.
	 */
	public boolean heuteZurueckgegeben();

	/**
	 * Bestimmt, ob die Ausleihe aktuell verl�ngert wurde; d.h. ob diese
	 * Ausleihe eine Verl�ngerung heute verl�ngert wurde.
	 *
	 * @return <code>true</code> gdw. die Ausleihe aktuell verl�ngert wurde.
	 */
	public boolean istAktuellVerlaengert();

	/**
	 * Bestimmt, ob die Ausleihe heute get�tigt wurde; d.h. ob das Medium
	 * heute ausgeliehen wurde.
	 * @return <code>true</code> gdw. die Ausleihe heute get�tigt wurde
	 */
	public boolean heuteGetaetigt();

	/**
	 * Liefert den Benutzer, den diese Ausleihe betrifft
	 * @return den Benutzer, den diese Ausleihe betrifft
	 */
	public Benutzer getBenutzer();

	/**
	 * Liefert das Medium, das diese Ausleihe betrifft
	 * @return den Medium, das diese Ausleihe betrifft
	 */
	public Medium getMedium();

	/**
	 * Liefert den Mitarbeiter, der das Medium herausgab. D.h. es wird der
	 * Mitarbeiter geliefert, der den Ersten Ausleihzeitraum der Ausleihe eintrug.
	 * @return den Mitarbeiter, der das Medium herausgab
	 */
	public Mitarbeiter getMitarbeiterAusleihe();

	/**
	 * Liefert den Mitarbeiter, der das Medium zur�cknahm
	 * @return den Mitarbeiter, der das Medium zur�cknahm
	 */
	public Mitarbeiter getMitarbeiterRueckgabe();

	/**
	 * Liefert das Datum, an dem das Medium ausgeliehen wurde, d.h. den Beginn
	 * des ersten Ausleihzeitraums.
	 * @return das Datum, an dem das Medium ausgeliehen wurde
	 */
	public Date getAusleihdatum();

	/**
	 * Liefert das Datum, an dem das Medium zur�ckgegeben werden soll, d.h. das
	 * Ende des bisher letzten Ausleihzeitraums
	 * @return das Datum, an dem das Medium zur�ckgegeben werden soll
	 */
	public Date getSollRueckgabedatum();

	/**
	 * Liefert das Datum, an dem das Medium zur�ckgegeben wurde. Ist
	 * das Medium noch nicht zur�ckgegeben wird <code>null</code> geliefert.
	 *
	 * @return das Datum, an dem das Medium zur�ckgegeben wurde
	 */
	public Date getRueckgabedatum();

	/**
	 * Liefert die Bemerkungen zu dieser Ausleihe.
	 * @return die Bemerkungen zu dieser Ausleihe
	 */
	public String getBemerkungen();

	/**
	 * Setzt den Benutzer, den diese Ausleihe betrifft
	 * @param benutzer der neue Benutzer, den diese Ausleihe betrifft
	 */
	public void setBenutzer(Benutzer benutzer);

	/**
	 * Setzt das Medium, das diese Ausleihe betrifft
	 * @param medium das neue Medium, das diese Ausleihe betrifft
	 */
	public void setMedium(Medium medium);

	/**
	 * Setzt den Mitarbeiter, der das Medium herausgab, d.h. den Mitarbeiter des
	 * ersten Ausleihzeitraums.
	 * @param mitarbeiterAusleihe der neue Mitarbeiter, der das Medium herausgab
	 */
	public void setMitarbeiterAusleihe(Mitarbeiter mitarbeiterAusleihe);

	/**
	 * Setzt den Mitarbeiter, der das Medium zur�cknahm
	 * @param mitarbeiterRueckgabe der neue Mitarbeiter, der das Medium zur�cknahm
	 */
	public void setMitarbeiterRueckgabe(Mitarbeiter mitarbeiterRueckgabe);

	/**
	 * Setzt das Datum, an dem das Medium ausgeliehen wurde, d.h den Beginn
	 * des ertsen Ausleihzeitraums.
	 * @param ausleihdatum das neue Datum, an dem das Medium ausgeliehen wurde
	 */
	public void setAusleihdatum(java.util.Date ausleihdatum);

	/**
	 * Setzt das Datum, an dem das Medium zur�ckgegeben werden soll, d.h. das
	 * Ende des letzen Ausleihzeitraums.
	 * @param sollrueckgabedatum das neue Datum, an dem das Medium zur�ckgegeben
	 *   werden soll
	 */
	public void setSollRueckgabedatum(java.util.Date sollrueckgabedatum);

	/**
	 * Setzt das Datum, an dem das Medium zur�ckgegeben wurde.
	 * <code>null</code> bedeutet, dass das Medium noch nicht zur�ckgegeben wurde.
	 *
	 * @param rueckgabedatum das Datum, an dem das Medium zur�ckgegeben wurde
	 */
	public void setRueckgabedatum(java.util.Date rueckgabedatum);

	/**
	 * Setzt die Bemerkungen zu dieser Ausleihe.
	 * @param bemerkungen die neuen Bemerkungen zu dieser Ausleihe
	 */
	public void setBemerkungen(String bemerkungen);

	/**
	 * Verl�ngert die Ausleihe bis mindestens zum �bergebenen Datum. 
	 * Zum Verl�ngern wird der �bergebene Mitarbeiter verwendet. D.h.
	 * es wird evtl. mehrfach verl�ngert, bis das Sollr�ckgabedatum mindestens
	 * dem �bergebenen Datum entspricht.
	 * @param datum das Datum, bis zu dem verl�ngert werden soll
	 * @param mitarbeiter der zu verwendende Mitarbeiter
	 */
	public void verlaengereBisMindestens(
		java.util.Date datum,	Mitarbeiter mitarbeiter);

	/**
	 * Verl�ngert die aktuelle Ausleihe und liefert das Ergebnis der Verl�ngerung.
	 * Zum Verl�ngern wird der �bergebene Mitarbeiter verwendet.
	 *
	 * @param mitarbeiter der Mitarbeiter, die die Verl�ngerung t�tigt
	 * @throws DatenbankInkonsistenzException falls die Ausleihe aus
	 *   Konsistenzgr�nden nicht verl�ngert werden darf
	 * @throws WidersprichtAusleihordnungException falls die Ausleihe nicht
	 *   verl�ngert werde darf, weil dies der Ausleihordnung widerspricht
	 * @return die Ausleihe, die die diese Ausleihe verl�ngert
	 */
	public void verlaengere(Mitarbeiter mitarbeiter);

	/**
	 * Macht das verl�ngern der Ausleihe r�ckg�ngig.
	 *
	 * @throws DatenbankInkonsistenzException falls das Verl�ngern aus
	 *   Konsistenzgr�nden nicht r�ckg�ngig gemacht werden darf
	 * @return die Ausleihe, die von dieser Ausleihe verl�ngert wurde
	 */
	public void verlaengernRueckgaengig();

	/**
	 * Gibt die aktuelle Ausleihe zur�ck. Zur R�ckgabe wird das aktuelle
	 * Datum und der �bergebene Mitarbeiter verwendet.
	 *
	 * @param mitarbeiter der Mitarbeiter, die die R�ckgabe t�tigt
	 */
	public void zurueckgeben(Mitarbeiter mitarbeiter);

	/**
	 * Liefert die Anzahl der Verl�ngerungen dieser Ausleihe.
	 * @return die Anzahl der Verl�ngerungen dieser Ausleihe
	 */
	public int getAnzahlVerlaengerungen();
	
	/**
	 * Liefert die Anzahl der Ausleihzeitr�ume dieser Ausleihe
	 * @return die Anzahl der Ausleihzeitr�ume dieser Ausleihe
	 */
	public int getAnzahlAusleihzeitraeume();
	
	/**
	 * Liefert die Ausleihzeitr�ume dieser Ausleihe sortiert nach
   * dem T�tigungsdatum
	 * @return die Ausleihzeitr�ume dieser Ausleihe
	 */
	public AusleihzeitraumListe getAusleihzeitraeume();
	
	/**
	 * Liefert den ersten Ausleihzeitraum dieser Ausleihe
	 * @return den ersten Ausleihzeitraum dieser Ausleihe
	 */
	public Ausleihzeitraum getErstenAusleihzeitraum();
	
	/**
	 * Liefert den letzten Ausleihzeitraum dieser Ausleihe
	 * @return den letzten Ausleihzeitraum dieser Ausleihe
	 */
	public Ausleihzeitraum getLetztenAusleihzeitraum();

  /**
   * Liefert das T�tigungsdatum dieser Ausleihe, also das Datum,
   * an dem der erste Zeitraum dieser Ausleihe freigegeben wurde.
   * @return das T�tigungsdatum
   */
  public Date getTaetigungsdatum();	

  /**
   * Setzt das T�tigungsdatum dieser Ausleihe, also das Datum,
   * an dem der erste Zeitraum dieser Ausleihe freigegeben wurde.
   * @param das neue T�tigungsdatum
   */
  public void setTaetigungsdatum(Date datum);

  /**
   * Liefert den Ausleihzeitraum, der auf den �bergebenen folgt oder
   * <code>null</code> falls kein solcher existiert.
   * @param ausleihzeitraum
   * @return den n�chsten Ausleihzeitraum
   */
  public Ausleihzeitraum getNaechstenAusleihzeitraum(
      Ausleihzeitraum ausleihzeitraum); 
}

