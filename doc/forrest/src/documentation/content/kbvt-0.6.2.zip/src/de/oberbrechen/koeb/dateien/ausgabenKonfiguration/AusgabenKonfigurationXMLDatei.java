/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.dateien.ausgabenKonfiguration;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import net.n3.nanoxml.*;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.EinstellungFactory;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
* Dieses Klasse dient dazu eine XML-Konfigurationsdatei f�r
* die Ausgaben auszulesen und zu schreiben. 
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class AusgabenKonfigurationXMLDatei {

  private String file;

  private static String standardDatei = null; 
  private static AusgabenKonfigurationXMLDatei instance;

  private Vector daten;
  
  /**
   * Setzt die Standard-Konfigurationsdatei
   * @param datei die neuen Standard-Konfigurationsdatei
   */
  public static void setStandardDatei(String datei) {
    standardDatei = datei;
    instance = null;
  }

  /**
   * Liefert die Standardkonfigurationsdatei, die vorher mittels
   * setStandardDatei(File datei) eingestellt wurde.
   *
   * @return die Standardkonfigurationsdatei
   */
  public static AusgabenKonfigurationXMLDatei getInstance() {
    if (standardDatei == null) {
      EinstellungFactory einstellungFactory =
        Datenbank.getInstance().getEinstellungFactory();
      standardDatei = einstellungFactory.getEinstellung(
        "de.oberbrechen.koeb.gui.ausgaben.AusgabenKonfigurationXMLDatei",
        "Standarddatei").getWert("einstellungen/AusgabeKonfiguration.xml");
    }

    if (instance == null) instance = new AusgabenKonfigurationXMLDatei(standardDatei);

    return instance;
  }

  /**
   * Erstellt ein neues  AusgabenKonfigurationXMLDatei-Objekt, das seine Informationen
   * in der �bergebenen Datei speichert. Die zur Zeit in dieser Datei
   * gespeicherten Informationen werden geladen.
   *
   * @param datei die Datei, in der die Informationen gespeichert werden
   */
  public AusgabenKonfigurationXMLDatei(String datei) {
    this.file = datei;
    load();
  }

  /**
   * L�d alle Informationen aus der Datei.
   */
  private void load() {
    daten = new Vector();

    try {
      IXMLParser parser = XMLParserFactory.createDefaultXMLParser();
      IXMLReader reader = StdXMLReader.fileReader(file);
      parser.setReader(reader);
      IXMLElement xml = (IXMLElement) parser.parse();
      
      for (int i=0; i < xml.getChildrenCount(); i++) {
        daten.add(getAusgabenFactoryBeschreibung(xml.getChildAtIndex(i)));
      }
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Konfigurationsdatei " +        "'"+file+"'.", false);
    }   
  }

  /**
   * Versucht die in dem �bergebenen Element gespeicherten Informationen
   * in ein AusgabeFactoryBeschreibung-Objekt einzulesen.
   * @return Object
   */
  private AusgabenFactoryBeschreibung getAusgabenFactoryBeschreibung(IXMLElement element) {
    AusgabenFactoryBeschreibung erg = new AusgabenFactoryBeschreibung();
    erg.setKlasse(element.getAttribute("class", null));
    erg.setOrdner(element.getChildAtIndex(0).getContent());
    
    Vector parameter = erg.getParameter();
    for (int i=1; i < element.getChildrenCount(); i++) {
      IXMLElement parameterElement = element.getChildAtIndex(i);
      Parameter newParameter = new Parameter();
      newParameter.name = parameterElement.getAttribute("name", null);
      newParameter.wert = parameterElement.getContent();
      parameter.add(newParameter);
    }
    
    return erg;
  }

  public AusgabenFactoryBeschreibung[] getDaten() {
    return (AusgabenFactoryBeschreibung[]) daten.toArray(new AusgabenFactoryBeschreibung[daten.size()]);  
  }
  
  public void setDaten(AusgabenFactoryBeschreibung[] daten) {
    Vector neueDaten = new Vector();
    for (int i=0; i < daten.length; i++) {
      neueDaten.add(daten[i]);  
    }
    this.daten = neueDaten;
    save();
  }
  
  /**
   * Speichert alle Informationen in die Datei   */
  private void save() {
    IXMLElement root = new XMLElement("AusgabeKonfiguration");    
    Iterator it = daten.iterator();
    while (it.hasNext()) {
      AusgabenFactoryBeschreibung beschreibung = 
        (AusgabenFactoryBeschreibung) it.next();
      
      XMLElement beschreibungKnoten = new XMLElement("AusgabenFactory");
      beschreibungKnoten.setAttribute("class", beschreibung.getKlasse());
      XMLElement ordnerKnoten = new XMLElement("Ordner");
      ordnerKnoten.setContent(beschreibung.getOrdner());
      beschreibungKnoten.addChild(ordnerKnoten);
      
      Iterator paramIt = beschreibung.getParameter().iterator();
      while (paramIt.hasNext()) {
        Parameter param = (Parameter) paramIt.next();
        XMLElement parameterKnoten = new XMLElement("Parameter");
        parameterKnoten.setAttribute("name", param.name);
        parameterKnoten.setContent(param.wert);
        beschreibungKnoten.addChild(parameterKnoten);
      }
      root.addChild(beschreibungKnoten);
    }
    
    try {
      FileWriter fileWriter = new FileWriter(file);
      new XMLWriter(fileWriter).write(root, true);
      fileWriter.close();
    } catch (IOException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern!", false);
    }    
  }
}