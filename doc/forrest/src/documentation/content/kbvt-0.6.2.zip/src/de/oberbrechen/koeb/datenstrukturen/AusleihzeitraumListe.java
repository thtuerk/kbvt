/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import java.util.Comparator;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihzeitraum;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von 
* Ausleihzeitr�umen. Es ist zu
* beachten, dass �berall nur Ausleihzeitr�ume 
* statt allgemeiner Objekte als
* Parameter �bergeben werden d�rfen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class AusleihzeitraumListe extends Liste {

	/**
	 * Ausleihzeitr�ume werden nach ihrem Beginn, dann nach ihrem Ende und
	 * schlie�lich nach der Ausleihe sortiert. 
	 * Autor ihres Mediums sortiert
	 */
	public static final int beginnSortierung = 2;
  public static final int taetigungsdatumSortierung = 3;

	protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;

    switch (sortierung) {
      
			case beginnSortierung : {
				sort = new Comparator() {
						public int compare(Object a, Object b) {
							Ausleihzeitraum zeitraumA = (Ausleihzeitraum) a;
							Ausleihzeitraum zeitraumB = (Ausleihzeitraum) b;

              if (zeitraumA.getBeginn() == null) return -1;
              if (zeitraumB.getBeginn() == null) return 1;
              int erg = zeitraumA.getBeginn().compareTo(zeitraumB.getBeginn());
              if (erg != 0) return erg;
              
              if (zeitraumA.getEnde() == null) return -1;
              if (zeitraumB.getEnde() == null) return 1;
              erg = zeitraumA.getEnde().compareTo(zeitraumB.getEnde());
              if (erg != 0) return erg;

              if (zeitraumA.getTaetigungsdatum() == null) return -1;
              if (zeitraumB.getTaetigungsdatum() == null) return 1;
              erg = zeitraumA.getTaetigungsdatum().compareTo(zeitraumB.getTaetigungsdatum());
              if (erg != 0) return erg;

              return a.hashCode() - b.hashCode();
						}};
				break;
			}
			  
      case taetigungsdatumSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Ausleihzeitraum zeitraumA = (Ausleihzeitraum) a;
              Ausleihzeitraum zeitraumB = (Ausleihzeitraum) b;

              if (zeitraumA.getTaetigungsdatum() == null) return -1;
              if (zeitraumB.getTaetigungsdatum() == null) return 1;
              int erg = zeitraumA.getTaetigungsdatum().compareTo(zeitraumB.getTaetigungsdatum());
              if (erg != 0) return erg;

              if (zeitraumA.getBeginn() == null) return -1;
              if (zeitraumB.getBeginn() == null) return 1;
              erg = zeitraumA.getBeginn().compareTo(zeitraumB.getBeginn());
              if (erg != 0) return erg;
              
              if (zeitraumA.getEnde() == null) return -1;
              if (zeitraumB.getEnde() == null) return 1;
              erg = zeitraumA.getEnde().compareTo(zeitraumB.getEnde());
              if (erg != 0) return erg;
              
              return a.hashCode() - b.hashCode();
            }};
        break;
      }

       default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }

}
