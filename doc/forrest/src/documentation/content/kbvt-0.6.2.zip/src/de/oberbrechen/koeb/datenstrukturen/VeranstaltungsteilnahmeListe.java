/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import java.util.Comparator;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von Benutzern. Ein Benutzer
* ist eindeutig �ber seine Benutzernr identifiziert und wird nur einmal in
* die Liste aufgenommen. Es ist zu
* beachten, dass �berall nur Benutzer statt allgemeiner Objekte als
* Parameter �bergeben werden d�rfen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/
public class VeranstaltungsteilnahmeListe extends Liste {

  /**
   * Teilnahmen werden alphabetisch zuerst nach ihrem Nachnamen, dann
   * nach dem Vornamen des Benutzers und schlie�lich nach dem Titel der
   * Veranstaltung sortiert
   */
  public static final int BenutzerNachnameVornameSortierung = 2;

  /**
   * Teilnahmen werden alphabetisch zuerst nach ihrem Vornamen, dann nach dem
   * Nachnamen des Benutzers und schlie�lich nach dem Titel der
   * Veranstaltungsortiert
   */
  public static final int BenutzerVornameNachnameSortierung = 3;

  /**
   * Teilnahmen werden alphabetisch zuerst nach der Klasse, dann nach dem
   * Nachnamen, Vornamen des Benutzers und schlie�lich nach dem Titel der
   * Veranstaltung sortiert
   */
  public static final int BenutzerKlasseSortierung = 4;

  /**
   * Teilnahmen werden alphabetisch zuerst nach dem Titel der Veranstaltung,
   * dann nach der Anmeldenr sortiert.
   */
  public static final int AnmeldeNrSortierung = 5;

  /**
   * Teilnahmen werden alphabetisch zuerst nach dem Titel der Veranstaltung,
   * dann nach der Bemerkung sortiert.
   */
  public static final int BemerkungenSortierung = 6;

  protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;

    switch (sortierung) {
      //Nachname/Vorname Sortierung
      case BenutzerNachnameVornameSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              int erg;
              Benutzer benA = ((Veranstaltungsteilnahme) a).getBenutzer();
              Benutzer benB = ((Veranstaltungsteilnahme) b).getBenutzer();

              erg = nullCompare(benA.getNachname(), benB.getNachname());
              if (erg == 0) erg = nullCompare(benA.getVorname(), benB.getVorname());
              if (erg != 0) return erg;

              Veranstaltung verA = ((Veranstaltungsteilnahme) a).getVeranstaltung();
              Veranstaltung verB = ((Veranstaltungsteilnahme) b).getVeranstaltung();
              return nullCompare(verA.getTitel(), verB.getTitel());
            }};
        break;
      }

      //Vorname/Nachname Sortierung
      case BenutzerVornameNachnameSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              int erg;
              Benutzer benA = ((Veranstaltungsteilnahme) a).getBenutzer();
              Benutzer benB = ((Veranstaltungsteilnahme) b).getBenutzer();

              erg = nullCompare(benA.getVorname(), benB.getVorname());
              if (erg == 0) erg = nullCompare(benA.getNachname(), benB.getNachname());
              if (erg != 0) return erg;

              Veranstaltung verA = ((Veranstaltungsteilnahme) a).getVeranstaltung();
              Veranstaltung verB = ((Veranstaltungsteilnahme) b).getVeranstaltung();
              return nullCompare(verA.getTitel(), verB.getTitel());
            }};
        break;
      }

      //Sortierung nach der Klasse Sortierung
      case BenutzerKlasseSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            int erg;
            Benutzer benA = ((Veranstaltungsteilnahme) a).getBenutzer();
            Benutzer benB = ((Veranstaltungsteilnahme) b).getBenutzer();

            erg = nullCompare(benA.getKlasse(), benB.getKlasse());
            if (erg == 0) erg = nullCompare(benA.getNachname(), benB.getNachname());
            if (erg == 0) erg = nullCompare(benA.getVorname(), benB.getVorname());
            if (erg != 0) return erg;

            Veranstaltung verA = ((Veranstaltungsteilnahme) a).getVeranstaltung();
            Veranstaltung verB = ((Veranstaltungsteilnahme) b).getVeranstaltung();
            return nullCompare(verA.getTitel(), verB.getTitel());
          }};
        break;
      }

      //Sortierung nach der AnmeldeNr
      case AnmeldeNrSortierung : {
        sort = new Comparator() {

          public int compare(Object a, Object b) {
            int erg;

            Veranstaltung verA = ((Veranstaltungsteilnahme) a).getVeranstaltung();
            Veranstaltung verB = ((Veranstaltungsteilnahme) b).getVeranstaltung();
            erg = nullCompare(verA.getTitel(), verB.getTitel());
            if (erg != 0) return erg;

            int nrA = ((Veranstaltungsteilnahme) a).getAnmeldeNr();
            int nrB = ((Veranstaltungsteilnahme) b).getAnmeldeNr();

            return nrA - nrB;
          }};
        break;
      }

      //Sortierung nach der Bemerkung
      case BemerkungenSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            int erg;
            String bemA = ((Veranstaltungsteilnahme) a).getBemerkungen();
            String bemB = ((Veranstaltungsteilnahme) b).getBemerkungen();
            erg = nullCompare(bemA, bemB);

            Benutzer benA = ((Veranstaltungsteilnahme) a).getBenutzer();
            Benutzer benB = ((Veranstaltungsteilnahme) b).getBenutzer();

            if (erg == 0) erg = nullCompare(benA.getNachname(), benB.getNachname());
            if (erg == 0) erg = nullCompare(benA.getVorname(), benB.getVorname());
            if (erg != 0) return erg;

            Veranstaltung verA = ((Veranstaltungsteilnahme) a).getVeranstaltung();
            Veranstaltung verB = ((Veranstaltungsteilnahme) b).getVeranstaltung();
            return nullCompare(verA.getTitel(), verB.getTitel());
          }};
        break;
      }

      default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }

}
