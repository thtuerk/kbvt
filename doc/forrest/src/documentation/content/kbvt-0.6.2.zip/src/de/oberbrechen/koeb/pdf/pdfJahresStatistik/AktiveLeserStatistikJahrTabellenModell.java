/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfJahresStatistik;

import java.text.Collator;
import java.util.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell f�r die Benutzer und Veranstaltungsstatistiken eines Jahres
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class AktiveLeserStatistikJahrTabellenModell extends TabellenModell {
  
  class BenutzerInfos {       
    Benutzer benutzer;
    AusleihenListe ausleihen = new AusleihenListe();
    AusleihzeitraumListe verlaengerungen = new AusleihzeitraumListe();
    MedienListe medien = new MedienListe();
    int medienAnzahlUnbekannt = 0;
    
    public BenutzerInfos(Benutzer benutzer) {
      this.benutzer = benutzer;     
    }
    
    public void addAusleihzeitraum(Ausleihzeitraum ausleihzeitraum) {
      ausleihen.add(ausleihzeitraum.getAusleihe());
      verlaengerungen.add(ausleihzeitraum);
      Medium medium = ausleihzeitraum.getAusleihe().getMedium();
      if (medium != null) { 
        medien.add(medium);
      } else {
        medienAnzahlUnbekannt++;
      }
    }
  }
  
  BenutzerInfos[] daten;
  int maxRows;
  
  public AktiveLeserStatistikJahrTabellenModell(int jahr) {    
    this(jahr, 15);
  }
  
  public AktiveLeserStatistikJahrTabellenModell(int jahr, int maxRows) {    
    Zeitraum zeitraum = new Zeitraum(jahr);
    this.maxRows = maxRows; 
    AusleiheFactory ausleiheFactory = Datenbank.getInstance().getAusleiheFactory();
    
    AusleihzeitraumListe ausleihzeitraumListe = 
      ausleiheFactory.getGetaetigteAusleihzeitraeumeInZeitraum(zeitraum);
    Hashtable infosHash = new Hashtable();
    
    int benutzerCount = 0;
    for (int i=0; i < ausleihzeitraumListe.size(); i++) {
      Ausleihzeitraum ausleihzeitraum = 
        (Ausleihzeitraum) ausleihzeitraumListe.get(i);
      
      BenutzerInfos infos = (BenutzerInfos) infosHash.get(ausleihzeitraum.getAusleihe().getBenutzer());
      if (infos == null) {
        infos = new BenutzerInfos(ausleihzeitraum.getAusleihe().getBenutzer());
        infosHash.put(infos.benutzer, infos);
        benutzerCount++;
      }

      infos.addAusleihzeitraum(ausleihzeitraum);
    }
    
    daten = new BenutzerInfos[benutzerCount];
    benutzerCount = 0;
    Enumeration enum = infosHash.elements();
    while (enum.hasMoreElements()) {
      daten[benutzerCount] = (BenutzerInfos) enum.nextElement();
      benutzerCount++;
    }
    
    Arrays.sort(daten, new Comparator() {

      Collator collator = Collator.getInstance();
      
      public int compare(Object a, Object b) {
        BenutzerInfos aInfos = (BenutzerInfos) a;
        BenutzerInfos bInfos = (BenutzerInfos) b;

        if (aInfos == null || bInfos == null)
          throw new NullPointerException("Array sollte keine Nulls enthalten!");
        
        int erg = (bInfos.verlaengerungen.size() - aInfos.verlaengerungen.size());
        if (erg != 0) return erg;
        erg = (bInfos.ausleihen.size() - aInfos.ausleihen.size());
        if (erg != 0) return erg;
        erg = collator.compare(aInfos.benutzer.getNameFormal(), bInfos.benutzer.getNameFormal()); 
        if (erg != 0) return erg;
        
        return aInfos.benutzer.getId() - bInfos.benutzer.getId();
      }});
    
    setBreiteProzent(1, 40);
    setBreiteProzent(2, 34);
    setBreiteProzent(3, 13);
    setBreiteProzent(4, 13);
    setSpaltenAusrichtung(2, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(3, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(4, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
  }

  public int getSpaltenAnzahl() {
    return 4;
  }

  public int getZeilenAnzahl() {
    return daten.length < maxRows?daten.length:maxRows;
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "Benutzer";
    if (spaltenNr == 2) return "Ausleihen & Verl�ngerungen";
    if (spaltenNr == 3) return "Ausleihen";
    if (spaltenNr == 4) return "Medien";
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    BenutzerInfos infos = daten[zeilenNr-1];
    if (spaltenNr == 1) return infos.benutzer.getNameFormal();
    if (spaltenNr == 2) {
      int erg = infos.verlaengerungen.size();      
      return erg == 0?"-":Integer.toString(erg);
    }
    if (spaltenNr == 3) {
      int erg = infos.ausleihen.size();      
      return erg == 0?"-":Integer.toString(erg);
    }
    if (spaltenNr == 4) {
      int erg = infos.medien.size()+infos.medienAnzahlUnbekannt;      
      return erg == 0?"-":Integer.toString(erg);
    }
    return "Fehler";
  } 
}
