/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnvollstaendigeDatenException;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlVeranstaltungsteilnahme 
	extends AbstractVeranstaltungsteilnahme {

	public MysqlVeranstaltungsteilnahme(int id) {
    load(id);
	}

  MysqlVeranstaltungsteilnahme(ResultSet result) throws SQLException {
    load(result);
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
  }
  
  public MysqlVeranstaltungsteilnahme(
      Benutzer benutzer, Veranstaltung veranstaltung) {
    super(benutzer, veranstaltung);    
  }
  
  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    load(getId());
	}

	public void save() {
    if (istGespeichert()) return;

    if (this.getVeranstaltung() == null || this.getBenutzer() == null) {
      throw new UnvollstaendigeDatenException("F�r jede Teilnahme muss eine "+
        "Veranstaltung und ein Benutzer eingegeben sein!");
    }

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();            
      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      PreparedStatement statement = 
      	(PreparedStatement) connection.prepareStatement(
            "select id from benutzer_besucht_veranstaltung where " +
            "benutzerID = ? and veranstaltungID = ? and id != ?");
			statement.setInt(1, getBenutzer().getId());
			statement.setInt(2, getVeranstaltung().getId());
			statement.setInt(3, getId());
      ResultSet result = (ResultSet) statement.executeQuery();      
      if (result.next()) throw new BenutzerBereitsAngemeldetException(
          new MysqlVeranstaltungsteilnahme(result.getInt(1)));
			
      if (this.istNeu()) {
        statement = (PreparedStatement) connection.prepareStatement(
          "insert into benutzer_besucht_veranstaltung " +
          "set BenutzerID = ?, VeranstaltungID = ?, Anmeldenr = ?, "+
          "Bemerkungen = ?");
      } else {
        statement = (PreparedStatement) connection.prepareStatement(
          "update benutzer_besucht_veranstaltung " +
          "set BenutzerID = ?, VeranstaltungID = ?, Anmeldenr = ?, "+
				  "Bemerkungen = ? where id="+this.getId());
      }
			statement.setInt(1, this.getBenutzer().getId());
			statement.setInt(2, this.getVeranstaltung().getId());
			statement.setInt(3, this.getAnmeldeNr());
			statement.setString(4, this.getBemerkungen());

      statement.execute();
      
      if (this.istNeu()) {
        result = (ResultSet) statement.getGeneratedKeys();
        result.next();
        id = result.getInt(1);
      }
      MysqlDatenbank.getMysqlInstance().endTransaktion();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern " +        "der folgenden Freigabe:\n\n"+this.toDebugString(), true);
    }

    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
	}

	public void loesche() throws DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      
      statement.execute("delete from benutzer_besucht_veranstaltung where "+
        "id = "+this.getId());
        
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);      
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des "+
        "Teilnahme "+this.toDebugString(), true);
    }
	}
  
  void load(ResultSet result) throws SQLException {
    id = result.getInt("id");
    
    int benutzerID = result.getInt("benutzerID");
		benutzer = (Benutzer) MysqlDatenbank.getMysqlInstance().
			getBenutzerFactory().get(benutzerID);

		int veranstaltungID = result.getInt("VeranstaltungID");
		veranstaltung = (Veranstaltung) MysqlDatenbank.getMysqlInstance().
			getVeranstaltungFactory().get(veranstaltungID);

    anmeldenr = result.getInt("Anmeldenr");
    bemerkungen = result.getString("Bemerkungen");
  }

  void load(int id) throws DatenNichtGefundenException {
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select * from benutzer_besucht_veranstaltung where id = " + id);
      boolean gefunden = result.next();
      if (!gefunden) throw new DatenNichtGefundenException(
        "Eine Teilnahme mit der ID "+id+" existiert nicht!");
  
      load(result);
  
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "der Teilnahme mit der ID "+id+"!", true);
    }
    setIstGespeichert();
    this.setChanged();
    this.notifyObservers();
    
  }  
}