/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.EinstellungenListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlEinstellungFactory extends AbstractEinstellungFactory {

  public EinstellungenListe getAlleEinstellungen() {
		clearCache();
		EinstellungenListe liste = new EinstellungenListe();
		try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
					"select * from einstellung;");
			while (result.next()) {
			  Einstellung einstellung = new MysqlEinstellung(result);
	
				cache.put(new Integer(einstellung.getId()), einstellung);
				liste.addNoDuplicate(einstellung);
			}
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der Einstellungenliste!", true);
		}
	
		return liste;
  }

  private Einstellung getEinstellungIntern(
      Client client, Mitarbeiter mitarbeiter, String name) {
		Einstellung erg = null;
    try {
			StringBuffer sqlStatement = new StringBuffer();
			sqlStatement.append("select id from einstellung where ");
			if (client == null) {
				sqlStatement.append("isNull(clientID) and ");			  
			} else {
				sqlStatement.append("clientID = "+client.getId()+" and ");			  
			}
			if (mitarbeiter == null) {
				sqlStatement.append("isNull(mitarbeiterID) and ");			  
			} else {
				sqlStatement.append("mitarbeiterID = "+mitarbeiter.getId()+" and ");			  
			}
			sqlStatement.append("name=\""+name+"\"");			  
			

			MysqlDatenbank.getMysqlInstance().beginTransaktion();			
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = 
				(ResultSet) statement.executeQuery(sqlStatement.toString());
			if (result.next()) {
			  erg = new MysqlEinstellung(result.getInt(1));
			} else {
			  erg = null;
			}

			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der Einstellung!", true);
		}
	
		return erg;
  }
  
	public Einstellung getEinstellung(
	    Client client, Mitarbeiter mitarbeiter, String name) {
		Einstellung erg = getEinstellungIntern(client, mitarbeiter, name);
		if (erg != null) return erg;
				
		erg = new MysqlEinstellung(client, mitarbeiter, name);
		Einstellung allgemeinereEinstellung =
			getEinstellungIntern(client, null, name);
		if (allgemeinereEinstellung == null)
		  allgemeinereEinstellung =	getEinstellungIntern(null, mitarbeiter, name);
		if (allgemeinereEinstellung == null)
			allgemeinereEinstellung =	getEinstellungIntern(null, null, name);
		if (allgemeinereEinstellung != null)
			erg.setWert(allgemeinereEinstellung.getWert());
		erg.save();
		return erg;
	}

  public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
    return new MysqlEinstellung(id);
  }
}