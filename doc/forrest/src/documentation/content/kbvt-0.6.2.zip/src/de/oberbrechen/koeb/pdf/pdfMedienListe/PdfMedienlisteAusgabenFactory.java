/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMedienListe;

import java.util.Iterator;

import javax.swing.JFrame;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.datenstrukturen.MedientypListe;
import de.oberbrechen.koeb.gui.components.medienAusgabeWrapper.MedienAusgabeWrapper;

/**
 * Dieses Klasse stellt eine Factory da, die
 * die eine Ausgabe erstellt, die eine PdfMedienliste ausgibt.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.10 $
 */
public class PdfMedienlisteAusgabenFactory implements AusgabenFactory {

  public String getName() {
    return "PDF-Medienlisten";
  }

  public String getBeschreibung() {
    return "Erzeugt einen Ordner 'Medienlisten', der die 3 Unterordner " +      "'Titel', 'Mediennummer' und 'Autor' enth�lt. Jeder dieser Ordner " +      "enth�lt Ausgaben, die eine nach dem entsprechenden Kriterium sortierte " +      "PDF-Medienliste aller Medien sowie PDF-Medienlisten aller Medien eines" +      "Medientyps erstellen.";
  }

  public void setParameter(String name, String wert) throws ParameterException {
    throw new ParameterException("Diese Factory erlaubt keine Parameter!");
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) {
    AusgabenTreeKnoten root = knoten.addKnoten("Medienlisten", true);

    AusgabenTreeKnoten sortierungNode = root.addKnoten("Titel", false);    
    addAusgabenFuerSortierung(sortierungNode, MedienListe.TitelAutorSortierung);

    sortierungNode = root.addKnoten("Autor", false);    
    addAusgabenFuerSortierung(sortierungNode, MedienListe.AutorTitelSortierung);

    sortierungNode = root.addKnoten("Mediennummer", false);    
    addAusgabenFuerSortierung(sortierungNode, MedienListe.MedienNummerSortierung);
    
    //Gesamtliste
    PdfMedienlisteMedienAusgabe konfigurierbareAusgabe = 
      new PdfMedienlisteMedienAusgabe() {
      
      public String getName() {
        return "konfigurierbare Medienliste";
      }
      
      public String getBeschreibung() {
        return "Erm�glicht die Erstellung einer Medienliste, die vorher " +
            "konfiguriert werden kann.";        
      }
      
    };
    root.addAusgabe("konfigurierbare Medienliste", 
        new MedienAusgabeWrapper(konfigurierbareAusgabe));
    
  }

  private void addAusgabenFuerSortierung(AusgabenTreeKnoten root, int sortierung) {
    String sortierungName = "";
    switch (sortierung) {
      case MedienListe.MedienNummerSortierung: 
        sortierungName = "Mediennummer"; break;
      case MedienListe.TitelAutorSortierung:
        sortierungName = "Titel"; break;
      case MedienListe.AutorTitelSortierung:
        sortierungName = "Autor"; break;      
    }

    //Gesamtliste
    Ausgabe gesamtAusgabe = new MedientyplisteAusgabe(
      "Gesamtliste", "Erstellt eine PDF-Datei, die eine Gesamtliste aller aktuellen Medien enthaelt "+
      " - sortiert nach "+sortierungName, "Gesamtliste - "+sortierungName,
      sortierung, null);

    root.addAusgabe(gesamtAusgabe);

    //Medientyplisten
    MedientypFactory medientypFactory = 
      Datenbank.getInstance().getMedientypFactory();
    MedientypListe medientypListe = medientypFactory.getAlleMedientypen();
    medientypListe.setSortierung(MedientypListe.StringSortierung);
    Iterator it = medientypListe.iterator();
    while (it.hasNext()) {
      Medientyp medientyp = (Medientyp) it.next();
      Ausgabe ausgabe = new MedientyplisteAusgabe(medientyp.getPlural(),  
        "Eine nach "+sortierungName+" sortierte PDF-Liste aller "+
        medientyp.getPlural()+".", medientyp.getPlural()+" - "+sortierungName, 
        sortierung, medientyp);
      root.addAusgabe(ausgabe);
    }
  }
}


class MedientyplisteAusgabe implements Ausgabe {

  private int sortierung;
  private String name;
  private String titel;
  private String beschreibung;
  private Medientyp medientyp;

  public MedientyplisteAusgabe(String name, 
      String beschreibung, String titel, int sortierung, 
      Medientyp medientyp) {
    
    this.sortierung = sortierung;
    this.name = name; 
    this.titel = titel;
    this.beschreibung = beschreibung;
    this.medientyp = medientyp;
  }

  public String getName() {
    return name;
  }

  public String getBeschreibung() {
    return beschreibung;
  }

  public void run(JFrame hauptFenster) throws Exception {
    MediumFactory mediumFactory = Datenbank.getInstance().getMediumFactory();   
    MedienListe medienliste = 
      mediumFactory.getMedienListe(medientyp, null, false);
    PdfMedienListe pdfListe = new PdfMedienListe(titel, medienliste, sortierung);
    pdfListe.zeige(false);
  }    
}
