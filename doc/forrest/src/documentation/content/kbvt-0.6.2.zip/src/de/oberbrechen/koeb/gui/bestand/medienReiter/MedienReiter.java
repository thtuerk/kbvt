/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand.medienReiter;

import java.awt.*;
import java.awt.event.*;
import java.util.Iterator;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.ausgaben.MedienAusgabe;
import de.oberbrechen.koeb.ausgaben.MedienAusgabeFactory;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AusgabeAuswahl;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.bestand.BestandMainReiter;
import de.oberbrechen.koeb.gui.bestand.Main;
import de.oberbrechen.koeb.gui.components.DelayListSelectionListener;
import de.oberbrechen.koeb.gui.components.SortiertComboBox;
import de.oberbrechen.koeb.gui.components.medienPanel.MedienPanel;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;
import de.oberbrechen.koeb.pdf.pdfMedienListe.PdfMedienlisteMedienAusgabeFactory;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Benutzern in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.26 $
 */

public class MedienReiter extends JPanel implements BestandMainReiter {

  interface MedienListeWrapper {
    public MedienListe getMedienliste();
    public String getAusgabeBeschreibung();
  }
  
  private MedienAusgabe medienlisteAusgabe;
  private MedientypFactory medientypFactory;

  private MediumFactory mediumFactory; 
  Main hauptFenster;
  boolean istVeraenderbar;

  private JButton neuButton = new JButton();
  private JButton saveButton = new JButton();
  private JButton ladenButton = new JButton();

  MedienPanel detailsPanel;
  JTable medienTable;
  private DelayListSelectionListener medienTabelleDelayListSelectionListener;
  MedienTableModel medienTableModel;
  private SortiertComboBox auswahlFeld;

  private JButton pdfButton;

  boolean medienListeUmgekehrteSortierung;
  int medienListeSortierung;

  //Doku siehe bitte Interface
  public void refresh() {
  }

  void initButtons() {
    neuButton.setEnabled(!istVeraenderbar);
    hauptFenster.erlaubeAenderungen(!istVeraenderbar);
    medienTable.setEnabled(!istVeraenderbar);
    auswahlFeld.setEnabled(!istVeraenderbar);    
    pdfButton.setEnabled(!istVeraenderbar && medienlisteAusgabe != null);
    
    if (!istVeraenderbar) {
      ladenButton.setText("L�schen");
      saveButton.setText("Bearbeiten");
    } else {
      ladenButton.setText("�nderungen verwerfen");
      saveButton.setText("Speichern");
    }
    
    boolean mediumAngezeigt = (detailsPanel.getMedium() != null);
    ladenButton.setEnabled(mediumAngezeigt); 
    saveButton.setEnabled(mediumAngezeigt); 

  }
  
  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  public void setVeraenderbar(boolean veraenderbar) {
    istVeraenderbar = veraenderbar;
    detailsPanel.setVeraenderbar(veraenderbar);
    initButtons();
  }

  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public MedienReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    mediumFactory = Datenbank.getInstance().getMediumFactory();
    medientypFactory = Datenbank.getInstance().getMedientypFactory();
    
    EinstellungFactory einstellungFactory = 
      Datenbank.getInstance().getEinstellungFactory();

    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
            
    try {
      medienlisteAusgabe = ((MedienAusgabeFactory) 
      einstellungFactory.getEinstellung(
          this.getClass().getName(), "MedienlisteAusgabe").
          getWertObject(MedienAusgabeFactory.class,
              PdfMedienlisteMedienAusgabeFactory.class)).createMedienAusgabe();
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der MedienlisteAusgabe!", false);
      medienlisteAusgabe = null;
    }
    
    setVeraenderbar(false);
    initAuswahlFeld();
    auswahlFeld.setSelectedIndex(0);
    medienListeSortierung = MedienListe.TitelAutorSortierung;
    medienListeUmgekehrteSortierung = false;
    medienTableModel.setSortierung(medienListeSortierung, medienListeUmgekehrteSortierung);
  }

  private void initAuswahlFeld() {        
    String configFile = 
      Datenbank.getInstance().getEinstellungFactory().getEinstellung(
          this.getClass().getName(), "MedienlistenConfigfile").
          getWert("einstellungen/Bestand-Medienlisten.conf");      
    
    boolean ok = false;
    try {
      AuswahlKonfiguration konfiguration = new AuswahlKonfiguration(configFile);      
            
      for (int i=0; i < konfiguration.getAusgabeAnzahl(); i++) {
        final AusgabeAuswahl ausgabe = konfiguration.getAusgabe(i);
        if (!ausgabe.istMediumAuswahl()) {
          ErrorHandler.getInstance().handleError("Ausgabe '"+ausgabe.getTitel()+
              "' ist keine Medium-Auswahl!", false);                 
        } else {
          ok = true;
          auswahlFeld.addItem(new MedienListeWrapper() {
            public MedienListe getMedienliste() {
              return ausgabe.bewerte(hauptFenster.getAlleMedien());
            }

            public String getAusgabeBeschreibung() {
              return ausgabe.getTitel();
            }        
            
            public String toString() {
              return ausgabe.getTitel();
            }
          });
        }
      }
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Parsen der Datei '"+configFile+"'!", false);
    }
    
    if (!ok) {
      auswahlFeld.addItem(new MedienListeWrapper() {
        public MedienListe getMedienliste() {
          return mediumFactory.getMedienListe(null, null, false);
        }
        
        public String toString() {
          return "alle Medien";
        }
  
        public Medientyp getStandardMedientyp() {
          return medientypFactory.getMeistBenutztenMedientyp();
        }
  
        public String getAusgabeBeschreibung() {
          return "Gesamtliste";
        }
      });
  
      auswahlFeld.addItem(new MedienListeWrapper() {
        public MedienListe getMedienliste() {
          return mediumFactory.getMedienListe(null, null, true);
        }
        
        public String toString() {
          return "entfernte Medien";
        }
  
        public Medientyp getStandardMedientyp() {
          return medientypFactory.getMeistBenutztenMedientyp();
        }
  
        public String getAusgabeBeschreibung() {
          return this.toString();
        }
      });
  
      auswahlFeld.addItem(new MedienListeWrapper() {
        public MedienListe getMedienliste() {
          MedienListe auswahlListe = 
            mediumFactory.getMedienListe(null, null, null);
  
          return auswahlListe;
        }
        
        public String toString() {
          return "alle Medien inklusive entfernte Medien";
        }
        
        public Medientyp getStandardMedientyp() {
          return medientypFactory.getMeistBenutztenMedientyp();
        }      
  
        public String getAusgabeBeschreibung() {
          return "Gesamtliste inklusive entfernte Medien";
        }
      });

      Iterator it = medientypFactory.getAlleMedientypen().iterator();
      while (it.hasNext()) {
        final Medientyp medientyp = (Medientyp) it.next();
        auswahlFeld.addItem(new MedienListeWrapper() {
          public MedienListe getMedienliste() {
            return mediumFactory.getMedienListe(medientyp, null, false);
          }
          
          public String toString() {
            return "Medientyp - "+medientyp.getName();
          }
          
          public Medientyp getStandardMedientyp() {
            return medientyp;
          }        
          
          public String getAusgabeBeschreibung() {
            return medientyp.getPlural();
          }        
        });
      }
    }
  }

  void neueMedienAuswahl(MedienListeWrapper auswahl) {
    this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
    MedienListe auswahlListe = auswahl.getMedienliste();
    medienTableModel.setDaten(auswahlListe);
    medienTable.clearSelection();

    if (auswahlListe.size() > 0) {
      medienTable.addRowSelectionInterval(0,0);
      medienTable.scrollRectToVisible(medienTable.getCellRect(0, 0, true));
      medienTabelleDelayListSelectionListener.fireDelayListSelectionEvent();
    } else {
      detailsPanel.setMedium(null);
      initButtons();      
    }
    this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Auswahl
    pdfButton = new JButton("Ausgabe");
    pdfButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        pdfAusgabe();
      }
    });
    JLabel auswahlLabel = new JLabel("Auswahl:");
    auswahlFeld = new SortiertComboBox(false);
    JComponentFormatierer.setDimension(auswahlFeld, new JTextField().getPreferredSize());
    JComponentFormatierer.setDimension(pdfButton, new Dimension(pdfButton.getPreferredSize().width, auswahlFeld.getPreferredSize().height));
    auswahlFeld.addDelayItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        neueMedienAuswahl((MedienListeWrapper) e.getItem());
      }
    });

    //Buttons bauen
    neuButton.setText("Neues Medium anlegen");
    neuButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        neuesMediumAnlegen();
      }
    });
    saveButton.setText("Speichern");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (istVeraenderbar) {
          saveChanges();
        } else {
          setVeraenderbar(true);
        }
      }
    });
    ladenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!istVeraenderbar) {
          loescheMedium();
        } else {
          aenderungenVerwerfen();
        }
      }
    });
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    buttonPanel.setLayout(new GridLayout(1, 3, 15, 5));
    buttonPanel.add(saveButton, null);
    buttonPanel.add(ladenButton, null);
    buttonPanel.add(neuButton, null);

    //Details bauen
    detailsPanel = new MedienPanel(hauptFenster);
    detailsPanel.setBorder(BorderFactory.createEmptyBorder(10,10,5,10));

    //Medienliste
    medienTable = new JTable();
    medienTableModel = new MedienTableModel(medienTable, hauptFenster);
    medienTableModel.setDaten(mediumFactory.getAlleMedienTitelSortierung());
    medienTable.setModel(medienTableModel);
    medienTable.setDefaultRenderer(Object.class, new MedienTableRenderer());
    medienTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    medienTable.addKeyListener(medienTableModel);
    
    medienTabelleDelayListSelectionListener = 
      new DelayListSelectionListener(250);
    medienTabelleDelayListSelectionListener.addListSelectionListener(
        new ListSelectionListener() {
          public void valueChanged(ListSelectionEvent e) {
            int gewaehlteReihe = medienTable.getSelectedRow();
            if (gewaehlteReihe != -1) {
              Medium gewaehltesMedium = medienTableModel.getMedium(gewaehlteReihe);
              detailsPanel.setMedium(gewaehltesMedium);
              initButtons();              
            }
          }
      });
    medienTable.getSelectionModel().addListSelectionListener(medienTabelleDelayListSelectionListener);
    medienTable.getTableHeader().addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        int spalteView = medienTable.getColumnModel().
                         getColumnIndexAtX(e.getX());
        int spalte = medienTable.convertColumnIndexToModel(spalteView);

        medienListeUmgekehrteSortierung =
          (e.getModifiers()&InputEvent.SHIFT_MASK) != 0;

        hauptFenster.setCursor(new Cursor(Cursor.WAIT_CURSOR));
        if (spalte == 0)
          medienListeSortierung = MedienListe.MedienNummerSortierung;
        if (spalte == 1)
          medienListeSortierung = MedienListe.TitelAutorSortierung;
        if (spalte == 2)
          medienListeSortierung = MedienListe.AutorTitelSortierung;
        medienTableModel.setSortierung(medienListeSortierung, medienListeUmgekehrteSortierung);
        hauptFenster.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
      }
    });


    JScrollPane jScrollPane1 = new JScrollPane();
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));

    JPanel medienPanel = new JPanel();
    medienPanel.setLayout(new GridBagLayout());
    medienPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    medienPanel.setMinimumSize(new Dimension(50,80));
    medienPanel.setPreferredSize(new Dimension(50,80));
    medienPanel.add(auswahlLabel,           new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 0, 10), 0, 0));
    medienPanel.add(jScrollPane1,         new GridBagConstraints(0, 1, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 0, 0, 0), 0, 0));
    medienPanel.add(auswahlFeld,      new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    medienPanel.add(pdfButton,       new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0, 10, 0, 0), 0, 0));
    jScrollPane1.getViewport().add(medienTable, null);

    //alles Zusammenbauen
    this.setLayout(new BorderLayout());
    JSplitPane jSplitPane = new JSplitPane();
    jSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane.setBorder(BorderFactory.createEmptyBorder());
    jSplitPane.add(detailsPanel, JSplitPane.BOTTOM);
    jSplitPane.add(medienPanel, JSplitPane.TOP);
    jSplitPane.setResizeWeight(1);

    this.add(jSplitPane, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
  }

  void pdfAusgabe() {
    this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
    MedienListeWrapper auswahl = ((MedienListeWrapper) auswahlFeld.getSelectedItem()); 
    MedienListe medienListe = auswahl.getMedienliste();
    
    String sortierungName = "";
    switch (medienListeSortierung) {
      case MedienListe.MedienNummerSortierung: 
        sortierungName = "Mediennummer"; break;
      case MedienListe.TitelAutorSortierung:
        sortierungName = "Titel"; break;
      case MedienListe.AutorTitelSortierung:
        sortierungName = "Autor"; break;      
    }
    
    try {
      medienlisteAusgabe.setDaten(medienListe);
      medienlisteAusgabe.setTitel(auswahl.getAusgabeBeschreibung()+" - "+sortierungName);
      medienlisteAusgabe.setSortierung(medienListeSortierung, medienListeUmgekehrteSortierung);     
      medienlisteAusgabe.run(hauptFenster);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Erstellen der PDF-Datei!", false);
    }
    
    this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  /**
   * Legt ein neues Medium an und zeigt es an
   */
  void neuesMediumAnlegen() {
    medienTabelleDelayListSelectionListener.fireDelayListSelectionEvent();
    Medium neuesMedium = mediumFactory.erstelleNeu();
    hauptFenster.getStandardwerte().initialisiereMedium(neuesMedium);
    detailsPanel.setMedium(neuesMedium);
    setVeraenderbar(true);
  }

  /**
   * L�d die Orte neu aus der Datenbank
   */
  public void aktualisiere() {
  }

  /**
   * L�scht das aktuelle Medium
   */
  public void loescheMedium() {
    Medium currentMedium = detailsPanel.getMedium();
    boolean loeschenOK = detailsPanel.loescheMedium();
    if (loeschenOK) medienTableModel.remove(currentMedium);
    if (medienTableModel.size() > 0) {
      medienTable.setRowSelectionInterval(0, 0);
      medienTable.scrollRectToVisible(medienTable.getCellRect(0, 0, true));
    } else {
      detailsPanel.setMedium(null);
    }
    initButtons();      
  }

  /**
   * Speichert die gemachten �nderungen
   */
  public void saveChanges() {
    boolean istNeu = detailsPanel.getMedium().istNeu();
    boolean speichernOK = detailsPanel.saveChanges();
    if (speichernOK) {
      setVeraenderbar(false);
      if (istNeu) medienTableModel.add(detailsPanel.getMedium());
    }
    Medium neuesMedium = detailsPanel.getMedium();
    detailsPanel.setMedium(neuesMedium);
    initButtons();      
  }

  /**
   * Verwirft die aktuellen �nderungen.
   */
  public void aenderungenVerwerfen() {
    boolean ok = detailsPanel.aenderungenVerwerfen();
    if (ok) {
      setVeraenderbar(false);
    }
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }
  
  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}