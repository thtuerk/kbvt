/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.medienPanel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.EAN;
import de.oberbrechen.koeb.datenstrukturen.EANListe;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von EANs.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class EANTableModel extends AbstractTableModel {

  private JFrame hauptFenster;
  private EANListe daten;
  private boolean showNewEAN;
  
  /**
   * Erstellt ein neues Modell ohne Daten
   */
  public EANTableModel(JFrame hauptFenster) {
    this.hauptFenster = hauptFenster;
    this.showNewEAN = false;
    daten = new EANListe();
    daten.setSortierung(EANListe.StringSortierung);
  }

  /**
   * Setzt die �bergebenen Daten
   * @param daten die zu setzenden Daten
   */
  public void setDaten(EANListe daten) {
    this.daten.clear();
    if (daten != null) this.daten.addAll(daten);
    fireTableDataChanged();
  }

  /**
   * Liefert die aktuellen Daten des Modells
   * @return die aktuellen Daten
   */
  public EANListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (showNewEAN) return daten.size()+1;
    return daten.size();
  }

  public int getColumnCount() {
    return 1;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "EAN";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex == daten.size()) return "...";
    
    EAN gewaehlteEAN = (EAN) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehlteEAN.getEAN();

    return "nicht definierte Spalte";
  }
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return true;
  }

  public void setValueAt(Object eanString, int rowIndex, int columnIndex) {
    EAN neueEAN = checkEAN((String) eanString);
    
    if (rowIndex < daten.size()) daten.remove(rowIndex);
    if (neueEAN != null) daten.add(neueEAN);
    
    fireTableDataChanged();
  }

  EAN checkEAN(String ean) {
    if (ean == null || ean.equals("")) return null;
    
    EAN neuEAN;
    try {
      neuEAN = new EAN(ean);
      return neuEAN;     
    } catch (IllegalArgumentException e) {
      JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
          ean + "' kann\nnicht als EAN interpretiert\n"+
          "werden!",
          "Ung�ltige EAN!",
          JOptionPane.ERROR_MESSAGE);
      return null;
    }    
  }

  /**
   * L�scht die Angegeben Zeile aus dem Modell
   * @param selectedRow
   */
  public void remove(int rowIndex) {
    if (rowIndex >= 0 && rowIndex < daten.size()) {
      daten.remove(rowIndex);
      fireTableDataChanged();
    }
  }

  /**
   * F�gt eine EAN zum Modell hinzu
   * @param ean die neue EAN
   */
  public void add(EAN ean) {
    if (ean != null) {
      daten.add(ean);
      fireTableDataChanged();
    }
  }  
  
  /**
   * Setzt, ob ... angezeigt wird
   * @author thtuerk
   */
  public void showNewItem(boolean show) {
    this.showNewEAN = show;
    fireTableDataChanged();
  }
}
