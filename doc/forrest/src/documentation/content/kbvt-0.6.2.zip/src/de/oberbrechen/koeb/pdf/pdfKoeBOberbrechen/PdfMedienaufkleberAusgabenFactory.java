/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfKoeBOberbrechen;

import de.oberbrechen.koeb.ausgaben.AusgabenFactory;
import de.oberbrechen.koeb.ausgaben.AusgabenTreeKnoten;
import de.oberbrechen.koeb.ausgaben.ParameterException;
import de.oberbrechen.koeb.gui.components.medienAusgabeWrapper.MedienAusgabeWrapper;

/**
 * Dieses Klasse stellt eine Factory da, die
 * die eine Ausgabe erstellt, die ein PdfMedienaufkleber ausgibt.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class PdfMedienaufkleberAusgabenFactory implements AusgabenFactory {
  
  public String getName() {
    return "Medienaufkleber";
  }

  public String getBeschreibung() {
    return "Erzeugt zwei Ausgaben f�r Medienaufkleber. Eine erstellt " +      "gro�e und eine kleine Medienaufkleber.";
  }

  public void setParameter(String name, String wert) throws ParameterException {
    throw new ParameterException("Diese Factory erlaubt keine Parameter!");
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) {
    knoten.addAusgabe(new MedienAusgabeWrapper(new PdfMedienaufkleberMedienAusgabe(true)));
    knoten.addAusgabe(new MedienAusgabeWrapper(new PdfMedienaufkleberMedienAusgabe(false)));
  }
}
