/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.benutzerListenAuswahlPanel;

import java.awt.Dimension;

import javax.swing.JTable;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AusgabeAuswahl;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenbankzugriff.BenutzerFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.ListenAuswahlPanel;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.TabellenSelektion;

/**
* Diese Klasse ist eine Implementierung
* des ListenAuswahlPanels f�r Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/
public class BenutzerListenAuswahlPanel extends ListenAuswahlPanel {
  
  public BenutzerListenAuswahlPanel() {
    this(false, false);
  }
    
	public BenutzerListenAuswahlPanel(boolean ausrichtung, boolean zeigeAuswahl) {
		super(ausrichtung, zeigeAuswahl);
    this.setPreferredSize(new Dimension(600, 200));
    auswahlTabelle.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    datenTabelle.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    
    TableColumnModel columnModel = datenTabelle.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(50);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(100);
    columnModel.getColumn(3).setPreferredWidth(250);    

    columnModel = auswahlTabelle.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(50);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(100);
    columnModel.getColumn(3).setPreferredWidth(250);    
	}

	protected AuswahlTableModel createDatenAuswahlTableModel(JTable table) {
    BenutzerFactory benutzerFactory = 
      Datenbank.getInstance().getBenutzerFactory();
      
    AuswahlTableModel auswahlTableModel = 
      new BenutzerTableModel(table, benutzerFactory.getAlleBenutzer());
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}

	protected AuswahlTableModel createEmptyAuswahlTableModel(JTable table) {
    AuswahlTableModel auswahlTableModel = 
    new BenutzerTableModel(table, new BenutzerListe());
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}
  
  public void initAuswahlFeld(AuswahlKonfiguration konfiguration) {        
    auswahlComboBox.removeAllItems();
    auswahlComboBox.addItem("");

    for (int i=0; i < konfiguration.getAusgabeAnzahl(); i++) {
      final AusgabeAuswahl ausgabe = konfiguration.getAusgabe(i);
      if (!ausgabe.istBenutzerAuswahl()) {
        ErrorHandler.getInstance().handleError("Ausgabe '"+ausgabe.getTitel()+
            "' ist keine Benutzer-Auswahl!", false);                 
      } else {
        auswahlComboBox.addItem(new TabellenSelektion() {            
          public String toString() {
            return ausgabe.getTitel();
          }

          protected boolean istInSelektion(Object o) {             
            return ausgabe.bewerte((Benutzer) o);              
          }
        });
      }
    }
  }
}