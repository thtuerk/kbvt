/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components;

import javax.swing.Timer;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Iterator;

/**
 * Diese Klasse stellt einen ListSelectitionListener da,
 * der die empfangenen Events
 * zwischenspeichert und erst nach einer bestimmten Zeit an andere
 * ListSelectionListener
 * weiterleitet. Tritt in dieser Zeit ein weiteres Event ein, so wird das
 * vorherige Event verworfen und die Wartezeit neu begonnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class DelayListSelectionListener implements ListSelectionListener {

  private Timer timer;
  ListSelectionEvent listSelectionEvent;
  Vector listeners;

  /**
   * Erstellt einen neuen DelayListSelectionListener,
   * der die Events nach dem �bergebenen
   * Zeitraum in ms weiterleitet.
   *
   * @param delay die Wartezeit in ms
   */
  public DelayListSelectionListener(int delay) {
    listeners = new Vector();
    timer = new javax.swing.Timer(delay, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Iterator it = listeners.iterator();
        while (it.hasNext()) {
          ((ListSelectionListener) it.next()).valueChanged(listSelectionEvent);
        }
      }
    });

    timer.setInitialDelay(delay);
    timer.setRepeats(false);
  }

  public void valueChanged(ListSelectionEvent e) {
    listSelectionEvent = e;
    timer.restart();
  }

  /**
   * F�gt einen neuen Listener, an den die eintreffenden Events weitergeleitet
   * werden sollen ein.
   *
   * @param listener der neue Listener
   */
  public void addListSelectionListener(ListSelectionListener listener) {
    listeners.add(listener);
  }

  /**
   * Bricht die Wartezeit sofort ab und leitet das wartende Event sofort weiter.
   */
  public void fireDelayListSelectionEvent() {
    if (!timer.isRunning()) return;

    timer.stop();
    Iterator it = listeners.iterator();
    while (it.hasNext()) {
      ((ListSelectionListener) it.next()).valueChanged(listSelectionEvent);
    }
  }
}
