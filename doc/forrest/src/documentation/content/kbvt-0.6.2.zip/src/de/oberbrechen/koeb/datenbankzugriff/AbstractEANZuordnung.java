/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.EAN;

/**
 * Stellt Standard-Implementierungen f�r die Methoden getMediumEAN und
 * getBenutzerEAN zur Verf�gung. F�r Medien beginnt die EAN mit 22, gefolgt von
 * der Id des Mediums. F�r Benutzer beginnt die EAN mit EAN mit 21 gefolgt von
 * der Id. Der Benutzer mit der Id 22 erh�lt z.B. die EAN
 * 210000000022x, wobei x eine automatisch bestimmte Pr�fziffer ist.
 * F�r Medien k�nnen zus�tzliche EANs vorhanden sein. Mittels sucheMedium(ean) 
 * kann nach solchen EANs gesucht werden.
 * @author thtuerk
 * @version $Revision: 1.2 $
 */
public abstract class AbstractEANZuordnung implements EANZuordnung {

	protected BenutzerFactory benutzerFactory = Datenbank.getInstance().getBenutzerFactory();
	protected MediumFactory mediumFactory = Datenbank.getInstance().getMediumFactory();    
  
	public EAN getBenutzerEAN(Benutzer benutzer) {
    StringBuffer eanBuffer = new StringBuffer();
    eanBuffer.append(benutzer.getId());
    while (eanBuffer.length() < 10) {
      eanBuffer.insert(0, "0");
    }
    eanBuffer.insert(0, "21");

    return new EAN(eanBuffer.toString());        
	}

	public EAN getMediumEAN(Medium medium) {
	 return getMediumEAN(medium.getId());
  }

  /**
   * @deprecated
   */
	public EAN getMediumEAN(int mediumID) {
    StringBuffer eanBuffer = new StringBuffer();
    eanBuffer.append(mediumID);
    while (eanBuffer.length() < 10) {
      eanBuffer.insert(0, "0");
    }
    eanBuffer.insert(0, "22");

    return new EAN(eanBuffer.toString());        
	}

	public Object getReferenz(EAN ean) {
		if (ean.getEAN().startsWith("21000")) {
			int id = Integer.parseInt(ean.getEAN().substring(5,12));
			try {
        return benutzerFactory.get(id);
			} catch (DatenNichtGefundenException e) {
				return null;
			}
		} else if (ean.getEAN().startsWith("22000")) {
				int id = Integer.parseInt(ean.getEAN().substring(5,12));
				try {
          return mediumFactory.get(id);
				} catch (DatenNichtGefundenException e) {
					return null;
				}
		} else {
		  return sucheMedium(ean);
		}
	}

	/**
	 * Versucht ein zur �bergebenen EAN passendes Medium zu finden.
	 * Wird kein Medium gefunden, wird <code>null</code> zur�ckgeliefert.
	 * @param ean die EAN, deren Medium gesucht werden soll
	 * @return
	 */
	protected abstract Medium sucheMedium(EAN ean);
}