/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.vipReiter;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.*;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.gui.admin.AdminMainReiter;
import de.oberbrechen.koeb.gui.admin.Main;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Benutzern in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */

public class VIPReiter extends JPanel
  implements AdminMainReiter {
  
  private VIPTableModel vipTableModel;
  private JTable vipTable;
  private Main hauptFenster;
  
  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public VIPReiter(Main parentFrame) {
    hauptFenster = parentFrame;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Medienliste
    vipTable = new JTable();
    vipTableModel = new VIPTableModel(vipTable);
    vipTable.setModel(vipTableModel);
    vipTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    vipTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    vipTable.addKeyListener(vipTableModel);
    TableColumnModel columnModel = vipTable.getColumnModel();
    for (int i = 0; i < vipTableModel.getColumnCount(); i++) 
      columnModel.getColumn(i).setPreferredWidth(
          vipTableModel.getDefaultColumnWidth(i));
    
    JScrollPane jScrollPane1 = new JScrollPane(vipTable);
    jScrollPane1.setMinimumSize(new Dimension(150,150));
    jScrollPane1.setPreferredSize(new Dimension(150,150));
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));
    this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));    
  
    this.setLayout(new BorderLayout());
    this.add(jScrollPane1, BorderLayout.CENTER);
  }

  
  public void aktualisiere() {
    refresh();
  }

  public void refresh() {
    vipTableModel.refresh();
    vipTable.doLayout();
  }
  
  public JMenu getMenu() {
    return null;
  }
  
  public void focusLost() {
  }
}