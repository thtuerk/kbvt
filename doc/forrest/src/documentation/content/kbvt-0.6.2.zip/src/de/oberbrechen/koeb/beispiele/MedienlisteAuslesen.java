/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.beispiele;

import java.util.Iterator;

import de.oberbrechen.koeb.ausgaben.MedienAusgabe;
import de.oberbrechen.koeb.ausgaben.MedienAusgabeFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenbankzugriff.MediumFactory;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.pdf.pdfMedienListe.PdfMedienlisteMedienAusgabeFactory;

/**
 * Diese Klasse gibt eine Liste aller Medien auf dem Bildschirm 
 * und mit der Standard-Ausgabe, d.h. je nach Konfiguration wahrscheinlich
 * als PDF-Datei aus.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 */
public class MedienlisteAuslesen {
  
  public static void main(String[] args) throws Exception {
    MediumFactory mediumFactory = Datenbank.getInstance().getMediumFactory();    
    MedienListe alleMedien = mediumFactory.getAlleMedien();
    alleMedien.setSortierung(MedienListe.TitelAutorSortierung);
    
    //Ausgabe auf Bildschirm
    Iterator medienIt = alleMedien.iterator();
    while (medienIt.hasNext()) {
      Medium aktuellesMedium = (Medium) medienIt.next();
      System.out.println(aktuellesMedium.getTitel());
    }
    
    //Ausgabe mit Ausgabe    
    MedienAusgabeFactory medienlisteAusgabenFactory = 
      new PdfMedienlisteMedienAusgabeFactory();
    MedienAusgabe ausgabe = medienlisteAusgabenFactory.createMedienAusgabe();
    ausgabe.setDaten(alleMedien);
    ausgabe.setTitel("Alle Medien");
    ausgabe.setSortierung(MedienListe.TitelAutorSortierung, false);
    ausgabe.run(null);
    
    //Warten auf Ausgabe, da bei Programmende tempor�re PDF gel�scht wird
    Thread.sleep(10000);    
  }
}
