/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfJahresStatistik;

import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfAusleihStatistik.AusleihStatistikTabellenModell;
import de.oberbrechen.koeb.pdf.pdfInternetStatistik.InternetStatistikJahrTabellenModell;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt eine Jahres-Statistik.
 */
public class PdfJahresstatistik extends PdfDokument {

  private PdfTemplateDokument pdfDokument; 
  private int jahr;
  AuswahlKonfiguration ausleihStatistik;
  AuswahlKonfiguration bestandStatistik;
  
  public PdfJahresstatistik(int jahr, AuswahlKonfiguration ausleihStatistik,
      AuswahlKonfiguration bestandStatistik) {
    this.jahr = jahr;
    this.ausleihStatistik = ausleihStatistik;
    this.bestandStatistik = bestandStatistik;
    
    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(30);
    String titel = "Jahresstatistik "+jahr;
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) throws Exception {
    Vector templates = new Vector();

    //Ausleihstatistik
    TabellenModell tabellenModell = 
      AusleihStatistikTabellenModell.createStatistikTabellenModell(
        ausleihStatistik, jahr, pdfDokument);    
    templates.add(getTemplate(tabellenModell, "Ausleihstatistik", true, writer));
    
    //Bestandstatistik
    tabellenModell = 
      new BestandStatistikJahrTabellenModell(jahr, bestandStatistik);
    templates.add(getTemplate(tabellenModell, "Bestandstatistik", true, writer));

    //Internetstatistik
    tabellenModell = 
      new InternetStatistikJahrTabellenModell(jahr);
    templates.add(getTemplate(tabellenModell, "Internetstatistik", true, writer));
    
    //Benutzer und Veranstaltungen
    tabellenModell = 
      new BenutzerUndVeranstaltungenStatistikJahrTabellenModell(jahr);
    templates.add(getTemplate(tabellenModell, "Benutzer und Veranstaltungen", false, writer));
    
    //aktive Leser
    tabellenModell = 
      new AktiveLeserStatistikJahrTabellenModell(jahr, 25);
    templates.add(getTemplate(tabellenModell, "Die 25 aktivsten Leser", true, writer));
    
    pdfDokument.setTemplates((PdfTemplate[]) templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }
  
  private PdfTemplate getTemplate(TabellenModell tabellenModell, String titel, 
      boolean zeigeSpaltenKopf, PdfWriter writer) throws Exception {
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1);

    if (tabellenModell.getZeilenAnzahl() > 1) {
      PdfTabelle tabelle = new PdfTabelle(tabellenModell);
      if (tabelle.hasNextTemplate()) {
        PdfTemplate tabellenTemplate = 
          tabelle.getNextTemplate(zeigeSpaltenKopf, maximaleHoehe, pdfDokument, writer.getDirectContent(), titel);
        return tabellenTemplate;
      }
    }        
    return null;
  }  
}
