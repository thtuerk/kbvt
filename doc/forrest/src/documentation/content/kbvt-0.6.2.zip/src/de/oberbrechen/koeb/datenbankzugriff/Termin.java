/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.datenstrukturen.ZeitraumInkonsistenzException;


/**
 * Diese Klasse repr�sentiert einen Termin einer Veranstaltung der B�cherei.
 *
 * @version $Revision: 1.9 $
 * @author Thomas T�rk (t_tuerk@gmx.de)
 */

public class Termin extends Zeitraum {

  /**
   * Erstellt einen neuen Termin.
   * @param beginn der Beginn
   * @param ende das Ende
   */
  public Termin(java.util.Date beginn, java.util.Date ende) {
    super(beginn, ende);
  }

	public Object clone() {
		return new Termin(beginn, ende);
	}

  public void check() throws ZeitraumInkonsistenzException  {
    if (beginn == null) { 
      throw new ZeitraumInkonsistenzException(
        "Ein Termin muss einen Beginn haben!");
    }  
    super.check();
  }
}