/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import java.util.Comparator;

import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.einstellungen.Buecherei;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von Medien. Ein Medium
* ist eindeutig �ber seine Nummer identifiziert und wird nur einmal in
* die Liste aufgenommen. Es ist zu
* beachten, dass �berall nur Medium-Objekte statt allgemeiner Objekte als
* Parameter �bergeben werden d�rfen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.10 $
*/

public class MedienListe extends Liste {

	/**
   * Medien werden alphabetisch zuerst nach ihrem Titel und dann nach dem
   * Autor sortiert
   */
  public static final int TitelAutorSortierung = 2;

  /**
   * Medien werden alphabetisch zuerst nach ihrem Autor und dann nach dem
   * Titel sortiert
   */
  public static final int AutorTitelSortierung = 3;

  /**
   * Medien werden nach ihrer Nummer sortiert.
   */
  public static final int MedienNummerSortierung = 4;

  /**
   * Medien werden nach ihrem Einstellungsdatum und dann nach ihrem
   * Titel sortiert.
   */
  public static final int EinstellungsdatumSortierung = 5;


  protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;
    final Comparator medienNrSort = 
      Buecherei.getInstance().getMedienNrComparator();    

    switch (sortierung) {
      case TitelAutorSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Medium mediumA = (Medium) a;
              Medium mediumB = (Medium) b;
              int erg = nullCompare(mediumA.getTitel(), mediumB.getTitel());                       
              if (erg == 0) erg = nullCompare(
                mediumA.getAutor(), mediumB.getAutor());
              if (erg == 0) erg = medienNrSort.compare(a, b);
              return erg;
            }};
        break;
      }

      case EinstellungsdatumSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Medium mediumA = (Medium) a;
              Medium mediumB = (Medium) b;              
              
              int erg = 0;
              if (mediumA.getEinstellungsdatum() == null &&
                  mediumB.getEinstellungsdatum() != null) erg = -1;
              if (mediumA.getEinstellungsdatum() == null &&
                  mediumB.getEinstellungsdatum() == null) erg = 0;
              if (mediumA.getEinstellungsdatum() != null &&
                  mediumB.getEinstellungsdatum() == null) erg = 1;
              if (mediumA.getEinstellungsdatum() != null &&
                  mediumB.getEinstellungsdatum() != null) 
                erg = mediumA.getEinstellungsdatum().compareTo(
                    mediumB.getEinstellungsdatum());              
              if (erg == 0) erg = nullCompare(
                  mediumA.getTitel(), mediumB.getTitel());
              if (erg == 0) erg = nullCompare(mediumA.getAutor(), mediumB.getAutor());
              if (erg == 0) erg = medienNrSort.compare(a, b);
              return erg;
            }};
        break;
      }

      case AutorTitelSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Medium mediumA = (Medium) a;
              Medium mediumB = (Medium) b;
              int erg = nullCompare(mediumA.getAutor(), mediumB.getAutor());
              if (erg == 0) erg = nullCompare(mediumA.getTitel(), mediumB.getTitel());
              if (erg == 0) erg = medienNrSort.compare(a, b);
              return erg;
            }};
        break;
      }

      //Nummer Sortierung
      case MedienNummerSortierung : {
        sort = medienNrSort;
        break;
      }

      default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }
}
