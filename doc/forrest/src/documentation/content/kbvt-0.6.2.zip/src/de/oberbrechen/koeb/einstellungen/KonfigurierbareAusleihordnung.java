/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import java.util.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;

/**
* Diese Klasse ist eine konfigurierbare Implementierung einer Ausleihordnung.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.12 $
*/

public class KonfigurierbareAusleihordnung extends Ausleihordnung {

  class MedientypEinstellung {
    Medientyp medientyp;
    int mindestAusleihdauerInTagen;
  }

  private int kulanzZeitInTagen;
  private double mahngebuehrProMediumProWocheInEuro;
  private Vector medientypEinstellungen;
  
  public KonfigurierbareAusleihordnung() {
    EinstellungFactory einstellungFactory =
      Datenbank.getInstance().getEinstellungFactory();
    
    kulanzZeitInTagen = einstellungFactory.getEinstellung( 
      this.getClass().getName(), "kulanzZeitInTagen").getWertInt(14);
    mahngebuehrProMediumProWocheInEuro = einstellungFactory.getEinstellung(
      this.getClass().getName(), 
      "mahngebuehrProMediumProWocheInEuro").getWertDouble(0.25);
      
    medientypEinstellungen = new Vector();
    Iterator medienTypIterator = Datenbank.getInstance().getMedientypFactory().
      getAlleMedientypen().iterator();
    while (medienTypIterator.hasNext()) {
      Medientyp currentTyp = (Medientyp) medienTypIterator.next();
      MedientypEinstellung einstellung = new MedientypEinstellung();
      einstellung.medientyp = currentTyp;
      einstellung.mindestAusleihdauerInTagen = 
        einstellungFactory.getEinstellung(this.getClass().getName(), 
        "mindestAusleihdauerInTagen."+currentTyp.getName()).
        getWertInt(21);
      medientypEinstellungen.add(einstellung);
    }
  }
  
  /**
   * Berechnet die Mahngeb�hren f�r die �bergebene Ausleihe.
   * @return die Mahngeb�hren f�r die �bergebene Ausleihe
   */
  public double berechneMahngebuehren(Ausleihe ausleihe) {       
    //VIPs nichts berechnen    
    if (ausleihe.getBenutzer().istVIP()) return 0;
      
    //ansonsten
    int sum=0;
    
    AusleihzeitraumListe ausleihen = ausleihe.getAusleihzeitraeume();
    for (int i=0; i < ausleihen.size(); i++) {      
      Date von = ((Ausleihzeitraum) ausleihen.get(i)).getEnde();
      Date bis = i < ausleihen.size()-1?
                   ((Ausleihzeitraum) ausleihen.get(i+1)).getBeginn():
                   new Date();
      
      if (von != null && bis != null) {
        int ueberzogeneTage = 
          DatenmanipulationsFunktionen.getDifferenzTage(von, bis);
        if (ueberzogeneTage > kulanzZeitInTagen) sum+=ueberzogeneTage;
      }      
    }
    
    int anzahlUeberzogeneWochen = (int) Math.floor(
      (double) sum / 7);
    return anzahlUeberzogeneWochen*mahngebuehrProMediumProWocheInEuro;
  }

  
  // Doku siehe bitte Ausleihordnung
  public Date getAusleihenBisDatum(Medium medium, Date datum) {
    Medientyp medientyp;
    if (medium == null) {
      medientyp = Datenbank.getInstance().
        getMedientypFactory().getMeistBenutztenMedientyp();
    } else {
      medientyp = medium.getMedientyp();
    }

    MedientypEinstellung benoetigteEinstellung = null;
    Iterator it = medientypEinstellungen.iterator();
    while (it.hasNext() && benoetigteEinstellung == null) {
      MedientypEinstellung aktuelleEinstellung = 
        (MedientypEinstellung) it.next();
      if (aktuelleEinstellung.medientyp.equals(medientyp))
        benoetigteEinstellung = aktuelleEinstellung;          
    }
    //Hier wird immer etwas gefunden, da vorher !alle! Medientypen initialisiert wurden
    
    Calendar neuesDatum = Calendar.getInstance();
    if (datum != null) neuesDatum.setTime(datum);
    neuesDatum.add(Calendar.DATE, benoetigteEinstellung.mindestAusleihdauerInTagen);

    return Buecherei.getInstance().getNaechstesOeffnungsdatum(
      neuesDatum.getTime());
  }
}
