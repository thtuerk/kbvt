/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben;

import java.util.Collection;

import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;

/**
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public abstract class AbstractBenutzerAusgabe implements BenutzerAusgabe{

  protected BenutzerListe daten = null;
  protected int datenSortierung = BenutzerListe.NachnameVornameSortierung;
  protected boolean datenUmgekehrteSortierung = false;
  protected String datenTitel = "Benutzerliste";
  
  public void setDaten(BenutzerListe daten) {
    this.daten = daten;
  }
  
  public void setDaten(Collection daten) {
    this.daten = new BenutzerListe();
    this.daten.addAllNoDuplicate(daten);
  }
  
  public void setTitel(String titel) {
    this.datenTitel = titel;
  }
    
  public void setSortierung(int sortierung, boolean umgekehrteSortierung) {
    this.datenSortierung = sortierung;
    this.datenUmgekehrteSortierung = umgekehrteSortierung;
  }
  
  /**
   * Liefert eine Kopie der Daten, sortiert nach der eingestellten Sortierung
   * @return die sortierten Daten
   */
  protected BenutzerListe getSortierteBenutzerListe() {
    BenutzerListe benutzerliste = new BenutzerListe();
    benutzerliste.addAllNoDuplicate(daten);
    benutzerliste.setSortierung(datenSortierung, datenUmgekehrteSortierung);
    return benutzerliste;
  }
}