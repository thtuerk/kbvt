/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.util.Iterator;

import de.oberbrechen.koeb.datenstrukturen.MitarbeiterListe;


/**
 * Dieses Klasse stellt einige grundlegende
 * Funktionen einer MitarbeiterFactory bereit. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public abstract class AbstractMitarbeiterFactory extends 
  AbstractDatenbankzugriffFactory implements MitarbeiterFactory {
  
  Mitarbeiter aktuellerMitarbeiter = null;

	public MitarbeiterListe getAlleMitarbeiterMitBerechtigung(int berechtigung) {
    MitarbeiterListe alleMitarbeiter = getAlleMitarbeiter();
    MitarbeiterListe ausgewaehlteMitarbeiter = new MitarbeiterListe();

    Iterator it = alleMitarbeiter.iterator();
    while (it.hasNext()) {
      Mitarbeiter currentMitarbeiter = (Mitarbeiter) it.next();
      if (currentMitarbeiter.besitztBerechtigung(berechtigung)) {
        ausgewaehlteMitarbeiter.add(currentMitarbeiter);
      }
    }
    return ausgewaehlteMitarbeiter;
	}

	public Mitarbeiter getAktuellenMitarbeiter() {
		return aktuellerMitarbeiter;
	}

	public void setAktuellenMitarbeiter(Mitarbeiter mitarbeiter) {
    aktuellerMitarbeiter = mitarbeiter;
	}

  public MitarbeiterListe getAktiveMitarbeiterMitBerechtigung(int berechtigung) {
    MitarbeiterListe alleMitarbeiter = getAlleMitarbeiterMitBerechtigung(berechtigung);
    MitarbeiterListe ausgewaehlteMitarbeiter = new MitarbeiterListe();

    Iterator it = alleMitarbeiter.iterator();
    while (it.hasNext()) {
      Mitarbeiter currentMitarbeiter = (Mitarbeiter) it.next();
      if (currentMitarbeiter.istAktiv()) {
        ausgewaehlteMitarbeiter.add(currentMitarbeiter);
      }
    }
    return ausgewaehlteMitarbeiter;
  }
}