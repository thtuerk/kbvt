/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;

/**
 * Dieses Interface stellt eine Factory f�r allgemeine
 * Datenbankzugriffe da. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public interface DatenbankzugriffFactory {
  
  /**
   * L�d das Datenbankzugriff-Objekt mit der �bergebenen
   * ID aus der Datenbank.
   * @param id die ID des zu ladenden Objekts
   * @throws DatenNichtGefundenException falls ein Objekt mit der
   *  �bergebenen id nicht in der Datenbank existiert
   * @return das geladene Datenbankzugriff-Objekt
   */
  public abstract Datenbankzugriff ladeAusDatenbank(int id)
    throws DatenNichtGefundenException;

	/**
	 * Versucht das Datenbankzugriff-Objekt mit der �bergebenen
	 * ID aus dem Cache zu holen.
	 * @param id die ID des zu ladenden Objekts
	 * @throws DatenNichtGefundenException falls ein Objekt mit der
	 *  �bergebenen id nicht in der Datenbank existiert
	 * @return das geladene Datenbankzugriff-Objekt oder null falls es nicht
	 *   im Cache gefunden wurde
	 */
  public Datenbankzugriff ladeAusCache(int id);
    
  /**
   * Liefert das zur �bergebenen ID passende Datenbankzugriff-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. 
   *
   * @param id die ID des zu ladenden Objekts
   * @throws DatenNichtGefundenException falls ein Objekt mit der
   *  �bergebenen id nicht in der Datenbank existiert
   * @return das geladene Datenbankzugriff-Objekt
   */
  public abstract Datenbankzugriff get(int id) 
    throws DatenNichtGefundenException;

  /**
   * F�gt das �bergebene Datenbankzugriff-Objekt in den Cache ein.
   * @param datenbankzugriff das einzuf�gende Objekt
   */
  public void fuegeInCacheEin(Datenbankzugriff datenbankzugriff);

  /**
   * L�scht alle im Cache enthaltenen Daten
   */
  public abstract void clearCache();
}