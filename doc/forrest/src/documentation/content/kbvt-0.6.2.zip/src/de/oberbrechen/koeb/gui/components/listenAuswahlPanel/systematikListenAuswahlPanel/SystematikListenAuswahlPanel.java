/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.systematikListenAuswahlPanel;

import javax.swing.JTable;

import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.SystematikFactory;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.ListenAuswahlPanel;

/**
* Diese Klasse ist eine Implementierung
* des ListenAuswahlPanels f�r Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/
public class SystematikListenAuswahlPanel extends ListenAuswahlPanel {

	public SystematikListenAuswahlPanel() {
		super(true, false);
	}

	protected AuswahlTableModel createDatenAuswahlTableModel(JTable table) {
    SystematikFactory systematikFactory = 
      Datenbank.getInstance().getSystematikFactory();
    SystematikListe alleSystematiken = systematikFactory.getAlleSystematiken();
    alleSystematiken.setSortierung(SystematikListe.alphabetischeSortierung);

    AuswahlTableModel auswahlTableModel = new SystematikTableModel(
      table, alleSystematiken);
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}

	protected AuswahlTableModel createEmptyAuswahlTableModel(JTable table) {
    AuswahlTableModel auswahlTableModel = new SystematikTableModel(
      table, new SystematikListe());
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}
}