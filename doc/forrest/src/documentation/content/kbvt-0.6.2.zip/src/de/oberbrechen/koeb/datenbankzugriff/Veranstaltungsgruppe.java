/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;


/**
 * Dieses Interface repr�sentiert eine Veranstaltungsgruppe.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.8 $
 */
public interface Veranstaltungsgruppe extends Datenbankzugriff {

  /**
   * Liefert der Namen der Veranstaltungsgruppe
   * @return den Namen der Veranstaltungsgruppe
   */
  public String getName();
  
  /**
   * Liefert die Beschreibung der Veranstaltungsgruppe
   * @return die Beschreibung der Veranstaltungsgruppe
   */
  public String getBeschreibung();
  
  /**
   * Liefert den gek�rzten Namen der Veranstaltungsgruppe
   * @return den gek�rzten Namen der Veranstaltungsgruppe
   */
  public String getKurzName();
  
  /**
   * Liefert das Heimatverzeichnis der Veranstaltungsgruppe
   * @return die Heimatverzeichnis der Veranstaltungsgruppe
   */
  public String getHomeDir();
        
  /**
   * Setzt die Beschreibung der Veranstaltungsgruppe
   * @param beschreibung die neue Beschreibung der Veranstaltungsgruppe
   */
  public void setBeschreibung(String beschreibung);

  /**
   * Setzt das Heimatverzeichnis der Veranstaltungsgruppe
   * @param homeDir das neue Heimatverzeichnis der Veranstaltungsgruppe
   */
  public void setHomeDir(String homeDir);

  /**
   * Setzt den gek�rzten Namen der Veranstaltungsgruppe
   * @param kurzName den neue gek�rzte Name der Veranstaltungsgruppe
   */
  public void setKurzName(String kurzName);

  /**
   * Setzt den Namen der Veranstaltungsgruppe
   * @return name der neue Name der Veranstaltungsgruppe
   */
  public void setName(String name);  
}