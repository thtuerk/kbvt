/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components;

import javax.swing.Timer;
import java.awt.event.*;
import java.util.Vector;
import java.util.Iterator;

/**
 * Diese Klasse stellt einen ItemListener dar, der die empfangenen Events
 * zwischenspeichert und erst nach einer bestimmten Zeit an andere ItemListener
 * weiterleitet. Tritt in dieser Zeit ein weiteres Event ein, so wird das
 * vorherige Event verworfen und die Wartezeit neu begonnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public class DelayItemListener implements ItemListener {

  private boolean enabled;
  private Timer timer;
  ItemEvent itemEvent;
  Vector listeners;

  /**
   * Erstellt einen neuen DelayItemListener der die Events nach dem �bergebenen
   * Zeitraum in ms weiterleitet.
   *
   * @param delay die Wartezeit in ms
   */
  public DelayItemListener(int delay) {
    listeners = new Vector();
    timer = new javax.swing.Timer(delay, new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Iterator it = listeners.iterator();
        while (it.hasNext()) {
          ((ItemListener) it.next()).itemStateChanged(itemEvent);
        }
      }
    });

    timer.setInitialDelay(delay);
    timer.setRepeats(false);
    enabled=true;
  }

  public void itemStateChanged(ItemEvent e) {
    if (!enabled) return;
    itemEvent = e;
    timer.restart();
  }

  /**
   * F�gt einen neuen Listener, an den die eintreffenden Events weitergeleitet
   * werden sollen ein.
   *
   * @param itemListener der neue Listener
   */
  public void addItemListener(ItemListener itemListener) {
    listeners.add(itemListener);
  }

  /**
   * Bricht die Wartezeit sofort ab und leitet das wartende Event sofort weiter.
   */
  public void fireDelayItemListenerEvent() {
    if (!timer.isRunning()) return;

    timer.stop();
    Iterator it = listeners.iterator();
    while (it.hasNext()) {
      ((ItemListener) it.next()).itemStateChanged(itemEvent);
    }
  }

  /**
   * Bestimmt, ob der DelayItemListener aktiv ist, d.h. ob er
   * irgendwelche Events weiterleitet. Ein bereits gestarteter
   * Timer wird aber nicht abgebrochen. 
   * @param enabled
   */
  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
}
