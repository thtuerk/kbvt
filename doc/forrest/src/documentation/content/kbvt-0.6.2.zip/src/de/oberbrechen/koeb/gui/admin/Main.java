/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin;

import javax.swing.JMenuBar;

import de.oberbrechen.koeb.datenbankzugriff.Mitarbeiter;
import de.oberbrechen.koeb.gui.AbstractMain;
import de.oberbrechen.koeb.gui.admin.alleEinstellungenReiter.AlleEinstellungenReiter;
import de.oberbrechen.koeb.gui.admin.clientReiter.ClientReiter;
import de.oberbrechen.koeb.gui.admin.konfigurierbareBuechereiAusleihordnungReiter.KonfigurierbareBuechereiAusleihordnungReiter;
import de.oberbrechen.koeb.gui.admin.medientypReiter.MedientypReiter;
import de.oberbrechen.koeb.gui.admin.mitarbeiterReiter.MitarbeiterReiter;
import de.oberbrechen.koeb.gui.admin.systematikReiter.SystematikReiter;
import de.oberbrechen.koeb.gui.admin.vipReiter.VIPReiter;

/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die zur
 * Administration des Systems dient.
 *
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.13 $
 */
public class Main extends AbstractMain {
  
  public Main(boolean isMain, Mitarbeiter mitarbeiter) {
    super(isMain, "Administrationstool", Mitarbeiter.BERECHTIGUNG_ADMIN,
          "de/oberbrechen/koeb/gui/icon-admin.png", mitarbeiter);    
  }

  public static void main(String[] args) {
    init();
    new Main(true, null);
  }
  
  protected void initDaten() {
  }

  protected void reiterHinzufuegen() {
    reiter.add(new KonfigurierbareBuechereiAusleihordnungReiter(this), 
      "konfigurierbare B�cherei / Ausleihordnung");
    reiter.add(new AlleEinstellungenReiter(this), "Einstellungen");
    reiter.add(new VIPReiter(this), "VIPs");
    reiter.add(new MitarbeiterReiter(this), "Mitarbeiter");
    reiter.add(new MedientypReiter(this), "Medientypen");
    reiter.add(new ClientReiter(this), "Clients");
    reiter.add(new SystematikReiter(this), "Systematiken");
  }
  
  protected void addMenue(JMenuBar menue) {
    menue.add(getDateiMenue(true));
    addReiterMenues(menue);
    menue.add(getInfoMenue());
  }    
}