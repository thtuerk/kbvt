/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsteilnahmeListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

public class MysqlVeranstaltungsteilnahmeFactory 
	extends AbstractVeranstaltungsteilnahmeFactory {

  private BenutzerFactory benutzerFactory =
  	MysqlDatenbank.getMysqlInstance().getBenutzerFactory();
  
  public Veranstaltungsteilnahme erstelleNeu(
      Benutzer benutzer, Veranstaltung veranstaltung) {
    return new MysqlVeranstaltungsteilnahme(benutzer, veranstaltung);
  }

  public Veranstaltungsteilnahme getVeranstaltungsteilnahme(
      Benutzer benutzer, Veranstaltung veranstaltung) {
    try {
	    MysqlDatenbank.getMysqlInstance().beginTransaktion();            
			Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
			PreparedStatement statement = 
				(PreparedStatement) connection.prepareStatement(
						"select id from benutzer_besucht_veranstaltung where " +
						"benutzerID = ? and veranstaltungID = ?");
			statement.setInt(1, benutzer.getId());
			statement.setInt(2, veranstaltung.getId());
			ResultSet result = (ResultSet) statement.executeQuery();      
			
			MysqlDatenbank.getMysqlInstance().endTransaktion();            
			
			boolean gefunden = result.next();
			if (!gefunden) return null;
			return (Veranstaltungsteilnahme) get(result.getInt(1));
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen" +
      	"der Teilnahme des Benutzers "+benutzer.getName()+" an der " +
      	"Veranstaltung "+veranstaltung.getTitel()+"!", true);
    }
    return null;
  }

  public VeranstaltungsteilnahmeListe getTeilnahmeListe(
      Veranstaltung veranstaltung) {
		VeranstaltungsteilnahmeListe liste = new VeranstaltungsteilnahmeListe();
		try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
					"select * from benutzer_besucht_veranstaltung " +
					"where veranstaltungid = "+veranstaltung.getId());
			while (result.next()) {
				Veranstaltungsteilnahme teilnahme = 
					new MysqlVeranstaltungsteilnahme(result);

				cache.put(new Integer(teilnahme.getId()), teilnahme);
				liste.addNoDuplicate(teilnahme);
			}
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Laden der Veranstaltungsteilnahmeliste f�r die" +
				"Veranstaltung "+veranstaltung.getTitel()+"!", true);
		}

		return liste;
  }

  public int getTeilnehmerAnzahl(Veranstaltung veranstaltung) {
		int erg = 0;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select count(*) from benutzer_besucht_veranstaltung " +
          "where veranstaltungid = "+veranstaltung.getId());
      result.next();
      erg = result.getInt(1);
      
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Veranstaltungsteilnahmeliste f�r die" +
          "Veranstaltung "+veranstaltung.getTitel()+"!", true);
    }
    
		return erg;
  }
  
  public int[] getTeilnehmerAnzahl(VeranstaltungenListe veranstaltungen) {
    int[] erg = new int[veranstaltungen.size()];
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select veranstaltungid, count(*) from benutzer_besucht_veranstaltung " +
          "where veranstaltungid IN ("+
          veranstaltungen.toKommaGetrenntenString(new IDFormat())+
          ") group by veranstaltungid");
      while(result.next()) {
        int currentID = result.getInt(1);
        for (int i = 0; i < veranstaltungen.size(); i++) {                 
          if (((Veranstaltung) veranstaltungen.get(i)).getId() == currentID) {
            erg[i] = result.getInt(2);
            break;
          }
        }
      }
      
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Veranstaltungsteilnahmeliste f�r die" +
          "Veranstaltungen "+veranstaltungen.toKommaGetrenntenString()+"!", true);
    }    
    return erg;
  }
  
    
  public int getTeilnehmerAnzahl(Veranstaltungsgruppe veranstaltungsgruppe) {
		int erg = 0;
		try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
				"select count(DISTINCT bbv.benutzerID) from "+
				"benutzer_besucht_veranstaltung as bbv left join veranstaltung as v "+
				"on bbv.veranstaltungID = v.id "+
				"where v.veranstaltungsgruppeID="+veranstaltungsgruppe.getId());
			result.next();
			erg = result.getInt(1);
			
			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, 
				"Fehler beim Bestimmen der Teilnehmeranzahl f�r die" +
				"Veranstaltungsgruppe "+veranstaltungsgruppe+"!", true);
		}

		return erg;        
  }

  public BenutzerListe getTeilnehmerListe(Veranstaltungsgruppe veranstaltungsgruppe) {
		BenutzerListe liste = new BenutzerListe();
    try {
			MysqlDatenbank.getMysqlInstance().beginTransaktion();
			Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
			ResultSet result = (ResultSet) statement.executeQuery(
      	"select DISTINCT bbv.benutzerid from "+
      	"benutzer_besucht_veranstaltung as bbv left join veranstaltung as v "+
      	"on bbv.veranstaltungID = v.id "+
      	"where v.veranstaltungsgruppeID="+veranstaltungsgruppe.getId());
			while (result.next()) {
				liste.add(benutzerFactory.get(result.getInt("benutzerID")));
			}

			MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
			MysqlDatenbank.getMysqlInstance().endTransaktion();
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
				"TeilnehmerListe der Veranstaltungsgruppe "+
			  veranstaltungsgruppe.getName()+"!", true);
		}
		return liste;
  }

  public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
    return new MysqlVeranstaltungsteilnahme(id);
  }

  public BenutzerListe getTeilnehmerListe(Veranstaltung veranstaltung) {
    BenutzerListe liste = new BenutzerListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
          "select DISTINCT benutzerID from "+
          "benutzer_besucht_veranstaltung "+
          "where veranstaltungid = "+veranstaltung.getId());      
      while (result.next()) {
        liste.add(benutzerFactory.get(result.getInt("benutzerID")));
      }      
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Bestimmen der Teilnehmerliste f�r die" +
          "Veranstaltung "+veranstaltung+"!", true);
    }
    return liste;        
  }

  public boolean[][] getTeilnahmeArray(
    VeranstaltungenListe veranstaltungen, BenutzerListe benutzer) {

    boolean[][] erg = new boolean[veranstaltungen.size()][benutzer.size()];

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();            
      Connection connection = MysqlDatenbank.getMysqlInstance().getConnection();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
            "select benutzerID, veranstaltungID from " +
            "benutzer_besucht_veranstaltung where " +
            "benutzerID IN ("+benutzer.toKommaGetrenntenString(new IDFormat())+
            ") and veranstaltungID IN ("+
            veranstaltungen.toKommaGetrenntenString(new IDFormat())+
            ") order by benutzerID, veranstaltungID");
      
      for (int i = 0; i < veranstaltungen.size(); i++) {
        for (int j = 0; j < benutzer.size(); j++) {
          erg[i][j] = false;
        }      
      }
      
      int benutzerPos = 0;
      int veranstaltungPos = 0;
      while (result.next()) {
        int benutzerId = result.getInt(1);
        int veranstaltungId = result.getInt(2);
        
        while (benutzerId != ((Benutzer) benutzer.get(benutzerPos)).getId()) {
          benutzerPos++;
          if (benutzerPos == benutzer.size()) benutzerPos = 0;
        }

        while (veranstaltungId != 
          ((Veranstaltung) veranstaltungen.get(veranstaltungPos)).getId()) {
          veranstaltungPos++;
          if (veranstaltungPos == veranstaltungen.size()) veranstaltungPos = 0;
        }
        
        erg[veranstaltungPos][benutzerPos] = true;
      }

      MysqlDatenbank.getMysqlInstance().endTransaktion();            
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden " +
          "des Teilnahme-Arrays!", true);
    }
    
    return erg;           
  }

}