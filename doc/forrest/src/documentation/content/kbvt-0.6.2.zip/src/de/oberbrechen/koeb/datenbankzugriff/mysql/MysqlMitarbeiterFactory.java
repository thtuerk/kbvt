/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.MitarbeiterListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public class MysqlMitarbeiterFactory extends AbstractMitarbeiterFactory {

	public Mitarbeiter erstelleNeu(Benutzer benutzer) {
    return new MysqlMitarbeiter(benutzer);
	}

	public MitarbeiterListe getAlleMitarbeiter() {
    cache.clear();
    MitarbeiterListe liste = new MitarbeiterListe();

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select * from mitarbeiter;");
          
      while (result.next()) {
        Mitarbeiter neuMitarbeiter = new MysqlMitarbeiter(result);
        cache.put(new Integer(neuMitarbeiter.getId()),
          neuMitarbeiter);
        liste.add(neuMitarbeiter);
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e,
        "Fehler beim Laden der Mitarbeiterliste!", true);
    }

    return liste;
	}

	public int sucheBenutzer(int id) throws DatenNichtGefundenException {
    int erg = 0;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select ID from mitarbeiter where "+
				  "benutzerID=\""+id+"\"");

      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) {
        MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
        MysqlDatenbank.getMysqlInstance().endTransaktion();
        
        throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit der BenutzerID '"+id+"' existiert "+
        "nicht.");
      }
      
      erg = result.getInt(1);
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des Mitarbeiters mit"+
        " der Benutzernummer '"+id+"'!", true);
    }

    return erg;
	}

	public int sucheMitarbeiterBenutzername(String benutzername) throws DatenNichtGefundenException {
    int erg = 0;

    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(
				  "select ID from mitarbeiter where "+
				  "Benutzername=\""+benutzername+"\"");

      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit dem Benutzernamen '"+benutzername+"' existiert "+
        "nicht.");

      erg = result.getInt(1);
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des " +        "Mitarbeiters mit dem Benutzernamen '"+benutzername+"'!", true);
    }
    return erg;
	}

	public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
		return new MysqlMitarbeiter(id);
	}

}