/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.SystematikListe;

/**
 * Dieses Interface repr�sentiert eine Factory f�r Systematiken..
 * 
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */
public interface SystematikFactory extends DatenbankzugriffFactory {

  /**
   * L�scht alle Systematiken aus der Datenbank. Ist ein Medium einer
   * Systematik zugeordnet, wird dabei diese Zuordnung entfernt.
   */
  public void loescheAlleSystematiken();
  
  /**
   * Liefert eine unsortierte Liste aller Systematiken, die in der Datenbank
   * eingetragen sind.
   *
   * @return die Liste der Systematiken
   */
  public SystematikListe getAlleSystematiken();

  /**
   * Liefert eine unsortierte Liste aller Systematiken, die keine
   * Obersystematiken besitzen, die also Hauptsystematiken bilden.
   *
   * @return die Liste der Systematiken
   */
  public SystematikListe getAlleHauptSystematiken();

  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Systematik-Objekt
   * 
   * @return das neue Systematik-Objekt
   */
  public Systematik erstelleNeu(); 

  /**
   * Liefert die Systematik mit dem �bergebenen Namen aus der Datenbank oder
   * aus dem Cache.
   * @return das neue Systematik-Objekt
   */
  public Systematik get(String name); 
}