/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.ausleiheReiter;

import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihe;
import de.oberbrechen.koeb.datenbankzugriff.Ausleihzeitraum;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;

/**
 * Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Ausleihen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class ZeitraumTableModel extends AbstractTableModel {

  private AusleihzeitraumListe daten;
  
  /**
   * Erstellt ein neues Modell ohne Daten, das nach dem Sollr�ckgabedatum
   * der Ausleihen sortiert ist
   */
  public ZeitraumTableModel() {
    daten = new AusleihzeitraumListe();
    daten.setSortierung(AusleihzeitraumListe.beginnSortierung);
  }

  /**
   * Setzt die �bergebenen Daten
   * @param daten die zu setzenden Daten
   */
  public void setDaten(Ausleihe ausleihe) {
    daten.clear();
    if (ausleihe != null) daten.addAll(ausleihe.getAusleihzeitraeume());
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 1;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Ausleihzeitraum gewaehlterZeitraum = 
      (Ausleihzeitraum) daten.get(rowIndex);
    if (columnIndex == 0)
      return gewaehlterZeitraum.getZeitraumFormat(
          Zeitraum.ZEITRAUMFORMAT_MITTEL);
    return "nicht definierte Spalte";
  }
  
  public String getColumnName(int col) {
    if (col == 0) return "Zeitraum";
    return "unbekannte Spalte";
  }

  /**
   * Liefert den Ausleihzeitraum, der sich in der �bergebenen
   * Zeile befindet 
   * @param row die Zeile
   * @return der Ausleihzeitraum
   */
  public Ausleihzeitraum getAusleihzeitraum(int row) {
    return (Ausleihzeitraum) daten.get(row);
  }

}
