/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.mysql;

import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import de.oberbrechen.koeb.datenstrukturen.AusleihzeitraumListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.7 $
 */
public class MysqlAusleiheFactory extends AbstractAusleiheFactory {

  public Ausleihe erstelleNeu() {
    return new MysqlAusleihe();
  }

  private AusleihenListe ladeAusAusleiheTabelle(String sqlQuery) {
    AusleihenListe liste = new AusleihenListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement();
      ResultSet result = (ResultSet) statement.executeQuery(sqlQuery);
      while (result.next()) {
        Ausleihe neueAusleihe = new MysqlAusleihe(result);
        liste.addNoDuplicate(neueAusleihe);
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihenliste!", true);
    }
    
    return liste;
  }

  private AusleihzeitraumListe ladeAusAusleihzeitraumTabelle(String sqlQuery) {
    AusleihzeitraumListe liste = new AusleihzeitraumListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement(); 
      ResultSet result = (ResultSet) statement.executeQuery(sqlQuery);
      while (result.next()) {
        liste.add(MysqlAusleihe.loadAusleihzeitraum(result));
      }
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Ausleihzeitraumliste!", true);
    }
  
    return liste;
  }

  public AusleihenListe getAlleAusleihen() {
    AusleihenListe liste = ladeAusAusleiheTabelle("select * from ausleihe");
    clearCache();
    Iterator it = liste.iterator();
    while(it.hasNext()) {
      Ausleihe neueAusleihe = (Ausleihe) it.next();
      cache.put(new Integer(neueAusleihe.getId()), neueAusleihe);
    }
    return liste;
  }

  public AusleihenListe getAlleAusleihenVon(Medium medium) {
    return ladeAusAusleiheTabelle(
        "select * from ausleihe where mediumID = "+medium.getId());
  }

  public Datenbankzugriff ladeAusDatenbank(int id) throws DatenNichtGefundenException {
    return new MysqlAusleihe(id);
  }

  public AusleihzeitraumListe getGetaetigteAusleihzeitraeumeInZeitraum(Zeitraum zeitraum) {
    AusleihzeitraumListe liste = new AusleihzeitraumListe();
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      PreparedStatement statement = 
        (PreparedStatement) MysqlDatenbank.getMysqlInstance().getConnection().
          prepareStatement("select DISTINCT a.* " +
             "from ausleihzeitraum z left join ausleihe a on " +
             "z.ausleiheID = a.id " +
             "where z.taetigungsdatum >= ? AND z.taetigungsdatum < ?");
      statement.setDate(1, DatenmanipulationsFunktionen.utilDate2sqlDate(
              zeitraum.getBeginn()));
      statement.setDate(2, DatenmanipulationsFunktionen.utilDate2sqlDate(
              zeitraum.getEnde()));
      ResultSet result = (ResultSet) statement.executeQuery();
      while (result.next()) {
        Ausleihe neueAusleihe = new MysqlAusleihe(result);
        
        Iterator zeitraumIt = neueAusleihe.getAusleihzeitraeume().iterator();
        while (zeitraumIt.hasNext()) {
          Ausleihzeitraum ausleihzeitraum = (Ausleihzeitraum) zeitraumIt.next();
          if (!ausleihzeitraum.getTaetigungsdatum().before(zeitraum.getBeginn()) &&
              zeitraum.getEnde().after(ausleihzeitraum.getTaetigungsdatum())) {              
            liste.addNoDuplicate(ausleihzeitraum);
          }
        }
      }
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihzeitraumliste!", true);
    }

    return liste;
  }
  
  public int getAnzahlGetaetigteAusleihzeitraeumeInZeitraum(Zeitraum zeitraum) {
    int erg = 0;
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      PreparedStatement statement = 
        (PreparedStatement) MysqlDatenbank.getMysqlInstance().getConnection().
          prepareStatement("select count(DISTINCT a.id) " +
             "from ausleihzeitraum z left join ausleihe a on " +
             "z.ausleiheID = a.id " +
             "where z.taetigungsdatum >= ? AND z.taetigungsdatum <= ?");
      statement.setDate(1, DatenmanipulationsFunktionen.utilDate2sqlDate(
              zeitraum.getBeginn()));
      statement.setDate(2, DatenmanipulationsFunktionen.utilDate2sqlDate(
              zeitraum.getEnde()));
      ResultSet result = (ResultSet) statement.executeQuery();
      result.next();
      erg = result.getInt(1);
      
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihzeitraumliste!", true);
    }

    return erg;
  }  

  public AusleihenListe getAlleAktuellenAusleihenVon(Benutzer benutzer, Date datum) {
    return ladeAusAusleiheTabelle(
      "select * from ausleihe where benutzerID = "+benutzer.getId() +
      " AND (isNull(rueckgabeDatum) OR rueckgabeDatum >= '"+
      MysqlDatenbank.sqldateFormat.format(datum)+"');");
  }

  public AusleihenListe getAlleAusleihenVon(Benutzer benutzer) {
    return ladeAusAusleiheTabelle(
      "select * from ausleihe where benutzerID = "+benutzer.getId());
  }
  
  public AusleihenListe getAlleNichtZurueckgegebenenAusleihenVon(
    Benutzer benutzer, Date datum) {
    return ladeAusAusleiheTabelle(
      "select * from ausleihe where benutzerID = "+benutzer.getId() +
      " AND (isNull(rueckgabeDatum) OR rueckgabeDatum > '"+
      MysqlDatenbank.sqldateFormat.format(datum)+"');");
  }

  public int[] getErstesLetztesJahrEinerAusleihe() {
    int[] erg = new int[2];
    try {
      MysqlDatenbank.getMysqlInstance().beginTransaktion();
      Statement statement = MysqlDatenbank.getMysqlInstance().getStatement(); 
      
      ResultSet result = (ResultSet) statement.executeQuery("select min(year(taetigungsdatum)), max(year(taetigungsdatum)) from ausleihzeitraum");
      result.next();
      erg[0] = result.getInt(1);
      erg[1] = result.getInt(2);
      
      MysqlDatenbank.getMysqlInstance().releaseStatement(statement);
      MysqlDatenbank.getMysqlInstance().endTransaktion();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Laden der Ausleihzeitraumliste!", true);
    }

    return erg;
  }  
}