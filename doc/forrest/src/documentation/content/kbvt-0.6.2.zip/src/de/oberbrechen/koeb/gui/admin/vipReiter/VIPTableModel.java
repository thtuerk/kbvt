/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.vipReiter;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenbankzugriff.BenutzerFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManager;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManagerListenDaten;

/**
 * Diese Klasse ist eine Tabellenmodell f�r eine Tabelle 
 * von Benutzer f�r das Setzen des VIP-Attributes.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class VIPTableModel extends AbstractTableModel
  implements KeyListener, ListenKeySelectionManagerListenDaten {

  private BenutzerListe daten;
  private JTable tabelle;
  private ListenKeySelectionManager keySelectionManager;  
  
  public VIPTableModel(JTable tabelle) {
    this.tabelle = tabelle;
    keySelectionManager = new ListenKeySelectionManager(this);    
  }
  
  public void refresh() {
    BenutzerFactory benutzerFactory =
      Datenbank.getInstance().getBenutzerFactory();
    daten = benutzerFactory.getAlleBenutzer();
    daten.setSortierung(BenutzerListe.NachnameVornameSortierung);
    fireTableDataChanged();
  }
  
  public BenutzerListe getDaten() {
    return daten;
  } 
    
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 4;
  }

  public String getColumnName(int columnIndex) {
		if (columnIndex == 0) return "VIP";
		if (columnIndex == 1) return "Name";
    if (columnIndex == 2) return "Adresse";
    if (columnIndex == 3) return "Ort";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return Boolean.class;
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Benutzer gewaehlterBenutzer = getBenutzer(rowIndex);
    
		switch (columnIndex) { 
      case 0:
        return new Boolean(gewaehlterBenutzer.istVIP());
      case 1: 
        return gewaehlterBenutzer.getNameFormal();
      case 2:
        return gewaehlterBenutzer.getAdresse();
      case 3:
        return gewaehlterBenutzer.getOrt();
    }

    return "nicht definierte Spalte";
  }
  
  public int getDefaultColumnWidth(int column) {
    switch (column) { 
      case 0: return 30;
      case 1: return 250;
      case 2: return 250;
      case 3: return 250;
    }
    
    return 100;
  }
  
  public Benutzer getBenutzer(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Benutzer) daten.get(rowIndex);
  }
  
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex == 0);
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (columnIndex != 0) return;
    
    Benutzer gewaehlterBenutzer = getBenutzer(rowIndex);
    gewaehlterBenutzer.setVIP(((Boolean) aValue).booleanValue());
    gewaehlterBenutzer.save();      
  }

  
  public void keyPressed(KeyEvent e) {
    if (tabelle.getSelectedColumn() != 1) return;
    
    char aKey = e.getKeyChar();
    int zuSelektierendeZeile = keySelectionManager.selectionForKey(aKey);
    if (zuSelektierendeZeile == -1) return;
    
    tabelle.setRowSelectionInterval(zuSelektierendeZeile, zuSelektierendeZeile);
    tabelle.scrollRectToVisible(tabelle.getCellRect(zuSelektierendeZeile, 0, true));
  }
  
  public void keyReleased(KeyEvent arg0) {}
  public void keyTyped(KeyEvent arg0) {}

  public String getKeySelectionValue(int row) {
    return getValueAt(row, 1).toString();
  }

  public int size() {
    return getRowCount();
  }
}
