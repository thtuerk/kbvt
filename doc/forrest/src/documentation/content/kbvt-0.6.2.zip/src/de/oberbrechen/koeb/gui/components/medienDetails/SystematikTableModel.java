/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.medienDetails;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $
*/

public class SystematikTableModel extends AbstractTableModel {

  private SystematikListe daten;

  /**
   * Erstellt ein neues Modell ohne Daten, das nach dem Sollr�ckgabedatum
   * der Ausleihen sortiert ist
   */
  public SystematikTableModel() {
    daten = new SystematikListe();
    daten.setSortierung(SystematikListe.alphabetischeSortierung);
  }

  /**
   * Erstellt ein neues Modell mit den �bergebenen Daten in der dort angegebenen
   * Sortierung
   *
   * @param daten die enthaltenen Ausleihen
   */
  public SystematikTableModel(SystematikListe daten) {
    this.daten = daten;
  }

  /**
   * Setzt die �bergebenen Daten und die darin enthaltene Sortierung
   * @param daten die zu setzenden Daten
   */
  public void setDaten(SystematikListe daten) {
    this.daten = daten;
    fireTableDataChanged();
  }

  /**
   * Liefert die aktuellen Daten des Modells als SortedSet. Dieses
   * wird intern verwendet, weswegen das SortedSet nicht
   * ver�ndert werden sollte.
   * @return die aktuellen Daten
   */
  public SystematikListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 2;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Systematik";
    if (columnIndex == 1) return "Beschreibung";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    Systematik gewaehlteSystematik = (Systematik) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehlteSystematik.getName();
    if (columnIndex == 1) return gewaehlteSystematik.getBeschreibung();

    return "nicht definierte Spalte";
  }
}
