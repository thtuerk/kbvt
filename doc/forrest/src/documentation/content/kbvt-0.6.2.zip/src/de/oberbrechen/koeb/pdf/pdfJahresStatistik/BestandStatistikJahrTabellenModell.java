/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfJahresStatistik;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfigurationDaten;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.datenbankzugriff.MediumFactory;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.datenstrukturen.Zeitraum;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell f�r die Bestandstatistiken eines Jahres
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public class BestandStatistikJahrTabellenModell extends TabellenModell {
  
  Vector namen;
  Vector daten;
  Vector spalten;

  public BestandStatistikJahrTabellenModell(int jahr, 
      AuswahlKonfiguration konfiguration) {
    
    Zeitraum zeitraum = new Zeitraum(jahr);
    Calendar cal = Calendar.getInstance();
    cal.setTime(new Date());
    
    if (cal.getTime().before(zeitraum.getEnde()) && cal.getTime().after(zeitraum.getBeginn())) {
      cal.add(Calendar.DATE, 1);
      zeitraum.setEnde(cal.getTime());
    }
        
    MediumFactory mediumFactory = Datenbank.getInstance().getMediumFactory();
    
    MedienListe beginnMedien = mediumFactory.getAlleMedien(zeitraum.getBeginn());
    AuswahlKonfigurationDaten beginnDaten = konfiguration.bewerte(beginnMedien);
    beginnDaten.ueberpruefeChecks();
    
    MedienListe neuMedien = mediumFactory.getEingestellteMedienInZeitraum(zeitraum); 
    AuswahlKonfigurationDaten neuDaten = konfiguration.bewerte(neuMedien);
    neuDaten.ueberpruefeChecks();  
    
    MedienListe entferntMedien = mediumFactory.getEntfernteMedienInZeitraum(zeitraum); 
    AuswahlKonfigurationDaten entferntDaten = konfiguration.bewerte(entferntMedien);
    entferntDaten.ueberpruefeChecks();
    
    MedienListe endeMedien = mediumFactory.getAlleMedien(zeitraum.getEnde()); 
    AuswahlKonfigurationDaten endeDaten = konfiguration.bewerte(endeMedien);
    endeDaten.ueberpruefeChecks();
    
    namen = new Vector();
    daten = new Vector();
    
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    spalten = new Vector();
    spalten.add(dateFormat.format(zeitraum.getBeginn()));
    spalten.add("entfernt");
    spalten.add("Neueinstellungen");
    spalten.add(dateFormat.format(zeitraum.getEnde()));
    
    
    for (int i=0; i < konfiguration.getAusgabeAnzahl(); i++) {
      namen.add(konfiguration.getAusgabe(i).getTitel());
      int[] neueDaten = new int[4];
      neueDaten[0] = beginnDaten.getAusgabeTreffer(i).size();
      neueDaten[1] = entferntDaten.getAusgabeTreffer(i).size();
      neueDaten[2] = neuDaten.getAusgabeTreffer(i).size();
      neueDaten[3] = endeDaten.getAusgabeTreffer(i).size();
      
      if (neueDaten[0]-neueDaten[1]+neueDaten[2] != neueDaten[3]) {
        ErrorHandler.getInstance().handleError("Falsche Berechnung der Daten f�r "+
            konfiguration.getAusgabe(i).getTitel()+"!", false);
      }
        
      daten.add(neueDaten);
    }
       
    setSpaltenAusrichtung(2, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(3, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(4, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(5, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setBreiteProzent(1, 40f);    
    setBreiteProzent(2, 15f);    
    setBreiteProzent(3, 15f);    
    setBreiteProzent(4, 15f);        
    setBreiteProzent(5, 15f);        
  }

  public int getSpaltenAnzahl() {
    return 5;
  }

  public int getZeilenAnzahl() {
    return namen.size();
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "";
    if (spaltenNr > 1 && spaltenNr < 6) {
      return spalten.get(spaltenNr-2).toString();
    }
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (spaltenNr == 1) return namen.get(zeilenNr-1).toString();
    if (spaltenNr > 1 && spaltenNr < 6) {
      int wert = ((int[]) daten.get(zeilenNr-1))[spaltenNr-2];      
      return wert == 0?"-":Integer.toString(wert);
    }
    return "Fehler";
  }
}