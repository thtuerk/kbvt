/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnpassendeEinstellungException;

/**
 * Dieses Interface repr�sentiert eine Einstellung, die in der Datenbank
 * abgelegt ist.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public interface Einstellung extends Datenbankzugriff {  

  /**
   * Liefert den Namen der Einstellung
   * @return den Namen der Einstellung
   */
  public String getName();
  
  /**
   * Liefert den Client, den die Einstellung betrift. Falls die Einstellung alle
   * Clients betrifft, wird <code>null</code> geliefert.
   * @return den Client, den die Einstellung betrift
   */
  public Client getClient();

  /**
   * Liefert den Mitarbeiter, den die Einstellung betrift. 
   * Falls die Einstellung alle Mitarbeiter betrifft, wird 
   * <code>null</code> geliefert.
   * @return den Mitarbeiter, den die Einstellung betrift
   */
  public Mitarbeiter getMitarbeiter();

  /**
   * Liefert den Wert der Einstellung als String
   * @return den Wert der Einstellung als String
   */
  public String getWert();
   
  /**
   * Liefert den Wert der Einstellung als String.
   * Ist der Wert null, so wird der Standardwert geliefert und 
   * direkt in der Einstellung gespeichert.
   * @param standard der Standardwert
   * @return den Wert der Einstellung als String
   */
  public String getWert(String standard);

  /**
   * Liefert den Wert der Einstellung als Integer
   * @return den Wert der Einstellung als Integer
   */
  public int getWertInt() throws UnpassendeEinstellungException;

  /**
   * Liefert den Wert der Einstellung als Integer. 
   * Kann der Wert nicht als Integer
   * interpretiert werden, wird der Standardwert geliefert und direkt in der
   * Einstellung gespeichert.
   * @param standard der Standardwert
   * @return den Wert der Einstellung als Integer
   */
  public int getWertInt(int standard);

  /**
   * Liefert den Wert der Einstellung als Double
   * @return den Wert der Einstellung als Double
   */
  public double getWertDouble() throws UnpassendeEinstellungException;

  /**
   * Liefert den Wert der Einstellung als Integer. 
   * Kann der Wert nicht als Double
   * interpretiert werden, wird der Standardwert geliefert und direkt in der
   * Einstellung gespeichert.
   * @param standard der Standardwert
   * @return den Wert der Einstellung als Integer
   */
  public double getWertDouble(double standard);

  /**
   * Liefert den Wert der Einstellung als Boolean
   * @return den Wert der Einstellung als Boolean
   */
  public boolean getWertBoolean() throws UnpassendeEinstellungException;

  /**
   * Liefert den Wert der Einstellung als Boolean
   * Kann der Wert nicht als Boolean
   * interpretiert werden, wird der Standardwert geliefert und direkt in der
   * Einstellung gespeichert.
   * @param standard der Standardwert
   * @return den Wert der Einstellung als Boolean
   */
  public boolean getWertBoolean(boolean standard);

  /**
   * Der Wert der Einstellung wird als Klassenname interpretiert und 
   * versucht mit einem parameterlosen Konstruktor 
   * eine Instanz zu erzeugen. Diese wird zur�ckgeliefert. Dies ist insbesondere
   * daf�r gedacht, Factories zu erzeugen, mit denen dann viele der eingentlich
   * ben�tigten Objecte bebaut werden k�nnen.
   * Kann kein Objekt des �bergebenen Typs erzeugt werden, wird versucht ein
   * Objekt des Standardtyps zu erzeugen. Scheitert auch dies, wird eine
   * UnpassendeEinstellungException geworfen
   * @param standard der Standardtyp
   * @param typ der Typ, d.h. die Klasse oder das Interface des Objektes, das 
   *  zur�ckgeliefert werden soll     
   */
  public Object getWertObject(Class typ, Class standard);

  /**
   * Setzt den Wert der Einstellung
   * @param wert der neue Wert der Einstellung
   */
  public void setWert(String wert);

  /**
   * Setzt den Wert der Einstellung
   * @param wert der neue Wert der Einstellung
   */
  public void setWertInt(int wert);

  /**
   * Setzt den Wert der Einstellung
   * @param wert der neue Wert der Einstellung
   */
  public void setWertDouble(double wert);

  /**
   * Setzt den Wert der Einstellung
   * @param wert der neue Wert der Einstellung
   */
  public void setWertBoolean(boolean wert);
}
