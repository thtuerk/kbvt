/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.benutzerAusgabeWrapper;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import de.oberbrechen.koeb.ausgaben.BenutzerAusgabe;
import de.oberbrechen.koeb.ausgaben.KonfigurierbareAusgabe;
import de.oberbrechen.koeb.dateien.auswahlKonfiguration.AuswahlKonfiguration;
import de.oberbrechen.koeb.datenbankzugriff.BenutzerFactory;
import de.oberbrechen.koeb.datenbankzugriff.Datenbank;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.benutzerListenAuswahlPanel.BenutzerListenAuswahlPanel;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

class AuswahlDialog extends JDialog {
    
  BenutzerListenAuswahlPanel auswahlPanel;
  BenutzerAusgabe benutzerAusgabe;
  JFrame hauptFenster;
  
  public AuswahlDialog(JFrame hauptFenster, BenutzerAusgabe benutzerAusgabe) {
    this(hauptFenster, benutzerAusgabe, null);
  }
  
  public AuswahlDialog(JFrame hauptFenster, BenutzerAusgabe benutzerAusgabe,
    AuswahlKonfiguration konfiguration) {
    super(hauptFenster, "Benutzerauswahl", false);      
    this.hauptFenster = hauptFenster;
    this.benutzerAusgabe = benutzerAusgabe;
    try {
      jbInit();
      initAuswahlFeld(konfiguration);
      
      BenutzerFactory benutzerFactory = 
        Datenbank.getInstance().getBenutzerFactory();
      auswahlPanel.setDaten(benutzerFactory.getAlleBenutzer());                  
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  
  void jbInit() throws Exception {
    auswahlPanel =  new BenutzerListenAuswahlPanel(false, true);
    
    JButton okButton = new JButton("OK");
    JButton cancelButton = new JButton("Abbrechen");
    JButton konfigButton = new JButton("Konfigurieren");
    JComponentFormatierer.setDimension(okButton, cancelButton.getPreferredSize());
    
    okButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent arg0) {
        dispose();
        try { 
          benutzerAusgabe.setDaten(auswahlPanel.getAuswahl());          
          benutzerAusgabe.run(hauptFenster);
        } catch (Exception e) {
          ErrorHandler.getInstance().handleException(e, "Fehler beim Ausf�hren der Medienausgabe!", false);
        }
      }        
    });
    
    cancelButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent arg0) {
        dispose();
      }        
    });

    if (benutzerAusgabe instanceof KonfigurierbareAusgabe) {      
      konfigButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent arg0) {
          ((KonfigurierbareAusgabe) benutzerAusgabe).konfiguriere(hauptFenster);
        }        
      });
    } else {
      konfigButton.setVisible(false);
    }
    
    JPanel pane = new JPanel();
    pane.setLayout(new GridBagLayout());
    pane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    
    pane.add(new JLabel("Bitte w�hlen Sie die auszugebenden Benutzer aus:"), new GridBagConstraints(0, 0, 3, 1, 0.0, 0.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 5, 0), 0, 0));      
    pane.add(auswahlPanel, new GridBagConstraints(0, 1, 3, 1, 1.0, 1.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 20, 0), 0, 0));      
    
    pane.add(okButton, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 10), 0, 0));      
    pane.add(cancelButton, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
        ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));      
    pane.add(konfigButton, new GridBagConstraints(2, 2, 1, 1, 1.0, 0.0
        ,GridBagConstraints.NORTHEAST, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));
    
    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(pane, BorderLayout.CENTER);
    this.pack();
  }
  
  private void initAuswahlFeld(AuswahlKonfiguration konfiguration) {
    AuswahlKonfiguration konfig = konfiguration;
    if (konfig == null) {
      String configFile = 
        Datenbank.getInstance().getEinstellungFactory().getEinstellung(
            this.getClass().getName(), "BenutzerlistenConfigfile").
            getWert("einstellungen/Ausgaben-Benutzerlisten.conf");              
      try {      
        konfig = new AuswahlKonfiguration(configFile);              
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, 
            "Fehler beim Parsen der Datei '"+configFile+"'!", false);
      }    
    }    
    auswahlPanel.initAuswahlFeld(konfig);    
  }
}

  