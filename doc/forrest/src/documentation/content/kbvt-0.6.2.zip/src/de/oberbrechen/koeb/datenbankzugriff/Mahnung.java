/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;

/**
 * Diese Klasse repr�sentiert eine Mahnung, d.h. eine Liste von Ausleihen eines
 * Benutzers zu einem bestimmten Zeitpunkt. Es handelt sich damit um kein
 * eigentliches Datenbankzugriff-Objekt sondern um eine Zusammenfassung
 * mehrerer solcher.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.11 $
 */

public interface Mahnung {
  
  /**
   * Liefert der Anzahl der Ausleihen, die in dieser Mahnung enthalten sind
   * @return die Anzahl der Ausleihen, die in dieser Mahnung enthalten sind
   */
  public int getAnzahlAusleihen();

  /**
   * Liefert eine aller Liste der Ausleihen, die in dieser Mahnung enthalten sind
   * @return eine aller Liste der Ausleihen, die in dieser Mahnung enthalten sind
   */
  public AusleihenListe getAusleihenListe();

  /**
   * Liefert eine Liste der �berzogenen Ausleihen, die in dieser Mahnung enthalten sind
   * @return eine Liste der �berzogenen Ausleihen, die in dieser Mahnung enthalten sind
   */
  public AusleihenListe getGemahnteAusleihenListe();

  /**
   * Liefert der Anzahl der Ausleihen, die gemahnt werden
   * @return die Anzahl der Ausleihen, die gemahnt werden
   */
  public int getAnzahlGemahnteAusleihen();

  /**
   * Liefert den Benutzer, dessen Ausleihen angemahnt werden
   * @return den Benutzer, dessen Ausleihen angemahnt werden
   */
  public Benutzer getBenutzer();
  
  /**
   * Liefert die Mahngeb�hren f�r die �berzogenen Ausleihen, zu dem Zeitpunkt,
   * an dem die Mahnung erstellt wurde. Dieser Zeitpunkt kann mittels
   * getZeitpunkt() abgefragt werden.
   * f�r den Zeitpunkt nicht
   *
   * @return die Mahngeb�hren
   */
  public double getMahngebuehren();

  /**
   * Liefert die l�ngste �berziehung eines Mediums in Tagen
   * @return die l�ngste �berziehung eines Mediums in Tagen
   */
  public int getMaxUeberzogeneTage();
}