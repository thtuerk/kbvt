/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;


/**
 * Diese Klasse repr�sentiert einen ISBN-Code.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public class ISBN {

  private String isbn; 

  public ISBN(String isbn) {
    ISBN.checkISBNSyntax(isbn);
    char pruefziffer = ISBN.berechnePruefziffer(isbn);

    int laenge = isbn.length();
    if (laenge == 9) {
      this.isbn = isbn + pruefziffer;
    } else {
      this.isbn = isbn; 
    }
    if (laenge == 10 && pruefziffer != isbn.charAt(9))
      throw new IllegalArgumentException("Die �bergebene ISBN-Nr ist ung�ltig."+
      " Die �berpr�fung der Pr�fziffer schlug fehl!");
  }
  
  /**
   * Checkt, ob der �bergebene String eine g�ltige ISBN sein kann. Es wird
   * nur der Syntax getestet, nicht die Pr�fziffer.
   *
   * @throws IllegalArgumentException falls der �bergebene String nicht aus
   *  9 oder 10 Ziffern besteht
   */
  private static void checkISBNSyntax(String isdn) {
    int laenge = isdn.length();
    if (laenge != 9 && laenge != 10) throw new
      IllegalArgumentException("Die ISBN-Nr muss 9 oder 10 Ziffern lang sein!"+
      " Sie ist aber "+laenge+" Ziffern lang!");

    for (int i = 0; i < laenge; i++) {
      if (Character.getType(isdn.charAt(i)) != Character.DECIMAL_DIGIT_NUMBER && 
          (i != 9 || isdn.charAt(i) != 'X'))
        throw new IllegalArgumentException("Die ISBN darf nur Ziffern "+
        "enthalten! An Position "+(i+1)+" des Argumentes '"+isdn+
        "' steht aber '"+isdn.charAt(i)+"'.");
    }    
  }
  
  /**
   * Checkt, ob der �bergebene String eine g�ltige ISBN ist. Ist dies
   * nicht der Fall wird <code>null</code> zur�ckgeliefert. Ansonsten wird die
   * g�ltige ISBN zur�ckgeliefert. Wird eine ISBN mit Pr�fziffer �bergeben,
   * so wird die Pr�fziffer �berpr�ft, ansonsten wird die Pr�fziffer
   * erg�nzt.
   * @param isbn die zu checkende ISBN-Nr.
   * @return <code>null</code> oder die g�ltige ISBN-Nr evtl. erweitert um die
   *   Pr�fziffer
   */
  public static String checkISBN(String isbn) {
    try {
      checkISBNSyntax(isbn);
    } catch (IllegalArgumentException e) {
      return null;
    }

    char pruefziffer = ISBN.berechnePruefziffer(isbn);

    int laenge = isbn.length();
    if (laenge == 9) return isbn + pruefziffer;
    if (laenge == 10 && pruefziffer != isbn.charAt(9)) {
      return null;
    }
    
    return isbn;
  }

  /**
   * Berechnet die Pr�fziffer der ISBN
   * @param isbn die Nummer, die gecheckt werden soll
   * @return die Pr�fziffer
   * @throws IllegalArgumentException, falls der �bergebene String nicht dem
   *  Syntax einer ISBN-Nr entspricht
   */
  private static char berechnePruefziffer(String isbn) {
    ISBN.checkISBNSyntax(isbn);
    int pruefsumme = 0;
    pruefsumme += 1 * Character.getNumericValue(isbn.charAt(0));
    pruefsumme += 2 * Character.getNumericValue(isbn.charAt(1));
    pruefsumme += 3 * Character.getNumericValue(isbn.charAt(2));
    pruefsumme += 4 * Character.getNumericValue(isbn.charAt(3));
    pruefsumme += 5 * Character.getNumericValue(isbn.charAt(4));
    pruefsumme += 6 * Character.getNumericValue(isbn.charAt(5));
    pruefsumme += 7 * Character.getNumericValue(isbn.charAt(6));
    pruefsumme += 8 * Character.getNumericValue(isbn.charAt(7));
    pruefsumme += 9 * Character.getNumericValue(isbn.charAt(8));

    int pruefziffer = pruefsumme % 11;    
    if (pruefziffer == 10) return 'X';
    return Integer.toString(pruefziffer).charAt(0);
  }


  /**
   * Liefert den ISBN-Code als String
   * @return den ISBN-Code als String
   */
  public String getISBN() {
    return isbn;
  }
  
  /**
   * Liefert den ISBN-Code ohne Pr�fziffer als String
   * @return den ISBN-Code ohne Pr�fziffer als String
   */
  public String getISBNOhnePruefziffer() {
    return isbn.substring(0,9);
  }
  
  public String toString() {
    return isbn;
  }
  
  /**
   * Liefert die zur ISBN passende EAN.
   * @return die passende EAN
   */
  public EAN convertToEAN() {
    return new EAN("978"+getISBNOhnePruefziffer());
  }
}