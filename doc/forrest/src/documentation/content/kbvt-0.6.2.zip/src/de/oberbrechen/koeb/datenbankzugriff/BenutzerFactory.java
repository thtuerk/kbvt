/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;


/**
 * Dieses Interface repr�sentiert eine Factory f�r Benutzer.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public interface BenutzerFactory extends DatenbankzugriffFactory {

  /**
   * Erstellt ein neues, noch nicht in der Datenbank
   * vorhandenes Benutzer-Objekt
   * 
   * @return das neue Benutzer-Objekt
   */
  public Benutzer erstelleNeu(); 

  /**
   * Liefert den Standardwohnwort f�r Benutzer. Dieser wird automatisch
   * gesetzt, wenn ein neuer Benutzer erstellt wird.
   * @return den Standardwohnwort f�r Benutzer
   */
  public String getStandardBenutzerwohnort();

  /**
   * Liefert eine unsortierte Liste aller Benutzer, die in der Datenbank
   * eingetragen sind.
   *
   * @see BenutzerListe
   */
  public BenutzerListe getAlleBenutzer();
  
  /**
   * Liefert eine alphabetisch sortierte Liste aller Orte, in denen Benutzer
   * wohnen. In der Liste sind die Orte als String-Objekte abgelegt.
   *
   * @return eine alphabetisch sortierte Liste aller Orte, in denen Benutzer
   * wohnen
   */
  public Liste getAlleOrte();

  /**
   * Bestimmt die Benutzernr, die zu dem �bergebenen Benutzernamen geh�rt.
   * @param benutzername der Benutzername
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit diesem Mitarbeiter-Benutzernamen existiert
   *
   * @return die zugeh�rige Benutzernr
   */
  public int sucheBenutzername(String benutzername) 
    throws DatenNichtGefundenException;
}