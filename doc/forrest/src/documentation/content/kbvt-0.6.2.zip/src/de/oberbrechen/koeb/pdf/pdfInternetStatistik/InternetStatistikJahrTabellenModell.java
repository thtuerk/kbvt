/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfInternetStatistik;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.Internetfreigabe;
import de.oberbrechen.koeb.datenbankzugriff.InternetfreigabeFactory;
import de.oberbrechen.koeb.datenstrukturen.InternetfreigabenListe;
import de.oberbrechen.koeb.einstellungen.Buecherei;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;

/**
 * Diese Klasse ist ein Modell f�r die Internetstatistiken eines Monats
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class InternetStatistikJahrTabellenModell extends TabellenModell {
  
  Vector namen;
  Vector kosten;
  Vector dauer;
  Vector anzahl;

  public InternetStatistikJahrTabellenModell(int jahr) {
    DecimalFormat zahlenFormat = new DecimalFormat("00");
    DecimalFormat waehrungsFormat = new DecimalFormat("0.00 EUR");
    SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM yyyy");

    namen = new Vector();
    kosten = new Vector();
    dauer = new Vector();
    anzahl = new Vector();
    
    int gesamtAnzahl = 0;
    double gesamtKosten = 0;
    int gesamtDauer = 0;
    
    for (int i=1; i < 13; i++) {    
      InternetfreigabeFactory internetfreigabeFactory =
        Datenbank.getInstance().getInternetfreigabeFactory();
      InternetfreigabenListe daten = 
        internetfreigabeFactory.getAlleInternetFreigabenInMonat(i, jahr);
      if (daten.size() > 0) {
        //Summen bestimmen
        double kostenSumme = 0;
        int dauerSumme = 0;
        Iterator it = daten.iterator();
        while (it.hasNext()) {
          Internetfreigabe aktuelleFreigabe = (Internetfreigabe) it.next();
          kostenSumme += Buecherei.getInstance().berechneInternetzugangsKosten(
            aktuelleFreigabe.getDauer());
          dauerSumme += aktuelleFreigabe.getDauer();
        }
        
        //Gesamtsummen
        gesamtAnzahl += daten.size();
        gesamtDauer += dauerSumme;
        gesamtKosten += kostenSumme;
        
        //Werte in Vectoren einf�gen
        Calendar monatKalender = Calendar.getInstance();
        monatKalender.set(jahr, i-1, 1);
        namen.add(monatDateFormat.format(monatKalender.getTime()));
        anzahl.add(Integer.toString(daten.size()));
        kosten.add(waehrungsFormat.format(kostenSumme));
        
        int restDauerInSekunden = dauerSumme;

        int anzahlStunden = restDauerInSekunden / 3600;
        restDauerInSekunden = restDauerInSekunden % 3600;
        int anzahlMinuten = restDauerInSekunden / 60;
        restDauerInSekunden = restDauerInSekunden % 60;

        dauer.add(zahlenFormat.format(anzahlStunden)+":"+
               zahlenFormat.format(anzahlMinuten)+":"+
               zahlenFormat.format(restDauerInSekunden));
      }
    }

    namen.add("Summe");
    anzahl.add(Integer.toString(gesamtAnzahl));
    kosten.add(waehrungsFormat.format(gesamtKosten));
    
    int restDauerInSekunden = gesamtDauer;

    int anzahlStunden = restDauerInSekunden / 3600;
    restDauerInSekunden = restDauerInSekunden % 3600;
    int anzahlMinuten = restDauerInSekunden / 60;
    restDauerInSekunden = restDauerInSekunden % 60;

    dauer.add(zahlenFormat.format(anzahlStunden)+":"+
           zahlenFormat.format(anzahlMinuten)+":"+
           zahlenFormat.format(restDauerInSekunden));    


    setSpaltenAusrichtung(2, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(3, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setSpaltenAusrichtung(4, TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS);
    setBreiteProzent(1, 25);    
    setBreiteProzent(2, 35);    
    setBreiteProzent(3, 27.5f);    
    setBreiteProzent(4, 12.5f);        
  }

  public int getSpaltenAnzahl() {
    return 4;
  }

  public int getZeilenAnzahl() {
    return namen.size();
  }

  public String getSpaltenName(int spaltenNr) {
    if (spaltenNr == 1) return "";
    if (spaltenNr == 2) return "Anzahl";
    if (spaltenNr == 3) return "Dauer";
    if (spaltenNr == 4) return "Kosten";
    return "unbekannte Spalte";
  }

  public String getEintrag(int spaltenNr, int zeilenNr) {
    if (spaltenNr == 1) return namen.get(zeilenNr-1).toString();
    if (spaltenNr == 2) return anzahl.get(zeilenNr-1).toString();
    if (spaltenNr == 3) return dauer.get(zeilenNr-1).toString();
    if (spaltenNr == 4) return kosten.get(zeilenNr-1).toString();
    return "Fehler";
  }

  public boolean getZeigeZeilenHintergrund(int modellZeile, int seitenZeile) {
    if (modellZeile == getZeilenAnzahl()) return false;
    return super.getZeigeZeilenHintergrund(modellZeile, seitenZeile);
  }

  public float getZellenRandOben(int modellZeile,int seitenZeile,int spalte) {
    if (modellZeile == 1 || modellZeile == getZeilenAnzahl()) return 1;
    return 0;   
  }    
}