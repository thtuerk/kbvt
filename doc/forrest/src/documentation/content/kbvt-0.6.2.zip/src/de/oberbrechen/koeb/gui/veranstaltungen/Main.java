/*  Copyright 2002 - 2004 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.EAN;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsgruppenListe;
import de.oberbrechen.koeb.gui.AbstractMain;
import de.oberbrechen.koeb.gui.barcodescanner.*;
import de.oberbrechen.koeb.gui.components.*;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;
import de.oberbrechen.koeb.gui.veranstaltungen.benutzerReiter.*;
import de.oberbrechen.koeb.gui.veranstaltungen.listenReiter.*;
import de.oberbrechen.koeb.gui.veranstaltungen.teilnahmenReiter.TeilnahmenBenutzerReiter;
import de.oberbrechen.koeb.gui.veranstaltungen.teilnahmenReiter.TeilnahmenReiter;
import de.oberbrechen.koeb.gui.veranstaltungen.veranstaltungenReiter.VeranstaltungenReiter;
import de.oberbrechen.koeb.gui.veranstaltungen.veranstaltungsgruppenReiter.VeranstaltungsgruppenReiter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die f�r
 * die das Eintragen der Veranstaltungsteilnahmen in die Datenbank gedacht ist.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.25 $
 */
public class Main extends AbstractMain implements BarcodeGelesenEventHandler {

  private SortiertComboBox benutzerFeld;
  private SortiertComboBox veranstaltungsgruppeFeld;
  private EANZuordnung eanZuordnung;

  public Main(boolean isMain, Mitarbeiter mitarbeiter) {
    super(isMain, "Veranstaltungen", 
      Mitarbeiter.BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE,
      "de/oberbrechen/koeb/gui/icon-veranstaltungen.png", mitarbeiter);
    eanZuordnung = Datenbank.getInstance().getEANZuordnung();
    this.addKeyListener(new BarcodeReaderKeyAdapter("\5", "\12", this));          
  }

  /**
   * Entfernt einen Benutzer aus der Liste
   * @param benutzer der zu entfernende Benutzer
   */
  public void removeBenutzer(Benutzer benutzer) {
    benutzerFeld.removeItem(benutzer);
    benutzerFeld.setSelectedIndex(0);
  }

  public void erlaubeAenderungen(boolean erlaubt) {
    super.erlaubeAenderungen(erlaubt);
    benutzerFeld.setEnabled(erlaubt);
    veranstaltungsgruppeFeld.setEnabled(erlaubt);
  }

  /**
   * Aktiviert den �bergebenen Benutzer, ist der Benutzer nicht in der
   * bisherigen Benutzerliste, so wird er erg�nzt, falls er gespeichert ist.
   * @param benutzer der zu aktivierende Benutzer
   */
  public void setAktiverBenutzer(Benutzer benutzer) {
    benutzerFeld.setSelectedItem(benutzer);
    benutzerFeld.fireDelayItemListenerEvent();
  }

  public static void main(String[] args) {
    init();
    new Main(true, null);
  }

  protected JPanel getAllgemeinPanel() throws Exception {
    JPanel allgemeinPanel = new JPanel();
    allgemeinPanel.setLayout(new GridBagLayout());

    JLabel benutzerLabel = new JLabel("Benutzer:");
    JLabel veranstaltungsgruppeLabel = new JLabel("Veranstaltunsgruppe:");

    benutzerFeld = new SortiertComboBox(new Format() {
      public String format(Object obj) {
        if (obj == null) return null;
        Benutzer ben = ((Benutzer) obj);
        return ben.getNameFormal();
      }
    });
    benutzerFeld.setToolTipText("Der aktuelle Benutzer!");

    veranstaltungsgruppeFeld = new SortiertComboBox(new Format() {
      public String format (Object obj) {
        if (obj == null) return null;
        Veranstaltungsgruppe gruppe = ((Veranstaltungsgruppe) obj);
        return gruppe.getName();
      }
    });
    veranstaltungsgruppeFeld.addDelayItemListener(
      new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        aktualisiereVeranstaltungsgruppe();
      }
    });
    veranstaltungsgruppeFeld.setToolTipText(
      "Die aktuelle Veranstaltungsgruppe!");

    int eingabeHoehe = new JTextField().getPreferredSize().height;
    Dimension eingabeDimension = new Dimension(100, eingabeHoehe);
    JComponentFormatierer.setDimension(benutzerFeld, eingabeDimension);
    JComponentFormatierer.setDimension(
      veranstaltungsgruppeFeld, eingabeDimension);
    benutzerFeld.addDelayItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        aktualisiereBenutzer();
      }
    });

    allgemeinPanel.add(benutzerLabel,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 2, 0, 10), 0, 0));
    allgemeinPanel.add(benutzerFeld,    new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    allgemeinPanel.add(veranstaltungsgruppeLabel,   new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 20, 0, 10), 0, 0));
    allgemeinPanel.add(veranstaltungsgruppeFeld,   new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));

    return allgemeinPanel;
  }

  /**
   * Wird aufgerufen, wenn ein neuer Benutzer ausgew�hlt wurde
   */
  public void aktualisiereBenutzer() {
    ((VeranstaltungenMainReiter) reiter.getSelectedComponent()).
      setBenutzer(this.getAktuellerBenutzer());
  }

  /**
   * Wird aufgerufen, wenn eine neue Veranstaltungsgruppe ausgew�hlt wurde
   */
  public void aktualisiereVeranstaltungsgruppe() {
    ((VeranstaltungenMainReiter) reiter.getSelectedComponent()).
      setVeranstaltungsgruppe(this.getAktuelleVeranstaltungsgruppe());
  }

  //Doku siehe bitte Interface
  public void barcodeGelesen(String barcode) {
    EAN neuerBarcode = new EAN(barcode);
    Object referenz = eanZuordnung.getReferenz(neuerBarcode);
    
    if (referenz == null) return;

    if (referenz instanceof Benutzer) {
      if (!erlaubeAenderungen) return;
      this.setAktiverBenutzer((Benutzer) referenz);
      return;
    }
  }

  //Doku siehe bitte Interface
  public void barcodeStartGelesen() {
    benutzerFeld.grabFocus();
  }

  /**
   * Liefert die aktuelle Veranstaltungsgruppe
   * @return die aktuelle Veranstaltungsgruppe
   */
  public Veranstaltungsgruppe getAktuelleVeranstaltungsgruppe() {
    return (Veranstaltungsgruppe) veranstaltungsgruppeFeld.getSelectedItem();
  }

  /**
   * Liefert den aktuellen Benutzer
   * @return den aktuellen Benutzer
   */
  public Benutzer getAktuellerBenutzer() {
    return (Benutzer) benutzerFeld.getSelectedItem();
  }


  protected void initDaten() {
    BenutzerFactory benutzerFactory = 
      Datenbank.getInstance().getBenutzerFactory();
    BenutzerListe alleBenutzerListe = benutzerFactory.getAlleBenutzer();
    alleBenutzerListe.setSortierung(BenutzerListe.NachnameVornameSortierung);    
    benutzerFeld.setDaten(alleBenutzerListe);

    VeranstaltungsgruppeFactory veranstaltungsgruppeFactory =
      Datenbank.getInstance().getVeranstaltungsgruppeFactory();
    VeranstaltungsgruppenListe liste =
    	veranstaltungsgruppeFactory.getAlleVeranstaltungsgruppen();
    liste.setSortierung(
        VeranstaltungsgruppenListe.alphabetischeSortierung, true);
    veranstaltungsgruppeFeld.setDaten(liste);

    aktualisiereBenutzer();
    aktualisiereVeranstaltungsgruppe();
  }

  protected void reiterHinzufuegen() {
    Datenbank datenbank = Datenbank.getInstance();
    Client currentClient = datenbank.
      getClientFactory().getBenutzenClient();
    
    if (datenbank.getEinstellungFactory().getEinstellung(
      currentClient, null, 
      this.getClass().getName(), "zeigeBenutzerReiterEinzeln").getWertBoolean(
            true)) {
      reiter.add(new BenutzerReiter(this), "Benutzer");
      reiter.add(new TeilnahmenReiter(this), "Teilnahmen");
    } else {
      reiter.add(new TeilnahmenBenutzerReiter(this), "Teilnahmen/Benutzer");
    }
     
    reiter.add(new ListenReiter(this), "Listen");
    reiter.add(new VeranstaltungsgruppenReiter(this), "Veranstaltungsgruppen");
    reiter.add(new VeranstaltungenReiter(this), "Veranstaltungen");
  }

  /**
   * Entfernt die �bergebene Veranstaltungsgruppe aus der Liste
   * @param veranstaltungsgruppe die zu entfernende Veranstaltungsgruppe
   */
  public void removeVeranstaltungsgruppe(Veranstaltungsgruppe veranstaltungsgruppe) {
    veranstaltungsgruppeFeld.removeItem(veranstaltungsgruppe);
    if (veranstaltungsgruppeFeld.getItemCount() > 0)
      veranstaltungsgruppeFeld.setSelectedIndex(0);
  }

  /**
   * Aktiviert die �bergebene Veranstaltungsgruppe. Ist die Gruppe nicht in der
   * bisherigen Veranstaltungsgruppenliste, so wird sie erg�nzt, falls sie 
   * gespeichert ist.
   * @param veranstaltungsgruppe die zu aktivierende Gruppe
   */
  public void setAktiveVeranstaltungsgruppe(Veranstaltungsgruppe veranstaltungsgruppe) {
    veranstaltungsgruppeFeld.setSelectedItem(veranstaltungsgruppe);
    veranstaltungsgruppeFeld.fireDelayItemListenerEvent();
  }
}