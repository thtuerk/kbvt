/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.framework;

/**
 * Dieses Interface kapselt Methoden, die es erm�glichen sollen, auf
 * Fehler zu reagieren. Auf eine konkrete Instanz kann mittels 
 * getInstanz() bzw. setInstanz() zugegriffen werden. 
 * Bei Fehlern wird die Fehlerbehandlung dann mittels der hier definierten
 * Methoden dieses ErrorHandlers durchgef�hrt.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */

public abstract class ErrorHandler {

  private static ErrorHandler instance = new StandardErrorHandler();
  
  /**
   * Liefert die eingestellte Instanz des ErrorHandlers
   * @return ErrorHandler
   */
  public static ErrorHandler getInstance() {
    return instance;
  }
  
  /**
   * Setzt die Instanz des ErrorHandlers die verwendet werden soll.
   * @param errorHandler der zu verwendende ErrorHandler
   */
  public static void setInstance(ErrorHandler errorHandler) {
    if (errorHandler == null) throw new NullPointerException();
    instance = errorHandler;
  }

  /**
   * Behandelt eine aufgetretene Exception.
   * @param beschreibung eine Beschreibung des Fehlers
   * @param e die zu behandelnde Exception
   * @param istKritisch ist der Fehler so kritisch, dass das System
   *   beendet werden muss
   */
  public void handleException(Exception e, String beschreibung, boolean istKritisch) {
    StringBuffer message = new StringBuffer();
    if (beschreibung != null) message.append(beschreibung);
    message.append("\n\n");
    message.append(e.getLocalizedMessage());
    
    handleError(message.toString(), istKritisch);
  }

  /**
   * Behandelt einen aufgetretenen Fehler.
   * @param beschreibung eine Beschreibung des Fehlers
   * @param istKritisch ist der Fehler so kritisch, dass das System
   *   beendet werden muss
   */
  public abstract void handleError(String beschreibung, boolean istKritisch);
}