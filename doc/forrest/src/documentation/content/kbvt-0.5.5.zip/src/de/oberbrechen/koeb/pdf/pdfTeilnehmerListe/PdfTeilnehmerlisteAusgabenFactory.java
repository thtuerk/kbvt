/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import java.util.Iterator;

import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.ausgaben.TeilnehmerlisteAusgabenFactory;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltung;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltungsgruppe;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.ausgaben.*;

/**
* Diese Klasse stellt eine Factory da, die
* eine Ausgabe erstellt, die eine Pdf-Teilnehmerliste 
* ausgibt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class PdfTeilnehmerlisteAusgabenFactory implements AusgabenFactory, TeilnehmerlisteAusgabenFactory {

  class GesamtlisteAusgabe implements Ausgabe {
    private Veranstaltungsgruppe gruppe;

    public GesamtlisteAusgabe(Veranstaltungsgruppe gruppe) {
      this.gruppe = gruppe;
    }

    public String getName() {
      return "Gesamtliste - "+gruppe.toString();
    }

    public String getBeschreibung() {
      return "Erstellt eine PDF-Teilnehmerliste der Veranstaltungsgruppe '"+
          gruppe.toString()+"'!";
    }

    public void run(javax.swing.JFrame hauptFenster) throws Exception {
      PdfTeilnehmerListeVeranstaltungsgruppe
      pdfTeilnehmerListeVeranstaltungsgruppe = new
          PdfTeilnehmerListeVeranstaltungsgruppe();
      pdfTeilnehmerListeVeranstaltungsgruppe.setVeranstaltungsgruppe(gruppe);
      pdfTeilnehmerListeVeranstaltungsgruppe.zeige(false);
    }
  }

  class VeranstaltungslisteAusgabe implements Ausgabe {
    private Veranstaltung veranstaltung;
    private int sortierung;

    public VeranstaltungslisteAusgabe(Veranstaltung veranstaltung,
                              int sortierung) {
      this.veranstaltung = veranstaltung;
      this.sortierung = sortierung;
    }

    public String getName() {
      return "Teilnehmerliste - "+veranstaltung.getTitel();
    }

    public String getBeschreibung() {
      String sortString = null;
      switch (sortierung) {
        case VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung:
          sortString = "dem Namen der Teilnehmer";
          break;
        case VeranstaltungsteilnahmeListe.AnmeldeNrSortierung:
          sortString = "der Anmeldenummer";
          break;
        case VeranstaltungsteilnahmeListe.BemerkungenSortierung:
          sortString = "den Bemerkungen";
          break;
        case VeranstaltungsteilnahmeListe.BenutzerKlasseSortierung:
          sortString = "der Klasse der Teilnehmer";
          break;
      }
      return "Erstellt eine nach "+sortString+" sortierte "+
          "PDF-Teilnehmerliste der Veranstaltung '"+
          veranstaltung.getTitel()+"' der Veranstaltunsgruppe '"+
          veranstaltung.getVeranstaltungsgruppe().getName()+"'!";
    }

    public void run(javax.swing.JFrame hauptFenster) throws Exception {
      PdfTeilnehmerListeVeranstaltung
      pdfTeilnehmerListeVeranstaltung = new
          PdfTeilnehmerListeVeranstaltung();
      pdfTeilnehmerListeVeranstaltung.setSortierung(sortierung);
      pdfTeilnehmerListeVeranstaltung.setVeranstaltung(veranstaltung);
      pdfTeilnehmerListeVeranstaltung.zeige(false);
    }
  }



  // Hauptklasse
  public Ausgabe createTeilnehmerlisteVeranstaltungAusgabe(
    Veranstaltung veranstaltung, int sortierung) {
    return new VeranstaltungslisteAusgabe(veranstaltung, sortierung);
  }

  public Ausgabe createTeilnehmerlisteVeranstaltungsgruppeAusgabe(
    Veranstaltungsgruppe veranstaltungsgruppe) {
     
    return new GesamtlisteAusgabe(veranstaltungsgruppe);
  }

  public String getName() {
    return "PDF-Teilnehmerlisten";
  }

  public String getBeschreibung() {
    return "Erstellt Teilnehmerlisten f�r alle Veranstaltungen!";
  }

  public void setParameter(String name, String wert) throws ParameterException {
    throw new ParameterException("Diese Factory erlaubt keine Parameter!");
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    AusgabenTreeKnoten root = knoten.addKnoten("Veranstaltungen", false);
    VeranstaltungsgruppenListe veranstaltungsgruppen =
        Veranstaltungsgruppe.getAlleVeranstaltungsgruppen(
        VeranstaltungenListe.alphabetischeSortierung, true);
    Iterator it = veranstaltungsgruppen.iterator();
    while(it.hasNext()) {      
      addVeranstaltungsgruppeAusgaben(root, (Veranstaltungsgruppe) it.next());
    }
  }
  
  private void addVeranstaltungsgruppeAusgaben(AusgabenTreeKnoten root, 
    Veranstaltungsgruppe gruppe) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
      
    AusgabenTreeKnoten knoten = root.addKnoten(gruppe.getName(), true);
    knoten.addAusgabe("Gesamtliste ("+gruppe.getTeilnehmerAnzahl()+")", 
      createTeilnehmerlisteVeranstaltungsgruppeAusgabe(gruppe));
  
    VeranstaltungenListe veranstaltungen = gruppe.getVeranstaltungenMitAnmeldung();
    veranstaltungen.setSortierung(
        VeranstaltungenListe.alphabetischeSortierung, true);
  
    
    addVeranstaltungsAusgaben(knoten, veranstaltungen, "Anmeldenummer", VeranstaltungsteilnahmeListe.AnmeldeNrSortierung);
    addVeranstaltungsAusgaben(knoten, veranstaltungen, "Bemerkungen", VeranstaltungsteilnahmeListe.BemerkungenSortierung);
    addVeranstaltungsAusgaben(knoten, veranstaltungen, "Klasse", VeranstaltungsteilnahmeListe.BenutzerKlasseSortierung);
    addVeranstaltungsAusgaben(knoten, veranstaltungen, "Name", VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung);    
  }
  
  private void addVeranstaltungsAusgaben(AusgabenTreeKnoten root, 
    VeranstaltungenListe veranstaltungen, String sortierungName, int sortierung) {
    AusgabenTreeKnoten sortKnoten = root.addKnoten(sortierungName, true);
    Iterator it = veranstaltungen.iterator();
    while (it.hasNext()) {
      Veranstaltung veranstaltung = (Veranstaltung) it.next();
      sortKnoten.addAusgabe(veranstaltung.getTitel()+" ("+veranstaltung.getTeilnehmerAnzahl()+")",         
        createTeilnehmerlisteVeranstaltungAusgabe(
        veranstaltung, sortierung));
    }
  }  
}