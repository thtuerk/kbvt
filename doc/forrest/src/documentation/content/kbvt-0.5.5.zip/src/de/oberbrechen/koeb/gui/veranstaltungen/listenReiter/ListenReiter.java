/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.listenReiter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.veranstaltungen.*;
import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.ausgaben.TeilnehmerlisteAusgabenFactory;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;


/**
 * Diese Klasse repr�sentiert den Reiter, der die Ausgabe von Listen darstellt.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.13 $
 */

public class ListenReiter extends JPanel implements VeranstaltungenMainReiter {

  private Main hauptFenster;
  private VeranstaltungenTableModel veranstaltungenModel;
  boolean listenModelWirdVeraendert;
  private JTable veranstaltungenTable;

  private TeilnehmerlisteAusgabenFactory teilnehmerlisteAusgabeFactory;

  private Veranstaltungsgruppe aktuelleVeranstaltungsgruppe;
  ListenTableModel listenModel;
  private JTable listenTable;
  private JRadioButton nameButton;
  private JRadioButton klasseButton;
  private JRadioButton anmeldeNrButton;
  private JRadioButton bemerkungenButton;

  boolean istVeraenderbar;
  private JButton bearbeitenButton;
  private JButton verwerfenButton;
  private JButton pdfButton;

  public ListenReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    
    teilnehmerlisteAusgabeFactory = (TeilnehmerlisteAusgabenFactory) 
      Einstellungen.getInstance().getEinstellungObject(
      null, null, this.getClass().getName(), "TeilnehmerlisteAusgabe", 
      TeilnehmerlisteAusgabenFactory.class,
      "de.oberbrechen.koeb.pdf.pdfTeilnehmerListe.PdfTeilnehmerlisteAusgabenFactory");
    
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    setVeraenderbar(false);
  }

  private void jbInit() throws Exception {
    //Button-Panel bauen
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 3, 15, 5));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));

    bearbeitenButton = new JButton("Bearbeiten");
    bearbeitenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (istVeraenderbar) {
          saveChanges();
        } else {
          setVeraenderbar(true);
        }
      }
    });
    verwerfenButton = new JButton("�nderungen verwerfen");
    verwerfenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        aenderungenVerwerfen();
      }
    });
    pdfButton = new JButton("Liste erstellen");
    pdfButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        pdfErstellen();
      }
    });

    buttonPanel.add(bearbeitenButton, null);
    buttonPanel.add(verwerfenButton, null);
    buttonPanel.add(pdfButton, null);



    //Liste bauen
    listenModel = new ListenTableModel();
    listenModel.addTableModelListener(new javax.swing.event.TableModelListener() {
      public void tableChanged(TableModelEvent e) {
        if (!istVeraenderbar && !listenModelWirdVeraendert) 
          setVeraenderbar(true);
      }
     });
    listenTable = new JTable(listenModel);
    listenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    listenTable.getSelectionModel().addListSelectionListener(
      new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          benutzerGewechselt();
        }
    });
    JScrollPane listenScrollPane = new JScrollPane(listenTable);
    listenScrollPane.setMinimumSize(new Dimension(200, 30));

    JPanel listenPanel = new JPanel();
    listenPanel.setLayout(new BorderLayout());
    listenPanel.setBorder(BorderFactory.createEmptyBorder(15,6,15,10));
    listenPanel.setPreferredSize(new Dimension(200, 30));
    listenPanel.add(listenScrollPane, BorderLayout.CENTER);


    //Veranstaltungenauswahl bauen
    veranstaltungenModel = new VeranstaltungenTableModel(null);
    veranstaltungenTable = new JTable(veranstaltungenModel);
    veranstaltungenTable.setDefaultRenderer(Object.class,
      new VeranstaltungenTableRenderer());
    veranstaltungenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    veranstaltungenTable.getSelectionModel().addListSelectionListener(
      new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent e) {
          veranstaltungGewechselt();
        }
    });
    JScrollPane veranstaltungenScrollPane=new JScrollPane(veranstaltungenTable);
    veranstaltungenScrollPane.setPreferredSize(new Dimension(300, 30));

    ActionListener sortierungAuswahlListener = new ActionListener() {
      public void actionPerformed(ActionEvent event) {
        int sortierung = getSortierung();
        listenModelWirdVeraendert = true;
        listenModel.sortiere(sortierung);
        listenModelWirdVeraendert = false;
      }
    };
    nameButton = new JRadioButton("Name");
    klasseButton = new JRadioButton("Klasse");
    anmeldeNrButton = new JRadioButton("Anmeldenr");
    bemerkungenButton = new JRadioButton("Bemerkungen");

    nameButton.addActionListener(sortierungAuswahlListener);
    klasseButton.addActionListener(sortierungAuswahlListener);
    anmeldeNrButton.addActionListener(sortierungAuswahlListener);
    bemerkungenButton.addActionListener(sortierungAuswahlListener);

    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(nameButton);
    buttonGroup.add(klasseButton);
    buttonGroup.add(anmeldeNrButton);
    buttonGroup.add(bemerkungenButton);
    nameButton.setSelected(true);

    JPanel sortierungPanel = new JPanel();
    sortierungPanel.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));
    sortierungPanel.setLayout(new GridLayout());
    sortierungPanel.add(nameButton, null);
    sortierungPanel.add(klasseButton, null);
    sortierungPanel.add(anmeldeNrButton, null);
    sortierungPanel.add(bemerkungenButton, null);

    JPanel veranstaltungenPanel = new JPanel();
    veranstaltungenPanel.setLayout(new BorderLayout());
    veranstaltungenPanel.setBorder(BorderFactory.createEmptyBorder(15,10,15,6));
    veranstaltungenPanel.add(veranstaltungenScrollPane, BorderLayout.CENTER);
    veranstaltungenPanel.add(sortierungPanel, BorderLayout.SOUTH);
    veranstaltungenPanel.setPreferredSize(new Dimension(300, 30));
    veranstaltungenPanel.setMinimumSize(new Dimension(300, 30));

    //Splitpanel
    JSplitPane jSplitPane1 = new JSplitPane();
    jSplitPane1.setBorder(BorderFactory.createEmptyBorder());
    jSplitPane1.add(listenPanel, JSplitPane.RIGHT);
    jSplitPane1.add(veranstaltungenPanel, JSplitPane.LEFT);

    //alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(jSplitPane1, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
  }

  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob die aktuelle
   * Liste ver�ndert werden darf.
   * @param veraenderbar ist Liste veraenderbar oder nicht?
   */
  public void setVeraenderbar(boolean veraenderbar) {
    istVeraenderbar = veraenderbar;

    //Buttons anpassen
    pdfButton.setEnabled(!veraenderbar);
    verwerfenButton.setEnabled(veraenderbar);

    hauptFenster.erlaubeAenderungen(!veraenderbar);
    veranstaltungenTable.setEnabled(!veraenderbar);

    if (!veraenderbar) {
      bearbeitenButton.setText("Bearbeiten");
    } else {
      bearbeitenButton.setText("Speichern");
    }
  }

  /**
   * Wird aufgerufen, wenn einen neue Veranstaltung in der Tabelle ausgew�hlt
   * wird.
   */
  void veranstaltungGewechselt() {
    int gewaehlteReihe = veranstaltungenTable.getSelectedRow();
    if (gewaehlteReihe == -1) return;
    if (gewaehlteReihe == 0) {
      nameButton.setSelected(true);
      anmeldeNrButton.setEnabled(false);
      bemerkungenButton.setEnabled(false);
      klasseButton.setEnabled(false);

      BenutzerListe benutzerliste =
        hauptFenster.getAktuelleVeranstaltungsgruppe().
        getTeilnehmerListe(BenutzerListe.NachnameVornameSortierung,false);
      listenModelWirdVeraendert = true;
      listenModel.setDaten(benutzerliste);
      listenModel.sortiere(getSortierung());
      listenModelWirdVeraendert = false;
    } else {
      anmeldeNrButton.setEnabled(true);
      bemerkungenButton.setEnabled(true);
      klasseButton.setEnabled(true);

      VeranstaltungsteilnahmeListe teilnahmeListe =
        veranstaltungenModel.getVeranstaltung(gewaehlteReihe).
        getTeilnahmeListe(
        VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung,
        false);
      listenModelWirdVeraendert = true;        
      listenModel.setDaten(teilnahmeListe);
      listenModel.sortiere(getSortierung());
      listenModelWirdVeraendert = false;      
    }
  }

  /**
   * Wird aufgerufen, wenn einen neuer Benutzer in der Tabelle ausgew�hlt
   * wird.
   */
  void benutzerGewechselt() {
    int gewaehlteReihe = listenTable.getSelectedRow();
    if (gewaehlteReihe == -1) return;

    Benutzer gewaehlterBenutzer = listenModel.getBenutzer(gewaehlteReihe);
    hauptFenster.setAktiverBenutzer(gewaehlterBenutzer);
  }

  //Doku siehe bitte Interface
  public void aktualisiere() {
  }

  //Doku siehe bitte Interface
  public void setBenutzer(Benutzer benutzer) {
  }

  //Doku siehe bitte Interface
  public void refresh() {
    setVeranstaltungsgruppe(hauptFenster.getAktuelleVeranstaltungsgruppe());
  }

  //Doku siehe bitte Interface
  public void setVeranstaltungsgruppe(Veranstaltungsgruppe gruppe) {
    int markierteZeile = veranstaltungenTable.getSelectedRow();
    veranstaltungenModel.setDaten(gruppe);

    if (gruppe != aktuelleVeranstaltungsgruppe) markierteZeile = 0;
    aktuelleVeranstaltungsgruppe = gruppe;

    if (veranstaltungenModel.getRowCount() > markierteZeile) {
      veranstaltungenTable.setRowSelectionInterval(markierteZeile,
        markierteZeile);
      veranstaltungenTable.scrollRectToVisible(veranstaltungenTable.getCellRect(markierteZeile, 0, true));        
    }
  }

  /**
   * Bestimmt die aktuell ausgew�hlte Sortierung der Teilnehmerliste
   */
  public int getSortierung() {
    if (nameButton.isSelected()) return ListenTableModel.SORTIERUNG_NAME;
    if (klasseButton.isSelected()) return ListenTableModel.SORTIERUNG_KLASSE;
    if (anmeldeNrButton.isSelected())
      return ListenTableModel.SORTIERUNG_ANMELDENR;
    if (bemerkungenButton.isSelected()) return ListenTableModel.SORTIERUNG_BEMERKUNGEN;

    return -1;
  }

  /**
   * Gibt die Liste in eine PDF-Datei aus
   */
  public void pdfErstellen() {
    int gewaehlteReihe = veranstaltungenTable.getSelectedRow();

    if (gewaehlteReihe == -1) return;
    Ausgabe ausgabe;
    this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    try {
      if (gewaehlteReihe == 0) {
        Veranstaltungsgruppe gruppe = hauptFenster.getAktuelleVeranstaltungsgruppe();
        ausgabe = teilnehmerlisteAusgabeFactory.createTeilnehmerlisteVeranstaltungsgruppeAusgabe(
          gruppe);
      } else {
        ausgabe = teilnehmerlisteAusgabeFactory.createTeilnehmerlisteVeranstaltungAusgabe(
          veranstaltungenModel.getVeranstaltung(gewaehlteReihe), getSortierung());
      }
      ausgabe.run(hauptFenster);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e,
        "Die PDF-Datei konnte nicht ausgegeben werden.", false);
    }
    this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
  }

  /**
   * Speichert die gemachten �nderungen
   */
  public void saveChanges() {
    if (listenTable.isEditing()) {
      JOptionPane.showMessageDialog(hauptFenster, "Bitte beenden Sie zuerst "+
        "die aktuelle Bearbeitung!",
        "Noch in Bearbeitung!", JOptionPane.ERROR_MESSAGE);
      return;
    }

    listenModel.save();
    this.setVeraenderbar(false);
  }

  /**
   * Verwirft die aktuellen �nderungen.
   */
  public void aenderungenVerwerfen() {
    if (listenTable.isEditing()) {
      JOptionPane.showMessageDialog(hauptFenster, "Bitte beenden Sie zuerst "+
        "die aktuelle Bearbeitung!",
        "Noch in Bearbeitung!", JOptionPane.ERROR_MESSAGE);
      return;
    }

    listenModel.reload();
    this.setVeraenderbar(false);
  }
}