/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben;

import de.oberbrechen.koeb.ausgaben.Ausgabe;

/**
* Dieses Interface repr�sentiert Knoten im AusgabenTreeModel.
* Es kapselt die wichtigen Methoden des eigentlichen Knotens.
* Als wichtig werden dabei nur Methoden erachtet, die neue Knoten
* hinzuf�gen. Ein L�schen von Knoten oder Zugriff auf Informationen
* wird dagegen verweigert!
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public interface AusgabenTreeKnoten {

  /**
   * F�gt eine Ausgabe zum Knoten hinzu
   * @param ausgabe die hinzuf�gende Ausgabe
   */
  public void addAusgabe(Ausgabe ausgabe);

  /**
   * F�gt eine Ausgabe zum Knoten hinzu
   * @param name der Name des neuen Knotens
   * @param ausgabe die hinzuf�gende Ausgabe
   */
  public void addAusgabe(String name, Ausgabe ausgabe);

  /**
   * F�gt einen neuen Unterknoten ein
   * @param name der Name des neuen Knotens
   * @param sortiert bestimmt, ob die Ausgaben und Ordner des Unterknotens
   *  alphabetisch sortiert werden sollen  
   * @return den neuen Unterknoten
   */
  public AusgabenTreeKnoten addKnoten(String name, boolean sortiert);
  
  /**
   * Liefert einen Unterknoten des �bergebenen Knotens mit dem �bergebenen
   * Namen. Existiert ein solcher Ordner nicht, wird <code>null</code>
   * zur�ckgeliefert.
   * @param name der Name des zu suchenden Knotens
   * @return den gefundenen Unterknoten oder <code>null</code>
   */
  public AusgabenTreeKnoten getKnoten(String name);
}