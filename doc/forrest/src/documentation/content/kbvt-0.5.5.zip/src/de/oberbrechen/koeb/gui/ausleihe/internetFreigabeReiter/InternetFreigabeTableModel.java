/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.internetFreigabeReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.ClientListe;
import de.oberbrechen.koeb.einstellungen.*;
import javax.swing.table.AbstractTableModel;
import java.text.DecimalFormat;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Ausleihen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/

public class InternetFreigabeTableModel extends AbstractTableModel {

  private static DecimalFormat zahlenFormat = new DecimalFormat("00");
  private static DecimalFormat kostenFormat = new DecimalFormat("0.00 EUR");
  private ClientListe daten;

  /**
   * Erstellt ein neues Modell
   */
  public InternetFreigabeTableModel() {
    daten = Client.getAlleClients();
    daten.setSortierung(ClientListe.NameSortierung, false);
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 4;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Rechner";
    if (columnIndex == 1) return "Benutzer";
    if (columnIndex == 2) return "Dauer";
    if (columnIndex == 3) return "Kosten";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Client gewaehlterClient = (Client) daten.get(rowIndex);
    Internetfreigabe gewaehlteInternetfreigabe =
      gewaehlterClient.getAktuelleInternetfreigabe();

    switch (columnIndex) {
      case 0:
        return gewaehlterClient.getName();
      case 1:
        if (gewaehlteInternetfreigabe == null ||
            !gewaehlteInternetfreigabe.istAktuell()) return "-";
        return gewaehlteInternetfreigabe.getBenutzer().getName();
      case 2:
        if (gewaehlteInternetfreigabe == null ||
            !gewaehlteInternetfreigabe.istAktuell()) return "-";
        int restDauerInSekunden = gewaehlteInternetfreigabe.getDauer();

        int anzahlStunden = restDauerInSekunden / 3600;
        restDauerInSekunden = restDauerInSekunden % 3600;
        int anzahlMinuten = restDauerInSekunden / 60;
        restDauerInSekunden = restDauerInSekunden % 60;

        return zahlenFormat.format(anzahlStunden)+":"+
               zahlenFormat.format(anzahlMinuten)+":"+
               zahlenFormat.format(restDauerInSekunden);
      case 3:
        if (gewaehlteInternetfreigabe == null ||
            !gewaehlteInternetfreigabe.istAktuell()) return "-";
        return kostenFormat.format(Buecherei.getInstance().
          berechneInternetzugangsKosten(gewaehlteInternetfreigabe.getDauer()));
    }
    return "nicht definierte Spalte";
  }

  /**
   * Liefert den Client, dessen Internetfreigabe in der angebenen
   * Zeile dargestellt wird
   * @param rowIndex die Zeile
   */
  public Client getClient(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    return (Client) daten.get(rowIndex);
  }
}
