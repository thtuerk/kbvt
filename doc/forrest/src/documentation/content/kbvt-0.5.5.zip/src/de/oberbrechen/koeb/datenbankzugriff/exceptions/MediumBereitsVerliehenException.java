/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.exceptions;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
* Diese Exception wird geworfen, wenn versucht wird, eine Ausleihe zu speichern,
* deren Medium in dem auszuleihenden Zeitraum bereits ausgeliehen ist.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/
public class MediumBereitsVerliehenException extends
  DatenbankzugriffException {

  private Ausleihe konfliktAusleihe;
  private Ausleihe verursachendeAusleihe;

  /**
   * Erstellt eine neue MediumBereitsVerliehenException
   * @param meldung die anzuzeigende Meldung
   * @param konfliktAusleihe die Ausleihe, durch die das Medium in dem
   *   auszuleihenden Zeitraum bereits ausgeliehen ist
   * @param verursachendeAusleihe die Ausleihe, deren Medium in
   *   dem auszuleihenden Zeitraum bereits ausgeliehen ist
   */
  public MediumBereitsVerliehenException(String meldung,
    Ausleihe konfliktAusleihe, Ausleihe verursachendeAusleihe) {
    super(meldung);
    this.konfliktAusleihe = konfliktAusleihe;
    this.verursachendeAusleihe = verursachendeAusleihe;
  }

  /**
   * Erstellt eine neue MediumBereitsVerliehenException
   * @param konfliktAusleihe die Ausleihe, durch die das Medium in dem
   *   auszuleihenden Zeitraum bereits ausgeliehen ist
   * @param verursachendeAusleihe die Ausleihe, deren Medium in
   *   dem auszuleihenden Zeitraum bereits ausgeliehen ist
   */
  public MediumBereitsVerliehenException(Ausleihe konfliktAusleihe,
    Ausleihe verursachendeAusleihe) {
    this(standardFehlerMeldung(konfliktAusleihe, verursachendeAusleihe),
         konfliktAusleihe, verursachendeAusleihe);
  }

  /**
   * Liefert die Standardfehlermeldung f�r die �bergebenen Ausleihen
   * @return die Standardfehlermeldung
   */
  private static String standardFehlerMeldung(Ausleihe konfliktAusleihe,
    Ausleihe verursachendeAusleihe) {
    String meldung;
    if (verursachendeAusleihe.istNeu())
      meldung = "Die neue Ausleihe";
    else
      meldung = "Die Ausleihe Nr. "+ verursachendeAusleihe.getAusleihNr();

    meldung += " konnte nicht gespeichert werden, da das Medium '"+
               konfliktAusleihe.getMedium().getTitel()+"' ("+
               konfliktAusleihe.getMedium().getMedienNr()+") im "+
               "auszuleihenden Zeitraum schon von "+
               "Ausleihe Nr. "+konfliktAusleihe.getAusleihNr()+
               " verliehen wird.";
    return meldung;
  }

  /**
   * Liefert die Ausleihe, die das Medium im auszuleihenden Zeitraum bereits
   *   ausleiht.
   * @return die Ausleihe, die das Medium im auszuleihenden Zeitraum bereits
   *   ausleiht
   */
  public Ausleihe getKonfliktAusleihe() {
    return konfliktAusleihe;
  }

  /**
   * Liefert die Ausleihe, die das Medium neu ausleihen m�chte.
   * @return die Ausleihe, die das Medium neu ausleihen m�chte
   */
  public Ausleihe getVerursachendeAusleihe() {
    return verursachendeAusleihe;
  }
}
