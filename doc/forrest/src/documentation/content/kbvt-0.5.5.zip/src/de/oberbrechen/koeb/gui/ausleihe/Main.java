/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe;

import java.awt.*;
import java.awt.event.ItemEvent;

import javax.swing.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.gui.AbstractMain;
import de.oberbrechen.koeb.gui.ausleihe.ausleiheReiter.AusleiheReiter;
import de.oberbrechen.koeb.gui.ausleihe.ausleihenInfoReiter.AusleihenInfoReiter;
import de.oberbrechen.koeb.gui.ausleihe.benutzerReiter.BenutzerReiter;
import de.oberbrechen.koeb.gui.ausleihe.internetFreigabeReiter.InternetFreigabeReiter;
import de.oberbrechen.koeb.gui.ausleihe.mahnungenReiter.MahnungenReiter;
import de.oberbrechen.koeb.gui.ausleihe.medienInfoReiter.MedienInfoReiter;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeGelesenEventHandler;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeReaderKeyAdapter;
import de.oberbrechen.koeb.gui.components.Format;
import de.oberbrechen.koeb.gui.components.SortiertComboBox;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die f�r
 * die t�glich auftredenden Aufgaben, also vor allem f�r die Ausleihe gedacht
 * ist.
 *
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.18 $
 */
public class Main extends AbstractMain implements BarcodeGelesenEventHandler {
	private JTextField mitarbeiterFeld;
	private SortiertComboBox benutzerFeld;

	private AusleiheReiter ausleiheReiter;

	public Main(boolean isMain) {
		super(
			isMain,
			"Ausleihe",
			Mitarbeiter.BERECHTIGUNG_STANDARD,
			"de/oberbrechen/koeb/gui/icon-ausleihe.png");
		this.addKeyListener(new BarcodeReaderKeyAdapter("\5", "\12", this));
	}

	/**
	 * Entfernt einen Benutzer aus der Liste
	 * @param benutzer der zu entfernende Benutzer
	 */
	public void removeBenutzer(Benutzer benutzer) {
		benutzerFeld.removeItem(benutzer);
		benutzerFeld.setSelectedIndex(0);
	}

	public void erlaubeAenderungen(boolean erlaubt) {
		super.erlaubeAenderungen(erlaubt);
		benutzerFeld.setEnabled(erlaubt);
	}

	/**
	 * Aktiviert den �bergebenen Benutzer, ist der Benutzer nicht in der
	 * bisherigen Benutzerliste, so wird er erg�nzt, falls er gespeichert ist.
	 * @param benutzer der zu aktivierende Benutzer
	 */
	public void setAktiverBenutzer(Benutzer benutzer) {
		benutzerFeld.setSelectedItem(benutzer);
		benutzerFeld.fireDelayItemListenerEvent();
	}

	public static void main(String[] args) {
		init();
		new Main(true);
	}

	protected JPanel getAllgemeinPanel() throws Exception {
		//allgemeinPanel bauen
		JPanel allgemeinPanel = new JPanel();
		allgemeinPanel.setLayout(new GridBagLayout());

		JLabel mitarbeiterLabel = new JLabel("Mitarbeiter:");
		JLabel benutzerLabel = new JLabel("Benutzer:");
		int labelBreite =
			Math.max(
				benutzerLabel.getPreferredSize().width,
				mitarbeiterLabel.getPreferredSize().width);
		int labelHoehe =
			Math.max(
				benutzerLabel.getPreferredSize().height,
				mitarbeiterLabel.getPreferredSize().height);
		Dimension labelDimension = new Dimension(labelBreite, labelHoehe);

		JComponentFormatierer.setDimension(benutzerLabel, labelDimension);
		JComponentFormatierer.setDimension(mitarbeiterLabel, labelDimension);

		mitarbeiterFeld = new JTextField();
		mitarbeiterFeld.setToolTipText("Der aktuell angemeldete Mitarbeiter!");
		benutzerFeld = new SortiertComboBox(new Format() {
			public String format(Object obj) {
				if (obj == null)
					return null;
				Benutzer ben = ((Benutzer) obj);
				return ben.getNameFormal();
			}
		});
		benutzerFeld.setToolTipText("Der aktuelle Benutzer!");
		int eingabeHoehe = mitarbeiterFeld.getPreferredSize().height;
		Dimension eingabeDimension = new Dimension(100, eingabeHoehe);
		JComponentFormatierer.setDimension(mitarbeiterFeld, eingabeDimension);
		JComponentFormatierer.setDimension(benutzerFeld, eingabeDimension);
		mitarbeiterFeld.setEditable(false);
		benutzerFeld.addDelayItemListener(new java.awt.event.ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				aktualisiereBenutzer();
			}
		});

		allgemeinPanel.add(
			benutzerLabel,
			new GridBagConstraints(
				0,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.NONE,
				new Insets(0, 2, 0, 10),
				0,
				0));
		allgemeinPanel.add(
			benutzerFeld,
			new GridBagConstraints(
				1,
				0,
				1,
				1,
				1.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 0, 0),
				0,
				0));
		allgemeinPanel.add(
			mitarbeiterLabel,
			new GridBagConstraints(
				2,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.NONE,
				new Insets(0, 20, 0, 10),
				0,
				0));
		allgemeinPanel.add(
			mitarbeiterFeld,
			new GridBagConstraints(
				3,
				0,
				1,
				1,
				1.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 0, 0),
				0,
				0));

		return allgemeinPanel;
	}

	/**
	 * Wird aufgerufen, wenn ein neuer Benutzer ausgew�hlt wurde
	 */
	public void aktualisiereBenutzer() {
		((AusleiheMainReiter) reiter.getSelectedComponent()).setBenutzer(
			this.getAktuellerBenutzer());
	}

	//Doku siehe bitte Interface
	public void barcodeGelesen(String barcode) {
		EAN neuerBarcode = new EAN(barcode);
		if (neuerBarcode.getTyp() == EAN.UnbekannterTypEAN
			|| neuerBarcode.getReferenz() == null)
			return;

		if (neuerBarcode.getTyp() == EAN.BenutzerEAN) {
			if (!erlaubeAenderungen)
				return;
			Benutzer benutzer = (Benutzer) neuerBarcode.getReferenz();
			this.setAktiverBenutzer(benutzer);
			return;
		}

		if (neuerBarcode.getTyp() == EAN.MediumEAN) {
			Medium medium = (Medium) neuerBarcode.getReferenz();
			((AusleiheMainReiter) reiter.getSelectedComponent()).mediumEANGelesen(
				medium);
			return;
		}
	}

	//Doku siehe bitte Interface
	public void barcodeStartGelesen() {
		mitarbeiterFeld.grabFocus();
	}

	/**
	 * Liefert den aktuellen Benutzer
	 * @return den aktuellen Benutzer
	 */
	public Benutzer getAktuellerBenutzer() {
		return (Benutzer) benutzerFeld.getSelectedItem();
	}

	/**
	 * Zeigt die �bergebene Ausleihe an. D.h. es wird der zur Ausleihe
	 * geh�rende Benutzer gesetzt und der Ausleihe-Reiter aktiviert. Dort wird,
	 * falls m�glich, die �bergebene Ausleihe ausgew�hlt.
	 *
	 * @param ausleihe die anzuzeigende Ausleihe
	 */
	public void zeigeAusleihe(Ausleihe ausleihe) {
		this.setAktiverBenutzer(ausleihe.getBenutzer());
		zeigeAusleiheReiter();
		ausleiheReiter.zeigeAusleihe(ausleihe);
	}

	/**
	 * Zeigt den AusleiheReiter an
	 */
	public void zeigeAusleiheReiter() {
		reiter.setSelectedComponent(ausleiheReiter);
	}

	protected void initDaten() {
		BenutzerListe alleBenutzerListe = Benutzer.getAlleBenutzer();
		alleBenutzerListe.setSortierung(
			BenutzerListe.NachnameVornameSortierung,
			false);
		benutzerFeld.setDaten(alleBenutzerListe);
	}

	protected void reiterHinzufuegen() {
		Einstellungen einstellungen = Einstellungen.getInstance();
		Client benutzterClient = Client.getBenutzenClient();

		ausleiheReiter = new AusleiheReiter(this);
		reiter.add(ausleiheReiter, "Ausleihe / R�ckgabe");
		reiter.add(new BenutzerReiter(this), "Benutzerdaten");

		if (einstellungen.getEinstellungBoolean(
				benutzterClient, null, this.getClass().getName(),
				"ZeigeReiter.Medien-Informationen", true))
			reiter.add(new MedienInfoReiter(this), "Medien-Informationen");
		if (einstellungen.getEinstellungBoolean(
				benutzterClient, null, this.getClass().getName(),
				"ZeigeReiter.bisherige_Ausleihen", true))
			reiter.add(new AusleihenInfoReiter(this), "bisherige Ausleihen");
		if (einstellungen.getEinstellungBoolean(
        benutzterClient, null, this.getClass().getName(),
				"ZeigeReiter.Internetzugang",	true))
			reiter.add(new InternetFreigabeReiter(this), "Internetzugang");
		if (einstellungen.getEinstellungBoolean(
    		benutzterClient, null, this.getClass().getName(),
				"ZeigeReiter.Mahnungen", true))
			reiter.add(new MahnungenReiter(this), "Mahnungen");
	}

	public void setMitarbeiter(Mitarbeiter mitarbeiter) {
		super.setMitarbeiter(mitarbeiter);
		if (mitarbeiterFeld != null)
			mitarbeiterFeld.setText(mitarbeiter.getName());
	}
}