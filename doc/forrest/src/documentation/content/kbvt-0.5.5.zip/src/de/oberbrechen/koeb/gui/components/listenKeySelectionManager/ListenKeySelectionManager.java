/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenKeySelectionManager;

/**
 * Diese Klasse ist ein KeySelectionManager f�r beliebige Listen.
 * Die Methode getSelectedRow bekommt einen Tastendruck �bergeben
 * und liefert darauf die zu w�hlende Zeile. Die zur Verf�gung
 * stehenden Zeilen und die darin enthaltenden Daten m�ssen das
 * Interface ListenKeySelectionManagerListenDaten implementieren
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.4 $
 */
public class ListenKeySelectionManager {

  private StringBuffer pattern;
  private long lastKeyPress;  
  private ListenKeySelectionManagerListenDaten daten;

  public ListenKeySelectionManager(ListenKeySelectionManagerListenDaten daten) {
    this.daten = daten;
    pattern = new StringBuffer();
    lastKeyPress = 0;    
  }
  
  public int selectionForKey(char aKey) {
    if (aKey == '\u001b') {
      pattern.delete(0, pattern.length());
      return 0;
    }

    if (System.currentTimeMillis() - lastKeyPress > 20000) {
      pattern.delete(0, pattern.length());
    }
    
    lastKeyPress = System.currentTimeMillis();
  
    if (!(Character.isLetterOrDigit(aKey) ||
          aKey == ' ' || aKey == ',' || aKey == '-' || aKey == '\b' ||
          aKey == '�' || aKey == '�' || aKey == '�' || aKey == '�' ||
          aKey == '.' || aKey == '!' || aKey == ':' || aKey == '?' ||
          aKey == '�' || aKey == '�' || aKey == '�' )) return -1;
    
    if (aKey == '\b') {
      if (pattern.length() > 0)
        pattern.delete(pattern.length()-1, pattern.length());
    } else {
      pattern.append(Character.toLowerCase(aKey));
    }
    
    int currentPos = -1;
    do {
      currentPos += 1;
      String eintrag = daten.getKeySelectionValue(currentPos).toLowerCase(); 
      if (eintrag.startsWith(pattern.toString())) return currentPos;
    } while (currentPos < daten.size()-1);
    
    return 0;
  }
}
