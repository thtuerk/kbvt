/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Collection;

import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.*;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/
public abstract class AuswahlTableModel extends AbstractTableModel
  implements KeyListener, ListenKeySelectionManagerListenDaten {

  protected int sortierteSpalte;
	protected Liste daten;
  protected ListenKeySelectionManager keySelectionManager;
  protected JTable tabelle;

  /**
   * Erstellt ein neues Modell
   */
  public AuswahlTableModel(JTable tabelle, Liste daten) {
    this.daten = daten;
    sortierteSpalte = 0;    
    keySelectionManager = new ListenKeySelectionManager(this);
    this.tabelle = tabelle;
  }
  
  public void clear() {
    daten.clear();
    fireTableDataChanged();
  }
    
  public void setDaten(Collection neueDaten) {
    daten.clear();
    daten.addAllNoDuplicate(neueDaten);
    fireTableDataChanged();
  }

  public void addDaten(Collection neueDaten) {
    daten.addAll(neueDaten);
    fireTableDataChanged();
  }

  public void removeDaten(Collection alteDaten) {
    daten.removeAll(alteDaten);
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public Liste getDaten() {
    return daten;
  }

  public void keyTyped(KeyEvent e) {
    char aKey = e.getKeyChar();
    int zuSelektierendeZeile = keySelectionManager.selectionForKey(aKey);
    if (zuSelektierendeZeile == -1) return;
    
    tabelle.setRowSelectionInterval(zuSelektierendeZeile, zuSelektierendeZeile);
    tabelle.scrollRectToVisible(tabelle.getCellRect(zuSelektierendeZeile, 0, true));
  }


  public void keyPressed(KeyEvent e) {
  }

  public void keyReleased(KeyEvent e) {
  }

  public String getKeySelectionValue(int row) {
    return getValueAt(row, sortierteSpalte).toString();
  }

  public int size() {
    return this.getRowCount();
  }

  public void switchDaten(Object object) {
    if (daten.contains(object)) {
      daten.remove(object);
    } else {
      daten.add(object);
    }
    fireTableDataChanged();
  }
  
  public Object get(int row) {
    return daten.get(row);
  }


	/**
   * Sortiert die Daten nach dem Wert, der in der �bergebenen Spalte 
   * angezeigt wird. Implementierung dieser Methode m�ssen neben dem
   * eigentlichen Sortieren auch die Variable sortierteSpalte umsetzen.
	 * @param spalte die Spalte nach der Sortiert werden soll
   * @param umgekehrteSortierung sortierung umkehren?
	 */
  abstract protected void sortiereNachSpalte(
    int spalte, boolean umgekehrteSortierung);
    
  /**
   * Sortiert die Daten nach der Standardsortierung. Hierzu sollte die Methode
   * sortiereNachSpalte intern verwendet werden. Mittels dieser Methode kann
   * eine Standardsortierung vorgegeben werden.
   */
  abstract public void sortiereNachStandardSortierung();
}
