/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausgaben.ausgabenReiter;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.*;

import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.MainReiter;
import de.oberbrechen.koeb.gui.ausgaben.Main;
import de.oberbrechen.koeb.gui.ausgaben.util.AusgabenTreeModel;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die f�r
 * Auswahl von Ausgaben gedacht ist.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class AusgabenReiter extends JPanel implements MainReiter {
  private Main hauptFenster;
  private TreeModel model;
  private Ausgabe aktuelleAusgabe;

  private JTextArea beschreibung;
  private JButton ausfuehrenButton;
  private JTextField nameFeld;

  public AusgabenReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    //Panel bauen
    JPanel allgemeinPanel = new JPanel();
    allgemeinPanel.setBorder(BorderFactory.createEmptyBorder(0,10,0,0));
    allgemeinPanel.setLayout(new GridBagLayout());
    beschreibung = new JTextArea();
    beschreibung.setEditable(false);
    beschreibung.setLineWrap(true);
    beschreibung.setWrapStyleWord(true);
    ausfuehrenButton = new JButton("ausf�hren");
    ausfuehrenButton.setEnabled(false);
    ausfuehrenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        starteAusgabe();
      }
    });
    nameFeld = new JTextField();
    nameFeld.setEditable(false);

    JScrollPane jScrollPaneBeschreibung = new JScrollPane(beschreibung);
    JComponentFormatierer.setDimension(jScrollPaneBeschreibung, new Dimension(200, 10));

    JLabel nameLabel = new JLabel("Name:");
    JLabel beschreibungLabel = new JLabel("Beschreibung:");
    this.setMinimumSize(new Dimension(174, 168));
    this.setLayout(new BorderLayout());
    allgemeinPanel.add(nameLabel,             new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 5), 0, 0));
    allgemeinPanel.add(nameFeld,             new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    allgemeinPanel.add(beschreibungLabel,         new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 0, 0, 0), 0, 0));
    allgemeinPanel.add(jScrollPaneBeschreibung,       new GridBagConstraints(0, 2, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    allgemeinPanel.add(ausfuehrenButton,         new GridBagConstraints(0, 3, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(20, 0, 0, 0), 0, 0));

    //Baum bauen
    model = new AusgabenTreeModel();
    JTree ausgabenTree = new JTree(model);

    ausgabenTree.addTreeSelectionListener(new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent event)
      {
        TreePath tp = event.getNewLeadSelectionPath();
        if (tp != null && ((TreeNode) tp.getLastPathComponent()).isLeaf()) {
          setNeueAusgabe(((DefaultMutableTreeNode) tp.getLastPathComponent()));
        } else {
          setNeueAusgabe(null);
        }
      }
    }
    );

    //alles zusammenbauen
    JScrollPane jScrollPane = new JScrollPane(ausgabenTree);
    JComponentFormatierer.setDimension(jScrollPane, new Dimension(200, 200));
    JPanel baumPanel = new JPanel();
    baumPanel.setLayout(new BorderLayout());
    baumPanel.add(jScrollPane, BorderLayout.CENTER);
    baumPanel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));

    JSplitPane jSplitPane = new JSplitPane();
    jSplitPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    jSplitPane.add(baumPanel, JSplitPane.LEFT);
    jSplitPane.add(allgemeinPanel, JSplitPane.RIGHT);
    add(jSplitPane, BorderLayout.CENTER);
  }

  /**
   * Setzt eine neue Ausgabe zur Ausf�hrung. �bergeben wird der Knoten,
   * der diese Ausgabe repr�sentiert
   */
  void setNeueAusgabe(DefaultMutableTreeNode node) {
    if (node == null) {
      nameFeld.setText("");
      aktuelleAusgabe = null;
      beschreibung.setText("");
      ausfuehrenButton.setEnabled(false);
    } else {
      aktuelleAusgabe = (Ausgabe) node.getUserObject();
      nameFeld.setText(aktuelleAusgabe.getName());
      beschreibung.setText(aktuelleAusgabe.getBeschreibung());
      ausfuehrenButton.setEnabled(true);
    }
  }

  public void starteAusgabe() {
    setCursor(new Cursor(Cursor.WAIT_CURSOR));

    try {
      aktuelleAusgabe.run(hauptFenster);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Beim Ausf�hren der "+
        "Ausgabe trat ein Fehler auf:", false);
    }
    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  public void aktualisiere() {
  }

  public void refresh() {
  }
}