/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import java.util.Date;

/**
* Diese Klasse repr�sentiert eine Ausleihordnung einer B�cherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public abstract class Ausleihordnung {

  /**
   * Liefert eine Instanz der aktuell konfigurierten Ausleihordnung.
   * @return eine Instanz der aktuell konfigurierten Ausleihordnung
   */
  public static Ausleihordnung getInstance() {
    return Buecherei.getInstance().getAusleihordnung();
  }

  /**
   * Berechnet die Mahngeb�hren f�r die �bergebene Liste von Ausleihen
   * zum aktuellen Zeitpunkt
   * @param liste die AusleihenListe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public double berechneMahngebuehren(AusleihenListe liste) {
    return berechneMahngebuehren(liste, new Date());
  }
  
  /**
   * Berechnet die Mahngeb�hren f�r die uebergebene Ausleihe zum
   * aktuellen Zeitpunkt
   * @param ausleihe die Ausleihe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public double berechneMahngebuehren(Ausleihe ausleihe) {
    return berechneMahngebuehren(ausleihe, new Date());
  }  


  /**
   * Berechnet die Mahngeb�hren f�r die uebergebene Ausleihe zum
   * uebergebenen Zeitpunkt
   * @param zeitpunkt der Zeitpunkt, zu dem die Mahngeb�hren berechnet werden
   *   sollen
   * @param ausleihe die Ausleihe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public double berechneMahngebuehren(Ausleihe ausleihe, Date zeitpunkt) {
    AusleihenListe liste = new AusleihenListe();
    liste.add(ausleihe);
    return berechneMahngebuehren(liste, zeitpunkt);
  }  

  /**
   * Berechnet die Mahngeb�hren f�r die �bergebene Liste von Ausleihen
   * zum �bergebenen Zeitpunkt
   * @param zeitpunkt der Zeitpunkt, zu dem die Mahngeb�hren berechnet werden
   *   sollen
   * @param liste die AusleihenListe, f�r die die Mahngeb�hren berechnet werden
   *   sollen
   */
  public abstract double berechneMahngebuehren(AusleihenListe liste,
    Date zeitpunkt);

  /**
   * Bestimmt, ob es m�glich ist, die �bergebene Ausleihe zu verl�ngern.
   * Diese Implementierung liefert immer <code>true</code>, was jedoch in
   * Unterklassen �bergeschrieben werden kann.
   *
   * @param ausleihe die Ausleihe, die verl�ngert werden soll
   * @return <code>true</code> gdw. die Ausleihe verl�ngert werden darf.
   */
  public boolean istVerlaengernMoeglich(Ausleihe ausleihe) {
    return true;
  }

  /**
   * Liefert evtl. eine Begr�ndung, warum eine Verl�ngerung nicht m�glich ist.
   * Diese Implementierung liefert immer <code>null</code>, was jedoch in
   * Unterklassen �bergeschrieben werden kann.
   *
   * @param ausleihe die Ausleihe, die verl�ngert werden soll
   * @return <code>null</code> falls eine Verl�ngerung m�glich ist <br>
   *   <code>null</code> oder eine Begr�ndung sonst
   */
  public String getVerlaengernNichtMoeglichBegruendung(Ausleihe ausleihe) {
    return null;
  }

  /**
   * Liefert das Datum, bis zu dem die Ausleihe ausgehend von dem heutigen Datum
   * verl�ngert wird.
   *
   * @param ausleihe die Ausleihe, die verl�ngert werden soll
   * @return <code>null</code> falls eine Verl�ngerung nicht m�glich ist <br>
   *   das Datum, bis zu dem die Ausleihe normalerweise verl�ngert wird, sonst
   */
  public Date getVerlaengernBisDatum(Ausleihe ausleihe) {
    return getVerlaengernBisDatum(ausleihe, null);
  }

  /**
   * Liefert das Datum, bis zu dem die Ausleihe ausgehend vom �bergebenen Datum
   * verl�ngert wird.
   *
   * @param ausleihe die Ausleihe, die verl�ngert werden soll
   * @param datum das Datum, ab dem die Ausleihe verl�ngert werden soll
   * @return <code>null</code> falls eine Verl�ngerung nicht m�glich ist <br>
   *   das Datum, bis zu dem die Ausleihe normalerweise verl�ngert wird, sonst
   */
  public Date getVerlaengernBisDatum(Ausleihe ausleihe, Date datum) {
    if (!istVerlaengernMoeglich(ausleihe)) return null;
    return getAusleihenBisDatum(ausleihe.getMedium(), datum);
  }

  /**
   * Bestimmt das Sollr�ckgabedatum f�r das �bergebene Medium vorausgesetzt,
   * dass es heute ausgeliehen wird.
   *
   * @param medium das Medium, das ausgeliehen werden soll
   * @return das Sollr�ckgabedatum
   */
  public Date getAusleihenBisDatum(Medium medium) {
    return getAusleihenBisDatum(medium, null);
  }

  /**
   * Bestimmt das Sollr�ckgabedatum f�r das �bergebene Medium vorausgesetzt,
   * dass es am �bergebenen Datum ausgeliehen wird.
   *
   * @param medium das Medium, das ausgeliehen werden soll
   * @param datum das Datum, ab dem das Medium ausgeliehen werden soll,
   *   null wird als das heutige Datum interpretiert
   * @return das Sollr�ckgabedatum
   */
  public abstract Date getAusleihenBisDatum(Medium medium, Date datum);
}