/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.veranstaltungenPanel;

import java.util.Collection;
import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;

import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Terminen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class TerminTableModel extends AbstractTableModel {

  private TerminListe daten;

  /**
   * Erstellt ein neues Modell
   */
  public TerminTableModel() {
    daten = new TerminListe();
    daten.setSortierung(TerminListe.chronologischeSortierung, false);
  }

    
  public void setDaten(Collection neueDaten) {
    daten.clear();
    
    Iterator it = neueDaten.iterator();
    while (it.hasNext()) {
      daten.add(((Termin) it.next()).deepCopy());
    }
    
    fireTableDataChanged();
  }

  public void addDaten(Collection neueDaten) {
    daten.addAll(neueDaten);
    fireTableDataChanged();
  }

  public void removeDaten(Collection alteDaten) {
    daten.removeAll(alteDaten);
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 1;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Termine";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    Termin gewaehlterTermin = (Termin) daten.get(rowIndex);
    switch (columnIndex) {
      case 0: return gewaehlterTermin.getLangesTerminFormat();     
    }
    return "ung�ltige Spalte";
  }


  public Termin getTermin(int rowIndex) {
    return (Termin) daten.get(rowIndex);
  }

  public TerminListe getDaten() {
    return daten;
  }

  public int size() {
    return this.getRowCount();
  }


	/**
	 * F�gt den Termin in das Modell ein und liefert seinen Index
   * @param neuerTermin der einzuf�gende Termin
   * @return den Index des neuen Termins
	 */
	public int add(Termin neuerTermin) {
    daten.add(neuerTermin);
    return daten.indexOf(neuerTermin);
	}


	public void remove(Termin aktuellerTermin) {
    daten.remove(aktuellerTermin);
  }
}
