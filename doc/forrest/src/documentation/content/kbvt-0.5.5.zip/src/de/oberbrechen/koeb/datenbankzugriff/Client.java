/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.net.InetAddress;
import java.sql.*;
import java.util.Observable;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnvollstaendigeDatenException;
import de.oberbrechen.koeb.datenstrukturen.ClientListe;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.framework.KonfigurationsDatei;

/**
* Diese Klasse repr�sentiert einen Client, f�r den z.B. die Internetfreigabe
* get�tigt werden kann.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.9 $
*/

public class Client extends Observable {

  private boolean isSaved;

  private int nr;
  private String name;
  private String ip;
  private Internetfreigabe aktuelleFreigabe;
  private long zeitpunktLetztesLaden;

  private static Client benutzerClient = null;
  private static PreparedStatement ladeClientStatement;
  static{
    try {
      ladeClientStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select * from client where nr = ?");
    } catch (SQLException e) {
      throw new RuntimeException("Unerwarteter Fehler beim Initialisieren "+
        "der Statements f�r Clients!");
    }
  }

  /**
   * Liefert den Client, auf dem die Software ausgef�hrt wird. Existiert dieser nicht
   * in der Datenbank, so wird er hinzugef�gt!
   * @return der benutzte Client
   */
  public static Client getBenutzenClient() {
    if (benutzerClient != null) return benutzerClient;

    String clientNrString = KonfigurationsDatei.getStandardKonfigurationsdatei().getProperty("ClientNr");
    int clientNr = -1;
    try {
      clientNr = Integer.parseInt(clientNrString);
    } catch (NumberFormatException e) {
      //nichts zu tun, clientNr bleibt -1, Client wird nicht gefunden und neuer Client
      //erstellt
    }
    
    try {
      benutzerClient = new Client(clientNr);
    } catch (DatenNichtGefundenException e) {
      ErrorHandler.getInstance().handleError("Der benutzte Client " +        "konnte nicht bestimmt werden, da ein Client mit der Nummer '" +        clientNrString+"' nicht in der Datenbank eingetragen ist! Ein neuer " +        "Client wird erstellt!", false);
      try {
        benutzerClient = new Client();
        InetAddress inetAdress = InetAddress.getLocalHost();
        benutzerClient.setName(inetAdress.getHostName());
        benutzerClient.setIP(inetAdress.getHostAddress());
        benutzerClient.save();
        KonfigurationsDatei.getStandardKonfigurationsdatei().setProperty("ClientNr", 
          String.valueOf(benutzerClient.getNr()));
      } catch (Exception f) {
        ErrorHandler.getInstance().handleException(f, "Der benutzte Client " +
          "konnte nicht in die Datenbank eingetragen werden!", true);
      }
    }
    return benutzerClient;
  }
  
  /**
   * Holt die aktuelle Freigabe f�r den Client neu aus der Datenbank.
   */
  private void berechneAktuelleFreigabe() throws DatenNichtGefundenException {
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
          "select nr from internet_zugang where client = \"" + this.getNr() +
          "\" order by von DESC LIMIT 1");
      boolean freigabeGefunden = result.next();
      if (!freigabeGefunden) {
        aktuelleFreigabe = null;
      } else {
        int nr = result.getInt("Nr");
        aktuelleFreigabe = new Internetfreigabe(nr);
        if (!aktuelleFreigabe.istAktuell()) aktuelleFreigabe = null;
      }
      Datenbank.getInstance().releaseStatement(statement);

    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim holen der aktuellen "+
        "Internetfreigabe f�r den Rechner "+this.getName(), true);
    }
    zeitpunktLetztesLaden = System.currentTimeMillis();
  }

  /**
   * Liefert eine unsortierte Liste aller Clients, die in der Datenbank
   * eingetragen sind.
   *
   * @see ClientListe
   */
  public static ClientListe getAlleClients() {
    ClientListe liste = new ClientListe();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from client;");
      while (result.next()) {

        Client neuClient = new Client();

        neuClient.isSaved = true;
        neuClient.nr = result.getInt("nr");
        neuClient.name = result.getString("name");
        neuClient.ip = result.getString("ip");
        liste.addNoDuplicate(neuClient);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Clientliste!", true);
    }

    return liste;
  }

  /**
   * Gibt den Internetzugang f�r den �bergebenen Benutzer im Namen des aktuellen
   * Benutzers frei
   * @param benutzer der Benutzer, f�r den der Internetzugang freigegeben werden
   *   soll
   */
  public void internetZugangFreigeben(Benutzer benutzer,
    Mitarbeiter mitarbeiter) throws DatenNichtGefundenException {

    berechneAktuelleFreigabe();
    if (!istInternetzugangFreigegeben()) {
      aktuelleFreigabe = new Internetfreigabe(benutzer, this, mitarbeiter);
    }
  }

  /**
   * Bestimmt, ob der Internetzugang f�r diesen Client freigeschaltet ist
   * @return <code>true</code> gdw. der Internetzugang f�r diesen Client
   *   freigeschaltet ist
   */
  public boolean istInternetzugangFreigegeben() throws DatenNichtGefundenException {
    Internetfreigabe aktuelleFreigabe = getAktuelleInternetfreigabe();
    return (aktuelleFreigabe != null && aktuelleFreigabe.istFreigegeben());
  }

  /**
   * Gibt den Internetzugang f�r den �bergebenen Benutzer frei
   * @param benutzer der Benutzer, f�r den der Internetzugang freigegeben werden
   *   soll
   */
  public void internetZugangFreigeben(Benutzer benutzer) throws DatenNichtGefundenException {
    berechneAktuelleFreigabe();
    if (aktuelleFreigabe == null || !aktuelleFreigabe.istFreigegeben()) {
      aktuelleFreigabe = new Internetfreigabe(benutzer, this);
    }
  }

  /**
   * Sperrt den Internetzugang f�r den Client. Ist der Zugang nicht
   * freigegeben, wird keine Aktion ausgef�hrt.
   */
  public void internetZugangsSperren() throws DatenNichtGefundenException {
    berechneAktuelleFreigabe();
    if (aktuelleFreigabe.istFreigegeben()) {
      aktuelleFreigabe.sperren();
    }
  }


  /**
   * Liefert die aktuelle Freigabe des Clients.
   * Die aktuelle Freigabe, ist die zur Zeit aktive Freigabe oder die
   * letzte Freigabe des Clients, falls diese noch aktuell ist.
   * Existiert keine solche Freigabe, wird <code>null</code> null.
   *
   * @return die aktuelle Freigabe des Clients oder <code>null</code>, falls
   *   keine solche existiert
   */
  public Internetfreigabe getAktuelleInternetfreigabe() throws DatenNichtGefundenException {
    if ((System.currentTimeMillis() - zeitpunktLetztesLaden) > 1000*5) {
      berechneAktuelleFreigabe();
    }
    return aktuelleFreigabe;
  }

  /**
   * Erstellt einen neuen, bisher noch nicht in der Datenbank vorhandenen
   * Client. Alle Attribute des Clients werden mit Standardwerten
   * initialisiert. Insbesondere wird die Clientnr mit undefiniert
   * initialisiert. Beim ersten Speichern wird dann automatisch eine passende
   * Nummer zugewiesen.
   */
  public Client() {
    nr = 0;
    name = null;
    ip = null;
    aktuelleFreigabe = null;
    zeitpunktLetztesLaden = 0;
    isSaved = false;
  }
  
  /**
   * Erstellt ein neues <code>Client</code>-Objekt. Dazu wird der Client
   * mit der �bergebenen Benutzernummer aus der Datenbank geladen. Existiert
   * die Clientnummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param nr die Clientnummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Clientnr nicht in der
   *   Datenbank vorhanden ist
   */
  public Client(int nr) throws DatenNichtGefundenException {
    aktuelleFreigabe = null;
    zeitpunktLetztesLaden = 0;
    this.load(nr);
  }  

  /**
   * Liefert die IP des Clients.
   * Achtung: Es wird kein Konsitenzcheck durchgef�hrt. Es kann
   * also nicht garantiert werden, dass das Ergebnis eine
   * g�ltige IP-Adresse ist.
   * @return IP des Clients
   */
  public String getIP() {
    return ip;
  }

  /**
   * Liefert die Nr des Clients.
   * @return Nr des Clients
   */
  public int getNr() {
    return nr;
  }

  /**
   * Liefert den Namen des Clients.
   * @return den Namen des Clients
   */
  public String getName() {
    return name;
  }

  /**
   * Setzt die IP des Clients.
   * @param ip die neue IP
   */
  public void setIP(String ip) {
    isSaved = false;
    this.ip = ip;
    aktuelleFreigabe = null;
    zeitpunktLetztesLaden = 0;
    this.setChanged();
    this.notifyObservers();    
  }

  /**
   * Setzt den Namen des Clients.
   */
  public void setName(String name) {
    isSaved = false;
    this.name = name;
    this.setChanged();
    this.notifyObservers();    
  }

  /**
   * L�d die Daten zu der �bergebenen Clientnummer aus der Datenbank.
   * Existiert die Clientnummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param clientNr die Clientnummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Clientnr nicht in der
   *   Datenbank vorhanden ist
   */
  protected void load(int nr) throws DatenNichtGefundenException {
    isSaved = true;
    try {
      Statement statement = Datenbank.getInstance().getStatement();

      // Tabelle Medium lesen
      ladeClientStatement.setInt(1, nr);
      ResultSet result = ladeClientStatement.executeQuery();
      boolean clientGefunden = result.next();
      if (!clientGefunden) throw new DatenNichtGefundenException(
        "Ein Client mit der Nr "+nr+" existiert nicht!");

      this.nr = nr;
      name = result.getString("name");
      ip = result.getString("IP");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden des Clients mit der "+
        "Nummer "+nr+"!", true);
    }
  }
  
  /**
   * Bestimmt, ob es sich um einen neuen Client handelt, d.h. 
   * um einen Client, der gerade neu angelegt wird und noch nicht 
   * in der Datenbank gespeichert ist.
   *
   * @return <code>true</code> gdw der Client neu ist
   */
  public boolean istNeu() {
    return (nr == 0);
  }

  /**
   * L�d alle Daten des aktuellen Clients erneut aus der Datenbank. Ist der
   * Client noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls der Client inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    this.load(this.getNr());
  }
  
  /**
   * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
   * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
   *         <code>FALSE</code> sonst
   */
  public boolean istGespeichert() {
    return isSaved;
  }
  
  /**
   * L�scht den Client aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieser Client noch Beziehungen in der Datenbank
   * besitzt. Nur wenn keine solchen Beziehungen existieren, wird der Client gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *    Clients in der Datenbank existieren
   */
  public void loesche() throws DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);
      Statement statement = Datenbank.getInstance().getStatement();
      
      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(*) from internet_zugang where "+
        "Client = "+this.getNr());
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Client "+this.getName()+" ("+
          this.getNr()+") kann nicht gel�scht werden, da noch Freigaben " +          "dieses Clients existieren.");

      //Client l�schen
      statement.execute("delete from client where "+
        "nr = "+this.getNr());
        
      Datenbank.getInstance().releaseStatement(statement);      
      connection.commit();
      connection.setAutoCommit(true);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des "+
        "Clients "+this.toDebugString(), true);
    }
  }    
  
  public String toString() {
    return toDebugString();
  }
  
  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.getName()+" ("+this.getIP()+" / "+this.getNr()+")";
  }

  /**
   * Speichert den aktuellen Client bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws UnvollstaendigeDatenException 
   */
  public void save() throws UnvollstaendigeDatenException {
    if (isSaved) return;

    if (this.getName() == null || this.getName().trim().equals("")) {
      throw new UnvollstaendigeDatenException("Der Name jedes "+
        "Clients muss eingegeben sein.");
    }

    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);
      PreparedStatement statement = null;

      if (this.istNeu()) {
        nr = Client.getNeueClientnr();        
        statement = connection.prepareStatement(
          "insert into client set nr = "+nr+", Name = ?, IP = ?");
      } else {
        statement = connection.prepareStatement(
          "update client set Name = ?, IP = ? where nr="+this.getNr());
      }
      statement.setString(1, this.getName());
      statement.setString(2, Datenbank.entferneNullString(this.getIP()));

      statement.execute();
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des folgenden "+
        "Clients:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    this.setChanged();
    this.notifyObservers();
  }    
  
  /**
   * Bestimmt die gr��te verwendete Clientnummer.
   * @return die gr��te verwendete Clientnummer
   */
  public static int getGroessteClientnr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from client");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Clientnummer!", true);
    }

    return maxNr;
  }

  /**
   * Bestimmt die n�chste freie Clientnummer.
   * @return die n�chste freie Clientnummer
   */
  public static int getNeueClientnr() {
    return getGroessteClientnr()+1;
  }  
}
