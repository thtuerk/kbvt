/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.BitSet;

/**
* Diese Klasse repr�sentiert einen EAN13-Code.
* Bei diesen Barcodes stehen 12 Ziffern zur Codierung zur Verf�gung.
* Die 13. ist eine Pr�fziffer.
* Die in der B�cherei verwendeten Codes folgen folgendem Schema: <br><br>
*
* 2 Ziffern Typ:<br>
* &nbsp;&nbsp; - 20 Medium<br>
* &nbsp;&nbsp; - 21 Leser<br><br>
* f�r Leser:<br>
* &nbsp;&nbsp; - 10 Ziffern Lesernr <br><br>
* f�r Medium:<br>
* &nbsp;&nbsp; - 2 Stellen Medientyp<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 01 Buch<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 02 MC<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 03 CD<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 04 CD-ROM<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 05 Spiel<br>
* &nbsp;&nbsp;&nbsp;&nbsp; - 06 Video<br>
* &nbsp;&nbsp; - 4 Stellen Einstellungsjahr<br>
* &nbsp;&nbsp; - 4 Stellen Nr in Jahr<br><br>
*
* Diese Klasse erstellt neue EAN-Codes, berechnet und �berpr�ft die Pr�fziffern,
* liefert zu EAN-Nummern den passenden Datenbankeintrag. Au�erdem kann man die
* Strichcodedarstellung der Nummer erhalten.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.9 $
*/

public class EAN {

  private static final String[] codeA = {"000XX0X", "00XX00X", "00X00XX", "0XXXX0X", "0X000XX", "0XX000X", "0X0XXXX", "0XXX0XX", "0XX0XXX", "000X0XX"};
  private static final String[] codeB = {"0X00XXX", "0XX00XX", "00XX0XX", "0X0000X", "00XXX0X", "0XXX00X", "0000X0X", "00X000X", "000X00X", "00X0XXX"};
  private static final String[] codeC = {"XXX00X0", "XX00XX0", "XX0XX00", "X0000X0", "X0XXX00", "X00XXX0", "X0X0000", "X000X00", "X00X000", "XXX0X00"};
  private static final String[] ziffer1 = {"AAAAAA", "AABABB", "AABBAB", "AABBBA", "ABAABB", "ABBAAB", "ABBBAA", "ABABAB", "ABABBA", "ABBABA"};

  public static final int UnbekannterTypEAN = 0;
  public static final int MediumEAN = 1;
  public static final int BenutzerEAN = 2;

  private String nr; //die eigentliche EAN-Nr
  private Object referenz; // die Referenz auf das passende Datenbankobjekt
  private boolean typUndReferenzBestimmt = false;
  private int typ;

  /**
   * Pr�ft die EAN-Nr mit Hilfe der Pr�fziffer und sucht nach dem passenden
   * Eintrag in der Datenbank, der von dieser Nr repr�sentiert wird.
   *
   * @param ean die EAN-Nr, 12-stellige-Nummern werden um die Pr�fziffer
   *   erweitert, bei 13-stelligen wird die Pr�fziffer gecheckt
   * @throws IllegalArgumentException falls der �bergebene String nicht aus
   *  12 oder 13 Ziffern besteht oder der Check der Pr�fziffer fehlschl�gt
   */
  public EAN(String ean) {
    init(ean);

    //bestimme passendes Objekt und Typ;
    typ = UnbekannterTypEAN;
    referenz = null;
    typUndReferenzBestimmt = false;    
  }

  private void init(String ean) {
    EAN.checkEANSyntax(ean);
    int pruefziffer = EAN.berechnePruefziffer(ean);

    nr = ean;
    int laenge = ean.length();
    if (laenge == 12) nr = nr + pruefziffer;
    if (laenge == 13 && pruefziffer != Character.getNumericValue(nr.charAt(12)))
      throw new IllegalArgumentException("Die �bergebene EAN-Nr ist ung�ltig. "+
      "Die �berpr�fung der Pr�fziffer schlug fehl!");
  }
  
  /**
   * Erstellt den EAN-Code des �bergebenen Benutzers
   */
  public EAN(Benutzer benutzer) {
    StringBuffer eanBuffer = new StringBuffer();
    eanBuffer.append(benutzer.getBenutzerNr());
    while (eanBuffer.length() < 10) {
      eanBuffer.insert(0, "0");
    }
    eanBuffer.insert(0, "21");
        
    init(eanBuffer.toString());

    //bestimme passendes Objekt und Typ;
    typ = BenutzerEAN;
    referenz = benutzer;
    typUndReferenzBestimmt = true;    
  }


  private void bestimmeTypUndReferenz() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    typUndReferenzBestimmt = true;
    
    /* Eigentlich stehen 10 Ziffern f�r die Benutzernr zur Verf�gung
    so gro�e Zahlen sind als Benutzernummern aber unsinnig (welche B�cherei
    hat schon 10 Milliarden Leser ;-) Um den Datentyp int als Benutzernummer
    verwenden zu k�nnen, wird vorausgesetzt, dass die ersten 3 Ziffern 0
    sind. So sind nur noch 10 Millionen Benutzer m�glich, was aber gen�gen
    sollte. */
    if (nr.substring(0, 5).equals("21000")) {
      typ = BenutzerEAN;
    
      int benutzernr = Integer.parseInt(nr.substring(5,12));
      try {
        referenz = Benutzer.getBenutzer(benutzernr);
      } catch (DatenNichtGefundenException e) {
        referenz = null;
      }
    } else {
      //Medium
      
      typ = MediumEAN;
    
      try {
        Statement statement = Datenbank.getInstance().getStatement();
        ResultSet result = statement.executeQuery(
          "select Nr from medium where ean = \"" + nr + "\"");
        boolean mediumGefunden = result.next();
        if (mediumGefunden) {
          referenz = Medium.getMedium(result.getString("Nr"));
        }
    
        Datenbank.getInstance().releaseStatement(statement);
      } catch (SQLException e) {
        ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen des zur "+
          "EAN-Nr "+nr+" geh�renden Mediums!", true);
      }
    }
  }

  /**
   * Checkt, ob der �bergebene String eine g�ltige EAN sein kann. Es wird
   * nur der Syntax getestet, nicht die Pr�fziffer.
   *
   * @throws IllegalArgumentException falls der �bergebene String nicht aus
   *  12 oder 13 Ziffern besteht oder der Check der Pr�fziffer fehlschl�gt
   */
  private static void checkEANSyntax(String ean) {
    int laenge = ean.length();
    if (laenge != 12 && laenge != 13) throw new
      IllegalArgumentException("Die EAN-Nr muss 12 oder 13 Ziffern lang sein!"+
      " Sie ist aber "+laenge+" Ziffern lang!");

    for (int i = 0; i < ean.length(); i++) {
      if (Character.getType(ean.charAt(i)) != Character.DECIMAL_DIGIT_NUMBER)
        throw new IllegalArgumentException("Die EAN darf nur Ziffern "+
        "enthalten! An Position "+i+" des Argumentes '"+ean+"' steht aber '"+
        ean.charAt(i)+"'.");
    }
  }
  
  /**
   * Checkt, ob der �bergebene String eine g�ltige EAN sein kann. Ist dies
   * nicht der Fall wird <code>null</code> zur�ckgeliefert. Ansonsten wird
   * g�ltige EAN zur�ckgelierfert. Wird eine EAN mit Pr�fziffer �bergeben,
   * so wird die Pr�fziffer �berpr�ft, ansonsten wird die Pr�fziffer
   * erg�nzt.
   * @param ean die zu checkende EAN
   * @return <code>null</code> oder die g�ltige EAN
   */
  public static String checkEAN(String ean) {
    try {
      checkEANSyntax(ean);
    } catch (IllegalArgumentException e) {
      return null;
    }

    int pruefziffer = EAN.berechnePruefziffer(ean);

    int laenge = ean.length();
    if (laenge == 12) return ean + pruefziffer;
    if (laenge == 13 && pruefziffer != Character.getNumericValue(ean.charAt(12))) {
      return null;
    }
    
    return ean;
  }

  /**
   * Berechnet die Pr�fziffer der EAN
   * @param ean die Nummer, die gecheckt werden soll
   * @return die Pr�fziffer
   * @throws IllegalArgumentException, falls der �bergebene String nicht dem
   *  Syntax einer EAN-Nr entspricht
   */
  private static int berechnePruefziffer(String ean) {
    EAN.checkEANSyntax(ean);
    int pruefsumme = 0;
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(0));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(1));
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(2));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(3));
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(4));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(5));
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(6));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(7));
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(8));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(9));
    pruefsumme += 1 * Character.getNumericValue(ean.charAt(10));
    pruefsumme += 3 * Character.getNumericValue(ean.charAt(11));

    int pruefziffer = (10 - pruefsumme) % 10;
    if (pruefziffer < 0) pruefziffer+=10;
    return pruefziffer;
  }

  /**
   * Liefert den Typ der EAN-Nr, d.h. den Typ des Objektes, auf den die EAN
   * verweist. Die Typen sind als statische Konstanten dieser Klasse festgelegt
   *
   * @return Typ der EAN-Nr
   */
  public int getTyp() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!typUndReferenzBestimmt) bestimmeTypUndReferenz();
    return typ;
  }

  /**
   * Liefert das Objekt, auf das die EAN-Nr verweist.
   *
   * @return Objekt, auf das die EAN-Nr verweist
   */
  public Object getReferenz() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!typUndReferenzBestimmt) bestimmeTypUndReferenz();
    return referenz;
  }

  /**
   * Liefert die Strichcodedarstellung des EAN-Codes als Bitset. Ein gesetztes 
   * Bit bedeutet einen Strich, ein nicht gesetzes Bit eine L�cke. Die Striche und
   * L�cken d�rfen beliebig breit sein; sie m�ssen nur alle die gleiche Breite
   * besitzen.
   */
  public BitSet getBitSet() {
    StringBuffer erg = new StringBuffer();
    
    //Beginn
    erg.append("X0X");
    
    //Kodierung f�r die ersten 6 Ziffern bestimmen
    String kodierung = ziffer1[Character.getNumericValue(nr.charAt(0))];
    
    //erste 6 Ziffern (eigentlich 2-7). Die erste steckt in der Kodierung
    for (int i=1; i < 7; i++) {
      if (kodierung.charAt(i-1) == 'A') {
        erg.append(codeA[Character.getNumericValue(nr.charAt(i))]);
      } else {
        erg.append(codeB[Character.getNumericValue(nr.charAt(i))]);
      }
    }    
    
    //Trennzeichen
    erg.append("0X0X0");
    
    //letze 6 Ziffern 
    for (int i=7; i < 13; i++) {
      erg.append(codeC[Character.getNumericValue(nr.charAt(i))]);
    }
   
    //Ende
    erg.append("X0X");

    //Umwandlung in Bitset
    BitSet bitset = new BitSet(95);
    for (int i=0; i < erg.length(); i++) {
      if (erg.charAt(i) == 'X') {
        bitset.set(i);
      } else {
        bitset.clear(i);
      }
    }

    return bitset;
  }
  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    if (!typUndReferenzBestimmt) bestimmeTypUndReferenz();
    StringBuffer buffer = new StringBuffer();
    buffer.append("EAN-Nr  : "+nr+"\n");
    buffer.append("Typ     : ");
    switch (typ) {
      case MediumEAN:
        buffer.append("Medium"); break;
      case BenutzerEAN:
        buffer.append("Benutzer"); break;
    }
    buffer.append("\nReferenz: "+referenz);
    return buffer.toString();
  }

  public String toString() {
    return nr;
  }
}