/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.standarddialoge;

import javax.swing.*;
import java.awt.*;

/**
 * Diese Klasse zeigt einen Dialog an, der die Auswahl eines Datums aus einem
 * Kalender erm�glicht.
 */
public class WarteDialog extends JWindow {
  /**
   * Erzeugt eine neue Instanz, die den Dialog als Chield des �bergebenen
   * Frames anzeigt.
   *
   * @param mainWindow das Hauptfenster
   */
  public WarteDialog() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    this.pack();

    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation((dim.width - this.getWidth())/2, (dim.height - this.getHeight())/2);
  }


  private void jbInit() throws Exception {
    this.getContentPane().setLayout(new BorderLayout());

    java.net.URL iconURL = ClassLoader.getSystemResource(
      "de/oberbrechen/koeb/gui/standarddialoge/wartedialog.png");
    if (iconURL != null) {
      ImageIcon icon = new ImageIcon(iconURL);
      JLabel bild = new JLabel(icon);
      this.getContentPane().add(bild, BorderLayout.CENTER);

      this.setSize(icon.getIconWidth(), icon.getIconHeight());
    }
  }

}