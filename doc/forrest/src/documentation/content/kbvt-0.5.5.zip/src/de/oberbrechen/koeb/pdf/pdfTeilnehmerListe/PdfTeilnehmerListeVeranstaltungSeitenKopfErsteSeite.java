/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import com.lowagie.text.pdf.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.*;

import java.util.Iterator;

class PdfTeilnehmerListeVeranstaltungSeitenKopfErsteSeite
  implements SeitenKopfFuss{

  private final BaseFont schriftFett = PdfDokument.schriftFett;
  private final BaseFont schriftNormal = PdfDokument.schriftNormal;
  private final float schriftGroesse = 10;

  private Veranstaltung veranstaltung;
  private StandardSeitenKopfErsteSeite ueberschrift;

  public PdfTeilnehmerListeVeranstaltungSeitenKopfErsteSeite(
    Veranstaltung veranstaltung) {

    this.veranstaltung = veranstaltung;

    String teilnehmerAnzahl;
    if (veranstaltung.getTeilnehmerAnzahl() == 0)
      teilnehmerAnzahl = "keine Teilnehmer";
    else
      teilnehmerAnzahl = veranstaltung.getTeilnehmerAnzahl()+" Teilnehmer";
    ueberschrift = new StandardSeitenKopfErsteSeite(veranstaltung.getTitel(),
      null, teilnehmerAnzahl, null);
  }


  //Doku siehe bitte Interface
  public float getHoehe(int seitenNr) {
    float hoehe = ueberschrift.getHoehe(seitenNr);

    TerminListe termine = veranstaltung.getTermine();
    if (termine.size() > 2) hoehe += (termine.size() - 2)*12;
    return hoehe+60;
  }


  //Doku siehe bitte Interface
  public PdfTemplate getSeitenKopfFuss(ErweitertesPdfDokument pdfDokument,
    PdfContentByte pdf, int seitenNr) {

    float hoehe = this.getHoehe(seitenNr); 
    PdfTemplate template = pdf.createTemplate(
      pdfDokument.getSeitenBreite(), hoehe);

    PdfTemplate ueberschriftTemplate = ueberschrift.getSeitenKopfFuss(
      pdfDokument, pdf, seitenNr);
    template.addTemplate(ueberschriftTemplate, 0, 
      hoehe-ueberschriftTemplate.getHeight());
    hoehe -= ueberschrift.getHoehe(seitenNr) + 10;

    //bestimme Positionen
    float linkerRand = pdfDokument.getSeitenRandLinks();
    float rechterRand = pdfDokument.getSeitenBreite() -
                        pdfDokument.getSeitenRandRechts();
    float mitte = (rechterRand + linkerRand) / 2;

    //Texte bestimmen
    TerminListe termine = veranstaltung.getTermine();
    termine.setSortierung(TerminListe.chronologischeSortierung, false);
    String terminLabel = "Termin:";
    if (termine.size() > 1) terminLabel = "Termine:";
    String ansprechPartner = veranstaltung.getAnsprechpartner();
    if (ansprechPartner == null) ansprechPartner = "-";
    String bezugsGruppe = veranstaltung.getBezugsgruppe();
    if (bezugsGruppe == null) bezugsGruppe = "-";

    String kosten = veranstaltung.getKostenFormatiert();

    //bestimme Skalierung
    float skalierung = 1;
    float breiteAnsprechpartnerLabel =
      schriftFett.getWidthPoint("Ansprechpartner:", 10)+10;
    float maxBreite = schriftNormal.getWidthPoint(ansprechPartner, 10);
    float breite = schriftNormal.getWidthPoint(bezugsGruppe, 10);
    if (breite > maxBreite) maxBreite = breite;
    breite = schriftNormal.getWidthPoint(kosten, 10);
    if (breite > maxBreite) maxBreite = breite;
    maxBreite += breiteAnsprechpartnerLabel;

    Iterator it = termine.iterator();
    while(it.hasNext()) {
      Termin termin = (Termin) it.next();
      breite = schriftNormal.getWidthPoint(termin.getLangesTerminFormat(), 10);
      if (breite + 10 > maxBreite) maxBreite = breite+10;
    }

    if (maxBreite > ((rechterRand - linkerRand) / 2)) {
      skalierung = ((rechterRand - linkerRand) / 2) / maxBreite;
      breiteAnsprechpartnerLabel *= skalierung;
    }

    //Text ausgeben
    template.beginText();
    template.setFontAndSize(schriftFett, schriftGroesse);
    template.setHorizontalScaling(skalierung*100);

    template.setTextMatrix(mitte, hoehe);
    template.showText("Ansprechpartner:");
    template.setTextMatrix(linkerRand, hoehe);
    template.showText(terminLabel);
    template.setTextMatrix(mitte, hoehe-12);
    template.showText("Bezugsgruppe:");
    template.setTextMatrix(mitte, hoehe-24);
    template.showText("Kosten:");

    template.setFontAndSize(schriftNormal, schriftGroesse);
    template.setTextMatrix(mitte+breiteAnsprechpartnerLabel, hoehe);
    template.showText(ansprechPartner);
    template.setTextMatrix(mitte+breiteAnsprechpartnerLabel, hoehe-12);
    template.showText(bezugsGruppe);
    template.setTextMatrix(mitte+breiteAnsprechpartnerLabel, hoehe-24);
    template.showText(kosten);

    float y = hoehe-12;
    it = termine.iterator();
    while(it.hasNext()) {
      Termin termin = (Termin) it.next();
      template.setTextMatrix(linkerRand, y);
      template.showText(termin.getLangesTerminFormat());
      y-=12;
    }

    template.endText();

    hoehe -= 50;
    if (termine.size() > 2) hoehe -= 12*(termine.size() - 2);

    return template;
  }

  //Doku siehe bitte Interface
  public void finalisiere(int gesamtseitenAnzahl) {
  }
}
