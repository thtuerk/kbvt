/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.standarddialoge;

import de.oberbrechen.koeb.datenbankzugriff.*;
import javax.swing.*;
import java.awt.*;

/**
 * Diese Klasse zeigt einen Dialog an, der die �nderung des Passwortes eines
 * Benutzers oder eines Mitarbeiters erm�glicht.
 */
public class PasswortAendernDialog {

  private JFrame main;
  private JPanel ausgabe;
  private JTextField altesPasswortFeld;
  private JTextField neuesPasswortFeld;
  private JTextField bestaetigtesPasswort;
  private JLabel altesPasswortLabel;

  /**
   * Erzeugt eine neue Instanz, die den Dialog als Chield des �bergebenen
   * Frames anzeigt.
   *
   * @param mainWindow das Hauptfenster
   */
  public PasswortAendernDialog(JFrame mainWindow) {
    main = mainWindow;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Initialisiert den Dialog, d.h. setzt alle Eintr�ge zur�ck und bestimmt in
   * Abh�ngigkeit des Parameters checkOldPasswort, ob das Feld f�r die Eingabe
   * des alten Passworts angezeigt werden soll.
   * @param checkOldPasswort bestimmt, ob das Feld f�r die Eingabe
   *   des alten Passworts angezeigt werden soll
   */
  private void init(boolean checkOldPasswort) {
    SwingUtilities.updateComponentTreeUI(ausgabe);
    bestaetigtesPasswort.setText(null);
    neuesPasswortFeld.setText(null);
    altesPasswortFeld.setText(null);
    neuesPasswortFeld.grabFocus();
    altesPasswortFeld.setVisible(checkOldPasswort);
    altesPasswortLabel.setVisible(checkOldPasswort);

    if (checkOldPasswort) {
      altesPasswortFeld.grabFocus();
    } else {
      neuesPasswortFeld.grabFocus();
    }
  }

  /**
   * �ndert das Passwort des �bergebenen Benutzers
   * @param benutzer der Benutzer, dessen Passwort ge�ndert werden soll.
   * @param checkOldPasswort bestimmt, ob vor dem �ndern das
   *   bisherige Passwort abgefragt werden soll
   */
  public void changeBenutzerPasswort(Benutzer benutzer,
    boolean checkOldPasswort) {

    init(checkOldPasswort);

    int erg = JOptionPane.showConfirmDialog(main, ausgabe,"Passwort f�r "+
      benutzer.getName()+" �ndern", JOptionPane.OK_CANCEL_OPTION);
    if (erg != JOptionPane.OK_OPTION) return;

    if (checkOldPasswort &&
      !benutzer.checkPasswort(altesPasswortFeld.getText())) {

      JOptionPane.showMessageDialog(main, "Das Passwort kann nicht ge�ndert "+
        "werden, da das alte Passwort falsch eingegeben wurde.",
        "Altes Passwort ung�ltig!", JOptionPane.ERROR_MESSAGE);

      return;
    }

    if (!neuesPasswortFeld.getText().equals(bestaetigtesPasswort.getText())) {
      JOptionPane.showMessageDialog(main, "Das Passwort wurde nicht ge�ndert, "+
        "da sich das best�tigte Passwort unterschied.",
        "Best�tiges Passwort verschieden!", JOptionPane.ERROR_MESSAGE);
      return;
    }

    if (neuesPasswortFeld.getText() == null ||
        neuesPasswortFeld.getText().equals("")) {
      erg = JOptionPane.showConfirmDialog(main, "Soll das Passwort "+
        "deaktiviert werden?", "Passwort wirklich deaktivieren",
        JOptionPane.YES_NO_OPTION);

      if (erg == JOptionPane.YES_OPTION) benutzer.setPasswort(null);
      return;
    }

    benutzer.setPasswort(neuesPasswortFeld.getText());
  }

  /**
   * �ndert das Passwort des �bergebenen Mitarbeiters
   * @param mitarbeiter der Mitarbeiter, dessen Passwort ge�ndert werden soll.
   * @param ueberpruefeAltesPasswort bestimmt, ob vor dem �ndern das
   *   bisherige Passwort abgefragt werden soll
   */
  public void changeMitarbeiterPasswort(Mitarbeiter mitarbeiter,
    boolean checkOldPasswort) {

    init(checkOldPasswort);

    int erg = JOptionPane.showConfirmDialog(main, ausgabe,"Mitarbeiterpasswort "+
      "von "+mitarbeiter.getName()+" �ndern", JOptionPane.OK_CANCEL_OPTION);

    if (erg != JOptionPane.OK_OPTION) return;

    if (checkOldPasswort &&
      !mitarbeiter.checkMitarbeiterPasswort(altesPasswortFeld.getText())) {

      JOptionPane.showMessageDialog(main, "Das Passwort kann nicht ge�ndert "+
        "werden, da das alte Passwort falsch eingegeben wurde.",
        "Altes Passwort ung�ltig!", JOptionPane.ERROR_MESSAGE);

      return;
    }

    if (!neuesPasswortFeld.getText().equals(bestaetigtesPasswort.getText())) {
      JOptionPane.showMessageDialog(main, "Das Passwort wurde nicht ge�ndert, "+
        "da sich das best�tigte Passwort unterschied.",
        "Best�tiges Passwort verschieden!", JOptionPane.ERROR_MESSAGE);
      return;
    }

    if (neuesPasswortFeld.getText() == null ||
        neuesPasswortFeld.getText().equals("")) {
      erg = JOptionPane.showConfirmDialog(main, "Soll das Passwort "+
        "deaktiviert werden?", "Passwort wirklich deaktivieren",
        JOptionPane.YES_NO_OPTION);

      if (erg != JOptionPane.YES_OPTION) return;
    }

    mitarbeiter.setMitarbeiterPasswort(neuesPasswortFeld.getText());
  }

  private void jbInit() throws Exception {
    altesPasswortLabel = new JLabel();
    JLabel jLabel2 = new JLabel();
    JLabel jLabel3 = new JLabel();

    altesPasswortFeld = new JPasswordField();
    neuesPasswortFeld = new JPasswordField();
    bestaetigtesPasswort = new JPasswordField();
    ausgabe = new JPanel();
    ausgabe.setLayout(new GridBagLayout());

    altesPasswortLabel.setText("Bisheriges Passwort:");
    jLabel2.setText("Neues Passwort:");
    jLabel3.setText("Best�tigtes Passwort:");

    altesPasswortFeld.setPreferredSize(new Dimension(150, 21));

    neuesPasswortFeld.setPreferredSize(new Dimension(150, 21));
    bestaetigtesPasswort.setPreferredSize(new Dimension(150, 21));
    ausgabe.add(altesPasswortLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    ausgabe.add(altesPasswortFeld,    new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 10, 5, 0), 0, 0));
    ausgabe.add(jLabel2,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    ausgabe.add(neuesPasswortFeld,    new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 10, 5, 0), 0, 0));
    ausgabe.add(jLabel3,    new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 0), 0, 0));
    ausgabe.add(bestaetigtesPasswort,    new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 10, 5, 0), 0, 0));
  }

}