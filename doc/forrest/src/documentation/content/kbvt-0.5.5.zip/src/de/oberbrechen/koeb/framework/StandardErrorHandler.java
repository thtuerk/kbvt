/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.framework;

/**
 * Dieses Implementierung des ErrorHandlers gibt Meldungen 
 * auf System.err aus.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.2 $
 */
public class StandardErrorHandler extends ErrorHandler {

  public void handleException(Exception e, String beschreibung, boolean istKritisch) {
    System.err.println("Folgender Fehler trat auf:\n");
    if (beschreibung != null) System.err.println(beschreibung);
    System.err.println();
    System.err.println(e.getLocalizedMessage());
    System.err.println();
    e.printStackTrace(System.err);
    if (istKritisch) System.exit(1);
  }

  public void handleError(String beschreibung, boolean istKritisch) {
    System.err.println("Folgender Fehler trat auf:\n");
    if (beschreibung != null) System.err.println(beschreibung);
    System.err.println();
    if (istKritisch) System.exit(1);
  }
}