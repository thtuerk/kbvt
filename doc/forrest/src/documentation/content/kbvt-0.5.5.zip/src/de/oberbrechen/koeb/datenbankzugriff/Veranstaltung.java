/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.sql.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.Hashtable;
import java.util.Observable;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenstrukturen.TerminListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsteilnahmeListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse repr�sentiert eine Veranstaltung der B�cherei.
 * Sie stellt die Verbindung zur Datenbank her und Methoden, um
 * auf die Veranstaltung zuzugreifen, zur Verf�gung.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
*/

public class Veranstaltung extends Observable {

  // Statische Speicherung der Veranstaltungen
  private static Hashtable cache = new Hashtable();

  private static DecimalFormat waehrungsFormat = new DecimalFormat("0.00");

  /**
   * Liefert ein zur �bergebenen Veranstaltung passendes
   * <code>Veranstaltung</code>-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jede
   * Veranstaltung existiert nur ein Objekt.
   *
   * @param veranstaltungsnr die Nummer der Veranstaltung,
   *   die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  public static Veranstaltung getVeranstaltung(int veranstaltungsnr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    Veranstaltung erg = (Veranstaltung) cache.get(
      new Integer(veranstaltungsnr));
    if (erg == null) {
      erg = new Veranstaltung(veranstaltungsnr);
      cache.put(new Integer(veranstaltungsnr), erg);
    }
    return erg;
  }
  
  private boolean isSaved;  
  private TerminListe termine;
  private boolean anmeldungErforderlich;
  private double kosten;

  protected int teilnehmerAnzahl;
  private String titel, kurzTitel, ansprechpartner, beschreibung,  bezugsgruppe;
  private Veranstaltungsgruppe veranstaltungsgruppe;

  // Die Attribute der Veranstaltung wie in der Datenbank
  private int veranstaltungsNr, maxTeilnehmerAnzahl;
  private String waehrung;
  protected long zeitpunktLetztesTeilnehmerAnzahlLaden;

  /**
   * L�d das zum Parameter geh�rende
   * <code>Veranstaltung</code>-Objekt aus der Datenbank.
   * @param veranstaltungsNr die Nummer der Veranstaltung, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  private Veranstaltung(int veranstaltungsNr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    zeitpunktLetztesTeilnehmerAnzahlLaden = 0;
    load(veranstaltungsNr);
  }

  /**
   * Erstellt ein neues <code>Veranstaltung</code>-Objekt.
   * Standardw�hrung ist EUR, Standardkosten sind 0, eine
   * Anmeldung ist standardgem�� erforderlich, die 
   * Teilnehmeranzahl unbeschr�nkt. Alle anderen Werte werden
   * auf <code>null</code> gesetzt.
   */
  public Veranstaltung() {
    veranstaltungsgruppe = null;
    veranstaltungsNr = 0;

    isSaved = false;  
    termine = new TerminListe();
    anmeldungErforderlich = true;
    kosten = 0;

    titel = null;
    kurzTitel = null;
    ansprechpartner = null;
    beschreibung = null;
    bezugsgruppe = null;

    maxTeilnehmerAnzahl = 0;
    waehrung = "EUR";
    zeitpunktLetztesTeilnehmerAnzahlLaden = 0;
  }

  /**
   * L�d alle Daten der aktuellen Veranstaltung erneut aus der Datenbank. Ist die
   * Veranstaltung noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls die Veranstaltung inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    this.load(this.getVeranstaltungsNr());
    this.setChanged();
    this.notifyObservers();    
  }
  
  /**
   * Bestimmt, ob es sich um eine neue Veranstaltung handelt, d.h. um eine
   * Veranstaltung, die gerade neu angelegt wird und noch nicht in der Datenbank
   * gespeichert ist.
   *
   * @return <code>true</code> gdw die Veranstaltung neu ist
   */
  public boolean istNeu() {
    return (veranstaltungsNr == 0);
  }  

  /**
   * Bestimmt die gr��te verwendete Veranstaltungsnummer.
   * @return die gr��te verwendete Veranstaltungsnummer
   */
  public static int getGroessteVeranstaltungsnr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from veranstaltung");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Veranstaltungsnummer!", true);
    }

    return maxNr;
  }

  /**
   * Bestimmt die n�chste freie Veranstaltungsnummer.
   * @return die n�chste freie Veranstaltungsnummer
   */
  public static int getNeueVeranstaltungsnr() {
    return getGroessteVeranstaltungsnr()+1;
  }

  /**
   * Speichert die aktuelle Veranstaltung bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws UnvollstaendigeDatenException falls der Titel oder die Veranstaltungsgruppe nicht
   *  angegeben sind
   */
  public void save() throws UnvollstaendigeDatenException, 
    DatenNichtGefundenException, DatenbankInkonsistenzException {
      
    if (isSaved) return;

    if (this.getTitel() == null || this.getTitel().trim().equals("") || 
        this.getVeranstaltungsgruppe() == null) {
      throw new UnvollstaendigeDatenException("Titel und Veranstaltungsgruppe jeder "+
        "Veranstaltung m�ssen eingegeben sein.");
    }
    
    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);      
      PreparedStatement statement = null;

      if (this.istNeu()) {
        veranstaltungsNr = Veranstaltung.getNeueVeranstaltungsnr();
        statement = connection.prepareStatement(
          "insert into veranstaltung "+
          "SET nr = ?, titel = ?, kurzTitel = ?, "+
          "ansprechpartner = ?, beschreibung = ?, kosten = ?, " +          "bezugsgruppe = ?, veranstaltungsgruppe = ?, waehrung = ?, "+
          "anmeldung_erforderlich = ?, maximaleTeilnehmeranzahl = ?");
      } else {
        statement = connection.prepareStatement(
          "update veranstaltung "+
          "SET nr = ?, titel = ?, kurzTitel = ?, "+
          "ansprechpartner = ?, beschreibung = ?, kosten = ?, " +
          "bezugsgruppe = ?, veranstaltungsgruppe = ?, waehrung = ?, "+
          "anmeldung_erforderlich = ?, maximaleTeilnehmeranzahl = ? "+
          "where nr="+getVeranstaltungsNr());
      }
      statement.setLong(1,this.getVeranstaltungsNr());
      statement.setString(2, this.getTitel());
      statement.setString(3, Datenbank.entferneNullString(this.getKurzTitel()));
      statement.setString(4, Datenbank.entferneNullString(this.getAnsprechpartner()));
      statement.setString(5, Datenbank.entferneNullString(this.getBeschreibung()));
      statement.setDouble(6, this.getKosten());
      statement.setString(7, Datenbank.entferneNullString(this.getBezugsgruppe()));
      statement.setString(8, Datenbank.entferneNullString(this.getVeranstaltungsgruppe().getName()));
      statement.setString(9, Datenbank.entferneNullString(this.getWaehrung()));
      statement.setBoolean(10, this.istAnmeldungErforderlich());
      statement.setInt(11, this.getMaximaleTeilnehmerAnzahl());

      statement.execute();
      
      //Termine
      Statement termineLoeschStatement = Datenbank.getInstance().getStatement();
      termineLoeschStatement.execute("delete from termin " +        "where veranstaltung = "+getVeranstaltungsNr());
      Datenbank.getInstance().releaseStatement(termineLoeschStatement);
      
      Iterator it = termine.iterator();
      while (it.hasNext()) {
        Termin termin = (Termin) it.next();
        termin.insert();
      }
      
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Speichern der folgenden "+
        "Veranstaltung:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    this.setChanged();
    this.notifyObservers();
  }

  /**
   * L�scht die Veranstaltung aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob diese Veranstaltung noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise noch Benutzer f�r diese Veranstaltung
   * angemeldet sind. Nur
   * wenn keine solchen Beziehungen existieren, wird die Veranstaltung gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieser
   *  Veranstaltung in der Datenbank existieren
   */
  public void loesche() throws DatenbankInkonsistenzException {
    //nichts zu tun, falls Benutzer noch nicht gespeichert ist
    if (this.istNeu()) return;

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      berechneTeilnehmerAnzahl();
      if (this.getTeilnehmerAnzahl() > 0)
        throw new DatenbankInkonsistenzException("Die Veranstaltung '"+this.getTitel()+
        "' kann nicht gel�scht werden, da noch Teilnahmen an dieser Veranstaltung "+
        "existieren.");

      // Benutzer l�schen
      statement.execute("delete from veranstaltung where "+
        "Nr=\""+this.getVeranstaltungsNr()+"\"");
      statement.execute("delete from termin where "+
        "veranstaltung="+this.getVeranstaltungsNr());

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen der folgenden "+
        "Veranstaltung:\n\n"+this.toDebugString(), true);
    }
  }

  /**
   * L�d das zum Parameter geh�rende
   * <code>Veranstaltung</code>-Objekt aus der Datenbank.
   * @param veranstaltungsNr die Nummer der Veranstaltung, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  protected void load(int veranstaltungsNr)
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
  
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from veranstaltung where nr = \"" +
        veranstaltungsNr + "\"");
      boolean veranstaltungGefunden = result.next();
      if (!veranstaltungGefunden) throw new DatenNichtGefundenException(
        "Die Veranstaltung mit der Nummer "+veranstaltungsNr+
        " existiert nicht!");

      this.veranstaltungsNr = veranstaltungsNr;
      titel = result.getString("titel");
      kurzTitel = result.getString("kurzTitel");
      ansprechpartner = result.getString("ansprechpartner");
      bezugsgruppe = result.getString("bezugsgruppe");
      kosten = result.getDouble("kosten");
      beschreibung = result.getString("beschreibung");
      anmeldungErforderlich = result.getBoolean("anmeldung_erforderlich");
      waehrung = result.getString("waehrung");
      maxTeilnehmerAnzahl = result.getInt("maximaleTeilnehmerAnzahl");

      String veranstaltungsGruppeString =
        result.getString("veranstaltungsgruppe");
      try {
        veranstaltungsgruppe = Veranstaltungsgruppe.getVeranstaltungsgruppe(
          veranstaltungsGruppeString);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Veranstaltung mit der "+
          "Nummer "+veranstaltungsNr+" verweist auf die unbekannte "+
          "Veranstaltungsgruppe '"+veranstaltungsGruppeString+"'!");
      }

      termine = Termin.getAlleTermineDerVeranstaltung(this);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltung mit der Nummer "+veranstaltungsNr+"!", true);
    }
  }

  protected void berechneTeilnehmerAnzahl() {
    zeitpunktLetztesTeilnehmerAnzahlLaden = System.currentTimeMillis();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select count(benutzernr) from benutzer_besucht_veranstaltung "+
        "where veranstaltungsnr="+this.getVeranstaltungsNr());
      result.next();
      teilnehmerAnzahl = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der "+
        "Teilnehmeranzahl der Veranstaltung "+this.toString()+"!", true);
    }
  }

  /**
   * Liefert den Ansprechpartner der Veranstaltung
   * @return den Ansprechpartner der Veranstaltung
   */
  public String getAnsprechpartner() {
    return ansprechpartner;
  }

  /**
   * Liefert die Beschreibung der Veranstaltung
   * @return die Beschreibung der Veranstaltung
   */
  public String getBeschreibung() {
    return beschreibung;
  }

  /**
   * Liefert die Bezugsgruppe der Veranstaltung
   * @return die Bezugsgruppe der Veranstaltung
   */
  public String getBezugsgruppe() {
    return bezugsgruppe;
  }

  /**
   * Liefert die Kosten f�r diese Veranstaltung
   * @return die Kosten f�r diese Veranstaltung
   */
  public double getKosten() {
    return kosten;
  }

  /**
   * Liefert die Kosten f�r diese Veranstaltung als String
   * @return die Kosten im Format "0.00 "+Waehrung
   */
  public String getKostenFormatiert() {
    if (getKosten() == 0) {
      return "-";
    } else {
      return waehrungsFormat.format(getKosten())+" "+getWaehrung();
    }
  }

  /**
   * Liefert den gek�rzten Titel der Veranstaltung
   * @return den gek�rzten Titel der Veranstaltung
   */
  public String getKurzTitel() {
    return kurzTitel;
  }

  /**
   * Liefert die maximale Teilnehmeranzahl. Eine maximale Teilnehmeranzahl
   * von 0 bedeutet, dass beliebig viele Teilnehmer erlaubt sind.
   */
  public int getMaximaleTeilnehmerAnzahl() {
    return maxTeilnehmerAnzahl;
  }

  /**
   * Liefert eine sortierte Liste aller Teilnahmen an dieser Veranstaltung.
   * Die verf�gbaren Sortierungen sind �ber �ffentliche Konstanten der Klasse
   * VeranstaltungsteilnahmeListe ansprechbar
   *
   * @param sortierung die anzuwendende Sortierung
   * @param umgekehrteSortierung
   *   bestimmt, ob die Sortierung umgekehrt werden soll
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see VeranstaltungsgruppenListeListe
   * @return eine sortierte Liste aller Teilnahmen an dieser Veranstaltung
   */
  public VeranstaltungsteilnahmeListe getTeilnahmeListe(int sortierung,
    boolean umgekehrteSortierung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    VeranstaltungsteilnahmeListe liste = new VeranstaltungsteilnahmeListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from benutzer_besucht_veranstaltung "+
        "where veranstaltungsnr="+this.getVeranstaltungsNr());
      while (result.next()) {
        liste.add(new Veranstaltungsteilnahme(result.getInt("Nr")));
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "TeilnahmeListe der Veranstaltung "+this.toString()+"!", true);
    }
    liste.setSortierung(sortierung, umgekehrteSortierung);

    return liste;
  }

  /**
   * Bestimmt die Anzahl der Teilnehmer, die sich f�r diese Veranstaltung
   * bisher angemeldet haben.
   * @return die Anzahl der Teilnehmer, die sich f�r diese Veranstaltung
   *   bisher angemeldet haben
   */
  public int getTeilnehmerAnzahl() {
    if ((System.currentTimeMillis() - zeitpunktLetztesTeilnehmerAnzahlLaden)
      > 1000*20) {
      berechneTeilnehmerAnzahl();
    }

    return teilnehmerAnzahl;
  }

  /**
   * Liefert Liste aller Termine der Veranstaltung.
   * @return eine Liste der Termine der Veranstaltung
   */
  public TerminListe getTermine() {
    return termine;
  }

  /**
   * Liefert der Titel der Veranstaltung
   * @return den Titel der Veranstaltung
   */
  public String getTitel() {
    return titel;
  }

  /**
   * Liefert die Gruppe der Veranstaltung
   * @return die Gruppe der Veranstaltung
   */
  public Veranstaltungsgruppe getVeranstaltungsgruppe() {
    return veranstaltungsgruppe;
  }

  /**
   * Liefert die Nummer der Veranstaltung
   * @return die Nummer der Veranstaltung
   */
  public int getVeranstaltungsNr() {
    return veranstaltungsNr;
  }

  /**
   * Liefert die Waehrung, in der die Kosten dieser Veranstaltung angegeben
   * sind.
   */
  public String getWaehrung() {
    return waehrung;
  }

  /**
   * Bestimmt, ob f�r die Veranstaltung eine Anmeldung erforderlich ist
   * @return <code>true</code> gdw f�r die Veranstaltung
   *   eine Anmeldung erforderlich ist
   */
  public boolean istAnmeldungErforderlich() {
    return anmeldungErforderlich;
  }

  /**
   * Setzt, ob f�r die Veranstaltung eine Anmeldung erforderlich ist
   * @param anmeldungErforderlich f�r die Veranstaltung
   *   eine Anmeldung erforderlich ist
   */
  public void setAnmeldungErforderlich(boolean anmeldungErforderlich) {
    isSaved = false;
    this.anmeldungErforderlich = anmeldungErforderlich;
  }

  /**
   * Setzt den Ansprechpartner der Veranstaltung
   * @param der neue Ansprechpartner der Veranstaltung
   */
  public void setAnsprechpartner(String ansprechpartner) {
    isSaved = false;
    this.ansprechpartner = ansprechpartner;
  }

  /**
   * Setzt die Beschreibung der Veranstaltung
   * @param beschreibung die neue Beschreibung der Veranstaltung
   */
  public void setBeschreibung(String beschreibung) {
    isSaved = false;
    this.beschreibung = beschreibung;
  }

  /**
   * Setzt die Bezugsgruppe der Veranstaltung
   * @param bezugsgruppe die Bezugsgruppe der Veranstaltung
   */
  public void setBezugsgruppe(String bezugsgruppe) {
    isSaved = false;
    this.bezugsgruppe = bezugsgruppe;
  }

  /**
   * Setzt die Kosten f�r diese Veranstaltung
   * @param kosten die neuen Kosten f�r diese Veranstaltung
   */
  public void setKosten(double kosten) {
    isSaved = false;
    this.kosten = kosten;
  }

  /**
   * Setzt den gek�rzten Titel der Veranstaltung
   * @return kurzTitel der neue gek�rzte Titel der Veranstaltung
   */
  public void setKurzTitel(String kurzTitel) {
    isSaved = false;
    this.kurzTitel = kurzTitel;
  }

  /**
   * Setzt die maximale Teilnehmeranzahl. Eine maximale Teilnehmeranzahl
   * von 0 bedeutet, dass beliebig viele Teilnehmer erlaubt sind.
   * @param maxTeilnehmerAnzahl die neue maximale Teilnehmeranzahl
   */
  public void setMaximaleTeilnehmerAnzahl(int maxTeilnehmerAnzahl) {
    isSaved = false;
    this.maxTeilnehmerAnzahl = maxTeilnehmerAnzahl;
  }


  /**
   * Setzt die Termine der Veranstaltung.
   * @param termine die neuen Termine der Veranstaltung
   */
  public void setTermine(TerminListe termine) {
    isSaved = false;
    if (termine == null) throw new NullPointerException();

    this.termine.clear();
    this.termine.addAll(termine);
  }

  /**
   * Setzt den Titel der Veranstaltung
   * @param titel der neue Titel der Veranstaltung
   */
  public void setTitel(String titel) {
    isSaved = false;
    this.titel = titel;
  }

  /**
   * Setzt die Gruppe der Veranstaltung
   * @param die neue Gruppe der Veranstaltung
   */
  public void setVeranstaltungsgruppe(Veranstaltungsgruppe veranstaltungsgruppe) {
    isSaved = false;
    this.veranstaltungsgruppe = veranstaltungsgruppe;
  }

  /**
   * Setzt die W�hrung, in der die Kosten dieser Veranstaltung angegeben
   * sind.
   * @param waehrung die neue W�hrung
   */
  public void setWaehrung(String waehrung) {
    isSaved = false;
    this.waehrung = waehrung;
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.toString();
  }

  public String toString() {
    return titel+" ("+veranstaltungsNr+")";
  }

}