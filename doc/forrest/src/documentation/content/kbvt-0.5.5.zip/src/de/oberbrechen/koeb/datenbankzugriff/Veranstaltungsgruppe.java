/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;
import java.util.Observable;

/**
 * Diese Klasse repr�sentiert eine Veranstaltungsgruppe der B�cherei.
 * Sie stellt die Verbindung zur Datenbank her und Methoden, um
 * auf die Veranstaltungsgruppe zuzugreifen, zur Verf�gung.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 */

public class Veranstaltungsgruppe extends Observable {

  // Statische Speicherung der Veranstaltungsgruppen
  private static Hashtable cache = new Hashtable();

  /**
   * Liefert ein zur �bergebenen Veranstaltungsgruppe passendes
   * <code>Veranstaltungsgruppe</code>-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jede
   * Veranstaltungsgruppe existiert nur ein Objekt.
   *
   * @param veranstaltungsgruppe die Veranstaltungsgruppe,
   *   die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltungsgruppe nicht in der Datenbank existiert
   */
  public static Veranstaltungsgruppe getVeranstaltungsgruppe
    (String veranstaltungsgruppe) throws DatenNichtGefundenException {

    Veranstaltungsgruppe erg =
      (Veranstaltungsgruppe) cache.get(veranstaltungsgruppe);
    if (erg == null) {
      erg = new Veranstaltungsgruppe(veranstaltungsgruppe);
      cache.put(veranstaltungsgruppe, erg);
    }
    return erg;
  }

  // Die Attribute der Veranstaltungsgruppe wie in der Datenbank
  private String name, oldName, kurzName, beschreibung, homeDir;
  private boolean isSaved;

  /**
   * L�d das zum Parameter geh�rende
   * <code>Veranstaltungsgruppe</code>-Objekt aus der Datenbank.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltungsgruppe nicht in der Datenbank existiert
   */
  private Veranstaltungsgruppe(String veranstaltungsgruppe) throws DatenNichtGefundenException {
    load(veranstaltungsgruppe);
  }
  
  
  /**
   * Erstellt ein neues <code>Veranstaltungsgruppe</code>-Objekt.
   */
  public Veranstaltungsgruppe() {
    name = null;
    oldName = null;
    beschreibung = null;
    kurzName = null;
    homeDir = null;
  }

  /**
   * L�d das zum Parameter geh�rende
   * <code>Veranstaltungsgruppe</code>-Objekt aus der Datenbank.
   * @param veranstaltungsgruppe die Veranstaltungsgruppe, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltungsgruppe nicht in der Datenbank existiert
   */
  private void load(String veranstaltungsgruppe) throws DatenNichtGefundenException {    
    isSaved = true;
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from veranstaltungsgruppe where name = \"" +
        veranstaltungsgruppe + "\"");
      boolean veranstaltunggruppeGefunden = result.next();
      if (!veranstaltunggruppeGefunden) throw new DatenNichtGefundenException(
        "Die Veranstaltungsgruppe '"+veranstaltungsgruppe+"' existiert nicht!");

      name = veranstaltungsgruppe;
      oldName = name;
      kurzName = result.getString("kurzName");
      homeDir = result.getString("homeDir");
      beschreibung = result.getString("Beschreibung");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltungsgruppe '"+veranstaltungsgruppe+"'!", true);
    }
  }

  /**
   * Bestimmt die Anzahl der Teilnehmer, die sich f�r Veranstaltungen dieser
   * Veranstaltungsgruppe bisher angemeldet haben. Nimmt ein Benutzer an
   * mehreren Veranstaltungen der Gruppe teil, wird er nur einfach gez�hlt.
   * @return die Anzahl der Teilnehmer, die sich f�r Veranstaltungen dieser
   *   Veranstaltungsgruppe bisher angemeldet haben
   */
  public int getTeilnehmerAnzahl() {
    int teilnehmerAnzahl = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select count(DISTINCT bbv.benutzernr) from "+
        "benutzer_besucht_veranstaltung as bbv left join veranstaltung as v "+
        "on bbv.veranstaltungsnr = v.nr "+
        "where v.veranstaltungsgruppe=\""+this.getName()+"\"");
      result.next();
      teilnehmerAnzahl = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der "+
        "Teilnehmeranzahl der Veranstaltung "+this.toString()+"!", true);
    }

    return teilnehmerAnzahl;
  }

  /**
   * Liefert der Namen der Veranstaltungsgruppe
   * @return den Namen der Veranstaltungsgruppe
   */
  public String getName() {
    return name;
  }

  /**
   * Liefert die Beschreibung der Veranstaltungsgruppe
   * @return die Beschreibung der Veranstaltungsgruppe
   */
  public String getBeschreibung() {
    return beschreibung;
  }

  /**
   * Liefert den gek�rzten Namen der Veranstaltungsgruppe
   * @return den gek�rzten Namen der Veranstaltungsgruppe
   */
  public String getKurzName() {
    return kurzName;
  }

  /**
   * Liefert das Heimatverzeichnis der Veranstaltungsgruppe
   * @return die Heimatverzeichnis der Veranstaltungsgruppe
   */
  public String getHomeDir() {
    return homeDir;
  }

  public String toString() {
    return name;
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.toString();
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller
   * Veranstaltungen der Gruppe, die in der Datenbank eingetragen sind.
   *
   * @return eine sortierte Liste aller Veranstaltungen der Gruppe
   */
  public VeranstaltungenListe getVeranstaltungen() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    return getVeranstaltungen(
      VeranstaltungenListe.alphabetischeSortierung, false);
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller
   * Veranstaltungen der Gruppe, die in der Datenbank eingetragen sind.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * VeranstaltungsListe ansprechbar.
   *
   * @param sortierung die anzuwendende Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see VeranstaltungsgruppenListe
   * @return eine sortierte Liste aller Veranstaltungsgruppen
   */
  public VeranstaltungenListe getVeranstaltungen
    (int sortierung, boolean umgekehrteSortierung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    VeranstaltungenListe liste = new VeranstaltungenListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from veranstaltung where "+
        "veranstaltungsgruppe='"+this.getName()+"'");
      while (result.next()) {
        int nr = result.getInt("nr");
        Veranstaltung neueVeranstaltung = Veranstaltung.getVeranstaltung(nr);
        liste.add(neueVeranstaltung);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltungen der Veranstaltungsgruppe!", true);
    }
    liste.setSortierung(sortierung, umgekehrteSortierung);

    return liste;
  }

  /**
   * Liefert eine umgekehrt alphabetisch sortierte Liste aller
   * Veranstaltungsgruppen, die in der Datenbank eingetragen sind.
   *
   * @return eine sortierte Liste aller Veranstaltungsgruppen
   */
  public static VeranstaltungsgruppenListe getAlleVeranstaltungsgruppen() throws DatenNichtGefundenException {
    return getAlleVeranstaltungsgruppen(
      VeranstaltungsgruppenListe.alphabetischeSortierung, true);
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller
   * Veranstaltungen der Gruppe, f�r die eine Anmeldung erforderlich ist.
   *
   * @return eine sortierte Liste der Veranstaltungen der Gruppe
   */
  public VeranstaltungenListe getVeranstaltungenMitAnmeldung() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    return getVeranstaltungenMitAnmeldung(
      VeranstaltungenListe.alphabetischeSortierung, false);
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller
   * Veranstaltungen der Gruppe, f�r die eine Anmeldung erforderlich ist.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * VeranstaltungsListe ansprechbar.
   *
   * @param sortierung die anzuwendende Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see VeranstaltungsgruppenListe
   * @return eine sortierte Liste der Veranstaltungen
   */
  public VeranstaltungenListe getVeranstaltungenMitAnmeldung
    (int sortierung, boolean umgekehrteSortierung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    VeranstaltungenListe liste = new VeranstaltungenListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from veranstaltung where "+
        "veranstaltungsgruppe='"+this.getName()+"' AND "+
        "anmeldung_erforderlich <> 0");
      while (result.next()) {
        int nr = result.getInt("nr");
        Veranstaltung neueVeranstaltung = Veranstaltung.getVeranstaltung(nr);
        liste.add(neueVeranstaltung);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltungen der Veranstaltungsgruppe!", true);
    }

    liste.setSortierung(sortierung, umgekehrteSortierung);
    return liste;
  }

  /**
   * Liefert eine sortierte Liste aller Benutzer die sich f�r Veranstaltungen
   * dieser Veranstaltungsgruppe bisher angemeldet haben. Nimmt ein Benutzer an
   * mehreren Veranstaltungen der Gruppe teil, wird er nur einmal aufgenommen.
   * Die verf�gbaren Sortierungen sind �ber �ffentliche Konstanten der Klasse
   * BenutzerListe ansprechbar
   *
   * @param sortierung die anzuwendende Sortierung
   * @param umgekehrteSortierung
   *   bestimmt, ob die Sortierung umgekehrt werden soll
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see VeranstaltungsgruppenListeListe
   * @return eine sortierte Liste aller Teilnahmen an dieser Veranstaltung
   */
  public BenutzerListe getTeilnehmerListe(int sortierung,
    boolean umgekehrteSortierung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    BenutzerListe liste = new BenutzerListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select DISTINCT bbv.benutzernr from "+
        "benutzer_besucht_veranstaltung as bbv left join veranstaltung as v "+
        "on bbv.veranstaltungsnr = v.nr "+
        "where v.veranstaltungsgruppe=\""+this.getName()+"\"");
      while (result.next()) {
        liste.add(Benutzer.getBenutzer(result.getInt("benutzernr")));
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "TeilnehmerListe der Veranstaltungsgruppe "+this.getName()+"!", true);
    }

    liste.setSortierung(sortierung, umgekehrteSortierung);
    return liste;
  }

  /**
   * Liefert eine sortierte Liste aller Veranstaltungsgruppen,
   * die in der Datenbank eingetragen sind.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * VeranstaltungsgruppenListe ansprechbar.
   *
   * @param sortierung die anzuwendende Sortierung
   * @param umgekehrte Sortierung
   *   bestimmt, ob die Sortierung umgekehrt werden soll
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see VeranstaltungsgruppenListeListe
   * @return eine sortierte Liste aller Veranstaltungsgruppen
   */
  public static VeranstaltungsgruppenListe
    getAlleVeranstaltungsgruppen(int sortierung, boolean umgekehrteSortierung) throws DatenNichtGefundenException {

    VeranstaltungsgruppenListe liste = new VeranstaltungsgruppenListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select name from veranstaltungsgruppe");
      while (result.next()) {
        String name = result.getString("name");
        Veranstaltungsgruppe neueGruppe = getVeranstaltungsgruppe(name);
        liste.add(neueGruppe);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltungsgruppenliste!", true);
    }

    liste.setSortierung(sortierung, umgekehrteSortierung);
    return liste;
  }
    
  /**
   * Setzt die Beschreibung der Veranstaltungsgruppe
   * @param beschreibung die neue Beschreibung der Veranstaltungsgruppe
   */
  public void setBeschreibung(String beschreibung) {
    isSaved = false;
    this.beschreibung = beschreibung;
  }

  /**
   * Setzt das Heimatverzeichnis der Veranstaltungsgruppe
   * @param homeDir das neue Heimatverzeichnis der Veranstaltungsgruppe
   */
  public void setHomeDir(String homeDir) {
    isSaved = false;
    this.homeDir = homeDir;
  }

  /**
   * Setzt den gek�rzten Namen der Veranstaltungsgruppe
   * @param kurzName den neue gek�rzte Name der Veranstaltungsgruppe
   */
  public void setKurzName(String kurzName) {
    isSaved = false;
    this.kurzName = kurzName;
  }

  /**
   * Setzt den Namen der Veranstaltungsgruppe
   * @return name der neue Name der Veranstaltungsgruppe
   */
  public void setName(String name) {
    isSaved = false;
    this.name = name;
  }
  
  /**
   * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
   * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
   *         <code>FALSE</code> sonst
   */
  public boolean istGespeichert() {
    return isSaved;
  }  
  
  /**
   * L�d alle Daten der Veranstaltungsgruppe erneut aus der Datenbank. Ist die
   * Veranstaltungsgruppe noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls die Veranstaltungsguppe 
   *   inzwischen aus der Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException {
    if (this.istNeu()) return;
    this.load(this.getName());
    this.setChanged();
    this.notifyObservers();
  }  

  /**
   * Bestimmt, ob es sich um eine neue Veranstaltungsgruppe handelt, 
   * @return <code>true</code> gdw die Veranstaltungsgruppe neu ist
   */
  public boolean istNeu() {
    return (oldName == null);
  }
  
  /**
   * Speichert die aktuelle Veranstaltungsgruppe bzw 
   * die gemachten �nderungen in der
   * Datenbank
   *
   * @throws BenutzernameSchonVergebenException falls der Benutzername
   *  schon von einem anderen Benutzer verwendet wird
   * @throws EANSchonVergebenException falls die EAN
   *  schon von einem anderen Benutzer verwendet wird
   * @throws UnvollstaendigeDatenException 
   */
  public void save() throws MedienNrSchonVergebenException, DatenNichtGefundenException, DatenbankInkonsistenzException, UnvollstaendigeDatenException, EANSchonVergebenException {
    if (isSaved) return;

    if (this.getName() == null)
      throw new UnvollstaendigeDatenException("Der Name jeder Veranstaltungsgruppe" +        "muss eingegeben sein!");

    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);

      Statement normalStatement = Datenbank.getInstance().getStatement();
      if (!this.getName().equals(oldName)) {
        ResultSet result = normalStatement.executeQuery("select count(*) from veranstaltungsgruppe where name = \""+this.getName()+"\"");
        if (result.next() && result.getInt(1) > 0) {
          Veranstaltungsgruppe konfliktVeranstaltungsgruppe = 
            Veranstaltungsgruppe.getVeranstaltungsgruppe(name);
          throw new VeranstaltungsgruppeSchonVergebenException(
            konfliktVeranstaltungsgruppe);          
        }
        
        if (!istNeu()) {
          normalStatement.executeUpdate("update veranstaltung " +
            "set veranstaltungsgruppe = \""+getName()+"\" where " +                      "veranstaltungsgruppe = \""+oldName+"\"");          
        }
        
        Datenbank.getInstance().releaseStatement(normalStatement);
      }
                              
      PreparedStatement statement = null;
      if (this.istNeu()) {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "insert into veranstaltungsgruppe " +
          "set name = ?, kurzName = ?, "+
          "beschreibung = ?, homeDir = ?");
      } else {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "update veranstaltungsgruppe "+
          "set name = ?, kurzName = ?, "+
          "beschreibung = ?, homeDir = ? "+
          "where name=\""+oldName+"\"");
      }
      statement.setString(1, this.getName());
      statement.setString(2, this.getKurzName());
      statement.setString(3, this.getBeschreibung());
      statement.setString(4, this.getHomeDir());
      statement.execute();
            
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern der folgenden "+
        "Veranstaltungsgruppe:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    oldName = name;
    this.setChanged();
    this.notifyObservers();
  }    

  /**
   * L�scht die Veranstaltunsgruppe aus der Datenbank. 
   * Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob diese Veranstaltunsgruppe noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise Veranstaltungen dieser Gruppe existieren. Nur
   * wenn keine solchen Beziehungen existieren, wird die Veranstaltungsgruppe gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *    Mediums in der Datenbank existieren
   */
  public void loesche() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);
      Statement statement = Datenbank.getInstance().getStatement();
      
      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(*) from veranstaltung where "+
        "veranstaltungsgruppe=\""+oldName+"\"");
      result.next();
      if (result.getInt(1) > 0) {
        throw new DatenbankInkonsistenzException("Die Veranstaltungsgruppe '"+
        oldName+
        "' kann nicht gel�scht werden, da noch Veranstaltungen dieser Gruppe "+
        "existieren.");
      }

      // Medium l�schen
      statement.execute("delete from veranstaltungsgruppe where "+
        "name=\""+oldName+"\"");
        
      Datenbank.getInstance().releaseStatement(statement);      
      connection.commit();
      connection.setAutoCommit(true);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen der folgenden "+
        "Veranstaltungsgruppe:\n\n"+this.toDebugString(), true);
    }
  }
}