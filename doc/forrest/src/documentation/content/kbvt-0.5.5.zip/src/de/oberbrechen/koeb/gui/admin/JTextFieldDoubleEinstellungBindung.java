/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin;


import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;

import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.Client;
import de.oberbrechen.koeb.datenbankzugriff.Mitarbeiter;

/**
 * Diese Klasse dient dazu String-Einstellung an eine 
 * JTextField zu binden. Initial wird dem JTextField der Wert der 
 * Einstellung zugewiesen. Bei �nderung des JTextFields wird automatisch
 * der Einstellungswert in der Datenbank aktualisiert.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class JTextFieldDoubleEinstellungBindung implements JComponentEinstellungBindung {
    
  final Client client;
  final Mitarbeiter mitarbeiter;
  final String name;
  final String namespace;
  final double standard;
  final JTextField jTextField;
  final Einstellungen einstellungen;  
  final JFrame hauptFenster;
    
  /**
   * Erstellt eine neue JTextFieldIntEinstellungBindung, die
   * das �bergebene JTextField an die beschriebene Einstellung 
   * bindet und als Standardwert standard verwendet.
   * @param jCheckBox
   * @param client
   * @param mitarbeiter
   * @param namespace
   * @param name
   * @param standard
   */
  public JTextFieldDoubleEinstellungBindung(
    JFrame hauptFenster, JTextField jTextField, 
    Client client, Mitarbeiter mitarbeiter, String namespace, String name, 
    double standard) {
      
    this.hauptFenster = hauptFenster;
    this.client = client;
    this.mitarbeiter = mitarbeiter;
    this.name = name;
    this.namespace = namespace;
    this.standard = standard;
    this.jTextField = jTextField;
    einstellungen = Einstellungen.getInstance();

    init();
    refresh();
  }
  
  private void init() {
    final javax.swing.Timer timer = new javax.swing.Timer(500, 
      new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setzeWert(false);
      }
    });
    timer.setRepeats(false);
    
    jTextField.addKeyListener(new KeyListener() {

      public void keyTyped(KeyEvent e) {}
      public void keyReleased(KeyEvent e) {}

      public void keyPressed(KeyEvent e) {
        timer.restart();        
      }

    });
    jTextField.addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
      }
  
      public void focusLost(FocusEvent e) {
        setzeWert(true);
      }
    });
    jTextField.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        setzeWert(true);
      }    
    });
  }

  //Doku siehe bitte Interface
  public void refresh() {
    jTextField.setText(Double.toString(einstellungen.getEinstellungDouble(
      client, mitarbeiter, namespace, name, standard)));        
  }

  /**
   * Speichert den im Feld gespeicherten Wert in der Datenbank.
   * @param zeigeFehler sollen Fehler beim Speichern gemeldet oder
   *  ignoriert werden
   */
  void setzeWert(boolean zeigeFehler) {
    String value = jTextField.getText();
    try {
      double doubleValue = Double.parseDouble(value);
      einstellungen.setEinstellungDouble(client, mitarbeiter, namespace, name, 
        doubleValue);       
    } catch (NumberFormatException e) {
      if (zeigeFehler) {
        refresh();
        JOptionPane.showMessageDialog(hauptFenster, "Die Eingabe '"+
          value + "' kann\nnicht als Zahl interpretiert\n"+
          "werden!",
          "Ung�ltige Eingabe!",
          JOptionPane.ERROR_MESSAGE);
      }
    }    
    
  }
}