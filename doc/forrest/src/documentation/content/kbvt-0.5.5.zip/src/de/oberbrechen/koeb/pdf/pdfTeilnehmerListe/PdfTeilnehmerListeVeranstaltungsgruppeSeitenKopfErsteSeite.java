/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import com.lowagie.text.pdf.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;
import java.util.Iterator;

class PdfTeilnehmerListeVeranstaltungsgruppeSeitenKopfErsteSeite
  implements SeitenKopfFuss{

  private final BaseFont schriftFett = PdfDokument.schriftFett;

  private TabellenKopf normalerSeitenKopf;
  private StandardSeitenKopfErsteSeite ueberschrift;
  private VeranstaltungenListe veranstaltungenListe;

  public PdfTeilnehmerListeVeranstaltungsgruppeSeitenKopfErsteSeite(
    Veranstaltungsgruppe veranstaltungsgruppe,
    TabellenKopf normalerSeitenKopf) {

    this.normalerSeitenKopf = normalerSeitenKopf;

    veranstaltungenListe = veranstaltungsgruppe
                           .getVeranstaltungenMitAnmeldung();

    String teilnehmerAnzahl;
    if (veranstaltungsgruppe.getTeilnehmerAnzahl() == 0)
      teilnehmerAnzahl = "keine Teilnehmer";
    else
      teilnehmerAnzahl = veranstaltungsgruppe.getTeilnehmerAnzahl()+" Teilnehmer";
    ueberschrift = new StandardSeitenKopfErsteSeite(
      veranstaltungsgruppe.getName(), null, teilnehmerAnzahl, null);
  }

  //Doku siehe bitte Interface
  public float getHoehe(int seitenNr) {
    float hoehe = veranstaltungenListe.size()*10+30;
    if (normalerSeitenKopf.getHoehe(seitenNr) > hoehe)
      hoehe = normalerSeitenKopf.getHoehe(seitenNr);
    hoehe += ueberschrift.getHoehe(seitenNr);
    return hoehe;
  }

  //Doku siehe bitte Interface
  public float getBenoetigeSpaltenBreite(int spaltenNr) {
    return normalerSeitenKopf.getBenoetigeSpaltenBreite(spaltenNr);
  }

  //Doku siehe bitte Interface
  public PdfTemplate getSeitenKopfFuss(ErweitertesPdfDokument pdfDokument, 
    PdfContentByte pdf, int seitenNr) {

    float maxHoehe = normalerSeitenKopf.getMaximalHoehe();

    float yPos = this.getHoehe(seitenNr); 
    PdfTemplate template = pdf.createTemplate(
      pdfDokument.getSeitenBreite(), yPos);

    PdfTemplate ueberschriftTemplate = ueberschrift.getSeitenKopfFuss(
      pdfDokument, pdf, seitenNr);
    template.addTemplate(ueberschriftTemplate, 0, 
      yPos-ueberschriftTemplate.getHeight());

    //bestimme Positionen f�r Statistikbox
    TabellenModell tabellenModell = normalerSeitenKopf.getTabellenModell();
    float linkerRand = pdfDokument.getSeitenRandLinks();
    float rechterRand = pdfDokument.getSeitenRandLinks()+
      tabellenModell.getBreite(1)+tabellenModell.getBreite(2)+
      tabellenModell.getBreite(3)+tabellenModell.getBreite(4)+
      tabellenModell.getSpaltenAbstand(1)+tabellenModell.getSpaltenAbstand(2)+
      tabellenModell.getSpaltenAbstand(3);
    float hoehe = veranstaltungenListe.size()*10+10;
    if (hoehe > maxHoehe) normalerSeitenKopf.setMaximalHoehe(hoehe);

    //Skalierung
    float[] spaltenBreite = new float[3];
    Iterator it = veranstaltungenListe.iterator();
    while (it.hasNext()) {
      Veranstaltung veranstaltung = (Veranstaltung) it.next();
      float breite = schriftFett.getWidthPoint(veranstaltung.getTitel(), 8);
      if (breite > spaltenBreite[0]) spaltenBreite[0] = breite;

      breite = schriftFett.getWidthPoint(
        Integer.toString(veranstaltung.getTeilnehmerAnzahl()), 8);
      if (breite > spaltenBreite[1]) spaltenBreite[1] = breite;
    }

    float spaltenBreiteSumme = spaltenBreite[0]+spaltenBreite[1];

    float skalierung = 1;
    if (spaltenBreiteSumme + 10 > rechterRand - linkerRand - 10) {
      skalierung = (rechterRand - linkerRand - 10) / (spaltenBreiteSumme+10);
    }

    template.setGrayFill((float) 0.8);
    template.setHorizontalScaling(skalierung*100);
    template.rectangle(linkerRand, yPos-hoehe-ueberschrift.getHoehe(seitenNr), 
      rechterRand-linkerRand, hoehe);
    template.fillStroke();
    template.setGrayFill(0);

    //Texte ausgeben
    float y = yPos-ueberschrift.getHoehe(seitenNr)-3;
    template.beginText();
    template.setFontAndSize(schriftFett, 8);

    it = veranstaltungenListe.iterator();
    while (it.hasNext()) {
      Veranstaltung veranstaltung = (Veranstaltung) it.next();
      y -= 10;

      float x = linkerRand+5;
      template.setTextMatrix(x, y);
      template.showText(veranstaltung.getTitel());

      String text = Integer.toString(veranstaltung.getTeilnehmerAnzahl());
      x = rechterRand-5-(schriftFett.getWidthPoint(text, 8))*skalierung;
      template.setTextMatrix(x, y);
      template.showText(text);
    }
    template.endText();

    PdfTemplate normalerSeitenKopfTemplate =
      normalerSeitenKopf.getSeitenKopfFuss(pdfDokument, template, seitenNr);
    template.addTemplate(normalerSeitenKopfTemplate, 0, 0);
    normalerSeitenKopf.setMaximalHoehe(maxHoehe);
        
    return template;
  }

  //Doku siehe bitte Interface
  public void finalisiere(int gesamtseitenAnzahl) {
    //Nichts zu tun
  }
}

