/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;

import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.framework.KonfigurationsDatei;

/**
* Diese Klasse stellt die grundlegenden Funktionalit�t f�r den Zugriff auf
* die Datenbank zur Verf�gung. Sie stellt eine Verbindung mit der Datenbank her
* und stellt diese <code>Connection</code> sowie <code>Statement</code>-
* Objekte zur Verf�gung. <br>
* Au�erdem bietet sie grundlegende Funktionen zur Konvertierung der in der
* Datenbank verwendeten Datentypen.<br>
* Um m�glichst einfachen Zugriff zu gew�hrleisten, ist diese Klasse
* als Singleton realisiert.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class Datenbank {

  // die statische Instanz f�r das Signleton
  private static Datenbank datenbankInstanz = null;

  // die Verbindung mit der Datenbank
  private Connection verbindung;

  // Queue in der verf�gbare Statements gespeichert werden
  private LinkedList cache;

  /* dieses Pattern wird f�r die Formatierung und das Parsen eines Datums
   * verwendet. Siehe auch SimpleDateFormat
   */
  private static String datumsformat = "dd.MM.yyyy";
  private SimpleDateFormat datumsFormatierer;


  /**
   * Liefert ein verf�gbares Statement zur�ck.
   * Die Erzeugung neuer <code>Statement</code>-Objekte ist aufwendig. Daher
   * werden vorhandene Objekte wiederverwendet. Die Methode <code>getStatemet
   * </code> liefert ein verf�gbares, nicht aber notwendigerweise neu erzeugtes
   * Statement.
   *
   * @return verf�gbares Statement
   * @see #releaseStatement
   */
  public Statement getStatement() {
    if (cache.isEmpty()) {
      try {
        return verbindung.createStatement();
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, 
          "Fehler beim Erzeugen eines neuen Statements!", true);
      }
      return null;
    } else {
      return (Statement) cache.removeFirst();
    }
  }


   /**
   * Wandelt den leeren String '' in <code>null</code> um.
   * @param testString der zu testende String
   * @return den �bergebenen String oder <code>null</code> falls dieser leer ist
   */
  public static String entferneNullString(String testString) {
    if (testString == null || testString.equals("")) return null;
    return testString;
  }

  /**
   * Wandlet <code>null</code< in den leeren String '' um.
   * @param string der zu bearbeitetende String
   * @return der �berarbeitete String
   */
  public static String erstelleNullString(String string) {
    if (string == null) return "";
    return string;
  }

 /**
   * Gibt ein Statement zur Verwendung frei.
   * Die Erzeugung neuer <code>Statement</code>-Objekte ist aufwendig. Daher
   * werden vorhandene Objekte wiederverwendet. Die Methode
   * <code>releaseStatemet</code> markiert das �bergebene Statement als
   * verf�gbar.
   *
   * @param statement das freizugebende Statement
   * @see #getStatement
   */
  public void releaseStatement(Statement statement) {
    cache.addLast(statement);
  }


  /**
   * Liefert ein <code>Connection</code>-Objekt, das zur ge�ffneten Datenbank
   * geh�rt.
   *
   * @return Connection-Objekt
   */
  public Connection getConnection() {
     return verbindung;
  }


  /**
   * Entsprechend dem Sigelton-Pattern liefert diese Methode eine Instanz der
   * <code>Datenbank</code>-Klasse.
   *
   * @return Instanz der <code>Datenbank</code>-Klasse
   */
  public static Datenbank getInstance() {
     if (datenbankInstanz == null) datenbankInstanz = new Datenbank();
     return datenbankInstanz;
  }

  public Datenbank() {
    String configString = null;
    try {
      KonfigurationsDatei confDatei =
      KonfigurationsDatei.getStandardKonfigurationsdatei();

      String host          = confDatei.getProperty("MySQL-Host");
      String port          = confDatei.getProperty("MySQL-Port");
      String datenbankname = confDatei.getProperty("MySQL-Datenbankname");
      String user          = confDatei.getProperty("MySQL-User");
      String passwort      = confDatei.getProperty("MySQL-Passwort");

      configString =  "Host:          "+host+"\n";
      configString += "Port:          "+port+"\n";
      configString += "Datenbankname: "+datenbankname+"\n";
      configString += "User:          "+user+"\n";
      configString += "Passwort:      "+passwort;

      Class.forName("org.gjt.mm.mysql.Driver");
      verbindung = DriverManager.getConnection("jdbc:mysql://"+
        host+":"+port+"/"+datenbankname+"?user="+user+"&password="+passwort);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Verbinden mit Datenbank schlug fehl! Folgende "+
       "Einstellungen wurden verwendet:\n\n"+configString, true);
    }

    cache = new LinkedList();
    datumsFormatierer = new SimpleDateFormat(datumsformat);
  }


  /**
   * Formatiert das �bergebene Datum
   * @param datum das zu formatierende Datum
   * @return eine Stringrepr�sentation des Datums
   */
  public String formatDatum(java.util.Date datum) {
    return datumsFormatierer.format(datum);
  }
}