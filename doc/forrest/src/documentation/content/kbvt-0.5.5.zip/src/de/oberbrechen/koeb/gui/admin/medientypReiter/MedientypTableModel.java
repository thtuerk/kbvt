/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.medientypReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.MedientypSchonVergebenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.UnvollstaendigeDatenException;

import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.MedientypListe;
import de.oberbrechen.koeb.gui.admin.Main;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Medientypen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class MedientypTableModel extends AbstractTableModel {

  private Main hauptFenster;
	private MedientypListe daten;
  
  public MedientypTableModel(Main hauptFenster) {
    this.hauptFenster = hauptFenster;
  }
  
  public void refresh() {
    daten = Medientyp.getAlleMedientypen();
    daten.setSortierung(MedientypListe.StringSortierung, false);
    fireTableDataChanged();
  }
  
  public MedientypListe getDaten() {
    return daten;
  } 
    
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 2;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Name";
    if (columnIndex == 1) return "Plural";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Medientyp gewaehlterMedientyp = (Medientyp) daten.get(rowIndex);
    
    if (columnIndex == 0) {
      return gewaehlterMedientyp.getName();
    }
    if (columnIndex == 1) {
      return gewaehlterMedientyp.getPlural();
    }
    
    return "nicht definierte Spalte";
  }

  public Medientyp getMedientyp(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Medientyp) daten.get(rowIndex);
  }
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return true;
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    String oldValue = null;
    Medientyp medientyp = getMedientyp(rowIndex);
    try {      
      if (columnIndex == 0) {
        oldValue = medientyp.getName();
        medientyp.setName(aValue.toString());         
        medientyp.save();
      } else if (columnIndex == 1) {
        oldValue = medientyp.getPlural();
        medientyp.setPlural(aValue.toString());
        medientyp.save();          
      } else {
        throw new IndexOutOfBoundsException();
      }
      this.fireTableDataChanged();
      return;
    } catch (MedientypSchonVergebenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Medientyp schon vergeben!",
        JOptionPane.ERROR_MESSAGE);      
    } catch (UnvollstaendigeDatenException e) {
      JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
        "Unvollst�ndige Daten!",
        JOptionPane.ERROR_MESSAGE);      
    }

    if (columnIndex == 0) {
      medientyp.setName(oldValue);         
    } else if (columnIndex == 1) {
      medientyp.setPlural(oldValue);
    }
    this.fireTableDataChanged();
  }

}
