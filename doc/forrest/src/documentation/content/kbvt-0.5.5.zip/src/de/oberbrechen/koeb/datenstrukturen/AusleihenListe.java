/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import java.util.Comparator;
import java.text.Collator;

/**
* Diese Klasse repr�sentiert eine sortierte Liste von Ausleihen. Eine Ausleihe
* ist eindeutig �ber ihre Nummer identifiziert und wird nur einmal in
* die Liste aufgenommen. Es ist zu
* beachten, dass �berall nur Ausleihe-Objekte statt allgemeiner Objekte als
* Parameter �bergeben werden d�rfen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.7 $
*/

public class AusleihenListe extends Liste {

  /**
   * Ausleihen werden alphabetisch zuerst nach ihrem Titel und dann nach dem
   * Autor ihres Mediums sortiert
   */
  public static final int MedienTitelSortierung = 2;

  /**
   * Ausleihen werden nach ihrem Ausleihdatum sortiert
   */
  public static final int AusleihdatumSortierung = 3;

  /**
   * Ausleihen werden nach ihrem Sollr�ckgabedatum sortiert
   */
  public static final int SollrueckgabeDatumSortierung = 4;

  /**
   * Ausleihen werden nach ihrer Nummer sortiert
   */
  public static final int AusleihenNrSortierung = 5;

  /**
   * Ausleihen werden alphabetisch nach der MedienNr sortiert
   */
  public static final int MedienNrSortierung = 6;

  protected Comparator getComparatorFuerSortierung(int sortierung) {
    final Comparator sort;
    final Collator col = Collator.getInstance();

    switch (sortierung) {
      case MedienTitelSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Medium mediumA = ((Ausleihe) a).getMedium();
              String titelA = "?";
              String autorA = "?";
              if (mediumA != null) {
                titelA = mediumA.getTitel();
                autorA = mediumA.getAutor();
              }

              Medium mediumB = ((Ausleihe) b).getMedium();
              String titelB = "?";
              String autorB = "?";
              if (mediumB != null) {
                titelB = mediumB.getTitel();
                autorB = mediumB.getAutor();
              }
              
              int erg = col.compare(titelA, titelB);
              if (erg == 0) erg = col.compare(autorA, autorB);

              if (erg != 0) return erg;
              if (!((Ausleihe) a).istZurueckgegeben()) return 1;
              if (!((Ausleihe) b).istZurueckgegeben()) return -1;
              return ((Ausleihe) a).getRueckgabedatum().compareTo(((Ausleihe) b).getRueckgabedatum());
            }};
        break;
      }

      case MedienNrSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              Medium mediumA = ((Ausleihe) a).getMedium();
              Medium mediumB = ((Ausleihe) b).getMedium();
              String nrA = mediumA.getMedienNr();
              String nrB = mediumB.getMedienNr();

              int erg = col.compare(nrA, nrB);

              if (erg != 0) return erg;
              if (!((Ausleihe) a).istZurueckgegeben()) return 1;
              if (!((Ausleihe) b).istZurueckgegeben()) return -1;
              return ((Ausleihe) a).getRueckgabedatum().compareTo(((Ausleihe) b).getRueckgabedatum());
            }};
        break;
      }

      case SollrueckgabeDatumSortierung : {
        sort = new Comparator() {
            public int compare(Object a, Object b) {
              int erg = ((Ausleihe) a).getSollRueckgabedatum().compareTo(((Ausleihe) b).getSollRueckgabedatum());
              
              if (erg != 0) return erg;
              Comparator comp = getComparatorFuerSortierung(MedienTitelSortierung);                
              return comp.compare(a, b);
            }};
        break;
      }

      case AusleihdatumSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            int erg = ((Ausleihe) a).getAusleihdatum().compareTo(((Ausleihe) b).getAusleihdatum());

            if (erg != 0) return erg;
            Comparator comp = getComparatorFuerSortierung(MedienTitelSortierung);                
            return comp.compare(a, b);
        }};
        break;
      }

      //Nummer Sortierung
      case AusleihenNrSortierung : {
        sort = new Comparator() {
          public int compare(Object a, Object b) {
            return ((Ausleihe) a).getAusleihNr() - ((Ausleihe) b).getAusleihNr();
        }};
        break;
      }

      default:
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
    }

    return sort;
  }
}
