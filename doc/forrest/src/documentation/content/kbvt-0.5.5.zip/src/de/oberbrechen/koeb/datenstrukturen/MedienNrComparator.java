/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenstrukturen;

import java.util.Comparator;
import java.text.Collator;
import java.util.StringTokenizer;

/**
* Diese Klasse dient dazu zwei Mediennr miteinander zu vergleichen. Je nachdem
* welche Mediennummer verwendet werden, muss der Vergleich unterschiedlich
* ausgef�hrt werden. Diese Klasse zerlegt die Nummer in 2-3 Teile, den Medientyp
* , das Einstellungsjahr und die Einstellungsnummer im Jahr. Diese Medien
* werden lexikographisch verglichen. Beispielsweise wird B 2002-20 in
* B, 2002 und 20 verlegt.
*
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class MedienNrComparator implements Comparator {

  private Collator collocator = Collator.getInstance();

  public int compare(Object a, Object b) {
    try {
      StringTokenizer stringTokenizerA = new StringTokenizer(a.toString(), " -");
      StringTokenizer stringTokenizerB = new StringTokenizer(b.toString(), " -");

      // Medientypvergleich
      if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
        String tokenA = stringTokenizerA.nextToken();
        String tokenB = stringTokenizerB.nextToken();

        int erg = collocator.compare(tokenA, tokenB);
        if (erg != 0) return erg;
      }

      // Jahresvergleich
      if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
        int tokenA = Integer.parseInt(stringTokenizerA.nextToken());
        int tokenB = Integer.parseInt(stringTokenizerB.nextToken());

        int erg = tokenA - tokenB;
        if (erg != 0) return erg;
      }

      // Nummernvergleich
      if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
        int tokenA = Integer.parseInt(stringTokenizerA.nextToken());
        int tokenB = Integer.parseInt(stringTokenizerB.nextToken());

        int erg = tokenA - tokenB;
        if (erg != 0) return erg;
      }

      if (stringTokenizerA.hasMoreTokens() && stringTokenizerB.hasMoreTokens()) {
        throw new Exception("Unerwartetes Mediennummernformat");
      }
      if (!stringTokenizerA.hasMoreTokens()) return -1;
      if (!stringTokenizerB.hasMoreTokens()) return 1;
      return 0;
    } catch (Exception e) {
      // unerwartetes Medienformat
      return collocator.compare(a.toString(), b.toString());
    }

  }

}
