/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.util.Iterator;
import java.util.Hashtable;
import java.util.Observable;
import java.sql.*;
import java.util.Date;

/**
* Diese Klasse repr�sentiert ein Medium der B�cherei. Es stellt die
* Verbindung zur Datenbank her und Methoden, um das Medium zu manipulieren.
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.12 $
*/

public class Medium extends Observable {

  // Die Attribute des Mediums wie in der Datenbank
  private String nr, oldNr, titel, autor, beschreibung;
  private EAN ean;
  private Medientyp medientyp;
  private int medienAnzahl;
  private Date eingestellt_seit, aus_Bestand_entfernt;

  //die Systematiken, zu denen das Medium direkt geh�rt
  private SystematikListe systematiken;
  private boolean datenGeladen;
  private boolean isSaved;

  // Statische Speicherung des Mediums
  private static Hashtable cache = new Hashtable();

  private static MedienListe alleMedienTitel = null;
  private static MedienListe alleMedienNr = null;

  private static PreparedStatement ladeMediumStatement;
  static{
    try {
      ladeMediumStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select * from medium where nr = ?");
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Unerwarteter Fehler beim " +        "Initialisieren der Statements f�r Medium!", true);
    }
  }

  /**
   * Liefert das zur �bergebenen Mediennr passende Medium-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jedes Medium
   * existiert nur ein Objekt.
   *
   * @param mediennr die Mediennummer, die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene Mediennummer
   *  nicht in der Datenbank existiert
   */
  public static Medium getMedium(String mediennr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    Medium erg = (Medium) cache.get(mediennr);
    if (erg == null) {
      erg = new Medium(mediennr);
      cache.put(mediennr, erg);
    }
    return erg;
  }

  /**
   * Erstellt ein neues <code>Medium</code>-Objekt. Dazu wird das Medium
   * mit der �bergebenen Mediennummer aus der Datenbank geladen. Existiert
   * die Mediennummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param medienNr die Mediennummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Mediennr nicht in der
   *   Datenbank vorhanden ist
   * @throws DatenbankInkonsistenzException falls eine Inkonsitenz in der
   *   Datenbank auftritt
   */
  private Medium(String medienNr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.load(medienNr);
  }

  /**
   * Erstellt ein neues <code>Medium</code>-Objekt. Dazu wird das Medium
   * mit der �bergebenen Mediennummer erst bei Bedarf aus der Datenbank geladen.
   *
   * @param medienNr die Mediennummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @param titel der Titel des Mediums
   * @param autor der Autor des Mediums
   */
  private Medium(String medienNr, String titel, String autor) {
    beschreibung = null;
    ean = null;
    medientyp = null;
    medienAnzahl = 1;
    eingestellt_seit = null;
    aus_Bestand_entfernt = null;

    nr = medienNr;
    oldNr = medienNr;
    this.titel = titel;
    this.autor = autor;
    datenGeladen = false;
    isSaved = true;
  }

  /**
   * Erstellt ein neues <code>Medium</code>-Objekt. Dazu wird das Medium
   * beim speichern neu in die Datenbank geschrieben.
   */
  public Medium() {
    nr = null;
    oldNr = null;
    titel = null;
    autor = null;
    beschreibung = null;
    ean = null;
    medientyp = null;
    medienAnzahl = 1;
    eingestellt_seit = new Date();
    aus_Bestand_entfernt = null;
    datenGeladen = true;
    systematiken = new SystematikListe();
    isSaved = false;
  }

  /**
   * L�d die Daten zu der �bergebenen Mediennummer aus der Datenbank.
   * Existiert die Mediennummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param medienNr die Mediennummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Mediennr nicht in der
   *   Datenbank vorhanden ist
   */
  protected void load(String medienNr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    isSaved = true;
    try {
      Statement statement = Datenbank.getInstance().getStatement();

      // Tabelle Medium lesen
      ladeMediumStatement.setString(1, medienNr);
      ResultSet result = ladeMediumStatement.executeQuery();
      boolean mediumGefunden = result.next();
      if (!mediumGefunden) throw new DatenNichtGefundenException(
        "Ein Medium mit der Nr '"+medienNr+"' existiert nicht!");

      nr = result.getString("nr");
      oldNr = nr;
      medienAnzahl = result.getInt("medienanzahl");
      titel = result.getString("titel");
      autor = result.getString("autor");
      beschreibung = result.getString("beschreibung");
      
      try {
        String eanString = result.getString("ean");
        ean = null;
        if (eanString != null) ean = new EAN(eanString);
      } catch (IllegalArgumentException e) {
        throw new DatenbankInkonsistenzException("Das Medium '"+nr+"'"+
          " besitzt eine ung�ltige EAN-Nr. '"+result.getString("ean")+"'!");        
      }
      eingestellt_seit = result.getDate("eingestellt_seit");
      aus_Bestand_entfernt = result.getDate("aus_Bestand_entfernt");

      String medientypString = result.getString("Medientyp");
      try {
        medientyp = Medientyp.getMedientyp(medientypString);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Das Medium '"+nr+"' geh�rt "+
          "zum Medientyp '"+medientypString+"'. Dieser Medientyp existiert "+
          "jedoch nicht in der Datenbank!");
      }

      systematiken = new SystematikListe();
      systematiken.setSortierung(SystematikListe.alphabetischeSortierung, false);

      // Systematiken lesen
      result = statement.executeQuery(
        "select Systematik from medium_gehoert_zu_systematik " +
        "where medium = \"" + medienNr + "\"");
      while (result.next()) {
        String eintrag = result.getString("Systematik");
        try {
          Systematik sys = Systematik.getSystematik(eintrag);
          systematiken.add(sys);
        } catch (DatenNichtGefundenException e) {
          throw new DatenbankInkonsistenzException("Das Medium '"+nr+"'"+
            " geh�rt zur Systematik '"+eintrag+"'. Diese Systematik existiert "+
            "jedoch nicht in der Datenbank!");
        }
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden des Mediums mit der "+
        "Mediennr '"+medienNr+"'!", true);
    }
    datenGeladen = true;
  }

  /**
   * Liefert den Titel des Medium
   * @return Titel des Mediums
   */
  public String getTitel() {
    if (titel == null) titel = "";
    return titel;
  }

  /**
   * Setzt den Titel des Medium
   * @param titel der neue Titel des Mediums
   */
  public void setTitel(String titel) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.titel = Datenbank.entferneNullString(titel);
  }

  /**
   * Liefert den Autor des Medium
   * @return Autor des Mediums
   */
  public String getAutor() {
    if (autor == null) autor = "";
    return autor;
  }

  /**
   * Setzt den Autor des Medium
   * @param autor der neue Autor des Mediums
   */
  public void setAutor(String autor) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.autor = Datenbank.entferneNullString(autor);
  }

  /**
   * Liefert die Beschreibung des Medium
   * @return Beschreibung des Mediums
   */
  public String getBeschreibung() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    return beschreibung;
  }

  /**
   * Setzt die Beschreibung des Medium
   * @param beschreibung die neue Beschreibung des Mediums
   */
  public void setBeschreibung(String beschreibung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.beschreibung = Datenbank.entferneNullString(beschreibung);
  }

  /**
   * Liefert den Typ des Medium
   * @return Typ des Mediums
   */
  public Medientyp getMedientyp() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    return medientyp;
  }

  /**
   * Setzt den Typ des Medium
   * @param typ der neue Typ des Mediums
   */
  public void setMedientyp(Medientyp typ) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.medientyp = typ;
  }

  /**
   * Liefert die Nr des Medium
   * @return Nr des Mediums
   */
  public String getMedienNr() {
    return nr;
  }

  /**
   * Setzt die Nr des Medium
   * @param nr die neue Nr des Mediums
   */
  public void setMediennr(String nr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    this.nr = Datenbank.entferneNullString(nr);
  }

  /**
   * Liefert die EAN-Nr des Medium
   * @return EAN-Nr des Mediums
   */
  public EAN getEAN() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    return ean;
  }

  /**
   * Setzt die EAN-Nr des Medium
   * @param ean die neue EAN-Nr des Mediums
   */
  public void setEAN(EAN ean) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.ean = ean;
  }

  /**
   * Liefert die Medienanzahl des Mediums
   * @return die Medienanzahl des Mediums
   */
  public int getMedienAnzahl() {
    return medienAnzahl;
  }

  /**
   * Setzt die Medienanzahl des Mediums
   * @param anzahl die neue Medienanzahl des Mediums
   */
  public void setMedienAnzahl(int anzahl) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.medienAnzahl = anzahl;
  }

  /**
   * Liefert das Einstellungsdatum des Mediums
   * @return Einstellungsdatum des Mediums
   */
  public Date getEinstellungsdatum() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    if (eingestellt_seit == null) return null;
    return (Date) eingestellt_seit.clone();
  }

  /**
   * Setzt das Einstellungsdatum des Mediums
   * @param datum das neue Einstellungsdatum des Mediums
   */
  public void setEinstellungsdatum(Date datum) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    eingestellt_seit = datum;
  }

  /**
   * Liefert das Datum, an dem das Medium aus dem Bestand entfernt wurde.
   * <code>null</code> wird f�r noch im Bestand befindliche Medien
   * zur�ckgeliefert.
   * @return das Datum, an dem das Medium aus dem Bestand entfernt wurde
   */
  public Date getEntfernungsdatum() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    if (aus_Bestand_entfernt == null) return null;
    return (Date) aus_Bestand_entfernt.clone();
  }

  /**
   * Setzt das Datum, an dem das Medium aus dem Bestand entfernt wurde.
   * @param datum das neue Entfernungsdatum des Mediums
   */
  public void setEntfernungsdatum(Date datum) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    aus_Bestand_entfernt = datum;
  }

  /**
   * Liefert die Systematiken, zu denen das Medium direkt geh�rt
   * @return eine Liste aller Systematiken, zu denen das Medium direkt geh�rt
   */
  public SystematikListe getSystematiken() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    return systematiken;
  }

  /**
   * Liefert die Systematiken, zu denen das Medium direkt geh�rt.
   * Diese werden - durch Kommata getrennt - in einem String zur�ckgegeben.
   * @return eine kommatagetrennten String aller Systematiken, 
   *   zu denen das Medium direkt geh�rt
   */
  public String getSystematikenString() {
    Iterator it = getSystematiken().iterator();
    StringBuffer buffer = new StringBuffer();
    
    if (it.hasNext()) buffer.append(((Systematik) it.next()).getName());    
    while (it.hasNext()) {
      buffer.append(", ");
      buffer.append(((Systematik) it.next()).getName());          
    }
    return buffer.toString();
  }

  /**
   * Setzt die Systematiken, zu denen das Medium direkt geh�rt
   * @param systematiken die neue Liste aller Systematiken, zu denen das Medium direkt geh�rt
   */
  public void setSystematiken(SystematikListe systematiken) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    isSaved = false;
    this.systematiken.clear();
    this.systematiken.addAllNoDuplicate(systematiken);
  }

  /**
   * Pr�ft, ob das Medium zu einer Systematik, die sich in der �bergebenen
   * befindet, geh�rt;
   * @param systematik die zu testenden Systematiken
   * @return <code>TRUE</code> gdw. das Medium zur �bergebenen Systematik
   *   geh�rt.
   */
  public boolean gehoertZuSystematik(Systematik systematik) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (getSystematiken().size() == 0) return false;

    StringBuffer systematikenListeBuffer = new StringBuffer();
    Iterator it = getSystematiken().iterator();
    while (it.hasNext()) {
      systematikenListeBuffer.append("\"");
      systematikenListeBuffer.append(((Systematik) it.next()).getName());
      systematikenListeBuffer.append("\", ");
    }
    String systematikenListe =
        systematikenListeBuffer.substring(0,systematikenListeBuffer.length()-2);

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      // Tabelle Medium lesen
      ResultSet result = statement.executeQuery(
        "select * from systematik_spezialisiert where "+
        "spezialisiert = \"" + systematik.getName() + "\" AND "+
        "systematik IN ("+systematikenListe+") LIMIT 1");
      boolean ergebnis = result.next();
      Datenbank.getInstance().releaseStatement(statement);
      return ergebnis;
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen, ob das Medium "+
        "mit der Mediennr '"+getMedienNr()+"' zur Systematikliste '"+
        systematiken.toString()+"' geh�rt!", true);
    }
    return false;
  }

  /**
   * �berpr�ft, ob das Medium noch im Bestand ist
   * @return <code>TRUE</code> falls das Medium noch im Bestand ist<br>
   * <code>FALSE</code> falls es bereits aus dem Bestand entfernt wurde
   */
  public boolean istNochInBestand() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    return (aus_Bestand_entfernt == null);
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (!datenGeladen) this.load(nr);
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append(this.getMedienNr()).append(" (").
      append(this.getMedientyp()).append(")\n");
    ausgabe.append("-------------------------------\n");
    if (this.getTitel() != null) ausgabe.append(this.getTitel()).append("\n");
    if (this.getAutor() != null) ausgabe.append(this.getAutor()).append("\n");
    if (this.getEAN() != null)   ausgabe.append("EAN                 : "+this.getEAN()+"\n");
    if (this.getEinstellungsdatum() != null) ausgabe.append("eingestellt seit    : ").append(Datenbank.getInstance().formatDatum(eingestellt_seit)).append("\n");
    ausgabe.append("aus Bestand entfernt: ");
    if (this.getEntfernungsdatum() != null)
      ausgabe.append(Datenbank.getInstance().formatDatum(this.getEntfernungsdatum()));
    else
      ausgabe.append("-");
    ausgabe.append("\nMedienanzahl        : ");
    ausgabe.append(this.getMedienAnzahl());

    ausgabe.append("\n");
    if (this.getBeschreibung() != null) {
      ausgabe.append("\n");
      ausgabe.append(this.getBeschreibung());
    }

    ausgabe.append("\n\nSystematiken:\n");

    Iterator it = systematiken.iterator();
    while (it.hasNext()) {
      Systematik sys = (Systematik) it.next();
      ausgabe.append(sys.getName()).append(" - ").append(sys.getBeschreibung()).append("\n");
    }

    return ausgabe.toString();
  }

  public String toString() {
    return nr;
  }

  /**
   * Liefert eine sortierte Liste aller Medien, die in der Datenbank
   * eingetragen sind und noch nicht aus dem Bestand entfernt wurden.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * Medienliste ansprechbar.
   * Es wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
   * wird.
   *
   * @param sortierung die anzuwendende Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see MedienListe
   */
  public static MedienListe getAlleMedien(int sortierung) {
    ladeMedienListen();
    if (sortierung == MedienListe.TitelAutorSortierung)
      return alleMedienTitel;
    if (sortierung == MedienListe.MedienNummerSortierung)
      return alleMedienNr;

    MedienListe liste = new MedienListe();
    liste.addAllNoDuplicate(alleMedienTitel);
    liste.setSortierung(sortierung, false);

    return liste;
  }
  

  /**
   * Liefert eine unsortierte Liste aller Medien, die in der Datenbank
   * eingetragen sind und noch nicht aus dem Bestand entfernt wurden.
   * Es wird davon ausgegangen, dass die Ergebnisliste nicht modifiziert
   * wird.
   *
   * @see MedienListe
   */
  public static MedienListe getAlleMedien() {
    ladeMedienListen();
    return alleMedienTitel;
  }
  
  /**
   * Liefert eine Liste aller Medien, die in der Datenbank
   * eingetragen sind und dem uebergebenen Medientyp sowie der uebergebenen 
   * Systematik angehoeren.
   * Sollen alle Medientypen bzw alle Systematiken ausgegeben werden, so
   * ist <code>null</code> zu uebergeben.
   * Der Paramater <code>ausBestandEntfernt</code> bestimmt, ob nur Medien,
   * die sich noch im Bestand befinden, oder nur Medien, die bereits aus dem
   * Bestand entfernt wurden, zur�ckgeliefert werden sollen.
   *
   * @param typ der auszugebende Medientyp
   * @param ausBestandEntfernt in welchen medien soll gesucht werden?
   * @param systematik die auszugebende Systematik
   * @p
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see MedienListe
   */
  public static MedienListe getMedienListe(Medientyp typ, 
    Systematik systematik, boolean ausBestandEntfernt) throws DatenbankInkonsistenzException {
    
    String wherePart;
    if (ausBestandEntfernt) {
      wherePart = "!isNull(aus_bestand_entfernt)";
    } else {
      wherePart = "isNull(aus_bestand_entfernt)";
    }

    if (typ != null) 
      wherePart = wherePart + " AND Medientyp=\""+typ.getName()+"\"";
      
    StringBuffer sqlQuery = new StringBuffer();
    if (systematik != null) {
      SystematikListe unterSystematiken = systematik.getUntersystematiken();
      sqlQuery.append("select distinct nr, titel, autor from medium_gehoert_zu_systematik as ms "+
        "left join medium as m on ms.medium = m.nr where systematik in (");
      for (int i=0; i<unterSystematiken.size()-1; i++) {
        sqlQuery.append("\"");
        sqlQuery.append(((Systematik) unterSystematiken.get(i)).getName());
        sqlQuery.append("\",");
      }
      sqlQuery.append("\"");
      sqlQuery.append(((Systematik) unterSystematiken.get(unterSystematiken.size()-1)).getName());
      sqlQuery.append("\") AND ");
      sqlQuery.append(wherePart);
    } else {
      sqlQuery.append("select distinct nr, titel, autor from medium where ");      
      sqlQuery.append(wherePart);
    }

    MedienListe liste = ladeMedienListe(sqlQuery.toString());
    return liste;
  } 


  /**
   * L�d die Gesamt-Medienliste in den Cache.
   * Dies beschleunigt anschlie�ende Aufrufe von getAlleMedien() und
   * getMedium() extrem.
   */
  public static void ladeMedienListen() {
    synchronized(Medium.class) {
      if (alleMedienNr != null && alleMedienTitel != null) return;
      alleMedienNr = ladeMedienListe("select nr, titel, autor from medium where isNull(aus_bestand_entfernt);");
      alleMedienTitel = new MedienListe();
      alleMedienTitel.addAllNoDuplicate(alleMedienNr);
  
      alleMedienTitel.setSortierung(MedienListe.TitelAutorSortierung, false);
      alleMedienNr.setSortierung(MedienListe.MedienNummerSortierung, false);
    }
  }

  /**
   * Laed alle Medien die dem uebergebenen where-Part entsprechen aus
   * der Datenbank in eine MedienListe
   */
  private static MedienListe ladeMedienListe(String sqlQuery) {
    MedienListe medienListe = new MedienListe();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(sqlQuery);

      medienListe.garantiereGroesse(result.getFetchSize());

      while (result.next()) {
        String medienNr = result.getString("Nr");
        Medium neuMedium = (Medium) cache.get(medienNr);
        if (neuMedium == null) {
          String medienTitel = result.getString("Titel");
          String medienAutor = result.getString("Autor");
          neuMedium = new Medium(medienNr, medienTitel, medienAutor);
          cache.put(medienNr, neuMedium);
        }
        medienListe.addNoDuplicate(neuMedium);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Medienliste!", true);
    }
    return medienListe;
  }

  /**
   * L�d die gesamt Medienlisten im Hintergrund in einem eigenen Thread
   * in den Cache. Dies beschleunigt anschlie�ende Aufrufe von getAlleMedien
   * extrem.
   */
   public static void ladeMedienListenImHintergrund() {
     Thread ladeThread = new Thread(new Runnable() {
       public void run() {
         ladeMedienListen();
       }
     });
     ladeThread.setPriority(Thread.MIN_PRIORITY);
     ladeThread.start();
  }

  /**
   * Bestimmt, ob es sich um ein neues Medium handelt, d.h. um ein neues
   * Medium, das gerade neu angelegt wird, und noch nicht in der Datenbank
   * gespeichert ist.
   *
   * @return <code>true</code> gdw das Medium neu ist
   */
  public boolean istNeu() {
    return (oldNr == null);
  }

  /**
   * L�d alle Daten des aktuellen Mediums erneut aus der Datenbank. Ist das
   * Medium noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls das Medium inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    this.load(this.getMedienNr());
  }
  
  /**
   * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
   * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
   *         <code>FALSE</code> sonst
   */
  public boolean istGespeichert() {
    return isSaved;
  }

  /**
   * Speichert das aktuelle Medium bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws BenutzernameSchonVergebenException falls der Benutzername
   *  schon von einem anderen Benutzer verwendet wird
   * @throws EANSchonVergebenException falls die EAN
   *  schon von einem anderen Benutzer verwendet wird
   * @throws UnvollstaendigeDatenException 
   */
  public void save() throws MedienNrSchonVergebenException, DatenNichtGefundenException, DatenbankInkonsistenzException, UnvollstaendigeDatenException, EANSchonVergebenException {
    if (isSaved) return;

    if (this.getMedienNr() == null || this.getTitel() == null ||
        this.getMedientyp() == null)
      throw new UnvollstaendigeDatenException("Nummer, Titel und Typ jedes "+
        "Mediums m�ssen eingegeben sein.");

    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);

      Statement normalStatement = Datenbank.getInstance().getStatement();
      if (!this.getMedienNr().equals(oldNr)) {
        ResultSet result = normalStatement.executeQuery("select count(*) from medium where Nr = \""+this.getMedienNr()+"\"");
        if (result.next() && result.getInt(1) > 0) {
          Medium konfliktMedium = Medium.getMedium(this.getMedienNr());
          throw new MedienNrSchonVergebenException(konfliktMedium);          
        }
      }
      
      if (ean != null) {
        this.ean = new EAN(ean.toString());
        if (ean.getTyp() != EAN.MediumEAN) {
          throw new EANSchonVergebenException("Die EAN '"+ean.toString()+"' ist keine EAN f�r ein Medium.", null);
        } else {
          Medium eanMedium = (Medium) ean.getReferenz();
          if (eanMedium != null && 
            !eanMedium.getMedienNr().equals(oldNr)) {
            throw new EANSchonVergebenException("Die EAN '"+ean.toString()+"' wird " +              "schon von dem Medium '"+eanMedium.toString()+"' verwendet.", eanMedium);    
          }
        }
      }
                        
      PreparedStatement statement = null;
      if (this.istNeu()) {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "insert into medium " +          "set Nr = ?, Titel = ?, "+
          "Autor = ?, Beschreibung = ?, Medientyp = ?, " +          "Medienanzahl = ?, EAN = ?, eingestellt_seit = ?, "+
          "aus_Bestand_entfernt = ?");
      } else {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "update medium "+
          "set Nr = ?, Titel = ?, "+
          "Autor = ?, Beschreibung = ?, Medientyp = ?, " +
          "Medienanzahl = ?, EAN = ?, eingestellt_seit = ?, "+
          "aus_Bestand_entfernt = ? where nr=\""+oldNr+"\"");
      }
      statement.setString(1, this.getMedienNr());
      statement.setString(2, this.getTitel());
      statement.setString(3, this.getAutor());
      statement.setString(4, this.getBeschreibung());
      statement.setString(5, this.getMedientyp().getName());
      statement.setInt(6, this.getMedienAnzahl());
      
      if (this.getEAN() != null) {
        statement.setString(7, this.getEAN().toString());
      } else {
        statement.setString(7, null);
      }
      
      if (this.getEinstellungsdatum() != null) {
        statement.setDate(8, new java.sql.Date(this.getEinstellungsdatum().getTime()));
      } else {
        statement.setDate(8, null);
      }
      
      if (this.getEntfernungsdatum() != null) {
        statement.setDate(9, new java.sql.Date(this.getEntfernungsdatum().getTime()));
      } else {
        statement.setDate(9, null);
      }

      statement.execute();
      
      //Systematiken
      normalStatement.execute("delete from medium_gehoert_zu_systematik where medium = \""+oldNr+"\"");
      Iterator it = this.getSystematiken().iterator();
      while (it.hasNext()) {
        Systematik aktuelleSystematik = (Systematik) it.next();
        normalStatement.execute("insert into medium_gehoert_zu_systematik set medium = \""+getMedienNr()+"\", systematik=\""+aktuelleSystematik+"\"");              
      }
            
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des folgenden "+
        "Mediums:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    oldNr = nr;
    this.setChanged();
    this.notifyObservers();
  }  

  /**
   * L�scht das Medium aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieses Medium noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise Ausleihen dieses Mediums existieren. Nur
   * wenn keine solchen Beziehungen existieren, wird das Medium gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *    Mediums in der Datenbank existieren
   */
  public void loesche() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);
      Statement statement = Datenbank.getInstance().getStatement();
      
      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(*) from ausleihe where "+
        "Medium=\""+this.getMedienNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Das Medium '"+this.getMedienNr()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Mediums "+
        "existieren.");

      // Medium l�schen
      statement.execute("delete from medium where "+
        "Nr=\""+this.getMedienNr()+"\"");
        
      statement.execute("delete from medium_gehoert_zu_systematik where "+
        "Medium=\""+this.getMedienNr()+"\"");

      Datenbank.getInstance().releaseStatement(statement);      
      connection.commit();
      connection.setAutoCommit(true);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Mediums:\n\n"+this.toDebugString(), true);
    }
  }
}