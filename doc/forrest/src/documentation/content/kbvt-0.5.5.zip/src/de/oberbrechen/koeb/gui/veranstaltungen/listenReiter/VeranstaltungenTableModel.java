/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.listenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Veranstaltungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.6 $
*/

public class VeranstaltungenTableModel extends AbstractTableModel {

  private Veranstaltungsgruppe veranstaltungsgruppe;
  private Veranstaltung[] daten;

  public VeranstaltungenTableModel(Veranstaltungsgruppe daten) {
    setDaten(daten);
  }

  /**
   * Zeigt die zur �bergebenen Veranstaltungsgruppe geh�renden
   * Veranstaltungen in der Tabelle an.
   * @param neueGruppe die Veranstaltungsgruppe, deren Veranstaltungen angezeigt
   *   werden sollen.
   */
  public void setDaten(Veranstaltungsgruppe neueGruppe) {
    veranstaltungsgruppe = neueGruppe;
    VeranstaltungenListe neueDaten = null;
    if (veranstaltungsgruppe != null)
      neueDaten = veranstaltungsgruppe.getVeranstaltungenMitAnmeldung();

    if (neueDaten == null || neueDaten.size() == 0) {
      daten = new Veranstaltung[0];
    } else {
      daten = new Veranstaltung[neueDaten.size()];
      neueDaten.toArray(daten);
    }
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    return daten.length+1;
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Titel";
    if (columnIndex == 1) return "Teilnehmeranzahl";
    if (columnIndex == 2) return "Kosten";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex > daten.length) return null;

    if (rowIndex == 0) {
      if (columnIndex == 0) return "Gesamt";
      if (columnIndex == 1) return
        Integer.toString(veranstaltungsgruppe.getTeilnehmerAnzahl());
      if (columnIndex == 2) return "-";
    } else {
      Veranstaltung gewaehlteVeranstaltung = daten[rowIndex-1];
      if (columnIndex == 0) return gewaehlteVeranstaltung.getTitel();
      if (columnIndex == 1)
        if (gewaehlteVeranstaltung.getMaximaleTeilnehmerAnzahl() == 0)
          return Integer.toString(gewaehlteVeranstaltung.getTeilnehmerAnzahl());
        else
          return gewaehlteVeranstaltung.getTeilnehmerAnzahl() + "/"+
            gewaehlteVeranstaltung.getMaximaleTeilnehmerAnzahl();
      if (columnIndex == 2) return gewaehlteVeranstaltung.getKostenFormatiert();
    }
    return "nicht definierte Spalte";
  }

  /**
   * Liefert die Veranstaltung, die in der �bergebenen Zeile des Models
   * dargestellt wird
   */
  public Veranstaltung getVeranstaltung(int rowIndex) {
    if (rowIndex < 1 || rowIndex > daten.length) return null;
    return daten[rowIndex-1];
  }
}
