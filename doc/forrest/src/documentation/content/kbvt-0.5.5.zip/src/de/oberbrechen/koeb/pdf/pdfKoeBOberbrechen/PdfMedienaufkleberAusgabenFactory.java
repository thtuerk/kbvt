/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfKoeBOberbrechen;

import java.awt.BorderLayout;

import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.pdf.PdfDokument;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.mediumListenAuswahlPanel.MediumListenAuswahlPanel;

/**
* Dieses Klasse stellt eine Factory da, die
* die eine Ausgabe erstellt, die ein PdfMedienaufkleber ausgibt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class PdfMedienaufkleberAusgabenFactory implements AusgabenFactory {

  class MedienaufkleberAusgabe implements Ausgabe {

    private boolean klein;

    public MedienaufkleberAusgabe(boolean klein) {
      this.klein = klein;
    }

    public String getName() {
      String erg = klein?" - Klein":"";
      return "Medienaufkleber"+erg;
    }

    public String getBeschreibung() {
      return "Erm�glicht die Ausgabe von Medienaufklebern. Die Medien, " +        "deren Aufkleber ausgegeben werden sollen, k�nnen vorher ausgew�hlt " +        "werden.";
    }

    public void run(JFrame hauptFenster) throws Exception {   
      MedienListe medienliste = null;
      if (hauptFenster != null) { 
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        MediumListenAuswahlPanel auswahlPanel = 
          new MediumListenAuswahlPanel(hauptFenster);
        panel.add(auswahlPanel, BorderLayout.CENTER);
        panel.add(new JLabel("Bitte w�hlen Sie die Medien aus, deren " +
          "Aufkleber gedruckt werden sollen:"), BorderLayout.NORTH);
        int erg = JOptionPane.showConfirmDialog(hauptFenster, panel,
          "Medienauswahl", JOptionPane.OK_CANCEL_OPTION, 
          JOptionPane.PLAIN_MESSAGE);

        if (erg != JOptionPane.OK_OPTION) return; 
        medienliste = (MedienListe) auswahlPanel.getAuswahl();         
      } else {
        medienliste = Medium.getAlleMedien();          
      }

      PdfDokument pdfAufkleber;
      if (klein) { 
        pdfAufkleber = new PdfMedienaufkleberKlein(medienliste);
      } else {
        pdfAufkleber = new PdfMedienaufkleber(medienliste);
      }
      pdfAufkleber.zeige(false);
    }    
  }

  public String getName() {
    return "Medienaufkleber";
  }

  public String getBeschreibung() {
    return "Erzeugt zwei Ausgaben f�r Medienaufkleber. Eine erstellt " +      "gro�e und eine kleine Medienaufkleber.";
  }

  public void setParameter(String name, String wert) throws ParameterException {
    throw new ParameterException("Diese Factory erlaubt keine Parameter!");
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) {
    knoten.addAusgabe(new MedienaufkleberAusgabe(true));
    knoten.addAusgabe(new MedienaufkleberAusgabe(false));
 }
}