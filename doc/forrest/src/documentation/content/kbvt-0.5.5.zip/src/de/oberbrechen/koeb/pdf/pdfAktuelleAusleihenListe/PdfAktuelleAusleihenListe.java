/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAktuelleAusleihenListe;

import java.util.Collection;
import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt ein PdfDokument, das eine Liste aller aktuellen Mahnungen
 * enthaelt.
 */
public class PdfAktuelleAusleihenListe extends PdfDokument {

  private PdfTemplateDokument pdfDokument; 
  private BenutzerListe benutzerListe;

  public PdfAktuelleAusleihenListe(BenutzerListe benutzerListe) {
    this.benutzerListe = benutzerListe;
    benutzerListe.setSortierung(BenutzerListe.NachnameVornameSortierung, false);
    String titel = "Aktuelle Ausleihen";
    
    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(30);
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) 
    throws Exception {
    Vector templates = new Vector();

    for (int i = 0; i < benutzerListe.size(); i++) {
      templates.addAll(erstelleAusleihenTemplates(
        (Benutzer) benutzerListe.get(i), writer));      
    }

    pdfDokument.setTemplates((PdfTemplate[]) 
      templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }

  private Collection erstelleAusleihenTemplates(Benutzer benutzer, 
    PdfWriter writer) throws Exception {
    Vector erg = new Vector();  
    
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1)-26;

    AktuelleAusleihenTabellenModell tabellenModell = 
      new AktuelleAusleihenTabellenModell(benutzer);      
    PdfTabelle tabelle = new PdfTabelle(tabellenModell);
    while (tabelle.hasNextTemplate()) {
      PdfTemplate tabellenTemplate = 
        tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, 
        writer.getDirectContent());

      PdfTemplate neuesTemplate = 
        writer.getDirectContent().createTemplate(
        tabellenTemplate.getWidth(), tabellenTemplate.getHeight()+26);
      neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
                
      //Ueberschrift
      String name = benutzer.getNameFormal();

      neuesTemplate.beginText();
      neuesTemplate.setFontAndSize(schriftFett, 16);    
      float breite = neuesTemplate.getWidth()-pdfDokument.getSeitenRandLinks()-
        pdfDokument.getSeitenRandRechts();
      float nameBreite = schriftFettKursiv.getWidthPoint(name, 16);
      if (nameBreite > breite) {
        neuesTemplate.setHorizontalScaling((breite/nameBreite)*100);
      } else {
        neuesTemplate.setHorizontalScaling(100);
      }
      neuesTemplate.setTextMatrix(pdfDokument.getSeitenRandLinks(), 
        neuesTemplate.getHeight()-16);
      neuesTemplate.showText(name);
      neuesTemplate.endText();      

      erg.add(neuesTemplate);
    }
    return erg;
  }
}
