/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand.medienReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.*;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Medien.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.7 $
*/

public class MedienTableModel extends AbstractTableModel implements 
  KeyListener, ListenKeySelectionManagerListenDaten, Observer {

  private MedienListe daten;
  private int sortierteSpalte;
  private JTable tabelle;
  private ListenKeySelectionManager keySelectionManager;
  
  public MedienTableModel(JTable tabelle) {
    daten = new MedienListe();
    daten.setSortierung(MedienListe.TitelAutorSortierung, false);
    daten.addObserver(this);
    this.tabelle = tabelle;
    keySelectionManager = new ListenKeySelectionManager(this);
  }
  
  public void setDaten(Collection neueDaten) {
    daten.clear();
    daten.addAllNoDuplicate(neueDaten);
    fireTableDataChanged();
  }
  
  /**
   * Wechselt die Sortierung der Daten.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse Medienliste
   * ansprechbar. 0 steht daf�r, dass die Liste unsortiert sein soll.
   *
   * @param sortierung die anzuwendende Sortierung
   * @param umgekehrteSortierung soll die Sortierreihenfolge umgekehrt werden
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   */
  public void setSortierung(int sortierung, boolean umgekehrteSortierung) {
    daten.setSortierung(sortierung, umgekehrteSortierung);
    
    sortierteSpalte = -1;
    if (sortierung == MedienListe.MedienNummerSortierung)
      sortierteSpalte = 0;
    if (sortierung == MedienListe.TitelAutorSortierung)
      sortierteSpalte = 1;
    if (sortierung == MedienListe.AutorTitelSortierung)
      sortierteSpalte = 2;
    
    fireTableDataChanged();
  }
  
  public MedienListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Mediennr.";
    if (columnIndex == 1) return "Titel";
    if (columnIndex == 2) return "Autor";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    Medium gewaehltesMedium = (Medium) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehltesMedium.getMedienNr();
    if (columnIndex == 1) return gewaehltesMedium.getTitel();
    if (columnIndex == 2) return gewaehltesMedium.getAutor();
    return "nicht definierte Spalte";
  }

  public Medium getMedium(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Medium) daten.get(rowIndex);
  }

  public void update(Observable o, Object arg) {
    this.fireTableDataChanged();
  }

  /**
   * Bestimmt, ob die Daten nach der �bergebenen
   * Spalte sortiert sind
   * @param spalte die zu testende Spalte
   */
  public boolean istSortiertNach(int spalte) {
    return (spalte == sortierteSpalte);
  }

  //Selectiert ein geeignetes Medium aus der Tabelle
  public void keyTyped(KeyEvent e) {
    char aKey = e.getKeyChar();
    int zuSelektierendeZeile = keySelectionManager.selectionForKey(aKey);
    if (zuSelektierendeZeile == -1) return;
    
    tabelle.setRowSelectionInterval(zuSelektierendeZeile, zuSelektierendeZeile);
    tabelle.scrollRectToVisible(tabelle.getCellRect(zuSelektierendeZeile, 0, true));
  }

  public void keyPressed(KeyEvent e) {
  }

  public void keyReleased(KeyEvent e) {
  }

  public String getKeySelectionValue(int row) {
    return getValueAt(row, sortierteSpalte).toString();
  }

  public int size() {
    return getRowCount();
  }

}
