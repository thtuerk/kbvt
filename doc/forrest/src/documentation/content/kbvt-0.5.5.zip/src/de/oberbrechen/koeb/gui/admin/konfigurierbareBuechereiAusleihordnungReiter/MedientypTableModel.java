/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.konfigurierbareBuechereiAusleihordnungReiter;

import java.util.Vector;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.MedientypSchonVergebenException;
import de.oberbrechen.koeb.datenstrukturen.MedientypListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import java.util.Iterator;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von 
* Medientyp-Einstellungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class MedientypTableModel extends AbstractTableModel {
  
  class MedientypDaten {
    Medientyp medientyp;
    int mindestAusleihDauer;
    String medienNrPraefix;
    String eanPraefix;
    boolean langesMedienNrFormat;
    
    public MedientypDaten(Medientyp medientyp) {
      this.medientyp = new Medientyp(medientyp.getName());
      Einstellungen einstellungen = Einstellungen.getInstance();
      
      mindestAusleihDauer = 
        einstellungen.getEinstellungInt(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareAusleihordnung", 
        "mindestAusleihdauerInTagen."+getMedientyp(), 21);
      
      eanPraefix = 
        einstellungen.getEinstellungString(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "EANPraefix."+getMedientyp(), "01");

      medienNrPraefix = 
        einstellungen.getEinstellungString(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "MediennrPraefix."+getMedientyp(), getMedientyp());

      langesMedienNrFormat = 
        einstellungen.getEinstellungBoolean(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "EinstellungsjahrInMediennr."+getMedientyp(), true);

    }
    
    public String getEanPraefix() {
      return eanPraefix;
    }

    public boolean isLangesMedienNrFormat() {
      return langesMedienNrFormat;
    }

    public String getMedienNrPraefix() {
      return medienNrPraefix;
    }

    public String getMedientyp() {
      return medientyp.getName();
    }

    public int getMindestAusleihDauer() {
      return mindestAusleihDauer;
    }

    public String getPlural() {
      return medientyp.getPlural();
    }

    public void setEanPraefix(String string) {
      eanPraefix = string;
      if (string.length() != 2 || !Character.isDigit(string.charAt(0)) 
        || !Character.isDigit(string.charAt(1))) {
      
        JOptionPane.showMessageDialog(hauptFenster, "Ein EAN-Pr�fix " +          "muss aus 2 Ziffern bestehen.\n'"+
          string + "' entspricht nicht diesem Format!",
          "Ung�ltige Eingabe!",
          JOptionPane.ERROR_MESSAGE);
        
        eanPraefix = "01";        
        
      }
      Einstellungen.getInstance().setEinstellungString(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "EANPraefix."+getMedientyp(), eanPraefix);
    }

    public void setLangesMedienNrFormat(boolean b) {
      langesMedienNrFormat = b;
      Einstellungen.getInstance().setEinstellungBoolean(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "EinstellungsjahrInMediennr."+getMedientyp(), b);
    }

    public void setMedienNrPraefix(String string) {
      medienNrPraefix = string;
      Einstellungen.getInstance().setEinstellungString(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
        "MediennrPraefix."+getMedientyp(), string);
    }

    public void setMedientyp(String string) {
      String oldMedientyp = medientyp.getName();
      try {
        medientyp.setName(string);
        medientyp.save();

        //Einstellungen anpassen
        Einstellungen.getInstance().setEinstellungInt(null, null, 
          "de.oberbrechen.koeb.einstellungen.KonfigurierbareAusleihordnung", 
          "mindestAusleihdauerInTagen."+getMedientyp(), mindestAusleihDauer);
        Einstellungen.getInstance().setEinstellungString(null, null, 
          "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
          "MediennrPraefix."+getMedientyp(), medienNrPraefix);
        Einstellungen.getInstance().setEinstellungBoolean(null, null, 
          "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
          "EinstellungsjahrInMediennr."+getMedientyp(), langesMedienNrFormat);
        Einstellungen.getInstance().setEinstellungString(null, null, 
          "de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei", 
          "EANPraefix."+getMedientyp(), eanPraefix);
        new Einstellung("de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei."+
          "EANPraefix."+oldMedientyp, null, null, null).loesche();
        new Einstellung("de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei."+
          "EinstellungsjahrInMediennr."+oldMedientyp, null, null, null).loesche();
        new Einstellung("de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei."+
          "MediennrPraefix."+oldMedientyp, null, null, null).loesche();
        new Einstellung("de.oberbrechen.koeb.einstellungen.KonfigurierbareBuecherei."+
          "mindestAusleihdauerInTagen."+oldMedientyp, null, null, null).loesche();
        

      } catch (MedientypSchonVergebenException e) {
        JOptionPane.showMessageDialog(hauptFenster, "Der Medientyp '" +
          string+"' existiert bereits!",
          "Ung�ltige Eingabe!", JOptionPane.ERROR_MESSAGE);
        
        medientyp = new Medientyp(oldMedientyp);
        fireTableDataChanged();                
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des Medientyps "+medientyp.toDebugString()+"!", false);        
      }
    }

    public void setPlural(String string) {
      try {
        medientyp.setPlural(string);
        medientyp.save();
      } catch (Exception e) {
        ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des Medientyps "+medientyp.toDebugString()+"!", false);        
      }
    }

    public void setMindestAusleihDauer(int i) {
      mindestAusleihDauer = i;
      Einstellungen.getInstance().setEinstellungInt(null, null, 
        "de.oberbrechen.koeb.einstellungen.KonfigurierbareAusleihordnung", 
        "mindestAusleihdauerInTagen."+getMedientyp(), i);
    }

    public String getBeispiel() {
      StringBuffer buffer = new StringBuffer();
      if (medienNrPraefix != null && !medienNrPraefix.trim().equals("") )
        buffer.append(medienNrPraefix).append(" ");
      if (isLangesMedienNrFormat()) buffer.append("2003-");
      buffer.append("163");
      return buffer.toString();
    }

  }
  
  Vector daten;
  final JFrame hauptFenster;
  
  public MedientypTableModel(JFrame hauptFenster) {
    this.hauptFenster = hauptFenster;
    init();
  }
  
  public void init() {
    MedientypListe medientypListe = Medientyp.getAlleMedientypen();
    medientypListe.setSortierung(MedientypListe.StringSortierung, false);
    
    daten = new Vector();
    Iterator it = medientypListe.iterator();
    while (it.hasNext()) {
      daten.add(new MedientypDaten((Medientyp) it.next()));
    }
  }
      
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 7;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Medientyp";
    if (columnIndex == 1) return "Plural";
    if (columnIndex == 2) return "Mindestausleihdauer";
    if (columnIndex == 3) return "EAN-Pr�fix";
    if (columnIndex == 4) return "Mediennr.-Pr�fix";
    if (columnIndex == 5) return "langes Mediennr.-Format";
    if (columnIndex == 6) return "Beispiel";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return String.class;
    if (columnIndex == 1) return String.class;
    if (columnIndex == 2) return Integer.class;
    if (columnIndex == 3) return String.class;
    if (columnIndex == 4) return String.class;
    if (columnIndex == 5) return Boolean.class;
    if (columnIndex == 6) return String.class;
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    MedientypDaten gewaehlteDaten = (MedientypDaten) daten.get(rowIndex);
    
    if (columnIndex == 0) return gewaehlteDaten.getMedientyp();
    if (columnIndex == 1) return gewaehlteDaten.getPlural();
    if (columnIndex == 2) return new Integer(gewaehlteDaten.getMindestAusleihDauer());
    if (columnIndex == 3) return gewaehlteDaten.getEanPraefix();
    if (columnIndex == 4) return gewaehlteDaten.getMedienNrPraefix();
    if (columnIndex == 5) return new Boolean(gewaehlteDaten.isLangesMedienNrFormat());
    if (columnIndex == 6) return gewaehlteDaten.getBeispiel();
    return "nicht definierte Spalte";
  }

  public Einstellung getEinstellung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Einstellung) daten.get(rowIndex);
  }
  
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex < 6);
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (columnIndex >= 6) return;
    
    MedientypDaten gewaehlteDaten = (MedientypDaten) daten.get(rowIndex);
    
    if (columnIndex == 0) gewaehlteDaten.setMedientyp((String) aValue);
    if (columnIndex == 1) gewaehlteDaten.setPlural((String) aValue);
    if (columnIndex == 2) gewaehlteDaten.setMindestAusleihDauer(((Integer) aValue).intValue());
    if (columnIndex == 3) gewaehlteDaten.setEanPraefix((String) aValue);
    if (columnIndex == 4) gewaehlteDaten.setMedienNrPraefix((String) aValue);
    if (columnIndex == 5) gewaehlteDaten.setLangesMedienNrFormat(((Boolean) aValue).booleanValue());

    fireTableRowsUpdated(rowIndex, rowIndex);
  }

  public void refresh() {
    init();
  }

}
