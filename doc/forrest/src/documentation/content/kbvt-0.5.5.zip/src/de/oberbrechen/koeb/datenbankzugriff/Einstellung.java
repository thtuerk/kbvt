/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

/**
 * Diese Klasse ist ein "dummer" Datenconstainer, der in Verbindung 
 * mit Einstellungen benutzt werden sollte.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public class Einstellung {
  private String name = null;
  private String wert = null;
  private Client client = null;
  private Mitarbeiter mitarbeiter = null;
  
  public Einstellung(String name, String wert, Client client, Mitarbeiter mitarbeiter) {
    this.name = name;
    this.wert = wert;
    this.client = client;
    this.mitarbeiter = mitarbeiter;    
  }
  
  public String getName() {
    return name;
  }
  
  public String getWert() {
    return wert;
  }
   
  public Client getClient() {
    return client;
  }

  public Mitarbeiter getMitarbeiter() {
    return mitarbeiter;
  }

  public void setWert(String string) {
    wert = string;
  }
  
  public void save() {
    Einstellungen.getInstance().setEinstellungString(
      client, mitarbeiter, null, name, wert);  
  }
  
  public String toString() {
    return toDebugString();
  }
  
  public String toDebugString() {
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Client:      ");
    if (getClient() != null) {
      ausgabe.append(this.getClient().toDebugString());
    } else {
      ausgabe.append("-"); 
    }

    ausgabe.append("\nMitarbeiter: ");
    if (getMitarbeiter() != null) {
      ausgabe.append(getMitarbeiter().getName());
    } else {
      ausgabe.append("-"); 
    }
    
    ausgabe.append("\nName:        ");
    ausgabe.append(getName());

    ausgabe.append("\nWert:        ");
    ausgabe.append(getWert());

    return ausgabe.toString();
  }
  
  public void loesche() {
    Einstellungen.getInstance().removeEinstellungListe(client, mitarbeiter, name);
  }  
}
