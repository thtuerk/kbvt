/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;

/**
* Diese Klasse repr�sentiert einen Medientyp der B�cherei. Es stellt die
* Verbindung zur Datenbank her und Methoden, um auf Medientypen zuzugreifen.
* Mit dieser Klasse k�nnen Medientypen aber nicht ver�ndert werden.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.10 $
*/

public class Medientyp {

  // Statische Speicherung der Medientypen, um weniger Objekte erzeugen
  // zu m�ssen
  private static Hashtable cache = new Hashtable();

  /**
   * Liefert ein zum �bergebenen Medientyp passendes Medientyp-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jeden Medientyp
   * existiert nur ein Objekt.
   *
   * @param medientyp der Medientyp, der geladen werden soll
   * @throws DatenNichtGefundenException falls der �bergebene Medientyp
   *  nicht in der Datenbank existiert
   */
  public static Medientyp getMedientyp(String medientyp) throws DatenNichtGefundenException {

    Medientyp erg = (Medientyp) cache.get(medientyp);
    if (erg == null) {
      erg = new Medientyp(medientyp);
      cache.put(medientyp, erg);
    }
    return erg;
  }

  /**
   * Liefert den meist genutzten Medientypen, d.h. den Medientypen,
   * mit den meisten in der Datenbank eingetragenen Medien.
   * @return den meist genutzten Medientyp
   */
  public static Medientyp getMeistBenutztenMedientyp() throws DatenNichtGefundenException {
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select count(*) as anzahl, medientyp from medium group by medientyp order" +        " by anzahl DESC limit 1");
      boolean medientypGefunden = result.next();
      if (!medientypGefunden) { 
        result = statement.executeQuery("select name as medientyp from medientyp limit 1");
        medientypGefunden = result.next();
      }
      if (!medientypGefunden) {
        throw new DatenNichtGefundenException("Es konnte kein Medientyp gefunden werden!");                         
      }
      String name = result.getString("medientyp");
      Datenbank.getInstance().releaseStatement(statement);
      return getMedientyp(name);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden des meist benutzten Medientys!", true);
    }
    return null;
  }


  // Die Attribute des Medientyps wie in der Datenbank
  private String oldName;
  private String name;
  private String plural;
  private boolean isSaved;
  
  /**
   * Erstellt einen neuen, noch nicht gespeicherten Medientyp 
   */
  public Medientyp() {
    name = null;
    plural = null;
    isSaved = true;
    oldName = name;
  }
  
  /**
   * L�d das zum Parameter geh�rende
   * <code>Medientyp</code>-Objekt aus der Datenbank.
   * @param medientyp der Medientyp, der geladen werden soll
   * @throws DatenNichtGefundenException falls der �bergebene Medientyp
   *  nicht in der Datenbank existiert
   */
  public Medientyp(String medientyp) throws DatenNichtGefundenException {

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from medientyp where name = \"" + medientyp + "\"");
      boolean medientypGefunden = result.next();
      if (!medientypGefunden) throw new DatenNichtGefundenException(
        "Der Medientyp '"+medientyp+"' existiert nicht!");

      name = medientyp;
      plural = result.getString("plural");
      isSaved = true;
      oldName = name;

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden des Medientys "+
        medientyp+"!", true);
    }
  }

  /**
   * Liefert die Bezeichnung des Medientyps
   * @return die Bezeichnung des Medientyps
   */
  public String getName() {
    return name;
  }

  /**
   * Setzt die Bezeichnung des Medientyps
   * @param name die neue Bezeichnung des Medientyps
   */
  public void setName(String name) {
    this.name = name;
    isSaved = false;
  }

  /**
   * Liefert den Plural des Medientypnames. D.h. f�r den
   * Medientyp 'Buch' wird beispielsweise 'B�cher' geliefert.
   * @return den Plural des Medientypnames.
   */
  public String getPlural() {
    return plural;
  }

  /**
   * Setzt den Plural dieses Medientyps
   * @param plural der neue Plural
   */
  public void setPlural(String plural) {
    isSaved = false;
    this.plural = plural;
  }
  
  public boolean equals(Object o) {
    if (!(o instanceof Medientyp)) return false;
    return ((Medientyp) o).getName().equals(this.getName()); 
  }

  public String toString() {
    return this.getName();
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.getName()+" - "+this.getPlural();
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller 
   * Medientypen, die in der Datenbank
   * eingetragen sind.
   */
  public static MedientypListe getAlleMedientypen() {
    MedientypListe liste = new MedientypListe();
    cache.clear();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from medientyp;");
      while (result.next()) {

        Medientyp neuMedientyp = new Medientyp();

        neuMedientyp.name = result.getString("name");
        neuMedientyp.plural = result.getString("plural");
        neuMedientyp.isSaved = true;
        neuMedientyp.oldName = neuMedientyp.name;


        cache.put(neuMedientyp.name, neuMedientyp);
        liste.addNoDuplicate(neuMedientyp);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Benutzerliste!", true);
    }

    liste.setSortierung(Liste.StringSortierung, false);
    return liste;
  }
  
  /**
   * Bestimmt, ob es sich um einen neuen Medientyp handelt, d.h. 
   * um einen Meidntyp, der gerade neu angelegt wird und noch nicht 
   * in der Datenbank gespeichert ist.
   *
   * @return <code>true</code> gdw der Medientyp neu ist
   */
  public boolean istNeu() {
    return (oldName == null);
  }

  /**
   * Speichert den aktuellen Medientyp
   * bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws UnvollstaendigeDatenException 
   */
  public void save() throws UnvollstaendigeDatenException,
    MedientypSchonVergebenException {
    if (isSaved) return;

    if (this.getName() == null)
      throw new UnvollstaendigeDatenException("Der Medientyp-Name " +        "muss eingegeben sein!");

    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);

      if (!name.equals(oldName)) {
        Statement statement = Datenbank.getInstance().getStatement();
        ResultSet result = statement.executeQuery("select * from medientyp where name =\""+name+"\"");
        boolean medientypNameSchonVergeben = result.next();
        if (medientypNameSchonVergeben) {
          throw new MedientypSchonVergebenException(Medientyp.getMedientyp(name));
        }                  
        
        if (oldName != null) {
          statement.execute("update medium set medientyp=\""+name+"\" where medientyp=\""+oldName+"\"");
        }
      }

      
      PreparedStatement statement = null;

      if (this.istNeu()) {
        statement = connection.prepareStatement(
          "insert into medientyp set name = ?, Plural = ?");
      } else {
        statement = connection.prepareStatement(
          "update medientyp set Name = ?, Plural = ? where name=\""+oldName+"\"");
      }
      statement.setString(1, this.getName());
      statement.setString(2, Datenbank.erstelleNullString(this.getPlural()));

      statement.execute();
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des folgenden "+
        "Medientyps:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    oldName = name;
  }

  /**
   * L�scht den Medientyp aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieser Medientyp noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise Medien dieses Typs existieren. Nur
   * wenn keine solchen Beziehungen existieren, wird der Medientyp gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *    Medientyps in der Datenbank existieren
   */
  public void loesche() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    try {
      
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);
      Statement statement = Datenbank.getInstance().getStatement();
      
      //Medium
      ResultSet result = statement.executeQuery(
        "select count(*) from medium where "+
        "medientyp=\""+getName()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Medientyp '"+getName()+
        "' kann nicht gel�scht werden, da noch Medien dieses Typs "+
        "existieren.");

      //L�schen
      statement.execute("delete from medientyp where "+
        "name=\""+this.getName()+"\"");
        
      Datenbank.getInstance().releaseStatement(statement);      
      connection.commit();
      connection.setAutoCommit(true);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Medientyps:\n\n"+this.toDebugString(), true);
    }
  }      
}