/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.veranstaltungenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.*;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Medien.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class VeranstaltungenTableModel extends AbstractTableModel implements 
  KeyListener, ListenKeySelectionManagerListenDaten, Observer {

  private VeranstaltungenListe daten;
  private int sortierteSpalte;
  private JTable tabelle;
  private ListenKeySelectionManager keySelectionManager;
  
  public VeranstaltungenTableModel(JTable tabelle) {
    daten = new VeranstaltungenListe();
    daten.setSortierung(VeranstaltungenListe.alphabetischeSortierung, false);
    daten.addObserver(this);
    this.tabelle = tabelle;
    keySelectionManager = new ListenKeySelectionManager(this);
  }
  
  public void setDaten(Collection neueDaten) {
    daten.clear();
    daten.addAllNoDuplicate(neueDaten);
    fireTableDataChanged();
  }
    
  public VeranstaltungenListe getDaten() {
    return daten;
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Titel";
    if (columnIndex == 1) return "Kurz-Titel";
    if (columnIndex == 2) return "Ansprechpartner";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) return null;
    Veranstaltung gewaehlteVeranstaltung = (Veranstaltung) daten.get(rowIndex);
    if (columnIndex == 0) return gewaehlteVeranstaltung.getTitel();
    if (columnIndex == 1) return gewaehlteVeranstaltung.getKurzTitel();
    if (columnIndex == 2) return gewaehlteVeranstaltung.getAnsprechpartner();
    return "nicht definierte Spalte";
  }

  public Veranstaltung getVeranstaltung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Veranstaltung) daten.get(rowIndex);
  }

  public void update(Observable o, Object arg) {
    this.fireTableDataChanged();
  }

  //Selectiert eine geeignete Veranstaltung aus der Tabelle
  public void keyTyped(KeyEvent e) {
    char aKey = e.getKeyChar();
    int zuSelektierendeZeile = keySelectionManager.selectionForKey(aKey);
    if (zuSelektierendeZeile == -1) return;
    
    tabelle.setRowSelectionInterval(zuSelektierendeZeile, zuSelektierendeZeile);
    tabelle.scrollRectToVisible(tabelle.getCellRect(zuSelektierendeZeile, 0, true));
  }

  public void keyPressed(KeyEvent e) {
  }

  public void keyReleased(KeyEvent e) {
  }

  public String getKeySelectionValue(int row) {
    return getValueAt(row, sortierteSpalte).toString();
  }

  public int size() {
    return getRowCount();
  }
}
