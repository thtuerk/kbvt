/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components;

import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.*;


class FormatWrapper {
  Object daten;
  Format format;

  public FormatWrapper(Object daten, Format format) {
    if (daten instanceof FormatWrapper) {
      this.daten = ((FormatWrapper) daten).daten;
    } else {
      this.daten = daten;
    }

    this.format = format;
  }

  public String toString() {
    return format.format(daten);
  }
}

/**
 * Der StandardKeySelectionManager f�r die SortiertComboBox.
 */
class DefaultKeySelectionManager implements JComboBox.KeySelectionManager {

  StringBuffer pattern;
  long lastKeyPress;
  ListenKeySelectionManagerListenDaten daten;
  ListenKeySelectionManager keySelectionManager;

  public DefaultKeySelectionManager(final Format format, final ComboBoxModel aModel) {
    pattern = new StringBuffer();
    lastKeyPress = 0;
    daten = new ListenKeySelectionManagerListenDaten() {
      public String getKeySelectionValue(int row) {
        return format.format(aModel.getElementAt(row));
      }

      public int size() {
        return aModel.getSize();
      }
    };
    keySelectionManager = new ListenKeySelectionManager(daten);
  }

  public int selectionForKey(char aKey, ComboBoxModel aModel) {
    return keySelectionManager.selectionForKey(aKey);
  }
}

/**
 * Das Model der SortiertComboBox.
 */
class SortiertMutableComboBoxModel extends AbstractListModel
  implements MutableComboBoxModel {

  private Liste daten;
  private Object selected;

  public SortiertMutableComboBoxModel(Liste daten) {
    super();
    this.setDaten(daten);
  }

  public void setDaten(Liste daten) {
    this.daten = daten;
    selected = null;
    if (!daten.isEmpty()) selected = daten.first();
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void addAll(Collection c) {
    daten.addAll(c);
    if (selected == null && !daten.isEmpty()) selected = daten.first();
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void addElement(Object obj) {
    daten.add(obj);
    if (selected == null && !daten.isEmpty()) selected = daten.first();
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void removeElement(Object obj) {
    daten.remove(obj);
    if (daten.isEmpty() || obj == selected) selected = null;
    if (selected == null && !daten.isEmpty()) selected = daten.first();
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void insertElementAt(Object obj, int index) {
    daten.add(obj);
    if (selected == null && !daten.isEmpty()) selected = daten.first();
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void removeElementAt(int index) {
    Object obj = this.getElementAt(index);
    this.removeElement(obj);
    this.fireContentsChanged(this, 0, daten.size()-1);
  }

  public void setSelectedItem(Object obj) {
    if (obj != null && !daten.contains(obj))
      this.addElement(obj);

    if (selected != obj) {
      selected = obj;
      fireContentsChanged(this, -1, -1);
    }
  }

  public Object getSelectedItem() {
    return selected;
  }

  public int getSize() {
    return daten.size();
  }

  public Object getElementAt(int index) {
    if (index < 0 || index > daten.size()) return null;
    return daten.get(index);
  }
}


/**
 * Eine SortierComboBox ist eine JComboBox, die ihre Listeneintr�ge sortiert.
 * Au�erdem ist es m�glich, das Format, in dem die Eintr�ge angezeigt werden
 * zu bestimmen.
 */
public class SortiertComboBox extends JComboBox {

  private SortiertMutableComboBoxModel model;
  private DelayItemListener delayItemListener;

  /**
   * Erstellt eine SortiertComboBox, die die Listeneintr�ge mittels ihrer
   * toString Methode darstellt und nach dieser Stringdarstellung sortiert.
   */
  public SortiertComboBox() {
    Liste daten = new Liste();
    daten.setSortierung(convertFormatToComparator(new Format()));
    init(daten, new Format());
  }

  /**
   * Erstellt eine SortiertComboBox, die die Listeneintr�ge mittels ihrer
   * toString Methode darstellt und die im �bergegeben SortedSet gespeicherten
   * Daten in der dort festgelegten Reihenfolge enth�lt.
   *
   * @param daten die Daten, die dargestellt werden sollen
   */
  public SortiertComboBox(Liste daten) {
    init(daten, new Format());
  }

  /**
   * Erstellt eine SortiertComboBox, die die Listeneintr�ge mittels des
   * �bergebenen Formats darstellt und nach dieser Stringdarstellung sortiert.
   *
   * @param format das Format, das zum Darstellen verwendet wird
   */
  public SortiertComboBox(final Format format) {
    Liste daten = new Liste();
    daten.setSortierung(convertFormatToComparator(format));
    init(daten, format);
  }

  /**
   * Erstellt eine SortiertComboBox, die die Listeneintr�ge mittels des
   * �bergebenen Formats darstellt und die im �bergegeben SortedSet
   * gespeicherten Daten in der dort festgelegten Reihenfolge enth�lt.
   *
   * @param format das Format, das zum Darstellen verwendet wird
   * @param daten die Daten, die dargestellt werden sollen
   */
  public SortiertComboBox(final Liste daten, final Format format) {
    init(daten, format);
  }

  /**
   * Wird f�r Construktoren benutzt.
   * @param format das Format, das zum Darstellen verwendet wird
   * @param daten die Daten, die dargestellt werden sollen
   */
  private void init(final Liste daten, final Format format) {
    model = new SortiertMutableComboBoxModel(daten);
    this.setModel(model);

    delayItemListener = new DelayItemListener(500);
    this.addItemListener(delayItemListener);
    this.setKeySelectionManager(new DefaultKeySelectionManager(format, model));

    this.setRenderer(new DefaultListCellRenderer() {
      public Component getListCellRendererComponent(JList list, Object value,
        int index, boolean isSelected, boolean cellHasFocus) {
        JLabel renderer = (JLabel) super.getListCellRendererComponent(
          list, value, index, isSelected, cellHasFocus);
        renderer.setText(format.format(value));
        return renderer;
      }
    });
  }

  /**
   * F�gt einen neuen ItemListener zu der SortiertComboBox hinzu, der aber die
   * Auswahl eines neuen Items erst gemeldet bekommt, nachdem das Item
   * mindestens eine gewisse Zeit ausgew�hlt blieb.   *
   * Dies kann sinnvoll sein, um bei Comboboxen, die viele Daten
   * enthalten und bei denen das Wechseln der Auswahl
   * eine l�ngere Aktion anst��t, trotzdem
   * schnell durch die Eintr�ge scrollen zu k�nnen.
   *
   * @param itemListener der neue Listener
   */
  public void addDelayItemListener(ItemListener itemListener) {
    delayItemListener.addItemListener(itemListener);
  }

  /**
   * Bricht die Wartezeit sofort ab und leitet das wartende Event sofort weiter.
   */
  public void fireDelayItemListenerEvent() {
    delayItemListener.fireDelayItemListenerEvent();
  }

  /**
   * Aktiviert bzw deaktiviert alle DelayItemListener.
   */
  public void setDelayItemListenerEnabled(boolean enabled) {
    delayItemListener.setEnabled(enabled);
  }

  /**
   * Setzt die Listeneintr�ge auf die im �bergegeben SortedSet gespeicherten
   * Daten in der dort festgelegten Reihenfolge.
   *
   * @param daten die Daten, die dargestellt werden sollen
   */
  public void setDaten(Liste daten) {
    model.setDaten(daten);
  }

  /**
   * F�gt die in der Collection enthalten Daten zur Liste hinzu.
   * @param c die hinzuzuf�gende Collection
   */
  public void addAll(Collection c) {
    model.addAll(c);
  }

  private static Comparator convertFormatToComparator(final Format format) {
    return new Comparator () {
      public int compare(Object a, Object b) {
        return format.format(a).compareToIgnoreCase(format.format(b));
      }
    };
  }
}
