/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.listenReiter;

import java.util.Iterator;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import javax.swing.table.AbstractTableModel;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Veranstaltungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.7 $
*/

public class ListenTableModel extends AbstractTableModel {

  //Die zur Verf�gung stehenden Sortierungen
  public static final int SORTIERUNG_NAME =
    VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung;
  public static final int SORTIERUNG_KLASSE =
    VeranstaltungsteilnahmeListe.BenutzerKlasseSortierung;
  public static final int SORTIERUNG_ANMELDENR =
    VeranstaltungsteilnahmeListe.AnmeldeNrSortierung;
  public static final int SORTIERUNG_BEMERKUNGEN =
    VeranstaltungsteilnahmeListe.BemerkungenSortierung;

  private BenutzerListe benutzerListe;
  private VeranstaltungsteilnahmeListe veranstaltungsteilnahmeListe;

  public ListenTableModel() {
    benutzerListe = null;
    veranstaltungsteilnahmeListe = null;
  }

  /**
   * Zeigt die in der �bergebenen BenutzerListe enthaltenen Daten an.
   * @param benutzerListe die BenutzerListe, deren Daten angezeigt
   *   werden sollen.
   */
  public void setDaten(BenutzerListe benutzerListe) {
    this.benutzerListe = benutzerListe;
    this.veranstaltungsteilnahmeListe = null;
    fireTableDataChanged();
  }

  /**
   * Zeigt die in der �bergebenen VeranstaltungsteilnahmeListe
   * enthaltenen Daten an.
   * @param veranstaltungsteilnahmeListe die VeranstaltungsteilnahmeListe,
   *   deren Daten angezeigt werden sollen.
   */
  public void setDaten(VeranstaltungsteilnahmeListe
    veranstaltungsteilnahmeListe) {

    this.benutzerListe = null;
    this.veranstaltungsteilnahmeListe = veranstaltungsteilnahmeListe;
    fireTableDataChanged();
  }

  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (veranstaltungsteilnahmeListe != null)
      return veranstaltungsteilnahmeListe.size();

    if (benutzerListe != null)
      return benutzerListe.size();

    return 0;
  }

  public int getColumnCount() {
    return 3;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Name";
    if (columnIndex == 1) return "Klasse";
    if (columnIndex == 2) return "Bemerkungen";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    if (rowIndex < 0 || rowIndex > this.getRowCount()) return null;

    if (veranstaltungsteilnahmeListe != null) {
      Veranstaltungsteilnahme gewaehlteTeilnahme = (Veranstaltungsteilnahme)
         veranstaltungsteilnahmeListe.get(rowIndex);
      if (columnIndex == 0)
        return gewaehlteTeilnahme.getBenutzer().getNameFormal();
      if (columnIndex == 1) return gewaehlteTeilnahme.getBenutzer().getKlasse();
      if (columnIndex == 2) return gewaehlteTeilnahme.getBemerkungen();
      return "nicht definierte Spalte";
    }

    if (benutzerListe != null) {
      Benutzer gewaehlterBenutzer = (Benutzer) benutzerListe.get(rowIndex);
      if (columnIndex == 0) return gewaehlterBenutzer.getNameFormal();
      if (columnIndex == 1) return gewaehlterBenutzer.getKlasse();
      if (columnIndex == 2) return "";
      return "nicht definierte Spalte";
    }

    return null;
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (veranstaltungsteilnahmeListe != null) {
      Veranstaltungsteilnahme gewaehlteTeilnahme = 
        (Veranstaltungsteilnahme) veranstaltungsteilnahmeListe.get(rowIndex);
      if (columnIndex == 1)
        gewaehlteTeilnahme.getBenutzer().setKlasse(aValue.toString());
      if (columnIndex == 2)
        gewaehlteTeilnahme.setBemerkungen(aValue.toString());
    }

    if (benutzerListe != null) {
      Benutzer gewaehlterBenutzer = (Benutzer) benutzerListe.get(rowIndex);
      if (columnIndex == 1) gewaehlterBenutzer.setKlasse(aValue.toString());
    }
    fireTableCellUpdated(rowIndex, columnIndex);
  }

  /**
   * Liefert den Benutzer, der in der �bergebenen Zeile angezeigt wird.
   * @param rowIndex die Zeile, deren Benutzer geliefert werden soll
   */
  public Benutzer getBenutzer(int rowIndex) {
    if (veranstaltungsteilnahmeListe != null) {
      Veranstaltungsteilnahme gewaehlteTeilnahme = (Veranstaltungsteilnahme)
         veranstaltungsteilnahmeListe.get(rowIndex);
      return gewaehlteTeilnahme.getBenutzer();
    }

    if (benutzerListe != null) {
      return (Benutzer) benutzerListe.get(rowIndex);
    }

    return null;
  }

  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return ((columnIndex == 1 || (
            veranstaltungsteilnahmeListe != null && columnIndex == 2)));
  }

  /**
   * Sortiert die Tabelle nach der �bergebenen Sortierung. Die zur Verf�gung
   * stehenden Sortierungen stehen als �ffentliche Konstanten bereit.
   *
   * @param sortierung die neue Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   */
  public void sortiere(int sortierung) {
    if (veranstaltungsteilnahmeListe != null) {
      if (sortierung == SORTIERUNG_NAME) {
        veranstaltungsteilnahmeListe.setSortierung(
          VeranstaltungsteilnahmeListe.BenutzerNachnameVornameSortierung,
          false);
      } else if (sortierung == SORTIERUNG_KLASSE) {
        veranstaltungsteilnahmeListe.setSortierung(
          VeranstaltungsteilnahmeListe.BenutzerKlasseSortierung, false);
      } else if (sortierung == SORTIERUNG_ANMELDENR) {
        veranstaltungsteilnahmeListe.setSortierung(
          VeranstaltungsteilnahmeListe.AnmeldeNrSortierung, false);
      } else if (sortierung == SORTIERUNG_BEMERKUNGEN) {
        veranstaltungsteilnahmeListe.setSortierung(
          VeranstaltungsteilnahmeListe.BemerkungenSortierung, false);
      } else {
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
      }
      fireTableDataChanged();
      return;
    }

    if (benutzerListe != null) {
      if (sortierung == SORTIERUNG_NAME) {
        benutzerListe.setSortierung(
          BenutzerListe.NachnameVornameSortierung, false);
      } else if (sortierung == SORTIERUNG_KLASSE) {
        benutzerListe.setSortierung(
          BenutzerListe.KlasseNachnameVornameSortierung, false);
      } else if (sortierung == SORTIERUNG_ANMELDENR) {
        throw new IllegalArgumentException("Eine Benutzerliste kann nicht "+
          "nach der Anmeldenummer sortiert werden!");
      } else if (sortierung == SORTIERUNG_BEMERKUNGEN) {
        throw new IllegalArgumentException("Eine Benutzerliste kann nicht "+
          "nach den Bemerkungen sortiert werden!");
      } else {
        throw new IllegalArgumentException("Eine Sortierung mit der Nummer "+
          sortierung + " ist unbekannt!");
      }
      fireTableDataChanged();
      return;
    }
  }

  public void save() {
    if (veranstaltungsteilnahmeListe != null) {
      Iterator it = veranstaltungsteilnahmeListe.iterator();
      while(it.hasNext()) {
        Veranstaltungsteilnahme aktuelleTeilnahme =
          (Veranstaltungsteilnahme) it.next();
        aktuelleTeilnahme.save();
        aktuelleTeilnahme.getBenutzer().save();
      }
    }

    if (benutzerListe != null) {
      Iterator it = benutzerListe.iterator();
      while (it.hasNext()) {
        ((Benutzer) it.next()).save();
      }
    }
    fireTableDataChanged();
  }

  public void reload() {
    if (veranstaltungsteilnahmeListe != null) {
      Iterator it = veranstaltungsteilnahmeListe.iterator();
      while(it.hasNext()) {
        Veranstaltungsteilnahme aktuelleTeilnahme =
          (Veranstaltungsteilnahme) it.next();
        aktuelleTeilnahme.reload();
        aktuelleTeilnahme.getBenutzer().reload();
      }
    }

    if (benutzerListe != null) {
      Iterator it = benutzerListe.iterator();
      while (it.hasNext()) {
        ((Benutzer) it.next()).reload();
      }
    }
    fireTableDataChanged();
  }
}
