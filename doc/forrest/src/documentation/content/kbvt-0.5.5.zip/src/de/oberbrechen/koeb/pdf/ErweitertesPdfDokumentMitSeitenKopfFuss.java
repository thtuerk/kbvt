/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import com.lowagie.text.pdf.*;

/**
 * Diese Klasse dient dazu eine Tabelle einfach als PDF-Datei auszugeben. Die
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.6 $
 */
public abstract class ErweitertesPdfDokumentMitSeitenKopfFuss
  extends ErweitertesPdfDokument {

  protected SeitenKopfFuss seitenKopfErsteSeite;
  protected SeitenKopfFuss seitenKopf;
  protected SeitenKopfFuss seitenFuss;

  //Anpassungen der Position des Seitenkopfes; um diese Werte wird der
  //Seitenkopf nach Unten verschoben
  protected float seitenKopfPosition = 0;
  protected float seitenKopfPositionErsteSeite = 0;

  /**
   * Liefert den unteren Seitenrand in Points, wobei die H�he des Seitenfu�es
   * zum normalen Rand hinzugerechnet wird
   *
   * @param die Nummer der Seite
   * @return den unteren Seitenrand in Points unter Ber�cksichtigung des
   *   Seitenfu�es
   */
  public float getSeitenRandUntenMitFuss(int seitenNr) {
    if (seitenFuss == null) return randUnten;
    return randUnten + seitenFuss.getHoehe(seitenNr);
  }

  /**
   * Liefert den oberen Seitenrand in Points, wobei die H�he des Seitenkopfes
   * zum normalen Rand hinzugerechnet wird
   * @param die Nummer der Seite
   * @return den oberen Seitenrand in Points unter Ber�cksichtigung des
   *   Seitenkopfes
   */
  public float getSeitenRandObenMitKopf(int seitenNr) {
    if (seitenNr == 1) {
      if (seitenKopfErsteSeite != null)
        return randOben + seitenKopfErsteSeite.getHoehe(1);
    } else {
      if (seitenKopf != null) return randOben + seitenKopf.getHoehe(seitenNr);
    }
    return randOben;
  }

  /**
   * Finalisiert alle seit Seitenk�pfe / -f��e 
   * mit der �bergebenen Gesamtseitenanzahl.
   * @param gesamtseitenAnzahl
   */
  public void finalisiere(int gesamtseitenAnzahl) {  
    if (seitenKopf != null) seitenKopf.finalisiere(gesamtseitenAnzahl);
    if (seitenKopfErsteSeite != null) 
      seitenKopfErsteSeite.finalisiere(gesamtseitenAnzahl);
    if (seitenFuss != null) seitenFuss.finalisiere(gesamtseitenAnzahl);
  }
  
  /**
   * Schreibt den Seitenkopf und -fu� auf die aktuelle Seite
   */
  protected void schreibeSeitenKopfFuss(int seitenNr, PdfContentByte pdf) {
    PdfTemplate template;
    if (seitenNr == 1 && seitenKopfErsteSeite != null) {
      template = seitenKopfErsteSeite.getSeitenKopfFuss(this, pdf, seitenNr);
      pdf.addTemplate(template, 0, this.getSeitenHoehe()-
        getSeitenRandObenMitKopf(1)-seitenKopfPositionErsteSeite);
    } else if (seitenKopf != null) {
      template = seitenKopf.getSeitenKopfFuss(this, pdf, seitenNr);
      pdf.addTemplate(template, 0, this.getSeitenHoehe()-
        getSeitenRandObenMitKopf(seitenNr)-seitenKopfPosition);
    }

    if (seitenFuss != null) {
      template = seitenFuss.getSeitenKopfFuss(this, pdf, seitenNr);      
      pdf.addTemplate(template, 0, this.getSeitenRandUnten());
    }
  }
}