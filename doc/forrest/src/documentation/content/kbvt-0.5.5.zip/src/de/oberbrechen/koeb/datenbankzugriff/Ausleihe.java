/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.einstellungen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Calendar;
import java.util.Observable;

/**
* Diese Klasse repr�sentiert eine Ausleihe.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.21 $
*/

public class Ausleihe extends Observable {

  // Die Attribute der Benutzer wie in der Datenbank
  private int ausleihNr;
  private Benutzer benutzer;
  private Medium medium;
  private java.sql.Date ausleihdatum, rueckgabedatum, sollrueckgabedatum;
  private String bemerkungen;
  private Mitarbeiter mitarbeiterAusleihe;
  private Mitarbeiter mitarbeiterRueckgabe;


  //diese Variablen werden benutzt, um eine doppelt verkettete Liste
  //f�r die Verl�ngerung von Ausleihen darzustellen
  private Ausleihe verlaengerteAusleihe;
  private Ausleihe verlaengerndeAusleihe;

  private boolean isSaved;
  private boolean verlaengerungGeladen = false;


  private static PreparedStatement loescheUnnoetigeAusleiheStatement;
  private static PreparedStatement verlaengerteAusleiheStatement;
  private static PreparedStatement verlaengerndeAusleiheStatement;
  private static PreparedStatement ladeAusleiheStatement;
  static{
    try {
      loescheUnnoetigeAusleiheStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "delete from ausleihe where Medium = ? AND "+
          "Benutzer = ? AND Rueckgabedatum = ? AND Ausleihdatum = ? AND "+
          "Nr != ?");
      verlaengerteAusleiheStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select nr from ausleihe where Medium = ? AND "+
          "Benutzer = ? AND Rueckgabedatum = ? AND nr != ?");
      verlaengerndeAusleiheStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select nr from ausleihe where Medium = ? AND "+
          "Benutzer = ? AND Ausleihdatum = ? AND nr != ?");
      ladeAusleiheStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select * from ausleihe where nr = ?");
    } catch (SQLException e) {
      throw new RuntimeException("Unerwarteter Fehler beim Initialisieren "+
        "der Statements f�r die Ausleihe!");
    }
  }

  /**
   * Liefert eine unsortierte Liste aller Ausleihen.
   *
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihen() {
    AusleihenListe liste = new AusleihenListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from ausleihe");
      while (result.next()) {
        try {
          Ausleihe neueAusleihe = new Ausleihe(result);
          liste.add(neueAusleihe);
        } catch (DatenbankzugriffException e) {
          ErrorHandler.getInstance().handleException(e,
            "Fehler beim Laden einer Ausleihe f�r die Gesamtausleihenliste:\n", false);
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihliste!", true);
    }

    return liste;
  }

  /**
   * Liefert eine unsortierte Liste aller Ausleihen, die zwischen den beiden �bergebenen
   * Zeitpunkten get�tigt wurden.
   * 
   * @param von der Startzeitpunkt
   * @param bis der Entzeitpunkt
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihenInZeitraum(java.util.Date von, java.util.Date bis) {
    AusleihenListe liste = new AusleihenListe();

    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection().prepareStatement(
        "select * from ausleihe where ausleihdatum >= ? AND ausleihdatum <= ?");
      statement.setDate(1, new java.sql.Date(von.getTime()));
      statement.setDate(2, new java.sql.Date(bis.getTime()));
      ResultSet result = statement.executeQuery();
      while (result.next()) {
        try {
          Ausleihe neueAusleihe = new Ausleihe(result);
          liste.add(neueAusleihe);
        } catch (DatenbankzugriffException e) {
          ErrorHandler.getInstance().handleException(e,
            "Fehler beim Laden einer Ausleihe f�r die Ausleihenliste:\n", false);
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihliste!", true);
    }

    return liste;
  }

  /**
   * Liefert eine unsortierte Liste aller Ausleihen, die im �bergebenen
   * Monat get�tigt wurden.
   * 
   * @param monat die Nr des Monats von 1 bis 12
   * @param jahr das Jahr
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihenInMonat(int monat, int jahr) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(jahr, monat-1, 1);
    java.util.Date von = calendar.getTime();
    
    calendar.set(jahr, monat, 1);
    calendar.add(Calendar.DATE, -1);
    java.util.Date bis = calendar.getTime();    
    
    return getAlleAusleihenInZeitraum(von, bis);
  }

  /**
   * Liefert die Anzahl aller Ausleihen, die im �bergebenen
   * Monat get�tigt wurden.
   * 
   * @param monat die Nr des Monats von 1 bis 12
   * @param jahr das Jahr
   * @see AusleihenListe
   */
  public static int getAnzahlAusleihenInMonat(int monat, int jahr) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(jahr, monat-1, 1);
    java.util.Date von = calendar.getTime();
    
    calendar.set(jahr, monat, 1);
    calendar.add(Calendar.DATE, -1);
    java.util.Date bis = calendar.getTime();    
    
    int erg = 0;
    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection().prepareStatement(
        "select count(*) from ausleihe where ausleihdatum >= ? AND ausleihdatum <= ?");
      statement.setDate(1, new java.sql.Date(von.getTime()));
      statement.setDate(2, new java.sql.Date(bis.getTime()));
      ResultSet result = statement.executeQuery();

      result.next();
      erg = result.getInt(1);
      
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihliste!", true);
    }

    return erg;
  }

  /**
   * Liefert eine unsortierte Liste aller aktuellen Ausleihen des �bergebenen
   * Benutzers.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAktuellenAusleihenVon(Benutzer benutzer) {
    if (benutzer == null) throw new NullPointerException();
    return getAlleAusleihenVonAm(benutzer, new Date(System.currentTimeMillis()));
  }

  /**
   * Liefert eine unsortierte Liste aller Ausleihen des �bergebenen
   * Benutzers, die zu dem angegebenen Zeitpunkt zwar ausgeliehen aber noch
   * nicht zur�ckgegeben waren. Ausleihen, die am uebergebenen Datum
   * zurueckgegeben wurden, werden als ebenfalls zurueckgeliefert.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @param datum das Datum an dem die Ausleihen zwar get�tigt, aber noch
   *   nicht zur�ckgegeben waren
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihenVonAm(
    Benutzer benutzer, java.util.Date datum) {
    if (benutzer == null) throw new NullPointerException();
    if (datum == null) datum = new java.util.Date();
    Date sqlDatum = new Date(datum.getTime());

    AusleihenListe liste = new AusleihenListe();
    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection().
        prepareStatement("select * from ausleihe where benutzer=? "+
        "AND (isNull(rueckgabedatum) OR (ausleihdatum <= ? AND "+
        "rueckgabedatum >= ?))");
      statement.setInt(1, benutzer.getBenutzerNr());
      statement.setDate(2, sqlDatum);
      statement.setDate(3, sqlDatum);
      ResultSet result = statement.executeQuery();

      while (result.next()) {
        try {
          Ausleihe neueAusleihe = new Ausleihe(result);
          if (!neueAusleihe.wirdVonAndererAusleiheVerlaengert())
            liste.add(neueAusleihe);
        } catch (DatenbankzugriffException e) {
          ErrorHandler.getInstance().handleException(e,
            "Fehler beim Laden einer Ausleihe f�r die Gesamtausleihenliste:\n", false);        
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihliste!", true);
    }

    return liste;
  }

  /**
   * Liefert eine unsortierte Liste aller wirklichen Ausleihen des �bergebenen
   * Benutzers, d.h. aller Ausleihen des Benutzers, die nicht nur Verl�ngerungen
   * einer anderen Ausleihe darstellen.
   *
   * @param benutzer der Benutzer, dessen ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihenVon(
    Benutzer benutzer) {
    if (benutzer == null) throw new NullPointerException();

    AusleihenListe liste = new AusleihenListe();
    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection().
        prepareStatement("select * from ausleihe where benutzer=?");
      statement.setInt(1, benutzer.getBenutzerNr());
      ResultSet result = statement.executeQuery();

      while (result.next()) {
        try {
          Ausleihe neueAusleihe = new Ausleihe(result);
          liste.add(neueAusleihe);
        } catch (DatenbankzugriffException e) {
          ErrorHandler.getInstance().handleException(e,
            "Fehler beim Laden einer Ausleihe f�r die Gesamtausleihenliste:\n", false);        
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Ausleihliste!", true);
    }

    return liste;
  }

  /**
   * Liefert eine unsortierte Liste aller Ausleihen des �bergebenen
   * Mediums. Ausleihen, die von anderen Ausleihen verl�ngert werden, werden
   * ausgeschlossen.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * AusleihenListe ansprechbar.
   *
   * @param medium das Medium, dessen Ausleihen geliefert werden sollen
   * @see AusleihenListe
   */
  public static AusleihenListe getAlleAusleihenVon(Medium medium) {
    if (medium == null) throw new NullPointerException();
    AusleihenListe liste = new AusleihenListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from ausleihe where medium='"
        +medium.getMedienNr()+"'");
      while (result.next()) {
        try {
        Ausleihe neueAusleihe = new Ausleihe(result);
        if (!neueAusleihe.wirdVonAndererAusleiheVerlaengert())
          liste.add(neueAusleihe);
        } catch (DatenbankzugriffException e) {
          ErrorHandler.getInstance().handleException(e,
            "Fehler beim Laden einer Ausleihe f�r die Gesamtausleihenliste:\n", false);        
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Ausleihliste!", true);
    }

    return liste;
  }

  /**
   * Erstellt eine neue, bisher noch nicht in der Datenbank vorhandenen
   * Ausleihe. Alle Attribute der Ausleihe au�er dem Anmeldedatum werden mit
   * null initialisiert, das Anmeldedatum mit dem aktuellen Systemdatum.
   * Beim ersten Speichern wird automatisch eine passende Ausleihnummer
   * zugewiesen.
   */
  public Ausleihe() {
    ausleihNr = 0;
    bemerkungen = null;
    benutzer = null;
    medium = null;
    ausleihdatum = new Date(System.currentTimeMillis());
    rueckgabedatum = null;
    sollrueckgabedatum = null;
    mitarbeiterAusleihe = Mitarbeiter.getAktuellenMitarbeiter();
    mitarbeiterRueckgabe = null;

    verlaengerndeAusleihe = null;
    verlaengerteAusleihe = null;

    isSaved = false;
    verlaengerungGeladen = false;
  }

  /**
   * L�d die Daten zu der �bergebenen Ausleihnummer aus der Datenbank.
   * Existiert die Ausleihnummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @throws DatenbankInkonsistenzException falls die Ausleihe auf einen
   *   unbekannten Benutzer, Mitarbeiter oder ein unbekanntes Medium verweist
   * @throws DatenNichtGefundenException falls die Ausleihnr nicht in der
   *   Datenbank vorhanden ist
   */
  protected void loadKomplett() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.istNeu()) return;
    verlaengerungGeladen = true;
    try {
      Ausleihe aktuelleAusleihe = this;
      while (aktuelleAusleihe != null) {
        loescheUnnoetigeAusleiheStatement
          .setString(1, aktuelleAusleihe.getMedium().getMedienNr());
        loescheUnnoetigeAusleiheStatement
          .setInt(2, aktuelleAusleihe.getBenutzer().getBenutzerNr());
        loescheUnnoetigeAusleiheStatement
          .setDate(3, aktuelleAusleihe.getAusleihdatum());
        loescheUnnoetigeAusleiheStatement
          .setDate(4, aktuelleAusleihe.getAusleihdatum());
        loescheUnnoetigeAusleiheStatement
          .setInt(5, aktuelleAusleihe.getAusleihNr());
        loescheUnnoetigeAusleiheStatement.execute();

        verlaengerteAusleiheStatement
          .setString(1, aktuelleAusleihe.getMedium().getMedienNr());
        verlaengerteAusleiheStatement
          .setInt(2, aktuelleAusleihe.getBenutzer().getBenutzerNr());
        verlaengerteAusleiheStatement
          .setDate(3, aktuelleAusleihe.getAusleihdatum());
        verlaengerteAusleiheStatement
          .setInt(4, aktuelleAusleihe.getAusleihNr());

        Ausleihe neueAusleihe = null;
        ResultSet result = verlaengerteAusleiheStatement.executeQuery();
        boolean ausleiheGefunden = result.next();
        if (ausleiheGefunden) {
          int neueAusleihNr = result.getInt("nr");

          neueAusleihe = new Ausleihe(neueAusleihNr);
          neueAusleihe.verlaengerndeAusleihe = this;
          aktuelleAusleihe.verlaengerteAusleihe = neueAusleihe;
        }
        aktuelleAusleihe = neueAusleihe;
      }

      if (this.istZurueckgegeben()) {
        aktuelleAusleihe = this;
        while (aktuelleAusleihe != null) {
          loescheUnnoetigeAusleiheStatement
            .setString(1, aktuelleAusleihe.getMedium().getMedienNr());
          loescheUnnoetigeAusleiheStatement
            .setInt(2, aktuelleAusleihe.getBenutzer().getBenutzerNr());
          loescheUnnoetigeAusleiheStatement
            .setDate(3, aktuelleAusleihe.getRueckgabedatum());
          loescheUnnoetigeAusleiheStatement
            .setDate(4, aktuelleAusleihe.getRueckgabedatum());
          loescheUnnoetigeAusleiheStatement
            .setInt(5, aktuelleAusleihe.getAusleihNr());
          loescheUnnoetigeAusleiheStatement.execute();

          verlaengerndeAusleiheStatement
            .setString(1, aktuelleAusleihe.getMedium().getMedienNr());
          verlaengerndeAusleiheStatement
            .setInt(2, aktuelleAusleihe.getBenutzer().getBenutzerNr());
          verlaengerndeAusleiheStatement
            .setDate(3, aktuelleAusleihe.getRueckgabedatum());
          verlaengerndeAusleiheStatement
            .setInt(4, aktuelleAusleihe.getAusleihNr());

          Ausleihe neueAusleihe = null;
          ResultSet result = verlaengerndeAusleiheStatement.executeQuery();
          boolean ausleiheGefunden = result.next();
          if (ausleiheGefunden) {
            int neueAusleihNr = result.getInt("nr");

            neueAusleihe = new Ausleihe(neueAusleihNr);
            neueAusleihe.verlaengerteAusleihe = this;
            aktuelleAusleihe.verlaengerndeAusleihe = neueAusleihe;
          }
          aktuelleAusleihe = neueAusleihe;
        }
      }

    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "der Ausleihe mit der Nummer "+ausleihNr, true);
    }
    this.setChanged();
    this.notifyObservers();
  }

  private Ausleihe(ResultSet result) throws DatenbankInkonsistenzException, SQLException {
    this.init(result);
  }

  /**
   * Initialisiert die Ausgabe mit den Werten, die aus dem Resultset gelesen
   * werden
   */
  private void init(ResultSet result) throws SQLException, DatenbankInkonsistenzException {
    isSaved = true;
    ausleihNr = result.getInt("nr");
    int benutzerNr = result.getInt("benutzer");
    String mediumNr = result.getString("medium");
    ausleihdatum = result.getDate("ausleihdatum");
    sollrueckgabedatum = result.getDate("sollrueckgabedatum");
    rueckgabedatum = result.getDate("rueckgabedatum");

    int mitarbeiterAusleiheNr = result.getInt("mitarbeiterAusleihe");
    int mitarbeiterRueckgabeNr = result.getInt("mitarbeiterRueckgabe");

    bemerkungen = result.getString("bemerkungen");

    // Verl�ngerungskette wird in loadKomplett aufgebaut
    verlaengerndeAusleihe = null;
    verlaengerteAusleihe = null;
    verlaengerungGeladen = false;

    //teste, ob alle wichtigen Informationen vorhanden sind
    if (benutzerNr == 0 || ausleihdatum == null ||
        sollrueckgabedatum == null)
      throw new DatenbankInkonsistenzException("Die Ausleihe mit der "+
      "Nummer "+ausleihNr+" ist nicht vollst�ndig!");

    //hole die Daten zu den gelesenen Verweisen
    try {
      benutzer = Benutzer.getBenutzer(benutzerNr);
    } catch (DatenNichtGefundenException e) {
      throw new DatenbankInkonsistenzException("Die Ausleihe Nr "+
          ausleihNr + " enth�lt eine Referenz auf den Benutzer mit der Nr"+
          benutzerNr +". Dieser Benutzer exitiert jedoch nicht!");
    }

    try {
      if (mediumNr == null) {
        medium = new NichtEingestelltesMedium();
      } else {
        medium = Medium.getMedium(mediumNr);
      }
    } catch (DatenNichtGefundenException e) {
      throw new DatenbankInkonsistenzException("Die Ausleihe Nr "+
          ausleihNr + " enth�lt eine Referenz auf das Medium mit der Nr '"+
          mediumNr +"'. Dieses Medium exitiert jedoch nicht!");
    }

    if (mitarbeiterAusleiheNr == 0) {
      mitarbeiterAusleihe = null;
    } else {
      try {
        mitarbeiterAusleihe = Mitarbeiter
                            .getMitarbeiter(mitarbeiterAusleiheNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Ausleihe Nr "+
            ausleihNr + " enth�lt eine Referenz auf den Mitarbeiter mit "+
            "der Nr "+mitarbeiterAusleiheNr+". Dieser Mitarbeiter "+
            "exitiert jedoch nicht!");
      }
    }

    if (mitarbeiterRueckgabeNr == 0) {
      mitarbeiterRueckgabe = null;
    } else {
      try {
        mitarbeiterRueckgabe = Mitarbeiter
                             .getMitarbeiter(mitarbeiterRueckgabeNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Ausleihe Nr "+
            ausleihNr + " enth�lt eine Referenz auf den Mitarbeiter mit "+
            "der Nr "+mitarbeiterRueckgabeNr+". Dieser Mitarbeiter "+
            "exitiert jedoch nicht!");
      }
    }
  }

  /**
   * L�d die Daten zu der �bergebenen Ausleihnummer aus der Datenbank.
   * Existiert die Ausleihnummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param ausleihNr die Ausleihnummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenbankInkonsistenzException falls die Ausleihe auf einen
   *   unbekannten Benutzer, Mitarbeiter oder ein unbekanntes Medium verweist
   * @throws DatenNichtGefundenException falls die Ausleihnr nicht in der
   *   Datenbank vorhanden ist
   */
  protected void load(int ausleihNr) throws DatenbankInkonsistenzException, DatenNichtGefundenException {

    try {
      ladeAusleiheStatement.setInt(1, ausleihNr);
      ResultSet result = ladeAusleiheStatement.executeQuery();

      boolean ausleiheGefunden = result.next();
      if (!ausleiheGefunden) throw new DatenNichtGefundenException(
        "Eine Ausleihe mit der Nr "+ausleihNr+" existiert nicht!");

      init(result);

    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "der Ausleihe mit der Nummer "+ausleihNr, true);
    }
  }

  /**
   * Bestimmt, ob es sich um eine neue Ausleihe handelt, d.h. um eine
   * Ausleihe, die gerade neu angelegt wird und noch nicht in der Datenbank
   * gespeichert ist.
   *
   * @return <code>true</code> gdw die Ausleihe neu ist
   */
  public boolean istNeu() {
    return (ausleihNr == 0);
  }

  /**
   * L�d alle Daten der Ausleihe erneut aus der Datenbank. Ist die
   * Ausleihe noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls die Ausleihe inzwischen aus der
   *   Datenbank entfernt wurde
   * @throws DatenbankInkonsistenzException falls die Ausleihe auf einen
   *   unbekannten Benutzer, Mitarbeiter oder ein unbekanntes Medium verweist
   */
  public void reload() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.istNeu()) return;
    this.load(this.getAusleihNr());
  }

  /**
   * Erstellt ein neues <code>Ausleihe</code>-Objekt. Dazu wird die Ausleihe
   * mit der �bergebenen Ausleihnummer aus der Datenbank geladen.
   * Existiert die Ausleihnummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param ausleihNr die Ausleihnummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenbankInkonsistenzException falls die Ausleihe auf einen
   *   unbekannten Benutzer, Mitarbeiter oder ein unbekanntes Medium verweist
   * @throws DatenNichtGefundenException falls die Ausleihnr nicht in der
   *   Datenbank vorhanden ist
   */
  public Ausleihe(int ausleihNr) throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    this.load(ausleihNr);
  }

  /**
   * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
   * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
   *         <code>FALSE</code> sonst
   */
  public boolean istGespeichert() {
    return isSaved;
  }

  /**
   * Speichert die Ausleihe bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws UnvollstaendigeDatenException falls der Benutzer, das Medium,
   *   das Ausleihdatum oder das Sollr�ckgabedatum nicht angegeben sind
   */
  public void save() throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {
    
    if (isSaved) return;

    if (benutzer == null)
      throw new UnvollstaendigeDatenException("Der Benutzer "+
        "der Ausleihe ist nicht angegeben.");
    if (ausleihdatum == null)
      throw new UnvollstaendigeDatenException("Das Datum, an dem das Medium "+
        "ausgeliehen wurde, ist nicht angegeben.");
    if (medium == null) medium = new NichtEingestelltesMedium();    
    if (sollrueckgabedatum == null)
      sollrueckgabedatum = new Date(Buecherei.getInstance()
        .getAusleihordnung().getAusleihenBisDatum(medium).getTime());

    try {
      testeMediumBereitsVerliehen();
      PreparedStatement statement = null;

      if (this.istNeu()) {
        ausleihNr = Ausleihe.getNeueAusleihnr();
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "insert into ausleihe set "+
          "nr = ?, Benutzer = ?, "+
          "Medium = ?, Ausleihdatum = ?, SollRueckgabedatum = ?, "+
          "Rueckgabedatum = ?, MitarbeiterAusleihe = ?, "+
          "MitarbeiterRueckgabe = ?, Bemerkungen = ?");
      } else {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "update ausleihe set " +
          "nr = ?, Benutzer = ?, " +
          "Medium = ?, Ausleihdatum = ?, SollRueckgabedatum = ?, " +
          "Rueckgabedatum = ?, MitarbeiterAusleihe = ?, " +
          "MitarbeiterRueckgabe = ?, Bemerkungen = ? " +
          "where nr="+ausleihNr);
      }

      statement.setInt(1,this.getAusleihNr());
      statement.setInt(2, this.getBenutzer().getBenutzerNr());
      if (getMedium() instanceof NichtEingestelltesMedium) {
        statement.setString(3, null);
      } else {
        statement.setString(3, this.getMedium().getMedienNr());
      }
      statement.setDate(4, this.getAusleihdatum());
      statement.setDate(5, this.getSollRueckgabedatum());
      statement.setDate(6, this.getRueckgabedatum());
      if (this.getMitarbeiterAusleihe() == null) {
        statement.setInt(7, 0);
      } else {
        statement.setInt(7, this.getMitarbeiterAusleihe().getMitarbeiterNr());
      }
      if (this.getMitarbeiterRueckgabe() == null) {
        statement.setInt(8, 0);
      } else {
        statement.setInt(8, this.getMitarbeiterRueckgabe().getMitarbeiterNr());
      }
      statement.setString(9, this.getBemerkungen());

      statement.execute();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern der folgenden "+
        "Ausleihe:\n\n"+this.toDebugString(), true);
    }
    isSaved = true;
    this.setChanged();
    this.notifyObservers();
  }

  /**
   * �berpr�ft, ob die Ausleihe mit einer anderen Ausleihe in Konflikt ger�t,
   * weil das auszuleihende Medium im entsprechenden Zeitraum schon als
   * ausgeliehen eingetragen ist. In diesem Fall wird eine
   * MediumBereitsVerliehenException geworfen.
   *
   * @throws MediumBereitsVerliehenException falls die Ausleihe mit einer
   *   anderen Ausleihe in Konflikt ger�t
   */
  private void testeMediumBereitsVerliehen() throws DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {
      
    if (this.getMedium() instanceof NichtEingestelltesMedium) return;

    try {
      PreparedStatement statement;
      Connection connection = Datenbank.getInstance().getConnection();
      if (this.istZurueckgegeben()) {
        statement = connection.prepareStatement("select nr from "+
          "ausleihe where nr != "+this.getAusleihNr()+" AND "+
          "medium = '"+this.getMedium().getMedienNr()+"' AND "+
          "(ausleihdatum <= ?) AND "+
          "(isNull(rueckgabedatum) OR rueckgabedatum > ?)");
        statement.setDate(1, this.getRueckgabedatum());
        statement.setDate(2, this.getAusleihdatum());
      } else {
        statement = connection.prepareStatement("select nr from "+
          "ausleihe where nr != "+this.getAusleihNr()+" AND "+
          "medium = '"+this.getMedium().getMedienNr()+"' AND "+
          "(isNull(rueckgabedatum) OR rueckgabedatum > ?)");
        statement.setDate(1, this.getAusleihdatum());
      }
      ResultSet result = statement.executeQuery();
      boolean ausleiheGefunden = result.next();
      if (ausleiheGefunden) {
        Ausleihe konfliktAusleihe = new Ausleihe(result.getInt("nr"));
        throw new MediumBereitsVerliehenException(konfliktAusleihe, this);
      }
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim �berpr�fen, ob das "+
        "Medium der folgenden Ausleihe bereits ausgeliehen ist:\n\n"
        +this.toDebugString(), true);
    }
  }

  /**
   * Bestimmt, ob die Ausleihe �berzogen ist, d.h. das Sollr�ckgabedatum
   * bereits verstrichen ist
   *
   * @return <code>true</code> gdw. die Ausleihe �berzogen ist
   */
  public boolean istUeberzogen() {
    long ueberzogenInMilliSekunden =
      System.currentTimeMillis() - getSollRueckgabedatum().getTime();
    long milliSekundenProTag = 1000*60*60*24;

    return (ueberzogenInMilliSekunden > milliSekundenProTag);
  }

  /**
   * Liefert die Anzahl der Tage, die die Ausleihe �berzogen ist.
   * @return die Anzahl der Tage, die die Ausleihe �berzogen ist
   */
  public int getUeberzogeneTage() {
    return getUeberzogeneTage(new java.util.Date());
  }

  /**
   * Liefert die Anzahl der Tage, die die Ausleihe
   * zum �bergebenen Zeitpunkt �berzogen ist
   * @param zeitpunkt der Zeitpunkt
   * @return die Anzahl der Tage, die die Ausleihe
   * zum �bergebenen Zeitpunkt �berzogen ist
   */
  public int getUeberzogeneTage(java.util.Date zeitpunkt) {
    final long milliSekundenProTag = 1000*60*60*24;

    if (rueckgabedatum != null &&
        rueckgabedatum.getTime() < zeitpunkt.getTime()-milliSekundenProTag)
      return 0;

    long ueberzogenInMilliSekunden =
      zeitpunkt.getTime() - getSollRueckgabedatum().getTime();

    if (ueberzogenInMilliSekunden < 0) return 0;
    return (int) Math.floor(
      (double) ueberzogenInMilliSekunden / milliSekundenProTag);
  }

  /**
   * Bestimmt, ob die Ausleihe schon zur�ckgegeben ist.
   * @return <code>true</code> gdw. die Ausleihe zur�ckgegeben ist
   */
  public boolean istZurueckgegeben() {
    return (rueckgabedatum != null);
  }

  /**
   * Bestimmt, ob es sich um eine aktuelle Ausleihe handelt. Eine Ausleihe ist
   * aktuell, wenn sie noch nicht oder heute zur�ckgegeben wurde.
   *
   * @return <code>true</code> gwd. es sich um eine aktuelle Ausleihe handelt
   */
  public boolean istAktuell() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    return (!istZurueckgegeben() || heuteZurueckgegeben());
  }

  /**
   * Bestimmt, ob die Ausleihe heute zur�ckgegeben wurde; d.h. ob das
   * Rueckgabedatum dem aktuellen Datum entspricht und diese
   * Ausleihe von keiner anderen Ausleihe verl�ngert wird.
   *
   * @return <code>true</code> gdw. die Ausleihe heute zur�ckgegeben wurde.
   */
  public boolean heuteZurueckgegeben() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (!this.istZurueckgegeben() ||
        this.wirdVonAndererAusleiheVerlaengert()) return false;

    long milliSekundenSeitRueckgabe =
      System.currentTimeMillis() - this.getRueckgabedatum().getTime();
    long milliSekundenProTag = 1000*60*60*24;

    return (milliSekundenSeitRueckgabe < milliSekundenProTag &&
            milliSekundenSeitRueckgabe > -milliSekundenProTag);
  }

  /**
   * Bestimmt, ob die Ausleihe aktuell verl�ngert wurde; d.h. ob diese
   * Ausleihe eine Verl�ngerung einer anderen Ausleihe ist und diese
   * Verl�ngerung entweder heute oder in der Zukunft beginnt.
   *
   * @return <code>true</code> gdw. die Ausleihe aktuell verl�ngert wurde.
   */
  public boolean istAktuellVerlaengert() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (!this.verlaengertAndereAusleihe()) return false;

    long milliSekundenSeitAusleihe =
      System.currentTimeMillis() - this.getAusleihdatum().getTime();
    long milliSekundenProTag = 1000*60*60*24;

    return (milliSekundenSeitAusleihe < milliSekundenProTag);
  }

  /**
   * Bestimmt, ob die Ausleihe heute get�tigt wurde; d.h. ob das Medium
   * heute ausgeliehen wurde und es sich nicht um eine Verl�ngerung handelt.
   * @return <code>true</code> gdw. die Ausleihe heute get�tigt wurde
   */
  public boolean heuteAusgeliehen() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.verlaengertAndereAusleihe()) return false;

    long milliSekundenSeitAusleihe =
      System.currentTimeMillis() - this.getAusleihdatum().getTime();
    long milliSekundenProTag = 1000*60*60*24;

    return (milliSekundenSeitAusleihe < milliSekundenProTag &&
            milliSekundenSeitAusleihe > -milliSekundenProTag);
  }

  /**
   * L�scht die Ausleihe aus der Datenbank.
   */
  public void loesche() {
    //nichts zu tun, falls Ausleihe noch nicht gespeichert ist
    if (this.istNeu()) return;

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      statement.execute("delete from ausleihe where "+
        "nr="+this.getAusleihNr());

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Benutzers:\n\n"+this.toDebugString(), true);
    }
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Ausleihe ").append(ausleihNr);
    ausgabe.append("\n-------------------------------");
    ausgabe.append("\nBenutzer            : ").append(benutzer);
    ausgabe.append("\nMedium              : ").append(medium);
    ausgabe.append("\nAusleihdatum        : ").append(ausleihdatum);
    ausgabe.append("\nSollr�ckgabedatum   : ").append(sollrueckgabedatum);
    ausgabe.append("\nR�ckgabedatum       : ").append(rueckgabedatum);
    ausgabe.append("\nMitarbeiter Ausleihe: ").append(mitarbeiterAusleihe);
    ausgabe.append("\nMitarbeiter R�ckgabe: ").append(mitarbeiterRueckgabe);
    ausgabe.append("\nBemerkungen         : ").append(bemerkungen);
    ausgabe.append("\n");

    return ausgabe.toString();
  }

  public String toString() {
    return Integer.toString(ausleihNr);
  }

  /**
   * Bestimmt die gr��te verwendete Ausleihnummer.
   * @return die gr��te verwendete Ausleihnummer
   */
  public static int getGroessteAusleihnr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from ausleihe");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Ausleihnummer!", true);
    }

    return maxNr;
  }

  /**
   * Bestimmt die n�chste freie Ausleihnummer.
   * @return die n�chste freie Ausleihnummer
   */
  public static int getNeueAusleihnr() {
    return getGroessteAusleihnr()+1;
  }

  /**
   * Liefert die Nummer der Ausleihe.
   * @return die Nummer der Ausleihe
   */
  public int getAusleihNr() {
    return ausleihNr;
  }

  /**
   * Liefert den Benutzer, den diese Ausleihe betrifft
   * @return den Benutzer, den diese Ausleihe betrifft
   */
  public Benutzer getBenutzer() {
    return benutzer;
  }

  /**
   * Liefert das Medium, das diese Ausleihe betrifft
   * @return den Medium, das diese Ausleihe betrifft
   */
  public Medium getMedium() {
    return medium;
  }

  /**
   * Liefert den Mitarbeiter, der das Medium herausgab
   * @return den Mitarbeiter, der das Medium herausgab
   */
  public Mitarbeiter getMitarbeiterAusleihe() {
    return mitarbeiterAusleihe;
  }

  /**
   * Liefert den Mitarbeiter, der das Medium zur�cknahm
   * @return den Mitarbeiter, der das Medium zur�cknahm
   */
  public Mitarbeiter getMitarbeiterRueckgabe() {
    return mitarbeiterRueckgabe;
  }

  /**
   * Liefert das Datum, an dem das Medium ausgeliehen wurde
   * @return das Datum, an dem das Medium ausgeliehen wurde
   */
  public Date getAusleihdatum() {
    return ausleihdatum;
  }

  /**
   * Liefert das Datum, an dem das Medium zur�ckgegeben werden soll
   * @return das Datum, an dem das Medium zur�ckgegeben werden soll
   */
  public Date getSollRueckgabedatum() {
    return sollrueckgabedatum;
  }

  /**
   * Liefert das Datum, an dem das Medium zur�ckgegeben wurde. Ist
   * das Medium noch nicht zur�ckgegeben wird <code>null</code> geliefert.
   *
   * @return das Datum, an dem das Medium zur�ckgegeben wurde
   */
  public Date getRueckgabedatum() {
    return rueckgabedatum;
  }

  /**
   * Liefert das Datum, an dem das Medium ausgeliehen wurde, wobei
   * ber�cksichtigt wird, dass die Ausleihe evtl. andere Ausleihen verl�ngert.
   * Es wird das Ausleihdatum der ersten Ausleihe, die keine andere Ausleihe
   * verl�ngert, geliefert.
   * @return das Datum, an dem das Medium ausgeliehen wurde
   */
  public Date getAusleihdatumVerlaengerungen() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.verlaengertAndereAusleihe())
      return this.getVerlaengerteAusleihe().getAusleihdatumVerlaengerungen();
    else
      return ausleihdatum;
  }

  /**
   * Liefert das Datum, an dem das Medium zur�ckgegeben werden soll, wobei
   * ber�cksichtigt wird, dass die Ausleihe evtl. von einer anderen Ausleihe
   * verl�ngert wird. D.h. es wird das Sollr�ckgabedatum der
   * letzten Verl�ngerung dieser Ausleihe geliefert.
   *
   * @return das Datum, an dem das Medium zur�ckgegeben werden soll
   */
  public Date getSollRueckgabedatumVerlaengerungen() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.wirdVonAndererAusleiheVerlaengert()) 
      return this.getVerlaengerndeAusleihe().getSollRueckgabedatumVerlaengerungen();
    else
      return sollrueckgabedatum;
  }

  /**
   * Liefert das Datum, an dem das Medium zur�ckgegeben wurde, wobei evtuelle
   * Verl�ngerungen ber�cksichtigt werden. D.h. es wird das R�ckgabedatum der
   * letzten Verl�ngerung dieser Ausleihe geliefert. Ist
   * das Medium noch nicht zur�ckgegeben wird <code>null</code> geliefert.
   *
   * @return das Datum, an dem das Medium zur�ckgegeben wurde
   */
  public Date getRueckgabedatumVerlaengerungen() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (this.wirdVonAndererAusleiheVerlaengert())
      return this.getVerlaengerndeAusleihe().getRueckgabedatumVerlaengerungen();
    else
      return rueckgabedatum;
  }

  /**
   * Liefert die Bemerkungen zu dieser Ausleihe.
   * @return die Bemerkungen zu dieser Ausleihe
   */
  public String getBemerkungen() {
    return bemerkungen;
  }

  /**
   * Liefert die Ausleihe, die von dieser Ausleihe verl�ngert wird, oder
   * <code>null</code>, falls diese Ausleihe keine andere Ausleihe verl�ngert.
   *
   * @return die Ausleihe, die von dieser Ausleihe vorl�ngert wird
   */
  public Ausleihe getVerlaengerteAusleihe() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (!verlaengerungGeladen) loadKomplett();
    return verlaengerteAusleihe;
  }

  /**
   * Bestimmt, ob diese Ausleihe von einer anderen Ausleihe verl�ngert wird
   * @return <code>true</code> gdw. diese Ausleihe von einer anderen Ausleihe
   *   verl�ngert wird
   */
  public boolean wirdVonAndererAusleiheVerlaengert() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    return (this.getVerlaengerndeAusleihe() != null);
  }

  /**
   * Bestimmt, ob diese Ausleihe eine andere Ausleihe verl�ngert
   * @return <code>true</code> gdw. diese Ausleihe eine
   *   andere Ausleihe verl�ngert
   */
  public boolean verlaengertAndereAusleihe() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    return (this.getVerlaengerteAusleihe() != null);
  }

  /**
   * Liefert die Ausleihe, die diese Ausleihe verl�ngert, oder
   * <code>null</code>, falls diese Ausleihe nicht verl�ngert wird.
   *
   * @return die Ausleihe, die diese Ausleihe verl�ngert
   */
  public Ausleihe getVerlaengerndeAusleihe() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (!verlaengerungGeladen) loadKomplett();
    return verlaengerndeAusleihe;
  }


  /**
   * Setzt den Benutzer, den diese Ausleihe betrifft
   * @param benutzer der neue Benutzer, den diese Ausleihe betrifft
   */
  public void setBenutzer(Benutzer benutzer) {
    isSaved = false;
    this.benutzer = benutzer;
  }

  /**
   * Setzt das Medium, das diese Ausleihe betrifft
   * @param medium das neue Medium, das diese Ausleihe betrifft
   */
  public void setMedium(Medium medium) {
    isSaved = false;
    this.medium = medium;
  }

  /**
   * Setzt den Mitarbeiter, der das Medium herausgab
   * @param mitarbeiterAusleihe der neue Mitarbeiter, der das Medium herausgab
   */
  public void setMitarbeiterAusleihe(Mitarbeiter mitarbeiterAusleihe) {
    isSaved = false;
    this.mitarbeiterAusleihe = mitarbeiterAusleihe;
  }

  /**
   * Setzt den Mitarbeiter, der das Medium zur�cknahm
   * @param mitarbeiterRueckgabe der neue Mitarbeiter, der das Medium zur�cknahm
   */
  public void setMitarbeiterRueckgabe(Mitarbeiter mitarbeiterRueckgabe) {
    isSaved = false;
    this.mitarbeiterRueckgabe = mitarbeiterRueckgabe;
  }

  /**
   * Setzt das Datum, an dem das Medium ausgeliehen wurde
   * @param ausleihdatum das neue Datum, an dem das Medium ausgeliehen wurde
   */
  public void setAusleihdatum(java.util.Date ausleihdatum) {
    isSaved = false;
    if (ausleihdatum == null)
      this.ausleihdatum = null;
    else
      this.ausleihdatum = new Date(ausleihdatum.getTime());
  }

  /**
   * Setzt das Datum, an dem das Medium zur�ckgegeben werden soll
   * @param sollrueckgabedatum das neue Datum, an dem das Medium zur�ckgegeben
   *   werden soll
   */
  public void setSollRueckgabedatum(java.util.Date sollrueckgabedatum) {
    isSaved = false;
    if (sollrueckgabedatum == null)
      this.sollrueckgabedatum = null;
    else
      this.sollrueckgabedatum = new Date(sollrueckgabedatum.getTime());
  }

  /**
   * Setzt das Datum, an dem das Medium zur�ckgegeben wurde.
   * <code>null</code> bedeutet, dass das Medium noch nicht zur�ckgegeben wurde.
   *
   * @param rueckgabedatum das Datum, an dem das Medium zur�ckgegeben wurde
   */
  public void setRueckgabedatum(java.util.Date rueckgabedatum) {
    isSaved = false;
    if (rueckgabedatum == null)
      this.rueckgabedatum = null;
    else
      this.rueckgabedatum = new Date(rueckgabedatum.getTime());
  }

  /**
   * Setzt die Bemerkungen zu dieser Ausleihe.
   * @param bemerkungen die neuen Bemerkungen zu dieser Ausleihe
   */
  public void setBemerkungen(String bemerkungen) {
    isSaved = false;
    this.bemerkungen = bemerkungen;
  }


  /**
   * Verl�ngert die aktuelle Ausleihe und liefert das Ergebnis der Verl�ngerung.
   * Zum Verl�ngern wird der aktuelle Mitarbeiter verwendet.
   *
   * @return die Ausleihe, die die diese Ausleihe verl�ngert
   */
  public Ausleihe verlaengere() throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {
    return this.verlaengere(Mitarbeiter.getAktuellenMitarbeiter());
  }

  /**
   * Verl�ngert die Ausleihe bis mindestens zum �bergebenen Datum. 
   * Zum Verl�ngern wird der aktuelle Mitarbeiter verwendet. D.h.
   * es wird evtl. mehrfach verl�ngert, bis das Sollr�ckgabedatum mindestens
   * dem �bergebenen Datum entspricht.
   * @param datum das Datum, bis zu dem verl�ngert werden soll
   * @return die letzte Verl�ngerung
   */
  public Ausleihe verlaengereBisMindestens(java.util.Date datum) {
    return verlaengereBisMindestens(
      datum, Mitarbeiter.getAktuellenMitarbeiter());
  }

  /**
   * Verl�ngert die Ausleihe bis mindestens zum �bergebenen Datum. 
   * Zum Verl�ngern wird der �bergebene Mitarbeiter verwendet. D.h.
   * es wird evtl. mehrfach verl�ngert, bis das Sollr�ckgabedatum mindestens
   * dem �bergebenen Datum entspricht.
   * @param datum das Datum, bis zu dem verl�ngert werden soll
   * @param mitarbeiter der zu verwendende Mitarbeiter
   * @return die letzte Verl�ngerung
   */
  public Ausleihe verlaengereBisMindestens(java.util.Date datum, 
    Mitarbeiter mitarbeiter){
    Ausleihe aktuelleAusleihe = this;
    
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(datum);
    calendar.add(Calendar.DATE, -1);
    
    java.util.Date endDatum = calendar.getTime();
    
    while (endDatum.after(aktuelleAusleihe.getSollRueckgabedatum())) {
      aktuelleAusleihe = aktuelleAusleihe.verlaengere(mitarbeiter);
    }
    return aktuelleAusleihe;
  }

  /**
   * Verl�ngert die aktuelle Ausleihe und liefert das Ergebnis der Verl�ngerung.
   * Zum Verl�ngern wird der �bergebene Mitarbeiter verwendet.
   *
   * @param mitarbeiter der Mitarbeiter, die die Verl�ngerung t�tigt
   * @throws DatenbankInkonsistenzException falls die Ausleihe aus
   *   Konsistenzgr�nden nicht verl�ngert werden darf
   * @throws WidersprichtAusleihordnungException falls die Ausleihe nicht
   *   verl�ngert werde darf, weil dies der Ausleihordnung widerspricht
   * @return die Ausleihe, die die diese Ausleihe verl�ngert
   */
  public Ausleihe verlaengere(Mitarbeiter mitarbeiter) throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {

    if (this.istZurueckgegeben())
      throw new DatenbankInkonsistenzException("Die Ausleihe Nr. "+
      this.getAusleihNr() +" konnte nicht verl�ngert werden, da das "+
      "zugeh�rige Medium bereits zur�ckgegeben wurde.");

    Ausleihordnung ausleihordnung = Buecherei.getInstance().getAusleihordnung();

    //teste, ob Verl�ngern erlaubt ist
    if (!ausleihordnung.istVerlaengernMoeglich(this)) {
      String fehlerMeldung = "Die Ausleihe Nr. "+this.getAusleihNr()+" konnte "+
        "nicht verl�ngert werden, da die Ausleihordnung dies nicht zulie�.";

      String ausleihordnungMeldung =
        ausleihordnung.getVerlaengernNichtMoeglichBegruendung(this);
      if (ausleihordnungMeldung != null) fehlerMeldung += " Die Begr�ndung "+
        "der Ausleihordnung lautet: "+fehlerMeldung;
      throw new WidersprichtAusleihordnungException(fehlerMeldung);
    }
    
    //eigentliche Verl�ngerung
    java.util.Date rueckgabedatum = new java.util.Date(); 
    Calendar cal = Calendar.getInstance();
    cal.setTime(rueckgabedatum);
    cal.add(Calendar.DATE, -1);
    
    if (cal.getTime().before(this.getAusleihdatum()))
      rueckgabedatum = this.getSollRueckgabedatum();
    
    this.setMitarbeiterRueckgabe(mitarbeiter);
    this.setRueckgabedatum(rueckgabedatum);
    this.save();

    Ausleihe verlaengerung = new Ausleihe();
    verlaengerung.setAusleihdatum(rueckgabedatum);
    verlaengerung.setMitarbeiterAusleihe(mitarbeiter);
    verlaengerung.setMedium(this.getMedium());
    verlaengerung.setBenutzer(this.getBenutzer());
    verlaengerung.setSollRueckgabedatum(
      ausleihordnung.getVerlaengernBisDatum(this, rueckgabedatum));
    verlaengerung.verlaengerteAusleihe = this;
    verlaengerung.save();

    this.verlaengerndeAusleihe = verlaengerung;
    this.save();
    
    return verlaengerung;
  }
  
  /**
   * Liefert die erste Ausleihe in der Folge der aktuellen Verl�ngerungen.
   * @return die erste Ausleihe in der Folge der aktuellen Verl�ngerungen.
   */
  public Ausleihe getErsteAusleiheDerAktuellenVerlaengerungen() {
    if (istAktuellVerlaengert()) 
      return getVerlaengerteAusleihe().getErsteAusleiheDerAktuellenVerlaengerungen();
    
    return this;  
  }
  
  
  /**
   * Macht das verl�ngern der Ausleihe r�ckg�ngig, die von dieser Ausleihe
   * verl�ngert wird. D.h. diese Ausleihe wird gel�scht und die vorherige
   * Ausleihe wieder als nicht zur�ckgegeben gekennzeichnet.
   *
   * @throws DatenbankInkonsistenzException falls das Verl�ngern aus
   *   Konsistenzgr�nden nicht r�ckg�ngig gemacht werden darf
   * @return die Ausleihe, die die von diese Ausleihe verl�ngert wurde
   */
  public Ausleihe verlaengernRueckgaengig() throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {
    if (!this.verlaengertAndereAusleihe()) throw
      new DatenbankInkonsistenzException("Das Verl�ngern kann bei Ausleihe "+
      "Nr. "+this.getAusleihNr()+" nicht r�ckg�ngig gemacht werden, da diese "+
      "Ausleihe keine Verl�ngerung einer anderen Ausleihe ist.");

    Ausleihe verlaengerteAusleihe = this.getVerlaengerteAusleihe();

    this.loesche();

    verlaengerteAusleihe.verlaengerndeAusleihe = null;
    verlaengerteAusleihe.rueckgabedatum = null;
    verlaengerteAusleihe.mitarbeiterRueckgabe = null;
    verlaengerteAusleihe.isSaved = false;
    verlaengerteAusleihe.save();

    return verlaengerteAusleihe;
  }

  public boolean equals(Object ausleihe) {
    if (ausleihe == null) return false;
    if (!(ausleihe instanceof Ausleihe)) return false;

    return (this.getAusleihNr() == ((Ausleihe) ausleihe).getAusleihNr());
  }

  /**
   * Gibt die aktuelle Ausleihe zur�ck. Zur R�ckgabe wird das aktuelle
   * Datum und der �bergebene Mitarbeiter verwendet.
   *
   * @param mitarbeiter der Mitarbeiter, die die R�ckgabe t�tigt
   */
  public void zurueckgeben(Mitarbeiter mitarbeiter) throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {      
    this.setRueckgabedatum(new java.util.Date());
    this.setMitarbeiterRueckgabe(mitarbeiter);
    this.save();
  }

  /**
   * Gibt die aktuelle Ausleihe zur�ck. Zur R�ckgabe wird das aktuelle
   * Datum und der aktuelle Mitarbeiter verwendet.
   */
  public void zurueckgeben() throws UnvollstaendigeDatenException, DatenbankInkonsistenzException, DatenNichtGefundenException, MediumBereitsVerliehenException {
    this.zurueckgeben(Mitarbeiter.getAktuellenMitarbeiter());
  }

  /**
   * Liefert die Anzahl der Verl�ngerungen dieser Ausleihe.
   * @return die Anzahl der Verl�ngerungen dieser Ausleihe
   */
  public int getAnzahlVerlaengerungen() throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (!verlaengerungGeladen) loadKomplett();
    if (verlaengerteAusleihe == null) return 0;
    return verlaengerteAusleihe.getAnzahlVerlaengerungen() + 1;
  }
}