/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import de.oberbrechen.koeb.ausgaben.*;

/**
 * Eine Ausgabe, die als Aktion ein PdfDokument oeffnet
 * @author thtuerk
 */
public class PdfDokumentAusgabe implements Ausgabe {

  private String name;
  private String beschreibung;
  private PdfDokument pdfDokument;
  
  public PdfDokumentAusgabe(String name, String beschreibung,
    PdfDokument pdfDokument) {
    this.name = name;
    this.beschreibung = beschreibung;
    this.pdfDokument = pdfDokument;
  }

  public String getName() {
    return name;
  }

  public String getBeschreibung() {
    return beschreibung;
  }

  public void run(javax.swing.JFrame hauptFenster) throws Exception {
    pdfDokument.zeige(false);
  }
}
