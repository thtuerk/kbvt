/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.benutzerListenAuswahlPanel;

import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;

import javax.swing.JTable;

import de.oberbrechen.koeb.datenbankzugriff.Benutzer;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManagerListenDaten;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class BenutzerTableModel extends AuswahlTableModel
  implements KeyListener, ListenKeySelectionManagerListenDaten {

  private SimpleDateFormat datumsformat = new SimpleDateFormat("dd.MM.yyyy");

	public BenutzerTableModel(JTable tabelle, Liste daten) {
		super(tabelle, daten);
	}

	public int getColumnCount() {
    return 4;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Nr";
    if (columnIndex == 1) return "Name";
    if (columnIndex == 2) return "Anmeldedatum";
    if (columnIndex == 3) return "Adresse";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    if (columnIndex == 0) return Integer.class;
    return String.class;
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    Benutzer gewaehlterBenutzer = (Benutzer) daten.get(rowIndex);
    switch (columnIndex) {
      case 0:
        return new Integer(gewaehlterBenutzer.getBenutzerNr());
      case 1:
        return gewaehlterBenutzer.getNameFormal();
      case 2:
        return datumsformat.format(gewaehlterBenutzer.getAnmeldedatum());
      case 3:
        return gewaehlterBenutzer.getAdresse();
    }
    return "nicht definierte Spalte";
  }

	protected void sortiereNachSpalte(int spalte, boolean umgekehrteSortierung) {
    if (spalte == 0) daten.setSortierung(
      BenutzerListe.BenutzernrSortierung, umgekehrteSortierung);
    else if (spalte == 1) daten.setSortierung(
      BenutzerListe.NachnameVornameSortierung, umgekehrteSortierung);
    else if (spalte == 2) daten.setSortierung(
      BenutzerListe.AnmeldedatumSortierung, umgekehrteSortierung);
    else return;
    
    sortierteSpalte = spalte;
	}

	public void sortiereNachStandardSortierung() {
    sortiereNachSpalte(0, true);
	}
}
