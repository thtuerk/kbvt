/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.mahnungenReiter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.ausleihe.*;
import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.ausgaben.MahnungslisteAusgabenFactory;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;

/**
 * Diese Klasse repr�sentiert den Reiter, der die Anzeige der Mahnungen
 * erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.15 $
 */

public class MahnungenReiter extends JPanel implements AusleiheMainReiter {

  Main hauptFenster;

  JTable mahnungenTable;
  MahnungenTableModel model;

  JButton zuBenutzerButton;
  JButton mahnungslisteButton;

  MahnungslisteAusgabenFactory mahnungslisteAusgabeFactory;

  public MahnungenReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    
    mahnungslisteAusgabeFactory = (MahnungslisteAusgabenFactory) 
      Einstellungen.getInstance().getEinstellungObject(
      null, null, this.getClass().getName(), "MahnungslisteAusgabe", 
      MahnungslisteAusgabenFactory.class, "de.oberbrechen.koeb.pdf." +      "pdfMahnungsListe.PdfMahnungslisteAusgabenFactory");
    
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    //Buttons bauen
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    buttonPanel.setLayout(new GridLayout(1, 2, 15, 5));
    zuBenutzerButton = new JButton("Details");

    zuBenutzerButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        zuBenutzer();
      }
    });
    zuBenutzerButton.setEnabled(false);

    mahnungslisteButton = new JButton("Mahnungsliste");
    mahnungslisteButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mahnungslisteAusgeben();
      }
    });
    buttonPanel.add(zuBenutzerButton);
    buttonPanel.add(mahnungslisteButton);
    

    //Tabelle bauen
    mahnungenTable = new JTable();
    model = new MahnungenTableModel();
    mahnungenTable.setModel(model);
    mahnungenTable.setDefaultRenderer(
      Object.class, new MahnungenTableRenderer());
    mahnungenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    mahnungenTable.setColumnSelectionAllowed(false);
    mahnungenTable.getSelectionModel().addListSelectionListener(
      new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        if (mahnungenTable.getSelectedRow() == -1) {
          zuBenutzerButton.setEnabled(false);
        } else {
          zuBenutzerButton.setEnabled(true);
        }
      }
    });
    mahnungenTable.getTableHeader().addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        int spalteView = mahnungenTable.getColumnModel().
                         getColumnIndexAtX(e.getX());
        int spalte = mahnungenTable.convertColumnIndexToModel(spalteView);

        boolean umgekehrteSortierung =
          (e.getModifiers()&InputEvent.SHIFT_MASK) != 0;
        if (spalte == 0 || spalte == 1) model.getDaten().
          setSortierung(MahnungenListe.BenutzerSortierung,
                        umgekehrteSortierung);
        if (spalte == 2) model.getDaten().
          setSortierung(MahnungenListe.MedienAnzahlSortierung,
                        umgekehrteSortierung);
        if (spalte == 3) model.getDaten().
          setSortierung(MahnungenListe.UeberziehdauerSortierung,
                        umgekehrteSortierung);
        if (spalte == 4) model.getDaten().
          setSortierung(MahnungenListe.MahngebuehrSortierung,
                        umgekehrteSortierung);
      }
    });

    JScrollPane mahnungenScrollPane = new JScrollPane();
    JComponentFormatierer.setDimension(
      mahnungenScrollPane, new Dimension(0, 40));
    mahnungenScrollPane.setBorder(BorderFactory.createCompoundBorder(
      BorderFactory.createEmptyBorder(10,10,10,10),
      BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140))));
    mahnungenScrollPane.getViewport().add(mahnungenTable, null);

    //alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.add(mahnungenScrollPane, BorderLayout.CENTER);
  }

  //Doku siehe bitte Interface
  public void aktualisiere() {
  }

  //Doku siehe bitte Interface
  public void setBenutzer(Benutzer benutzer) {
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }

  //Doku siehe bitte Interface
  public void refresh() {
    model.reload();
  }

  void zuBenutzer() {
    Mahnung aktuelleMahnung = model.getMahnung(mahnungenTable.getSelectedRow());
    hauptFenster.setAktiverBenutzer(aktuelleMahnung.getBenutzer());
    hauptFenster.zeigeAusleiheReiter();
  }

  void mahnungslisteAusgeben() {
    try {
      this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
      Ausgabe ausgabe =mahnungslisteAusgabeFactory.createMahnungslisteAusgabe();
      ausgabe.run(hauptFenster);
      this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Ausgeben der Mahnungsliste:", false);
    }
  }
}