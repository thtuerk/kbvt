/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.alleEinstellungenReiter;

import de.oberbrechen.koeb.datenbankzugriff.*;
import javax.swing.table.AbstractTableModel;

import de.oberbrechen.koeb.datenstrukturen.EinstellungenListe;

/**
* Diese Klasse ist eine Tabellenmodell f�r eine Tabelle von Einstellungen.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.2 $
*/

public class EinstellungenTableModel extends AbstractTableModel {

  private EinstellungenListe daten;
  
  public EinstellungenTableModel() {
  }
  
  public void refresh() {
    daten = Einstellungen.getInstance().getAlleEinstellungen();
    daten.setSortierung(EinstellungenListe.AlphabetischeSortierung, false);
    fireTableDataChanged();
  }
  
  public EinstellungenListe getDaten() {
    return daten;
  } 
    
  //Methoden f�r das TableModel, Doku siehe bitte dort
  public int getRowCount() {
    if (daten == null) return 0;
    return daten.size();
  }

  public int getColumnCount() {
    return 4;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Client";
    if (columnIndex == 1) return "Mitarbeiter";
    if (columnIndex == 2) return "Name";
    if (columnIndex == 3) return "Wert";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    Einstellung gewaehlteEinstellung = getEinstellung(rowIndex);
    
    if (columnIndex == 0) {
      if (gewaehlteEinstellung.getClient() != null) {
        return gewaehlteEinstellung.getClient().getName();
      } else {
        return "-";
      } 
    } 
    if (columnIndex == 1) {
      if (gewaehlteEinstellung.getMitarbeiter() != null) {
        return gewaehlteEinstellung.getMitarbeiter().getName();
      } else {
        return "-";
      } 
    } 
    if (columnIndex == 2) {
      return gewaehlteEinstellung.getName();
    } 
    if (columnIndex == 3) {
      return gewaehlteEinstellung.getWert();
    } 
    return "nicht definierte Spalte";
  }

  public Einstellung getEinstellung(int rowIndex) {
    if (rowIndex < 0 || rowIndex >= daten.size()) 
      throw new IndexOutOfBoundsException();

    return (Einstellung) daten.get(rowIndex);
  }
  
  
  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return (columnIndex == 3);
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    if (columnIndex != 3) return;
    
    Einstellung gewaehlteEinstellung = getEinstellung(rowIndex);
    gewaehlteEinstellung.setWert(aValue.toString());
    gewaehlteEinstellung.save();      
  }
}
