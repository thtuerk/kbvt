/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTabelle;

import com.lowagie.text.pdf.*;
import de.oberbrechen.koeb.pdf.*;

/**
 * Diese Klasse dient dazu eine Tabelle einfach als PDF-Datei auszugeben.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.12 $
 */
public class PdfTabelle {

  private TabellenModell tabellenModell;
  private TabellenKopf tabellenKopf;
  private int aktuelleZeile;
  private boolean istInitialisiert;
  
  public PdfTabelle(TabellenModell tabellenModell) {
    this.tabellenModell = tabellenModell;
    
    this.tabellenKopf = new TabellenKopf(tabellenModell);
    aktuelleZeile = 0;
    istInitialisiert = false;      
  }  

  /**
   * Liefert den TabellenKopf
   * @return den TabellenKopf
   */
  public TabellenKopf getTabellenKopf() {
    return tabellenKopf;
  }
  
  
  /**
   * Schreibt die �bergebene Zeile des Models in die �bergebene Zeile der
   * aktuellen Seite der Tabelle
   *
   * @param modellZeile die Nummer der auszugebendem Zeile des Models
   * @param seitenZeile die Nummer der Seitenzeile an der die Modellzeile
   *   ausgegeben werden soll, die Zeile 1 ist dabei die letzte Zeile der Seite
   * @param seitenNr die Nummer der Seite, auf der die Zeile angezeigt werden soll
   * @param pdf das PdfContentByte, in dem ausgegeben werden soll
   */
  private void schreibeZeile(int modellZeile, int seitenZeile, PdfTemplate pdf,
    ErweitertesPdfDokument parentDokument) {
    float yPos = seitenZeile*15 - 11;

    //eigentlichen Text ausgeben
    pdf.beginText();
    pdf.setFontAndSize(PdfDokument.schriftNormal, 10);
    for (int spalte = 1; spalte <= tabellenModell.getSpaltenAnzahl(); spalte++) {
      // x-Position der Spalte bestimmen
      float links = tabellenModell.getSpaltenPositionLinks(spalte)+
        parentDokument.getSeitenRandLinks();
      float rechts = links + tabellenModell.getBreite(spalte);
      float mitte = (rechts + links) / 2;
      float breite = rechts - links;


      // Text holen und Skalierung bestimmen
      String text = tabellenModell.getEintrag(spalte, modellZeile);
      if (text == null) text = "";
      float textBreite = PdfDokument.schriftNormal.getWidthPoint(text, 10);

      float skalierung = 1;
      if (textBreite > breite || tabellenModell.getSpaltenAusrichtung(spalte) ==
          TabellenModell.SPALTEN_AUSRICHTUNG_BLOCKSATZ) {
        skalierung = breite / textBreite;
        textBreite *= skalierung;
      }
      
      //Position f�r Ausgabe bestimmen
      float xPos = links;
      switch (tabellenModell.getSpaltenAusrichtung(spalte)) {
        case TabellenModell.SPALTEN_AUSRICHTUNG_BLOCKSATZ:
        case TabellenModell.SPALTEN_AUSRICHTUNG_LINKS:
          xPos = links; break;
        case TabellenModell.SPALTEN_AUSRICHTUNG_RECHTS:
          xPos = rechts-textBreite; break;
        case TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL:
        case TabellenModell.SPALTEN_AUSRICHTUNG_ZENTRIERT:
          xPos = mitte-textBreite / 2; break;
      }

      // Ausgabe
      pdf.setHorizontalScaling(skalierung*100);
      pdf.setTextMatrix(xPos, yPos);
      pdf.showText(text);
    }
    pdf.endText();
  }

  public boolean hasNextTemplate() {
    return (aktuelleZeile < tabellenModell.getZeilenAnzahl());
  }
  
  /**
   * Liefert das n�chste Template der Tabelle.
   * @param zeigeSpaltenKopf soll der Spaltenkopf mit ausgegeben werden?
   * @param maximaleLaenge die maximale L�nge, die das Template besitzen darf
   * @param parent das ErweitertesPdfDokument, in das das Template eingef�gt
   *  werden soll
   * @throws Exception
   */
  public PdfTemplate getNextTemplate(boolean zeigeSpaltenKopf, 
    float maximaleLaenge,
    ErweitertesPdfDokument parent, PdfContentByte parentPdf) 
    throws Exception {

    //Bereits alles ausgegeben
    if (aktuelleZeile >= tabellenModell.getZeilenAnzahl()) return null;
    
    if (maximaleLaenge < 50 || (zeigeSpaltenKopf && maximaleLaenge < tabellenKopf.getHoehe(0)+50)) 
      throw new TemplateZuKurzException();
                
    float laengeFuerZeilen = maximaleLaenge;
    if (zeigeSpaltenKopf) laengeFuerZeilen-=tabellenKopf.getHoehe(0);
    int zeilenAnzahlInTemplate = (int) (laengeFuerZeilen/15);
    if (zeilenAnzahlInTemplate + aktuelleZeile > tabellenModell.getZeilenAnzahl())
      zeilenAnzahlInTemplate = tabellenModell.getZeilenAnzahl() - aktuelleZeile;
    
    float templateLaenge = zeilenAnzahlInTemplate*15;
    if (zeigeSpaltenKopf) templateLaenge+=tabellenKopf.getHoehe(0);
    
    PdfTemplate template = parentPdf.createTemplate(parent.getSeitenBreite(),
      templateLaenge);

    if (!istInitialisiert) init(parent);      
		erstelleHintergrund(parent, zeilenAnzahlInTemplate, aktuelleZeile, template);
    erstelleHorizontaleLinien(parent, zeilenAnzahlInTemplate, aktuelleZeile, template);
    erstelleVertikaleLinien(parent, zeilenAnzahlInTemplate, aktuelleZeile, template);
    
    //Spaltentitel
    if (zeigeSpaltenKopf) {
      PdfTemplate spaltenKopfTemplate = 
        tabellenKopf.getSeitenKopfFuss(parent, parentPdf, 1);
      template.addTemplate(spaltenKopfTemplate, 0, template.getHeight()-spaltenKopfTemplate.getHeight());
    }

    // Die unterste Zeile tr�gt die Nummer 1, die vorletzte die Nummer 2 usw.
    int aktuelleSeitenZeile = zeilenAnzahlInTemplate;
    for (int zeile=1; zeile <= zeilenAnzahlInTemplate; zeile++) {
      schreibeZeile(aktuelleZeile+zeile, zeilenAnzahlInTemplate-zeile+1, template, parent);
    }
    aktuelleZeile += zeilenAnzahlInTemplate;

    return template;
  }

  private void erstelleHintergrund(ErweitertesPdfDokument parent,
    int zeilenAnzahlInTemplate, int aktuelleZeile, PdfTemplate template) {

    int spaltenAnzahl = tabellenModell.getSpaltenAnzahl();
    boolean[][] bearbeitet = 
      new boolean[spaltenAnzahl][zeilenAnzahlInTemplate];
    for (int i = 0; i < spaltenAnzahl; i++) {
      for (int j = 0; j < zeilenAnzahlInTemplate; j++) {
        bearbeitet[i][j] = false;
      }        
    }
    
    for (int i = 1; i <= spaltenAnzahl; i++) {
      for (int j = 1; j <= zeilenAnzahlInTemplate; j++) {
        if (!bearbeitet[i-1][j-1]) {
          bearbeitet[i-1][j-1] = true;
          float hintergrund = tabellenModell.getZellenHintergrund(
            aktuelleZeile+j, j, i);            
          
          //wei�er Hintergrund muss nicht gezeichnet werden            
          if (hintergrund == 1) continue; 

          //suche R�nder
          
          //suche zun�chst nach Nachbarzellen in 
          //Zeile mit gleichem Hintergrund
          int i2 = i;
          while (i2 < spaltenAnzahl && tabellenModell.
            getZellenHintergrund(aktuelleZeile+j, j, i2+1) == hintergrund) {
            i2++;
            bearbeitet[i2-1][j-1] = true;              
          }

          //suche zun�chst nach Nachbarzellen in 
          //Zeile mit gleichem Hintergrund
          int j2 = j;
          boolean ok = true;
          while (j2 < zeilenAnzahlInTemplate && ok) {
            for (int pos=i; pos <= i2 && ok; pos++) {
              ok = tabellenModell.getZellenHintergrund(
                aktuelleZeile+j2+1, j2+1, pos) == hintergrund;  
            }              
            if (ok) {
              j2++;
              for (int pos = i; pos <= i2; pos++) {
                bearbeitet[pos-1][j2-1] = true;
              }
            }
          }
          
          //Eigentlichen Hintergrund
          float x = tabellenModell.getSpaltenPositionLinks(i) +
            parent.getSeitenRandLinks();

          float y = (zeilenAnzahlInTemplate-j2)*15;
          float hoehe = (j2 - j + 1)*15;
          float breite = tabellenModell.getSpaltenPositionRechts(i2)-
            tabellenModell.getSpaltenPositionLinks(i);
          if (i2 < spaltenAnzahl) 
            breite += tabellenModell.getSpaltenAbstand(i2)*
                      tabellenModell.getSpaltenAbstandHintergrund(i2);
          if (i > 1) {
            float factor = 1-tabellenModell.getSpaltenAbstandHintergrund(i-1);
            breite += tabellenModell.getSpaltenAbstand(i-1)*factor;          
            x -= tabellenModell.getSpaltenAbstand(i-1)*factor;
          }
          
          template.rectangle(x, y, breite, hoehe);
          template.setGrayFill(hintergrund);
          template.fill();
          template.setGrayFill(0);                
        }
      }        
    }         
  }

	private void erstelleVertikaleLinien(ErweitertesPdfDokument parent,
		int zeilenAnzahlInTemplate, int aktuelleZeile, PdfTemplate template) {

    int spaltenAnzahl = tabellenModell.getSpaltenAnzahl();

    for (int i = 0; i <= spaltenAnzahl; i++) {
      for (int j = 1; j <= zeilenAnzahlInTemplate; j++) {
        float linienDicke = getSpaltenLinienDicke(
          aktuelleZeile, j, i);
        if (linienDicke == 0) continue;
        
        int j2 = j;
        while (j2 < zeilenAnzahlInTemplate && linienDicke == 
          getSpaltenLinienDicke(aktuelleZeile, j2+1, i)) {
            j2++;
        }
        
        float x = tabellenModell.getSpaltenPositionRechts(i) +
          parent.getSeitenRandLinks();          
        if (i < spaltenAnzahl) x += tabellenModell.getSpaltenAbstand(i);
        float y = (zeilenAnzahlInTemplate-j+1)*15;
        float hoehe = (j2-j+1)*15;

        template.setLineWidth(linienDicke);
        template.moveTo(x, y);
        template.lineTo(x, y-hoehe);
        template.stroke();
        j = j2+1;
      }
    }
	}

  private void erstelleHorizontaleLinien(ErweitertesPdfDokument parent,
    int zeilenAnzahlInTemplate, int aktuelleZeile, PdfTemplate template) {

    int spaltenAnzahl = tabellenModell.getSpaltenAnzahl();

    for (int j = 0; j <= zeilenAnzahlInTemplate; j++) {
      for (int i = 1; i <= spaltenAnzahl; i++) {
        float linienDicke = getZeilenLinienDicke(
          zeilenAnzahlInTemplate, aktuelleZeile, j, i);
        if (linienDicke == 0) continue;
        
        int i2 = i;
        while (i2 < spaltenAnzahl && linienDicke == getZeilenLinienDicke(
          zeilenAnzahlInTemplate, aktuelleZeile, j, i2+1)) {
            i2++;
        }
        
        float x = tabellenModell.getSpaltenPositionLinks(i) +
          parent.getSeitenRandLinks();

        float y = (zeilenAnzahlInTemplate-j)*15;
        float breite = tabellenModell.getSpaltenPositionRechts(i2)-
          tabellenModell.getSpaltenPositionLinks(i);
        if (i2 < spaltenAnzahl && getZeilenLinienDicke(
          zeilenAnzahlInTemplate, aktuelleZeile, j, i2+1) != 0) 
          breite += tabellenModell.getSpaltenAbstand(i2);

        template.setLineWidth(linienDicke);
        template.moveTo(x, y);
        template.lineTo(x+breite, y);
        template.stroke();
        i = i2+1;
      }
    }
  }

	private float getSpaltenLinienDicke(int aktuelleZeile, int j, int i) {
		float linienDicke;
		if (i == 0) {        
		  linienDicke = tabellenModell.getZellenRandRechts(aktuelleZeile+j,j,1);
		} else if (i == tabellenModell.getSpaltenAnzahl()) {
		  linienDicke = tabellenModell.getZellenRandRechts(aktuelleZeile+j,j,i);            
		} else {
		  linienDicke = Math.max(
		    tabellenModell.getZellenRandRechts(aktuelleZeile+j,j,i),
		    tabellenModell.getZellenRandLinks(aktuelleZeile+j,j,i+1));                      
		}
    return linienDicke;
	}

  private float getZeilenLinienDicke(int zeilenAnzahlInTemplate, 
    int aktuelleZeile, int j, int i) {
    float linienDicke;
    if (j == 0) {        
      linienDicke = tabellenModell.getZellenRandOben(aktuelleZeile+j+1,j+1,i);
    } else if (j == zeilenAnzahlInTemplate || 
      j + aktuelleZeile == tabellenModell.getZeilenAnzahl()) {
      linienDicke = tabellenModell.getZellenRandUnten(aktuelleZeile+j,j,i);            
    } else {
      linienDicke = Math.max(
        tabellenModell.getZellenRandUnten(aktuelleZeile+j,j,i),
        tabellenModell.getZellenRandOben(aktuelleZeile+j+1,j+1,i));                      
    }
    return linienDicke;
  }

  /**
   * Initialisiert die Ausgabe, d.h. Seitenk�pfe, -f��e werden dahingehend
   * untersucht, wieviel Zeilen auf eine Seite passen und entsprechend
   * positioniert. Au�erdem werden die Spaltenbreiten entsprechend der
   * darzustellenden Daten angepasst.
   */
  public void init(ErweitertesPdfDokument parent) throws SpaltenZuBreitException{
    //bestimme optimale Breite f�r alle Spalten, die ver�nderbar sind
    aktuelleZeile = 0;
    istInitialisiert = true;
    float benoetigteBreite = 0;
    float gesamtBreite = parent.getSeitenBreite() -
      parent.getSeitenRandLinks() - parent.getSeitenRandRechts();

    for (int spalte=1; spalte < tabellenModell.getSpaltenAnzahl(); spalte++)
      gesamtBreite -= tabellenModell.getSpaltenAbstand(spalte);
    float verfuegbareBreite = gesamtBreite;

    for (int spalte=1; spalte <= tabellenModell.getSpaltenAnzahl(); spalte++) {
      if (tabellenModell.getBesitztFesteBreite(spalte)) {
        verfuegbareBreite -= tabellenModell.getBreite(spalte);
      } else if (tabellenModell.getBreiteProzent(spalte) > 0){
        tabellenModell.setBreite(spalte, gesamtBreite/100*
          tabellenModell.getBreiteProzent(spalte));
        verfuegbareBreite -= tabellenModell.getBreite(spalte);
      } else {
        float optBreite = 0;
        double sumBreite = 0;
        float breite = ((TabellenKopf) tabellenKopf).
          getBenoetigeSpaltenBreite(spalte);
        sumBreite += breite*breite*breite*breite;

        for (int zeile=1; zeile <= tabellenModell.getZeilenAnzahl(); zeile++) {
          String text = tabellenModell.getEintrag(spalte, zeile);
          if (text == null) text = "";
          breite = PdfDokument.schriftNormal.getWidthPoint(text, 10);
          sumBreite += breite*breite*breite*breite;
        }
        optBreite = (float) Math.sqrt(Math.sqrt(sumBreite / (tabellenModell.getZeilenAnzahl()+3)));
        tabellenModell.setBreite(spalte, optBreite);
        benoetigteBreite += optBreite;
      }
    }

    //wegen Rundungsfehlern beim Skalieren nicht 0 als Check
    if ((verfuegbareBreite < 0 && benoetigteBreite != 0) || 
        verfuegbareBreite < -2) throw new SpaltenZuBreitException();
       
    if (benoetigteBreite != 0) {      
      float skalierung = verfuegbareBreite / benoetigteBreite;
      for (int spalte=1; spalte <= tabellenModell.getSpaltenAnzahl(); spalte++) {
        if (!tabellenModell.getBesitztFesteBreite(spalte) &&
            !(tabellenModell.getBreiteProzent(spalte) > 0)) {
          float breite = tabellenModell.getBreite(spalte);
          tabellenModell.setBreite(spalte, breite*skalierung);
        }
      }           
    }
  }
}