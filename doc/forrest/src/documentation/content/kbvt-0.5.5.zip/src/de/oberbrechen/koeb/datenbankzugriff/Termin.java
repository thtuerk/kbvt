/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;
import java.text.SimpleDateFormat;


/**
 * Diese Klasse repr�sentiert einen Termin einer Veranstaltung der B�cherei.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 */

public class Termin {

  private static final SimpleDateFormat datumsFormat = new SimpleDateFormat("EE, d. MMMM yyyy");
  private static final SimpleDateFormat zeitFormat = new SimpleDateFormat("H:mm");

  // Statische Speicherung der Termine
  private static Hashtable cache = new Hashtable();

  /**
   * Liefert das zur �bergebenen Nummer passendes
   * <code>Termin</code>-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jeden
   * Termin existiert nur ein Objekt.
   *
   * @param terminNr die Nummer des Termins, der geladen werden soll
   * @throws DatenNichtGefundenException falls der
   *   Termin nicht in der Datenbank existiert
   */
  public static Termin getTermin (int terminNr) throws DatenNichtGefundenException {

    Termin erg = (Termin) cache.get(
      new Integer(terminNr));
    if (erg == null) {
      erg = new Termin(terminNr);
      cache.put(new Integer(terminNr), erg);
    }
    return erg;
  }

  // Die Attribute der Veranstaltung wie in der Datenbank
  private int nr, veranstaltungsNr;
  private java.util.Date beginn, ende;
  private Veranstaltung veranstaltung;

  /**
   * Erstellt einen neuen Termin.
   * @param veranstaltung die Veranstaltung zu der der Termin geh�rt
   * @param beginn der Beginn
   * @param ende das Ende
   */
  public Termin(Veranstaltung veranstaltung, java.util.Date beginn, 
    java.util.Date ende) 
    throws DatenNichtGefundenException {

    if (veranstaltung == null) {
      throw new NullPointerException("Keine Veranstaltung angegeben!");
    }
                     
    this.veranstaltung = veranstaltung;
    this.veranstaltungsNr = veranstaltung.getVeranstaltungsNr();
    this.beginn = beginn;
    this.ende = ende;
    this.nr = 0;
  }

  /**
   * Erstellt ein Kopie dieses Termins.
   * @param terminNr
   * @throws DatenNichtGefundenException
   */
  public Termin deepCopy() {
    return new Termin(this.getVeranstaltung(), beginn, ende);
  }

  /**
   * L�d das zum Parameter geh�rende
   * <code>Termin</code>-Objekt aus der Datenbank.
   * @param terminNr die Nummer des Termins, der geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Termin nicht in der Datenbank existiert
   */
  private Termin(int terminNr) throws DatenNichtGefundenException {

    try {
      Statement statement = Datenbank.getInstance().getStatement();      
      ResultSet result = statement.executeQuery(
        "select * from termin where nr = \"" + terminNr + "\"");
      boolean terminGefunden = result.next();
      if (!terminGefunden) throw new DatenNichtGefundenException(
        "Der Termin mit der Nummer "+terminNr+" existiert nicht!");

      this.nr = terminNr;
      beginn = result.getTimestamp("beginn");
      ende = result.getTimestamp("ende");
      veranstaltungsNr = result.getInt("veranstaltung");
      veranstaltung = null;

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden des "+
        "Termins mit der Nummer "+veranstaltungsNr+"!", true);
    }
  }

  /**
   * Liefert eine chronologisch sortierte Liste aller Termine der
   * �bergebenen Veranstaltung.
   * @param veranstaltung die Veranstaltung, deren Termin bestimmt werden soll
   * @return eine Liste der Termine der Veranstaltung
   */
  public static TerminListe getAlleTermineDerVeranstaltung(Veranstaltung veranstaltung) throws DatenNichtGefundenException {
    TerminListe liste = new TerminListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from termin where veranstaltung = " +
        veranstaltung.getVeranstaltungsNr());
      while (result.next()) {
        int nr = result.getInt("nr");
        liste.add(getTermin(nr));
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Terminliste der Veranstaltung "+veranstaltung+"!", true);
    }
    return liste;
  }

  /**
   * Liefert den Beginn-Zeitpunkt des Termins
   * @return den Beginn-Zeitpunkt des Termins
   */
  public java.util.Date getBeginn() {
    return beginn;
  }

  /**
   * Liefert den End-Zeitpunkt des Termins
   * @return den End-Zeitpunkt des Termins
   */
  public java.util.Date getEnde() {
    return ende;
  }

  /**
   * Setzt den Beginn-Zeitpunkt des Termins
   * @param beginn der neue Beginn-Zeitpunkt des Termins
   */
  public void setBeginn(java.util.Date beginn) {
    this.beginn = beginn;
  }

  /**
   * Setzt den End-Zeitpunkt des Termins
   * @param ende der neue End-Zeitpunkt des Termins
   */
  public void setEnde(java.util.Date ende) {
    this.ende = ende;
  }

  /**
   * Pr�ft, ob der Termin sinnvoll ist. Also ob bspw. der Beginn vor dem 
   * Ende liegt, ein Beginn gesetzt ist, etc. Tritt ein Problem auf, wird eine
   * TerminInkosistenzException geworfen.
   */
  public void check() throws TerminInkonsistenzException {
    if (veranstaltung == null) {
      throw new NullPointerException("Keine Veranstaltung angegeben!");
    }
    if (beginn == null) { 
      throw new TerminInkonsistenzException(
        "Ein Termin muss einen Beginn haben!");
    }  
    if (ende != null && !beginn.before(ende)) { 
      throw new TerminInkonsistenzException(
        "Der Beginn eines Termins muss vor seinem Ende liegen!"); 
    }
  }
  
  /**
   * F�gt diesen Termin neu in die Datenbank ein
   */
  public void insert() throws TerminInkonsistenzException {
    check();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      boolean nrNeuZuweisen = false;
      if (nr == 0) nrNeuZuweisen = true;
      if (!nrNeuZuweisen) {
        ResultSet result = statement.executeQuery(
          "select count(*) from termin where nr = \"" + nr + "\"");
        result.next();
        if (result.getInt(1) > 0) nrNeuZuweisen = true;      
      }
      nrNeuZuweisen = true;
      if (nrNeuZuweisen) {
        ResultSet result = statement.executeQuery(
          "select max(nr) from termin");
        result.next();
        nr = result.getInt(1) + 1;      
      }
      Datenbank.getInstance().releaseStatement(statement);

      Connection connection = Datenbank.getInstance().getConnection();      
      PreparedStatement termineInsertStatement = connection.prepareStatement(
        "insert into termin set nr = ?, veranstaltung = ?, beginn = ?, ende = ?");
      termineInsertStatement.setInt(1, nr);
      termineInsertStatement.setInt(2, veranstaltungsNr);
      Timestamp beginnTimestamp = null;
      if (beginn != null) beginnTimestamp = new Timestamp(beginn.getTime());
      Timestamp endeTimestamp = null;
      if (ende != null) endeTimestamp = new Timestamp(ende.getTime());     
      termineInsertStatement.setTimestamp(3, beginnTimestamp);      
      termineInsertStatement.setTimestamp(4, endeTimestamp);
      termineInsertStatement.execute();      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Einf�gen des folgenden "+
        "Termins:\n\n"+this.toDebugString(), true);
    }    
  }
  /**
   * Liefert die Veranstaltung, zu der der Termin geh�rt
   * @return die Veranstaltung, zu der der Termin geh�rt
   */
  public Veranstaltung getVeranstaltung() throws DatenbankInkonsistenzException {
    if (veranstaltung == null) {
      try {
        veranstaltung = Veranstaltung.getVeranstaltung(veranstaltungsNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Der Termin mit der Nummer "+
          this.getNr()+" verweist auf die nicht existierende Veranstaltung "+
          "mit der Nummer "+veranstaltungsNr);
      }
    }
    return veranstaltung;
  }

  /**
   * Liefert die Nummer des Termins
   * @return die Nummer des Termins
   */
  public int getNr() {
    return nr;
  }

  /**
   * Liefert eine String Repr�sentation des Termins im Format "Beginn - Ende".
   * Beispiel: So, 21. Oktober 2001 11:15 - 12:00 Uhr
   *
   * @return die String-Repr�sentation
   */
  public String getLangesTerminFormat() {
    if (beginn == null) return "-";
    if (ende == null)
      return datumsFormat.format(beginn)+" "+zeitFormat.format(beginn)+" Uhr";
    if (datumsFormat.format(beginn).equals(datumsFormat.format(ende))) {
      return datumsFormat.format(beginn)+" "+zeitFormat.format(beginn)+" - "+
        zeitFormat.format(ende)+ " Uhr";
    }
    return datumsFormat.format(beginn)+" "+zeitFormat.format(beginn)+" - "+
      datumsFormat.format(ende)+" "+zeitFormat.format(ende)+ " Uhr";
  }

  public String toString() {
    return getLangesTerminFormat();
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.toString();
  }
}