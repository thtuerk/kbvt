/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben.ausleihstatistik;

import de.oberbrechen.koeb.datenbankzugriff.Ausleihe;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankzugriffException;

/**
* Diese Klasse repr�sentiert eine allgemeine Ausleihstatistik
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $
*/

public interface Ausleihstatistik {

  /**
   * Liefert die Anzahl der Werte in der Statistik
   * @return die Anzahl der Werte in der Statistik
   */
  public int getEintraegeAnzahl();

  /**
   * Liefert den Namen des Eintrags mit der �bergebenen Nummer. Die Eintr�ge
   * sind von 0 bis getEintraegeAnzahl() nummeriert.
   * @return den Namen des Eintrags
   */
  public String getEintragName(int eintragNr);

  /**
   * Bewertet die �bergebene Ausleihe im Sinne der Statistik. Das �bergebene
   * int[] muss mindestens getEintraegeAnzahl() Werte enthalten. Passt die
   * �bergebene Ausleihe zum Eintrag Nr i, so wird statistik[i] um eins
   * erh�ht.
   *
   * @param ausleihe die zu bewertende Ausleihe
   * @param statistik die zu erg�nzende Statistik
   */
  public void bewerte(Ausleihe ausleihe, int[] statistik) throws DatenbankzugriffException;
}