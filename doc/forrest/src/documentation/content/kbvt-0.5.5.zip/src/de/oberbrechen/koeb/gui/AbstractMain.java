/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.gui.standarddialoge.*;
import de.oberbrechen.koeb.framework.*;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import javax.swing.event.*;

/**
 * Diese Klasse ist eine abstrakte Hauptklasse f�r die 
 * verschiedenen graphischen Oberfl�chen. Sie bietet die allgemeine
 * Funktionalit�t an, muss aber noch konkretisiert werden.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */
public abstract class AbstractMain extends JFrame {

  private static int instanceCount = 0;
  protected Mitarbeiter currentMitarbeiter;

  protected JTabbedPane reiter;
  protected MitarbeiterAuswahlDialog mitarbeiterAuswahlDialog;

  protected Dimension minDimension;
  protected boolean erlaubeAenderungen;
  protected int noetigeMitarbeiterBerechtigung;

  public AbstractMain(boolean isMain, 
    final String titel, int noetigeMitarbeiterBerechtigung, String icon) {
    AbstractMain.instanceCount++;      
    this.noetigeMitarbeiterBerechtigung = noetigeMitarbeiterBerechtigung;
    
    ladeIcon(icon);
    if (isMain) {
      setLookAndFeel();
      ErrorHandler.setInstance(new StandardGUIErrorHandler(this));
    } else {
      currentMitarbeiter = Mitarbeiter.getAktuellenMitarbeiter();
    }

    /*
     * Hintergrundthread bauen. Dieser Thread initialisiert w�hrend
     * der Passworteingabe bereits die GUI und beschleunigt so den
     * Start erheblich
     */
    final AbstractMain abstractMain = this;
    Thread hintergrundThread = new Thread(new Runnable(){
			public synchronized void run() {
        // GUI-Initialisieren
        try {
          jbInit(titel);
          addMenue();
        }
        catch(Exception e) {
          e.printStackTrace();
        }

        erlaubeAenderungen(true);
        reiterHinzufuegen();
        initDaten();
        abstractMain.pack();
        minDimension = abstractMain.getSize();
        SwingUtilities.updateComponentTreeUI(abstractMain);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((dim.width - abstractMain.getWidth())/2, 
          (dim.height - abstractMain.getHeight())/2);
			}});
    hintergrundThread.setPriority(Thread.MIN_PRIORITY);

    if (currentMitarbeiter == null || 
        !currentMitarbeiter.besitztBerechtigung(noetigeMitarbeiterBerechtigung)) {
      mitarbeiterAuswahlDialog = new MitarbeiterAuswahlDialog(this);
      currentMitarbeiter = null;
      hintergrundThread.start();
      mitarbeiterWechseln();
      if (currentMitarbeiter == null) {
        dispose();
        return;
      } //Abbruch, wenn kein Mitarbeiter gew�hlt
    } else {
      hintergrundThread.start();      
    }

    //Wartedialog anzeigen, bis hintergundThread alles initialisiert hat    
    if (hintergrundThread.isAlive()) {
      WarteDialog warteDialog = null;
      
      if (isMain) {
        warteDialog = new WarteDialog();
        warteDialog.setVisible(true);
      } else {
        setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
      }
      Thread.yield();

      synchronized(hintergrundThread) {
        while (hintergrundThread.isAlive()) {
          try {
    				hintergrundThread.wait();
    			} catch (InterruptedException e) {
    				e.printStackTrace();
    			}
        }
      }
  
      if (isMain) {
        warteDialog.dispose();
      } else {
        setCursor(Cursor.getDefaultCursor());
      }
    }

    setMitarbeiter(currentMitarbeiter);
    this.setVisible(true);
  }

  /**
   * F�gt das Men� hinzu
   */
  protected void addMenue() {
    // Men� bauen
    JMenuBar menue = new JMenuBar();
    JMenu dateiMenue = new JMenu("Datei");
    JMenuItem mitarbeiterAendernButton = new JMenuItem("Mitarbeiter wechseln");
    mitarbeiterAendernButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mitarbeiterWechseln();
      }
    });
    JMenuItem exitButton = new JMenuItem("Exit");
    exitButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        dispose();
      }
    });
    JMenuItem mitarbeiterPasswortAendern = new JMenuItem("Mitarbeiterpasswort �ndern");
    mitarbeiterPasswortAendern.setToolTipText("�ndern des Passwortes des aktuellen Mitarbeiters");
    mitarbeiterPasswortAendern.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mitarbeiterPasswortAendern();
      }
    });
    JMenuItem ausgabenButton = new JMenuItem("Ausgabe");
    ausgabenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ausgabeStarten();
      }
    });
    menue.add(dateiMenue);
    dateiMenue.add(mitarbeiterAendernButton);
    dateiMenue.add(mitarbeiterPasswortAendern);
    dateiMenue.addSeparator();
    dateiMenue.add(ausgabenButton);
    dateiMenue.addSeparator();
    dateiMenue.add(exitButton);

    this.setJMenuBar(menue);
  }
  
  protected void ausgabeStarten() {
    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    new de.oberbrechen.koeb.gui.ausgaben.Main(false);
    setCursor(Cursor.getDefaultCursor());
  }  

  public void dispose() {
    super.dispose();
    AbstractMain.instanceCount--;
    if (AbstractMain.instanceCount <= 0) System.exit(0);
  }
  
  /**
   * Initialisiert n�tige Daten
   */
  protected abstract void initDaten();

  /**
   * Wechselt den aktuell angemeldeten Mitarbeiter.
   */
  protected void mitarbeiterWechseln() {
    Mitarbeiter gewaehlterMitarbeiter = mitarbeiterAuswahlDialog.waehleMitarbeiter(
      noetigeMitarbeiterBerechtigung);
    setMitarbeiter(gewaehlterMitarbeiter);  
  }

  /**
   * F�gt die Reiter hinzu. 
   */
  protected abstract void reiterHinzufuegen();

  /**
   * Setzt das aktuelle Look & Feel.
   */
  protected void setLookAndFeel() {
    try {
      UIManager.setLookAndFeel("com.incors.plaf.kunststoff.KunststoffLookAndFeel");
      SwingUtilities.updateComponentTreeUI(this);
    } catch (Exception e) {
      JOptionPane.showMessageDialog( this,
        "Das Kunststoff-Look&Feel konnte nicht geladen werden!", "Ladefehler",
        JOptionPane.ERROR_MESSAGE);
    }
  }

  /**
   * L�d und setzt das Icon des Fensters.
   */
  protected void ladeIcon(String icon) {
    java.net.URL iconURL = ClassLoader.getSystemResource(
      icon);
    if (iconURL != null)
      this.setIconImage(getToolkit().getImage(iconURL));
    else {
       JOptionPane.showMessageDialog( this,
         "Das Icon '"+icon+"' konnte nicht "+
         "geladen werden!", "Ladefehler",
         JOptionPane.ERROR_MESSAGE);
    }

  }


  /**
   * Wechselt den aktuell angemeldeten Mitarbeiter
   * @param mitarbeiter der Mitarbeiter, zu dem gewechselt werden soll
   */
  public void setMitarbeiter(Mitarbeiter mitarbeiter) {
    currentMitarbeiter = mitarbeiter;
    Mitarbeiter.setAktuellenMitarbeiter(mitarbeiter);
  }

  /**
   * Erlaubt / verbietet �ndern der angezeigten Umgebung, d.h. es wird z.B. 
   * das Wechseln des Reiters verboten. Ein solches Verbot
   * ist n�tig, damit w�hrend der Dateneingabe in einem unsauberen Zustand nicht
   * die aktuelle Eingabe verlassen werden kann.
   *
   * @param erlaubt bestimmt, ob �nderungen erlaubt sind
   */
  public void erlaubeAenderungen(boolean erlaubt) {
    erlaubeAenderungen = erlaubt;
    reiter.setEnabled(erlaubt);
    
    JMenuBar menuBar = getJMenuBar();
    if (menuBar != null) {
      int menueAnzahl = menuBar.getMenuCount();
      for (int i=0; i < menueAnzahl; i++) 
        menuBar.getMenu(i).setEnabled(erlaubt);
    }
  }

  /**
   * F�hrt einige Initialisierungen durch.
   */
  public static void init() {
    UIManager.put("OptionPane.yesButtonText", "Ja");
    UIManager.put("OptionPane.noButtonText", "Nein");
    UIManager.put("OptionPane.cancelButtonText", "Abbrechen");

    java.io.File file = new java.io.File("einstellungen.conf");
    KonfigurationsDatei.setStandardDatei(file);    
  }
  
  protected void jbInit(String titel) throws Exception {
    //allgemeinPanel bauen
    JPanel allgemeinPanel = getAllgemeinPanel();
    if (allgemeinPanel != null) allgemeinPanel.setBorder(BorderFactory.createEmptyBorder(10,10,0,10));

    // Reiter bauen
    reiter = new JTabbedPane();
    reiter.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    reiter.addChangeListener(new javax.swing.event.ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        refresh();
      }
    });


    // Alles zusammenbauen
    this.setTitle(titel);
    this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    this.setLocale(new java.util.Locale("de", "DE", "EURO"));

    this.addComponentListener(new java.awt.event.ComponentAdapter() {
      public void componentResized(ComponentEvent e) {
        kontrolliereNeueGroesse();
      }
    });

    this.getContentPane().setLayout(new BorderLayout(10, 5));
    if (allgemeinPanel != null)
      this.getContentPane().add(allgemeinPanel, BorderLayout.NORTH);
    this.getContentPane().add(reiter, BorderLayout.CENTER);
  }

  /**
   * Liefert ein Panel, dass �ber den Reitern angezeigt wird und
   * das so eine Anpassung der GUI erm�glicht.
   * @return
   */
  protected JPanel getAllgemeinPanel() throws Exception {
    return null;
  }

  /**
   * Wird aufgerufen, wenn ein anderer Reiter gew�hlt wurde
   */
  public void refresh() {
    this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
    if (reiter != null) {
      MainReiter currentReiter = (MainReiter) reiter.getSelectedComponent();
      if (currentReiter != null) currentReiter.refresh();
    }
    this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  /**
   * Liefert den aktuell angemeldeten Mitarbeiter
   * @return den aktuell angemeldeten Mitarbeiter
   */
  public Mitarbeiter getAktuellerMitarbeiter() {
    return currentMitarbeiter;
  }

  /**
   * Zeigt das Dialogfeld zum �ndern des Mitarbeiterpasswortes an und speichert
   * das ver�nderte Passwort.
   */
  protected void mitarbeiterPasswortAendern() {
    Mitarbeiter aktuellerMitarbeiter = this.getAktuellerMitarbeiter();
    new PasswortAendernDialog(this).changeMitarbeiterPasswort(
      aktuellerMitarbeiter, true);
    aktuellerMitarbeiter.save();
  }

  /**
   * �berpr�ft nach einem Resize, ob das Fenster noch die Mindestgr��e besitzt.
   * Ist dies nicht der Fall, wird es vergr��ert.
   */
  protected void kontrolliereNeueGroesse() {
    if (minDimension == null) return;
    Dimension currentDimension = this.getSize();
    if (currentDimension.width < minDimension.width ||
        currentDimension.height < minDimension.height) {

      Dimension newDimension = new Dimension(
        Math.max(minDimension.width, currentDimension.width),
        Math.max(minDimension.height, currentDimension.height));

      this.setSize(newDimension);
    }
  }
}