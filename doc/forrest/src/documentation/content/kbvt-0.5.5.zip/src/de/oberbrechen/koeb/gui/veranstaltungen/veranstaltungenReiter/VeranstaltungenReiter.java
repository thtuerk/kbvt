/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.veranstaltungenReiter;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungenListe;
import de.oberbrechen.koeb.gui.components.DelayListSelectionListener;
import de.oberbrechen.koeb.gui.components.veranstaltungenPanel.VeranstaltungenPanel;
import de.oberbrechen.koeb.gui.veranstaltungen.Main;
import de.oberbrechen.koeb.gui.veranstaltungen.VeranstaltungenMainReiter;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Veranstaltungen in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */

public class VeranstaltungenReiter extends JPanel implements VeranstaltungenMainReiter {
  
  Main hauptFenster;
  boolean istVeraenderbar;

  private JButton neuButton = new JButton();
  private JButton saveButton = new JButton();
  private JButton ladenButton = new JButton();

  VeranstaltungenPanel detailsPanel;
  JTable veranstaltungenTabelle;
  private DelayListSelectionListener veranstaltungenTabelleDelayListSelectionListener;
  VeranstaltungenTableModel veranstaltungenTableModel;

  boolean veranstaltungenListeUmgekehrteSortierung;
  int veranstaltungenListeSortierung;

  //Doku siehe bitte Interface
  public void refresh() {
    setVeranstaltungsgruppe(hauptFenster.getAktuelleVeranstaltungsgruppe());
  }

  void initButtons() {
    neuButton.setEnabled(!istVeraenderbar);
    hauptFenster.erlaubeAenderungen(!istVeraenderbar);
    veranstaltungenTabelle.setEnabled(!istVeraenderbar);
    
    if (!istVeraenderbar) {
      ladenButton.setText("L�schen");
      saveButton.setText("Bearbeiten");
    } else {
      ladenButton.setText("�nderungen verwerfen");
      saveButton.setText("Speichern");
    }
    
    boolean veranstaltungAngezeigt = (detailsPanel.getVeranstaltung() != null);
    ladenButton.setEnabled(veranstaltungAngezeigt); 
    saveButton.setEnabled(veranstaltungAngezeigt); 

  }
  
  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  public void setVeraenderbar(boolean veraenderbar) {
    istVeraenderbar = veraenderbar;
    detailsPanel.setVeraenderbar(veraenderbar);
    initButtons();
  }

  /**
   * Erzeugt einen VeranstaltungenReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public VeranstaltungenReiter(Main parentFrame) {
    hauptFenster = parentFrame;

    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

    setVeraenderbar(false);
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Buttons bauen
    neuButton.setText("Neue Veranstaltung anlegen");
    neuButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        neueVeranstaltungAnlegen();
      }
    });
    saveButton.setText("Speichern");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (istVeraenderbar) {
          saveChanges();
        } else {
          setVeraenderbar(true);
        }
      }
    });
    ladenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!istVeraenderbar) {
          loescheVeranstaltung();
        } else {
          aenderungenVerwerfen();
        }
      }
    });
    JPanel buttonPanel = new JPanel();
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    buttonPanel.setLayout(new GridLayout(1, 3, 15, 5));
    buttonPanel.add(saveButton, null);
    buttonPanel.add(ladenButton, null);
    buttonPanel.add(neuButton, null);

    //Details bauen
    detailsPanel = new VeranstaltungenPanel(hauptFenster);
    detailsPanel.setBorder(BorderFactory.createEmptyBorder(10,10,5,10));

    //Medienliste
    veranstaltungenTabelle = new JTable();
    veranstaltungenTableModel = new VeranstaltungenTableModel(veranstaltungenTabelle);
    veranstaltungenTabelle.setModel(veranstaltungenTableModel);
    veranstaltungenTabelle.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    veranstaltungenTabelle.addKeyListener(veranstaltungenTableModel);
    
    veranstaltungenTabelleDelayListSelectionListener = new DelayListSelectionListener(250);
    veranstaltungenTabelleDelayListSelectionListener.addListSelectionListener(
        new ListSelectionListener() {
          public void valueChanged(ListSelectionEvent e) {
            int gewaehlteReihe = veranstaltungenTabelle.getSelectedRow();
            if (gewaehlteReihe != -1 && gewaehlteReihe < veranstaltungenTableModel.getRowCount()) {
              Veranstaltung gewaehlteVeranstaltung = 
                veranstaltungenTableModel.getVeranstaltung(gewaehlteReihe);
              detailsPanel.setVeranstaltung(gewaehlteVeranstaltung);
              initButtons();              
            }
          }
      });
    veranstaltungenTabelle.getSelectionModel().addListSelectionListener(veranstaltungenTabelleDelayListSelectionListener);

    JScrollPane jScrollPane1 = new JScrollPane();
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));

    JPanel medienPanel = new JPanel();
    medienPanel.setLayout(new GridBagLayout());
    medienPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    medienPanel.setMinimumSize(new Dimension(50,80));
    medienPanel.setPreferredSize(new Dimension(50,80));
    medienPanel.add(jScrollPane1,         new GridBagConstraints(0, 0, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    jScrollPane1.getViewport().add(veranstaltungenTabelle, null);

    //alles Zusammenbauen
    this.setLayout(new BorderLayout());
    JSplitPane jSplitPane = new JSplitPane();
    jSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPane.setBorder(BorderFactory.createEmptyBorder());
    jSplitPane.add(detailsPanel, JSplitPane.BOTTOM);
    jSplitPane.add(medienPanel, JSplitPane.TOP);

    this.add(jSplitPane, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
  }

  /**
   * Legt eine neue Veranstaltung an und zeigt es an
   */
  void neueVeranstaltungAnlegen() {
    veranstaltungenTabelleDelayListSelectionListener.fireDelayListSelectionEvent();
    Veranstaltung neueVeranstaltung = new Veranstaltung();
    neueVeranstaltung.setVeranstaltungsgruppe(hauptFenster.getAktuelleVeranstaltungsgruppe());
    detailsPanel.setVeranstaltung(neueVeranstaltung);
    setVeraenderbar(true);
  }

  public void aktualisiere() {
    detailsPanel.aktualisiere();
    refresh();
  }

  /**
   * L�scht die aktuelle Veranstaltung
   */
  public void loescheVeranstaltung() {
    Veranstaltung currentVeranstaltung = detailsPanel.getVeranstaltung();
    boolean loeschenOK = detailsPanel.loescheVeranstaltung();
    if (loeschenOK) {
      veranstaltungenTableModel.getDaten().remove(currentVeranstaltung);
      if (veranstaltungenTableModel.size() > 0) {
        veranstaltungenTabelle.setRowSelectionInterval(0, 0);
        veranstaltungenTabelle.scrollRectToVisible(veranstaltungenTabelle.getCellRect(0, 0, true));
      } else {
        detailsPanel.setVeranstaltung(null);
      }
      initButtons();
    }      
  }

  /**
   * Speichert die gemachten �nderungen
   */
  public void saveChanges() {
    boolean istNeu = detailsPanel.getVeranstaltung().istNeu();
    boolean speichernOK = detailsPanel.saveChanges();
    if (speichernOK) {
      setVeraenderbar(false);
      if (istNeu) veranstaltungenTableModel.getDaten().add(detailsPanel.getVeranstaltung());
      Veranstaltung neueVeranstaltung = detailsPanel.getVeranstaltung();
      detailsPanel.setVeranstaltung(neueVeranstaltung);
    }
    initButtons();      
  }

  /**
   * Verwirft die aktuellen �nderungen.
   */
  public void aenderungenVerwerfen() {
    boolean ok = detailsPanel.aenderungenVerwerfen();
    if (ok) {
      setVeraenderbar(false);
    }
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }

  // Doku siehe bitte Interface
	public void setBenutzer(Benutzer benutzer) {
	}

	public void setVeranstaltungsgruppe(Veranstaltungsgruppe veranstaltungsgruppe) {
    if (veranstaltungsgruppe == null) return;
    
    VeranstaltungenListe liste = veranstaltungsgruppe.getVeranstaltungen();
    liste.setSortierung(VeranstaltungenListe.alphabetischeSortierung, false);
    veranstaltungenTableModel.setDaten(liste);

    if (veranstaltungenTableModel.size() > 0) {
      veranstaltungenTabelle.setRowSelectionInterval(0, 0);
      veranstaltungenTabelle.scrollRectToVisible(veranstaltungenTabelle.getCellRect(0, 0, true));
    } else {
      detailsPanel.setVeranstaltung(null);
    }
	}
}