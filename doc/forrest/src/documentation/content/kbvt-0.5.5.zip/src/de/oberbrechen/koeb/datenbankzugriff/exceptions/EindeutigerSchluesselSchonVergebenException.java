/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.exceptions;

/**
* Diese Exception wird geworfen, wenn versucht wird, einen Datensatz zu
* speichern, aber ein in diesem Datensatz benutzer eindeutiger Schl�ssel schon
* verwendet wird.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/
public class EindeutigerSchluesselSchonVergebenException extends
  DatenbankzugriffException {

  private Object konflikt;


  /**
   * Liefert den Datensatz, der den eindeutigen Schl�ssel bereits verwendet.
   * @return den Datensatz, der den eindeutigen Schl�ssel bereits verwendet
   */
  public Object getKonfliktDatensatz() {
    return konflikt;
  }

  /**
   * Erstellt eine neue EindeutigerSchluesselSchonVergebenException mit
   * der �bergebenen Fehlermeldung und dem �bergebenen Datensatz, der den
   * eindeutigen Schl�ssel schon verwendet.
   *
   * @param meldung die Beschreibung der aufgetretenen Ausnahme
   * @param konfliktDatensatz der Datensatz, der den eindeutigen Schl�ssel
   *   schon verwendet
   */
  public EindeutigerSchluesselSchonVergebenException
    (String meldung, Object konfliktDatensatz) {
    super(meldung);
    konflikt = konfliktDatensatz;
  }
}
