/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfMahnungsListe;

import java.util.Vector;

import de.oberbrechen.koeb.ausgaben.*;
import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.ausgaben.MahnungslisteAusgabenFactory;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
* Diese Factory erstellt eine Ausgabe, die eine PDF-Liste aller 
* Mahnungen ausgibt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class PdfMahnungslisteAusgabenFactory implements 
  MahnungslisteAusgabenFactory, AusgabenFactory {

  private Vector ueberziehungen;
   
  public PdfMahnungslisteAusgabenFactory() {
    ueberziehungen = new Vector();
    ueberziehungen.add(new Integer(0));
  }

  private Ausgabe createMahnungslisteAusgabe(final int minUeberziehungInWochen) {
    String wochen = null;
    if (minUeberziehungInWochen == 0) wochen = null;
    if (minUeberziehungInWochen == 1) wochen = "1 Woche";
    if (minUeberziehungInWochen > 1) wochen = minUeberziehungInWochen+" Wochen";
    
    final String titel;
    final String beschreibung;
    if (wochen == null) {
      titel = "Mahnungsliste";
      beschreibung = "Erstellt eine PDF-Liste aller aktuellen Mahnungen!";
    } else {
      titel = "Mahnungsliste - "+wochen;      
      beschreibung = "Erstellt eine PDF-Liste aller aktuellen " +        "Mahnungen, bei denen ein Medium mindestens "+wochen+" �berzogen ist!";
    }

    return new Ausgabe() {
      public java.lang.String getName() {
        return titel;
      }

      public java.lang.String getBeschreibung() {
        return beschreibung;
      }

      public void run(javax.swing.JFrame hauptFenster) throws Exception {
        new PdfMahnungsListe(7*minUeberziehungInWochen, titel).zeige(false);  
      }
    };
  }
  
    
  public Ausgabe createMahnungslisteAusgabe() {
    return createMahnungslisteAusgabe(0);
  }

  public String getName() {
    return "PDF-Mahngungslisten";
  }

  public String getBeschreibung() {
    return null;
  }

  public void setParameter(String name, String wert) throws ParameterException {
    if (name != null && name.equals("MindestUeberziehungInWochen")) {    
      try {
        int intWert = Integer.parseInt(wert);
        ueberziehungen.add(new Integer(intWert));
      } catch (NumberFormatException e) {
        ErrorHandler.getInstance().handleException(e, "Dem Parameter 'MindestUeberziehungInWochen' " +
          "d�rfen nur Integer-Werte zugewiesen werden. Der Wert '"+wert+"' kann aber nicht als Integer " +
          "interpretiert werden!", false);
      }
    } else {
      throw new ParameterException("Diese Factory unterst�tzt keinen Parameter '"+name+"'!");
    }
  }

  public void addToKnoten(AusgabenTreeKnoten knoten) {
    for (int i=0; i < ueberziehungen.size(); i++) {
      knoten.addAusgabe(createMahnungslisteAusgabe(((Integer) ueberziehungen.get(i)).intValue()));
    }
  }
}