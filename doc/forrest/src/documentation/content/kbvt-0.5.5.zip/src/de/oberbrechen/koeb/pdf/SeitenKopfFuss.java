/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf;

import com.lowagie.text.pdf.*;

/**
 * Dieses Interface repr�sentiert einen Seitenkopf oder Seitenfuss. Die 
 * Benutzung erfolgt wie folgt: Ein ErweitertesPdfDokumentMitSeitenKopfFuss
 * fordert mittels getSeitenKopfFuss einen Seitenkopf bzw. -fuss an.
 * Das Template muss zwar beim Aufruf von getSeitenKopfFuss erstellt,
 * aber nicht vollst�ndig ausgef�llt werden. So ist es m�glich, 
 * z.B. die Gesamtseitenanzahl erst nachtr�glich einzutragen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.6 $
 */
public interface SeitenKopfFuss {

  /**
   * Liefert ein Template, das den Seitenkopf / -fuss f�r die 
   * �bergebene Seite enth�lt.
   *
   * @param pdfDokument das PdfDokument f�r das der Seitenkopf / -fuss
   *   geliefert werden soll
   * @param pdf das Contentbyte, in dem das Template sp�ter ausgegeben
   *   werden soll
   * @param seitenNr die Seitennr, f�r die der Seitenkopf / -fuss
   *   geliefert werden soll
   * @return das Template
   */
  public PdfTemplate getSeitenKopfFuss(ErweitertesPdfDokument
    pdfDokument, PdfContentByte pdf, int seitenNr);

  /**
   * Liefert die H�he des Seitenkopfes / -fusses f�r die �bergebene Seite
   * @param seitenNr die Seitennr
   * @return die H�he
   */
  public float getHoehe(int seitenNr);
  
  /**
   * Finalisiert alle seit dem letzten Aufruf von <code>finalisiere</code> mittels getSeitenKopfFuss
   * abgerufenen Templates mit der �bergebenen Gesamtseitenanzahl.
   * @param gesamtseitenAnzahl
   */
  public void finalisiere(int gesamtseitenAnzahl);  
}