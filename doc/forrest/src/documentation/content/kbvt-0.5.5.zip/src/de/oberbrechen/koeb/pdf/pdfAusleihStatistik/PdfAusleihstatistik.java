/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAusleihStatistik;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Vector;

import de.oberbrechen.koeb.ausgaben.ausleihstatistik.Ausleihstatistik;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTabelle.TabellenModell;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt ein PdfDokument, das eine Liste aller aktuellen Mahnungen
 * enthaelt.
 */
public class PdfAusleihstatistik extends PdfDokument {

  private PdfTemplateDokument pdfDokument; 
  private Ausleihstatistik statistik;
  private int jahr;
  private int monat;
  private SimpleDateFormat dateFormat = new SimpleDateFormat("EE, d. MMM. yyyy");
  private SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM");
  
  public PdfAusleihstatistik(int jahr, Ausleihstatistik statistik) {
    this(-1, jahr, statistik);
  }

  public PdfAusleihstatistik(int monat, int jahr, Ausleihstatistik statistik) {
    this.monat = monat;
    this.jahr = jahr;
    this.statistik = statistik;
    
    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(30);
    String titel;
    if (monat > 0) {
      Calendar monatKalender = Calendar.getInstance();
      monatKalender.set(jahr, monat-1, 1);
      titel = "Ausleihstatistik "+monatDateFormat.format(monatKalender.getTime())+" "+jahr;      
    } else {
      titel = "Ausleihstatistik "+jahr;
    }
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) throws Exception {
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1);
    Vector templates = new Vector();

    Vector monatsDaten = new Vector();
    Vector monatsNamen = new Vector();
    if (monat > 0) {
      StatistikTabellenModell tabellenModell = 
        getStatistikenFuerMonat(monat, jahr, monatsDaten, monatsNamen);
      
      if (tabellenModell.getZeilenAnzahl() > 0) {
        PdfTabelle tabelle = new PdfTabelle(tabellenModell);
        while (tabelle.hasNextTemplate()) {
          PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
          PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(tabellenTemplate.getWidth(), tabellenTemplate.getHeight());
          neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
          
          templates.add(neuesTemplate);
        }
      }    
    } else {    
      for (int monat=1; monat < 13; monat++) {
        StatistikTabellenModell tabellenModell = getStatistikenFuerMonat(monat, jahr, monatsDaten, monatsNamen);
        if (tabellenModell == null) {
          for (int i = 2; i < statistik.getEintraegeAnzahl() +2; i++) {
            tabellenModell.setSpaltenAusrichtung(i,
              TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL);
          }
          tabellenModell.setZeigeSpaltenHintergrund(2, true);
          tabellenModell.setZeigeSpaltenHintergrund(11, true);
          tabellenModell.setZeigeSpaltenHintergrund(20, true);
          tabellenModell.setSpaltenAbstand(2);       
        }
        
        if (tabellenModell.getZeilenAnzahl() > 0) {
          PdfTabelle tabelle = new PdfTabelle(tabellenModell);
          while (tabelle.hasNextTemplate()) {
            PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
            PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(tabellenTemplate.getWidth(), tabellenTemplate.getHeight());
            neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
                        
            neuesTemplate.beginText();
            neuesTemplate.setFontAndSize(PdfDokument.schriftFett, 18);
            neuesTemplate.setHorizontalScaling(100);
            neuesTemplate.setTextMatrix(pdfDokument.getSeitenRandLinks(), 
              neuesTemplate.getHeight()-18);
  
                  
            neuesTemplate.showText(monatsNamen.lastElement().toString()+" "+jahr);
            neuesTemplate.endText();
            templates.add(neuesTemplate);
          }
        }
      }
  
      //Gesamtsumme
      if (monatsDaten.size() > 0) {
        int[] summeStatistik = new int[statistik.getEintraegeAnzahl()];
        Iterator it = monatsDaten.iterator();
        while(it.hasNext()) {
          int[] daten = (int[]) it.next(); 
          for (int i=0; i < summeStatistik.length; i++) {
            summeStatistik[i] += daten[i];
          }
        }
        monatsDaten.add(summeStatistik); 
        monatsNamen.add("Summe");
  
        TabellenModell tabellenModell = new StatistikTabellenModell(monatsDaten, monatsNamen, statistik);
        PdfTabelle tabelle = new PdfTabelle(tabellenModell);
        while (tabelle.hasNextTemplate()) {
          PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
          PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(tabellenTemplate.getWidth(), tabellenTemplate.getHeight());
          neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
          
          templates.add(0, neuesTemplate);
        }
      }
    }                
    pdfDokument.setTemplates((PdfTemplate[]) templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }

  private StatistikTabellenModell getStatistikenFuerMonat(int monat, int jahr, Vector monatsDaten, Vector monatsNamen) {
    AusleihenListe liste = Ausleihe.getAlleAusleihenInMonat(monat, jahr);
    liste.setSortierung(AusleihenListe.AusleihdatumSortierung, false);

    Vector tagesDaten = new Vector();
    Vector tage = new Vector();
    String aktuellerTag = null;
    int[] aktuelleStatistik = null;
    Iterator it = liste.iterator();
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      String neuerTag = dateFormat.format(aktuelleAusleihe.getAusleihdatum());
      if (!neuerTag.equals(aktuellerTag)) {
        if (aktuelleStatistik != null) {
          tagesDaten.add(aktuelleStatistik);
          tage.add(aktuellerTag);
        }
        aktuellerTag = dateFormat.format(aktuelleAusleihe.getAusleihdatum());
        aktuelleStatistik = new int[statistik.getEintraegeAnzahl()];
      }
      statistik.bewerte(aktuelleAusleihe, aktuelleStatistik);
    }

    if (aktuelleStatistik != null) {
      tagesDaten.add(aktuelleStatistik); 
      tage.add(aktuellerTag);

      int[] summeStatistik = new int[statistik.getEintraegeAnzahl()];
      it = tagesDaten.iterator();
      while(it.hasNext()) {
        int[] daten = (int[]) it.next(); 
        for (int i=0; i < summeStatistik.length; i++) {
          summeStatistik[i] += daten[i];
        }
      }
      tagesDaten.add(summeStatistik); 
      tage.add("Summe");

      monatsDaten.add(summeStatistik);
      Calendar monatKalender = Calendar.getInstance();
      monatKalender.set(jahr, monat-1, 1);
      monatsNamen.add(monatDateFormat.format(monatKalender.getTime()));
    }
        
    return new StatistikTabellenModell(tagesDaten, tage, statistik);
  }
  
  
  class StatistikTabellenModell extends TabellenModell {
  
    Vector tagesDaten;
    Vector tage;
    Ausleihstatistik statistik;
    int spaltenAnzahl;
    int zeilenAnzahl;
  
    public StatistikTabellenModell(Vector tagesDaten, Vector tage,
                                   Ausleihstatistik statistik) {
      super(statistik.getEintraegeAnzahl()+1, true);
      this.tagesDaten = tagesDaten;
      this.tage = tage;
      this.statistik = statistik;
      spaltenAnzahl = statistik.getEintraegeAnzahl()+1;
      zeilenAnzahl = tagesDaten.size();
      
      for (int i = 2; i < statistik.getEintraegeAnzahl() +2; i++) {
        setSpaltenAusrichtung(i, TabellenModell.SPALTEN_AUSRICHTUNG_VERTIKAL);        
        setFesteBreite(i, 20);
      }
      setZeigeSpaltenHintergrund(2, true);
      setZeigeSpaltenHintergrund(11, true);
      setZeigeSpaltenHintergrund(20, true);
      setSpaltenAbstand(0);
      setSpaltenAbstand(1, 5);      
      setSpaltenAbstandHintergrund(1, 1);
    }
  
    public int getSpaltenAnzahl() {
      return spaltenAnzahl;
    }
  
    public int getZeilenAnzahl() {
      return zeilenAnzahl;
    }
  
    public String getSpaltenName(int spaltenNr) {
      if (spaltenNr == 1) return "";
      return statistik.getEintragName(spaltenNr-2);
    }
  
    public String getEintrag(int spaltenNr, int zeilenNr) {
      if (spaltenNr == 1) {
        return tage.get(zeilenNr-1).toString();
      }
      int anzahl = ((int[]) tagesDaten.get(zeilenNr-1))[spaltenNr-2];
      if (anzahl == 0) return "-";
      return Integer.toString(anzahl);
    }
    
    public boolean getZeigeZeilenHintergrund(int modellZeile, int seitenZeile) {
      if (modellZeile == getZeilenAnzahl()) return false;
      return super.getZeigeZeilenHintergrund(modellZeile, seitenZeile);
    }

    public float getZellenRandOben(int modellZeile,int seitenZeile,int spalte) {
      if (modellZeile == 1 || modellZeile == getZeilenAnzahl()) return 1;
      return 0;
    }    
  }
}
