/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfAufkleber;

/**
 * Diese Klasse dient dazu, Aufkleber im Format 70 mm mal 36 mm auszugeben. 
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public abstract class PdfAufkleber70x36 extends AbstractPdfAufkleber {
  
  protected PdfPosition getAufkleberPosition(int aufkleberNr) {
    int spalte = (aufkleberNr - 1) % 3 + 1;
    int zeile = (aufkleberNr - spalte) / 3;
    
    float x = (spalte-1)*198.3333f;
    float y = 11+(7-zeile)*102.5f;

    return new PdfPosition(x, y);
  }

  protected int getAufkleberAnzahlProSeite() {
    return 24;
  }

  protected PdfDimension getAufkleberDimension() {
    return new PdfDimension(198.3333f, 102.5f);
  }
}