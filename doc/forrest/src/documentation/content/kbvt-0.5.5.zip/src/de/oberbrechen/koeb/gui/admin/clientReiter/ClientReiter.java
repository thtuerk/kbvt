/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.clientReiter;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.datenbankzugriff.Client;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.gui.admin.AdminMainReiter;
import de.oberbrechen.koeb.gui.admin.Main;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Clients in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class ClientReiter extends JPanel
  implements AdminMainReiter {
  
  private ClientTableModel clientTableModel;
  private JTable clientTable;
  private Main hauptFenster;
  
  public ClientReiter(Main parentFrame) {
    hauptFenster = parentFrame;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Medienliste
    clientTable = new JTable();
    clientTableModel = new ClientTableModel(hauptFenster);
    clientTable.setModel(clientTableModel);
    clientTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    clientTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    clientTable.registerKeyboardAction( new ActionListener() {
       public void actionPerformed(ActionEvent e) {
         removeClient();
      }}, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), JComponent.WHEN_FOCUSED);
    TableColumnModel columnModel = clientTable.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(50);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(250);

    JScrollPane jScrollPane1 = new JScrollPane(clientTable);
    jScrollPane1.setMinimumSize(new Dimension(150,150));
    jScrollPane1.setPreferredSize(new Dimension(150,150));
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));
  
    //Buttonpanel
    JPanel buttonPanel = new JPanel();
    JButton neuButton = new JButton("Neuen Client anlegen");
    neuButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        neuerClient();
      }});
    JButton loeschenButton = new JButton("Client l�schen");
    loeschenButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e) {
        removeClient();
      }});
    
    buttonPanel.setLayout(new GridLayout(1, 2, 10, 0));
    buttonPanel.add(neuButton);
    buttonPanel.add(loeschenButton);
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));    
     
    //Alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(jScrollPane1, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
    this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));    
  }

  
  protected void neuerClient() {
    String erg = JOptionPane.showInputDialog(hauptFenster, 
      "Bitte den Namen des neuen Clients angeben:",
      "Neuen Client anlegen", JOptionPane.OK_CANCEL_OPTION);
    if (erg == null) return;
    if (erg.equals("")) return;

    Client client = new Client();
    client.setName(erg);
    client.save();
    clientTableModel.getDaten().add(client);
    clientTableModel.fireTableDataChanged();
  }

  /**
   * L�scht den in der Tabelle markierte Client 
   * nach einer Sicherheitsabfrage aus der Datenbank.  
   */
  protected void removeClient() {
    int selectedRow = clientTable.getSelectedRow();
    if (selectedRow != -1) {
      Client client = clientTableModel.getClient(selectedRow);
      try {
        int erg = JOptionPane.showConfirmDialog(hauptFenster, 
          "Soll der Client '"+client.toDebugString()+
          "' wirklich gel�scht werden?",
          "Client l�schen?", JOptionPane.YES_NO_OPTION);
        if (erg != JOptionPane.YES_OPTION) return;
  
        client.loesche();
        clientTable.clearSelection();
        clientTableModel.getDaten().remove(selectedRow);
        clientTableModel.fireTableDataChanged();
      } catch (DatenbankInkonsistenzException e) {
        JOptionPane.showMessageDialog(hauptFenster, e.getMessage(),
          "Datenbank Inkonsistenz!", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  public void aktualisiere() {
    refresh();
  }

  public void refresh() {
    clientTableModel.refresh();
    clientTable.doLayout();
  }
}