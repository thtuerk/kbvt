/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.mediumListenAuswahlPanel;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.ListenAuswahlPanel;

/**
* Diese Klasse ist eine Implementierung
* des ListenAuswahlPanels f�r Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/
public class MediumListenAuswahlPanel extends ListenAuswahlPanel {

	public MediumListenAuswahlPanel(JFrame hauptFenster) {
		super(hauptFenster, false);
    this.setPreferredSize(new Dimension(600, 200));
    auswahlTabelle.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    datenTabelle.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    
    TableColumnModel columnModel = datenTabelle.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(100);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(150);
    columnModel.getColumn(3).setPreferredWidth(100);
    columnModel.getColumn(4).setPreferredWidth(150);    

    columnModel = auswahlTabelle.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(100);
    columnModel.getColumn(1).setPreferredWidth(250);
    columnModel.getColumn(2).setPreferredWidth(150);
    columnModel.getColumn(3).setPreferredWidth(100);
    columnModel.getColumn(4).setPreferredWidth(150);    
	}

	protected AuswahlTableModel createDatenAuswahlTableModel(JTable table) {
    AuswahlTableModel auswahlTableModel = 
    new MediumTableModel(table, Medium.getAlleMedien());
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}

	protected AuswahlTableModel createEmptyAuswahlTableModel(JTable table) {
    AuswahlTableModel auswahlTableModel = 
    new MediumTableModel(table, new MedienListe());
    auswahlTableModel.sortiereNachStandardSortierung();
    return auswahlTableModel;
	}
}