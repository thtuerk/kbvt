/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
/*
13/12/2002 - 20:54:54

JLocaleChooserBeanInfo.java  - Bean Info for JLocaleChooser
Copyright (C) 2002 Thomas T�rk
t_tuerk@gmx.de

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package de.oberbrechen.koeb.datenbankzugriff.exceptions;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
* Diese Exception wird geworfen, wenn versucht wird, einen Benutzer f�r eine
* Veranstaltung anzumelden, f�r die er bereits angemeldet ist.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $

*/
public class BenutzerBereitsAngemeldetException extends
  EindeutigerSchluesselSchonVergebenException {

  /**
   * Erstellt eine neue BenutzerBereitsAngemeldetException mit
   * der �bergebenen Fehlermeldung und der �bergebenenen
   * Veranstaltungsteilnahme, die den Benutzer bereits f�r die Veranstaltung
   * anmeldet.
   *
   * @param meldung die Beschreibung der aufgetretenen Ausnahme
   * @param konfliktTeilnahme die Veranstaltungsteilnahme, die den Benutzer
   *   bereits f�r die Veranstaltung anmeldet
   */
  public BenutzerBereitsAngemeldetException(String meldung,
    Veranstaltungsteilnahme konfliktTeilnahme) {

    super(meldung, konfliktTeilnahme);
  }

  /**
   * Erstellt eine neue BenutzerBereitsAngemeldetException mit
   * der Standardfehlermeldung und der �bergebenenen
   * Veranstaltungsteilnahme, die den Benutzer bereits f�r die Veranstaltung
   * anmeldet.
   *
   * @param konfliktTeilnahme die Veranstaltungsteilnahme, die den Benutzer
   *   bereits f�r die Veranstaltung anmeldet
   */
  public BenutzerBereitsAngemeldetException(Veranstaltungsteilnahme
    konfliktTeilnahme) {

    super("Der Benutzer "+ konfliktTeilnahme.getBenutzer().getName()+
      " kann nicht f�r die Veranstaltung "+
      konfliktTeilnahme.getVeranstaltung().getTitel()+" angemeldet werden, "+
      "da die Teilnahme Nummer "+konfliktTeilnahme.getNr()+" dieses Benutzer "+
      "bereits f�r diese Veranstaltung anmeldet!", konfliktTeilnahme);
  }

  /**
   * Liefert die Teilnahme, die in Konflikt mit der Anmeldung steht
   * @return die Teilnahme, die in Konflikt mit der Anmeldung steht
   */
  public Veranstaltungsteilnahme getKonfliktTeilnahme() {
    return (Veranstaltungsteilnahme) super.getKonfliktDatensatz();
  }

}
