/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben.ausleihstatistik;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;

/**
* Diese Klasse repr�sentiert eine allgemeine allgemeine Ausleihstatistik
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.5 $
*/

public class StandardAusleihstatistik implements Ausleihstatistik {

  public int getEintraegeAnzahl() {
    return 19;
  }

  public String getEintragName(int eintragNr) {
    switch (eintragNr) {
      case  0: return "Gesamt";
      case  1: return "Sachb�cher - Erwachsene";
      case  2: return "Sch�ne Literatur - Erwachsene";
      case  3: return "Kinder-, Jugend-, Kindersachb�cher - Erwachsene";
      case  4: return "Spiele - Erwachsene";
      case  5: return "MC - Erwachsene";
      case  6: return "CD - Erwachsene";
      case  7: return "Video - Erwachsene";
      case  8: return "CD-ROM - Erwachsene";
      case  9: return "Gesamt - Erwachsene";
      case  10: return "Sachb�cher - Kinder, Jugendliche";
      case  11: return "Sch�ne Literatur - Kinder, Jugendliche";
      case  12: return "Kinder-, Jugend-, Kindersachb�cher - Kinder, Jugendliche";
      case  13: return "Spiele - Kinder, Jugendliche";
      case  14: return "MC - Kinder, Jugendliche";
      case  15: return "CD - Kinder, Jugendliche";
      case  16: return "Video - Kinder, Jugendliche";
      case  17: return "CD-ROM - Kinder, Jugendliche";
      case  18: return "Gesamt - Kinder, Jugendliche";
    }
    return "-";
  }

  public void bewerte(Ausleihe ausleihe, int[] statistik) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    Medium medium = ausleihe.getMedium();
    statistik[0]+=medium.getMedienAnzahl();

    int offSet = 1;
    //Ausleihe an Jugendlichen?
    if (ausleihe.getBenutzer().getAlter(ausleihe.getAusleihdatum()) < 16)
      offSet = 10;
    statistik[8+offSet]+=medium.getMedienAnzahl();

    if (medium.getMedientyp().getName().equals("MC")) {
      statistik[4+offSet]+=medium.getMedienAnzahl();
    } else if (medium.getMedientyp().getName().equals("CD")) {
      statistik[5+offSet]+=medium.getMedienAnzahl();
    } else if (medium.getMedientyp().getName().equals("Video")) {
      statistik[6+offSet]+=medium.getMedienAnzahl();
    } else if (medium.getMedientyp().getName().equals("Spiel")) {
      statistik[3+offSet]+=medium.getMedienAnzahl();
    } else if (medium.getMedientyp().getName().equals("CD-ROM")) {
      statistik[7+offSet]+=medium.getMedienAnzahl();
    } else if (medium.getMedientyp().getName().equals("Buch")) {

      if (medium.gehoertZuSystematik(Systematik.getSystematik("K"))) {
        statistik[2+offSet]+=medium.getMedienAnzahl();
      } else if (medium.gehoertZuSystematik(Systematik.getSystematik("S"))) {
        statistik[offSet]+=medium.getMedienAnzahl();
      } else {
        statistik[1+offSet]+=medium.getMedienAnzahl();
      }
    }
  }
}