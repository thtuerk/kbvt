/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.einstellungen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.*;

/**
* Diese Klasse repr�sentiert eine Mahnung, d.h. eine Liste von Ausleihen eines
* Benutzers zu einem bestimmten Zeitpunkt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.8 $
*/

public class Mahnung {

  private static PreparedStatement ladeAusleihenStatement;
  private static PreparedStatement ladeBenutzerStatement;

  static{
    try {
      ladeAusleihenStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "delete from ausleihe where Medium = ? AND "+
          "Benutzer = ? AND Rueckgabedatum = ? AND Ausleihdatum = ? AND "+
          "nr != ?");
    } catch (SQLException e) {
      throw new RuntimeException("Unerwarteter Fehler beim Initialisieren "+
        "der Statements f�r die Ausleihe!");
    }
  }

  private AusleihenListe ausleihen;
  private Benutzer benutzer;
  private java.util.Date zeitpunkt;

  /**
   * Erstellt eine Mahnung f�r den �bergebenen Benutzers zum aktuellen Zeitpunkt
   * @param benutzer der Benutzer, f�r den eine Mahnung erstellt werden soll
   */
  public Mahnung(Benutzer benutzer) throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    this(benutzer, null);
  }

  /**
   * Liefert eine Liste aller Benutzer, die zum aktuellen Zeitpunkt
   * Medien �berzogen haben / hatten.
   */
  public static BenutzerListe getAlleBenutzerMitMahnung() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    return getAlleBenutzerMitMahnung(null);
  }

  /**
   * Liefert eine Liste aller Benutzer, die zum �bergebenen Zeitpunkt
   * Medien �berzogen haben / hatten.
   * @param zeitpunkt der Zeitpunkt, zu dem die Mahnung erstellt werden soll
   *   <code>null</code> wird als der aktuelle Zeitpunkt interpretiert
   */
  public static BenutzerListe getAlleBenutzerMitMahnung(
    java.util.Date zeitpunkt) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    BenutzerListe erg = new BenutzerListe();
    try {
      ladeBenutzerStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select distinct benutzer from ausleihe where "+
          "(rueckgabedatum > ? OR isNull(RueckgabeDatum)) AND "+
          "sollrueckgabedatum < ?");

      java.sql.Date sqlZeitpunkt;
      if (zeitpunkt == null) {
        sqlZeitpunkt = new java.sql.Date(System.currentTimeMillis());
      } else {
        sqlZeitpunkt = new java.sql.Date(zeitpunkt.getTime());
      }

      ladeBenutzerStatement.setDate(1, sqlZeitpunkt);
      ladeBenutzerStatement.setDate(2, sqlZeitpunkt);

      ResultSet result = ladeBenutzerStatement.executeQuery();
      while(result.next()) {
        erg.add(Benutzer.getBenutzer(result.getInt(1)));
      }
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Benutzerliste!", true);
    }
    return erg;
  }

  /**
   * Erstellt eine Mahnung f�r den �bergebenen Benutzers zum
   * �bergebenen Zeitpunkt
   * @param benutzer der Benutzer, f�r den eine Mahnung erstellt werden soll
   * @param zeitpunkt der Zeitpunkt, zu dem die Mahnung erstellt werden soll
   *   <code>null</code> wird als der aktuelle Zeitpunkt interpretiert
   */
  public Mahnung(Benutzer benutzer, java.util.Date zeitpunkt) throws DatenbankInkonsistenzException, DatenNichtGefundenException {
    if (benutzer == null)
      throw new IllegalArgumentException(
      "Es darf nicht NULL als Benutzer �bergbenen werden!");

    this.benutzer = benutzer;
    this.zeitpunkt = zeitpunkt;

    try {
      ladeAusleihenStatement =
          Datenbank.getInstance().getConnection().prepareStatement(
          "select nr from ausleihe where Benutzer = ? AND "+
          "((Rueckgabedatum > ?) OR isnull(RueckgabeDatum)) AND "+
          "Sollrueckgabedatum < ?");

      java.sql.Date sqlZeitpunkt = null;
      if (zeitpunkt == null) {
        sqlZeitpunkt = new java.sql.Date(System.currentTimeMillis());
      } else {
        sqlZeitpunkt = new java.sql.Date(zeitpunkt.getTime());
      }

      ladeAusleihenStatement.setInt(1, benutzer.getBenutzerNr());
      ladeAusleihenStatement.setDate(2, sqlZeitpunkt);
      ladeAusleihenStatement.setDate(3, sqlZeitpunkt);

      ResultSet result = ladeAusleihenStatement.executeQuery();
      ausleihen = new AusleihenListe();
      while(result.next()) {
        ausleihen.add(new Ausleihe(result.getInt(1)));
      }
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Benutzerliste!", true);
    }
  }

  /**
   * Liefert eine Liste der Ausleihen, die in dieser Mahnung enthalten sind
   * @return eine Liste der Ausleihen, die in dieser Mahnung enthalten sind
   */
  public AusleihenListe getAusleihenListe() {
    return ausleihen;
  }

  /**
   * Liefert der Anzahl der Ausleihen, die gemahnt werden
   * @return die Anzahl der Ausleihen, die gemahnt werden
   */
  public int getAnzahlAusleihen() {
    return ausleihen.size();
  }

  /**
   * Liefert den Benutzer, dessen Ausleihen angemahnt werden
   * @return den Benutzer, dessen Ausleihen angemahnt werden
   */
  public Benutzer getBenutzer() {
    return benutzer;
  }

  /**
   * Liefert den Zeitpunkt, gez�glich dessen die Mahnungen erstellt wurden
   * @return den Zeitpunkt, gez�glich dessen die Mahnungen erstellt wurden
   */
  public java.util.Date getZeitpunkt() {
    return zeitpunkt;
  }

  /**
   * Liefert die Mahngeb�hren f�r die �berzogenen Ausleihen, zu dem Zeitpunkt,
   * an dem die Mahnung erstellt wurde. Dieser Zeitpunkt kann mittels
   * getZeitpunkt() abgefragt werden.
   * f�r den Zeitpunkt nicht
   *
   * @return die Mahngeb�hren
   */
  public double getMahngebuehren() {
    return Ausleihordnung.getInstance().berechneMahngebuehren(
        getAusleihenListe(), zeitpunkt);
  }

  /**
   * Liefert die l�ngste �berziehung eines Mediums in Tagen
   * @return die l�ngste �berziehung eines Mediums in Tagen
   */
  public int getMaxUeberzogeneTage() {
    int max = 0;

    Iterator it = ausleihen.iterator();
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      int aktuelleUeberziehung = aktuelleAusleihe.getUeberzogeneTage();
      if (aktuelleUeberziehung > max)
        max = aktuelleUeberziehung;
    }

    return max;
  }
}