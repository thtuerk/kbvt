/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfKoeBOberbrechen;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfTemplate;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.EAN;
import de.oberbrechen.koeb.datenstrukturen.MedienListe;
import de.oberbrechen.koeb.einstellungen.Buecherei;
import de.oberbrechen.koeb.pdf.PdfDokument;
import de.oberbrechen.koeb.pdf.components.PdfEANBarcode;
import de.oberbrechen.koeb.pdf.pdfAufkleber.*;
import de.oberbrechen.koeb.pdf.pdfAufkleber.AbstractPdfAufkleber;

/**
 * Diese Klasse erstellt kleine Medienaufkleber
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.1 $
 */
public class PdfMedienaufkleberKlein extends PdfAufkleber35x36 {
     
  float logoWidth;
  MedienListe medienListe;
  PdfTemplate allgemeinTemplate;
  
  public PdfMedienaufkleberKlein(MedienListe medienliste) {
    this.medienListe = medienliste;
    setSchneideMarkierungen(AbstractPdfAufkleber.SCHNEIDEMARKIERUNG_ECKEN);
    setPrintRueckseiten(false);
  }
  
  protected int getAufkleberAnzahl() {
    return medienListe.size();
  }

  protected PdfTemplate getAufkleberRueckSeite(int nr, PdfContentByte pdf) {
    return null;
  }

  protected PdfTemplate getAufkleberVorderSeite(int nr, PdfContentByte pdf) throws DocumentException, BadElementException, MalformedURLException, IOException {
    if (allgemeinTemplate == null) {
      allgemeinTemplate = pdf.createTemplate(99f, 102.5f);
            
      //Logo
      URL logoURL = ClassLoader.getSystemResource(
        "de/oberbrechen/koeb/pdf/pdfKoeBOberbrechen/logoKlein.png");
      Image logo = Image.getInstance(logoURL);
      logo.scalePercent(20/logo.height()*100);
      logoWidth = logo.plainWidth()+5;
      logo.setAbsolutePosition(55, 10);
      logo.setRotationDegrees(90);
      allgemeinTemplate.addImage(logo);
    }
    
    Medium currentMedium = (Medium) medienListe.get(nr-1);
    
    PdfTemplate vorderseiteTemplate = pdf.createTemplate(99, 102.5f);
    vorderseiteTemplate.addTemplate(allgemeinTemplate, 0, 0);
    
    //Barcode
    if (currentMedium.getEAN() == null) {
      currentMedium.setEAN(Buecherei.getInstance().getStandardMedienEAN(
        currentMedium.getMedienNr()));
      currentMedium.save();
    }
    EAN mediumEAN = currentMedium.getEAN();
    PdfTemplate barcodeTemplate = PdfEANBarcode.getTemplate(mediumEAN, pdf, 82.5f, 35);
    vorderseiteTemplate.addTemplate(barcodeTemplate, 0, 1, 1, 0, 14, 10);
  
    //Medienbeschreibung
    String titel = currentMedium.getTitel();
    if (titel == null || titel.equals("")) titel="-";
    String autor = currentMedium.getAutor();
    if (autor == null || autor.equals("")) autor="-";
    String medienNr = currentMedium.getMedienNr();

    float maxBreite = PdfDokument.schriftNormal.getWidthPoint(titel, 8.5f);
    float breite = PdfDokument.schriftNormal.getWidthPoint(autor, 8.5f)+logoWidth;
    if (maxBreite < breite) maxBreite = breite;
    breite = PdfDokument.schriftNormal.getWidthPoint(medienNr, 8.5f)+logoWidth;
    if (maxBreite < breite) maxBreite = breite;   
        
    float skalierung=1;
    if (maxBreite > 82.5f) skalierung = 82.5f/maxBreite; 
          
    vorderseiteTemplate.beginText();
    vorderseiteTemplate.setFontAndSize(PdfDokument.schriftNormal, 8.5f);
    vorderseiteTemplate.setHorizontalScaling(skalierung*100);
    vorderseiteTemplate.setTextMatrix(0, 1, -1, 0, 63.5f, 10+logoWidth);
    vorderseiteTemplate.showText(medienNr);
    vorderseiteTemplate.setTextMatrix(0, 1, -1, 0, 73.5f, 10+logoWidth);
    vorderseiteTemplate.showText(autor);
    vorderseiteTemplate.setTextMatrix(0, 1, -1, 0, 83.5f, 10);
    vorderseiteTemplate.showText(titel);
      
    vorderseiteTemplate.endText();
    return vorderseiteTemplate;
  }
}