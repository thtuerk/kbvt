/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.veranstaltungenPanel;

import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.text.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Date;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltung;
import de.oberbrechen.koeb.datenbankzugriff.Veranstaltungsgruppe;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.TerminListe;
import de.oberbrechen.koeb.datenstrukturen.VeranstaltungsgruppenListe;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.components.SortiertComboBox;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;
import de.oberbrechen.koeb.gui.standarddialoge.DatumAuswahlDialog;

/**
 * Diese Klasse stellt ein Panel dar, mit dem Veranstaltungen
 * angezeigt und bearbeitet werden k�nnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class VeranstaltungenPanel extends JPanel {

  private boolean terminWirdGeradeGecheckt;
	private boolean terminWirdGeradeGeupdated;
	public static DecimalFormat waehrungsFormat = new DecimalFormat("0.00");
  public static SimpleDateFormat terminFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

  private DatumAuswahlDialog datumAuswahlDialog;
	private JButton endeAendernButton;
	private JButton beginnAendernButton;
	private JButton terminHinzufuegenButton;
	private JButton terminLoeschenButton;
	private JTable terminTabelle;
	private TerminTableModel terminModell;
	private boolean istVeraenderbar;
	private JFrame hauptFenster;
	private Veranstaltung aktuelleVeranstaltung;
	private Veranstaltung oldVeranstaltung;
  private Termin aktuellerTermin;
  private int aktuellerTerminIndex;

	// die Datenfelder
	private JTextField titelFeld;
	private JTextField kurzTitelFeld;
	private JTextField ansprechpartnerFeld;
	private JTextArea beschreibungFeld;
	private JTextField kostenFeld;
	private JTextField bezugsgruppeFeld;
	private JTextField waehrungFeld;
	private SortiertComboBox veranstaltungsgruppeFeld;
	private JTextField maximaleTeilnehmeranzahlFeld;
	private JCheckBox anmeldungErforderlichBox;
	private JTextField beginnFeld;
	private JTextField endeFeld;

	/**
	 * Zeigt die �bergebene Veranstaltung an.
	 * @param veranstaltung die anzuzeigende Veranstaltung
	 */
	public void setVeranstaltung(Veranstaltung veranstaltung) {
    terminWirdGeradeGecheckt = true;

		aktuelleVeranstaltung = veranstaltung;
		if (veranstaltung == null) {
			titelFeld.setText(null);
			kurzTitelFeld.setText(null);
			ansprechpartnerFeld.setText(null);
			beschreibungFeld.setText(null);
			kostenFeld.setText(null);
			maximaleTeilnehmeranzahlFeld.setText(null);
			anmeldungErforderlichBox.setSelected(false);
			bezugsgruppeFeld.setText(null);
			waehrungFeld.setText(null);
			veranstaltungsgruppeFeld.setSelectedItem(null);
			terminModell.setDaten(new TerminListe());
		} else {
  		if (!veranstaltung.istNeu()) {
  			oldVeranstaltung = veranstaltung;
  		}
  		titelFeld.setText(veranstaltung.getTitel());
  		kurzTitelFeld.setText(veranstaltung.getKurzTitel());
  		ansprechpartnerFeld.setText(veranstaltung.getAnsprechpartner());
  		beschreibungFeld.setText(veranstaltung.getBeschreibung());
  		kostenFeld.setText(waehrungsFormat.format(veranstaltung.getKosten()));
  		maximaleTeilnehmeranzahlFeld.setText(
  			Integer.toString(veranstaltung.getMaximaleTeilnehmerAnzahl()));
  		anmeldungErforderlichBox.setSelected(
  			veranstaltung.istAnmeldungErforderlich());
  		bezugsgruppeFeld.setText(veranstaltung.getBezugsgruppe());
  		waehrungFeld.setText(veranstaltung.getWaehrung());
  		veranstaltungsgruppeFeld.setSelectedItem(
  			veranstaltung.getVeranstaltungsgruppe());
  		terminModell.setDaten(aktuelleVeranstaltung.getTermine());
    }
    terminWirdGeradeGecheckt = false;
	}

  /**
   * Liest die �nderungen am aktuellen Termin
   */
  private void updateTermin() {
    if (aktuellerTermin == null || terminWirdGeradeGeupdated) return;
    
    terminWirdGeradeGeupdated = true;

    try {
      Date beginn = null;
      Date ende = null;    

      String beginnString = beginnFeld.getText();
      if (beginnString != null && !beginnString.trim().equals("")) {
        beginn = terminFormat.parse(beginnString);
      }
      
      String endeString = endeFeld.getText();
      if (endeString != null && !endeString.trim().equals("")) {
        ende = terminFormat.parse(endeString);
      }

      aktuellerTermin.setBeginn(beginn);
      aktuellerTermin.setEnde(ende);
    } catch (ParseException e) {
      JOptionPane.showMessageDialog(
        hauptFenster,
        "Ein Termin muss im Format 'tt.mm.jjjj hh:mm' eingegeben werden.",
        "Ung�ltiger Termin!",
        JOptionPane.ERROR_MESSAGE);
    }
    
    setTermin(aktuellerTermin);
    terminModell.fireTableRowsUpdated(aktuellerTerminIndex, 
      aktuellerTerminIndex);
    terminWirdGeradeGeupdated = false;      
  }
  
  
	/**
	 * L�scht die aktuelle Veranstaltung nach einer Sicherheitsabfrage.
	 * @return <code>true</code> gdw das L�schen erfolgreich war
	 */
	public boolean loescheVeranstaltung() {
		try {
			int erg =
				JOptionPane.showConfirmDialog(
					hauptFenster,
					"Soll die Veranstaltung "
						+ aktuelleVeranstaltung.getTitel()
						+ " wirklich gel�scht werden?",
					"Veranstaltung l�schen?",
					JOptionPane.YES_NO_OPTION);
			if (erg != JOptionPane.YES_OPTION)
				return false;

			aktuelleVeranstaltung.loesche();
		} catch (DatenbankInkonsistenzException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Beim L�schen der Veranstaltung wurde eine "
					+ "Datenbank-Inkonsistenz bemerkt.",
				false);
			return false;
		}
		return true;
	}

	/**
	 * Mit dieser Methode wird der GUI mitgeteilt, ob die aktuell angezeigte
	 * Veranstaltung ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
	 * Buttons ver�ndert werden m�ssen.
	 * @param veraenderbar ist die Veranstaltung veraenderbar oder nicht?
	 */
	public void setVeraenderbar(boolean veraenderbar) {
		//Eingabefelder
		this.istVeraenderbar = veraenderbar;
		titelFeld.setEditable(veraenderbar);
		kurzTitelFeld.setEditable(veraenderbar);
		ansprechpartnerFeld.setEditable(veraenderbar);
		beschreibungFeld.setEditable(veraenderbar);
		kostenFeld.setEditable(veraenderbar);
		maximaleTeilnehmeranzahlFeld.setEditable(veraenderbar);
		anmeldungErforderlichBox.setEnabled(veraenderbar);
		bezugsgruppeFeld.setEditable(veraenderbar);
		waehrungFeld.setEditable(veraenderbar);
		veranstaltungsgruppeFeld.setEnabled(veraenderbar);
		terminTabelle.setEnabled(veraenderbar);
    setTerminVeraenderbar(veraenderbar);

		if (!veraenderbar) {
			terminTabelle.clearSelection();
		} else {    
      if (terminTabelle.getSelectedRow() == -1 && 
          terminModell.getRowCount() > 0)
        terminTabelle.getSelectionModel().setSelectionInterval(0,0);      
			titelFeld.grabFocus();
		}
	}

	private void setTerminVeraenderbar(boolean veraenderbar) {
    boolean editierbar = veraenderbar && aktuellerTermin != null;
    endeFeld.setEditable(editierbar);
    beginnFeld.setEditable(editierbar);
    beginnAendernButton.setEnabled(editierbar);
    endeAendernButton.setEnabled(editierbar);
    
    terminHinzufuegenButton.setEnabled(veraenderbar);
    terminLoeschenButton.setEnabled(editierbar);    
	}
  
  private void setTermin(Termin termin) {        
    aktuellerTermin = termin;

    if (termin == null || (termin.getBeginn() == null)) {
      beginnFeld.setText(null);      
    } else {
      beginnFeld.setText(terminFormat.format(termin.getBeginn()));      
    }
    
    if (termin == null || (termin.getEnde() == null)) {
      endeFeld.setText(null);      
    } else {
      endeFeld.setText(terminFormat.format(termin.getEnde()));      
    }
    setTerminVeraenderbar(istVeraenderbar);
  }

	/**
	 * Erzeugt ein VeranstaltungenPanel, das im �bergebenen Frame angezeigt wird
	 * @param parentFrame Frame, zu dem das Panel geh�rt
	 */
	public VeranstaltungenPanel(JFrame hauptFenster) {
		this.hauptFenster = hauptFenster;
		aktuelleVeranstaltung = null;
		oldVeranstaltung = null;
    terminWirdGeradeGecheckt = false;
    terminWirdGeradeGeupdated = false;
    datumAuswahlDialog = new DatumAuswahlDialog(hauptFenster);
		try {
			jbInit();
			aktualisiere();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	// erzeugt die GUI
	void jbInit() throws Exception {

		//Alle wichtigen Objeke initialisieren
		titelFeld = new JTextField();
		titelFeld.setMinimumSize(
			new Dimension(80, titelFeld.getPreferredSize().height));
		kurzTitelFeld = new JTextField();
		ansprechpartnerFeld = new JTextField();
		beschreibungFeld = new JTextArea();
		beschreibungFeld.setWrapStyleWord(true);
		beschreibungFeld.setLineWrap(true);
		kostenFeld = new JTextField();
		maximaleTeilnehmeranzahlFeld = new JTextField();
		anmeldungErforderlichBox = new JCheckBox();
		JComponentFormatierer.setDimension(
			anmeldungErforderlichBox,
			new Dimension(30, titelFeld.getPreferredSize().height));
		bezugsgruppeFeld = new JTextField();
		waehrungFeld = new JTextField();
		JComponentFormatierer.setDimension(
			waehrungFeld,
			new Dimension(40, waehrungFeld.getPreferredSize().height));
		veranstaltungsgruppeFeld = new SortiertComboBox();
		JComponentFormatierer.setDimension(
			veranstaltungsgruppeFeld,
			new Dimension(30, waehrungFeld.getPreferredSize().height));
		maximaleTeilnehmeranzahlFeld.setHorizontalAlignment(SwingConstants.RIGHT);
		kostenFeld.setHorizontalAlignment(SwingConstants.RIGHT);

		maximaleTeilnehmeranzahlFeld
			.addFocusListener(new java.awt.event.FocusAdapter() {
			public void focusLost(FocusEvent e) {
				checkMaxTeilnehmerAnzahl();
			}
		});
		kostenFeld.addFocusListener(new java.awt.event.FocusAdapter() {
			public void focusLost(FocusEvent e) {
				checkKosten();
			}
		});

		terminTabelle = new JTable();
		terminModell = new TerminTableModel();
		terminTabelle.setModel(terminModell);
		terminTabelle.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    terminTabelle.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {        
        checkAktuellenTermin();
        
        aktuellerTerminIndex = terminTabelle.getSelectedRow();        
        if (aktuellerTerminIndex == -1) {
          setTermin(null);
        } else {
          setTermin(terminModell.getTermin(aktuellerTerminIndex));
        }
			}
    });

		//Labels
		JLabel jLabel1 = new JLabel("Titel:");
		JLabel jLabel2 = new JLabel("Veranstaltungsgruppe:");
		JLabel jLabel3 = new JLabel("Bezugsgruppe:");
		JLabel jLabel4 = new JLabel("Kosten:");
		JLabel jLabel7 = new JLabel("Anmeldung erforderlich:");
		JLabel jLabel8 = new JLabel("max. Teilnehmeranzahl:");
		JLabel jLabel11 = new JLabel("Kurz-Titel:");
		JLabel jLabel12 = new JLabel("Ansprechpartner:");
		JLabel jLabel15 = new JLabel("Beschreibung:");
		JLabel jLabel16 = new JLabel("Beginn:");
		JLabel jLabel17 = new JLabel("Ende:");

		JScrollPane jScrollPane1 = new JScrollPane();
		jScrollPane1.setMinimumSize(new Dimension(0, 40));
		jScrollPane1.setPreferredSize(new Dimension(0, 40));

    //TerminPanel
    JPanel terminPanel = new JPanel();
		terminPanel.setLayout(new GridBagLayout());
    beginnFeld = new JTextField();
    endeFeld = new JTextField();     
    FocusListener terminFocusListener = new FocusListener() {
			public void focusGained(FocusEvent e) {}

			public void focusLost(FocusEvent e) {
        updateTermin();
			}
		};
    beginnFeld.addFocusListener(terminFocusListener);
    endeFeld.addFocusListener(terminFocusListener); 
		beginnAendernButton = new JButton("Kalender");
    beginnAendernButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        Date ausgangsDatum = aktuellerTermin.getBeginn();
        if (ausgangsDatum == null) ausgangsDatum = aktuellerTermin.getEnde(); 
        Date gewaehltesDatum = datumAuswahlDialog.waehleDatum(null, 
          ausgangsDatum, true);
        if (gewaehltesDatum == null) return;

        beginnFeld.setText(terminFormat.format(gewaehltesDatum));
        aktuellerTermin.setBeginn(gewaehltesDatum);
        terminModell.fireTableRowsUpdated(
          aktuellerTerminIndex, aktuellerTerminIndex);
			}
    });
		endeAendernButton = new JButton("Kalender");
    endeAendernButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Date ausgangsDatum = aktuellerTermin.getEnde();
        if (ausgangsDatum == null) ausgangsDatum = aktuellerTermin.getBeginn(); 
        Date gewaehltesDatum = datumAuswahlDialog.waehleDatum(null, 
          ausgangsDatum, true);
        if (gewaehltesDatum == null) return;

        endeFeld.setText(terminFormat.format(gewaehltesDatum));
        aktuellerTermin.setEnde(gewaehltesDatum);
        terminModell.fireTableRowsUpdated(
          aktuellerTerminIndex, aktuellerTerminIndex);
      }
    });
    JComponentFormatierer.setDimension(beginnAendernButton, new Dimension(
      beginnAendernButton.getPreferredSize().width, beginnFeld.getPreferredSize().height));
    JComponentFormatierer.setDimension(endeAendernButton, new Dimension(
      endeAendernButton.getPreferredSize().width, beginnFeld.getPreferredSize().height));
		jScrollPane1.getViewport().add(beschreibungFeld, null);
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1, 2, 15, 5));
    terminLoeschenButton = new JButton("L�schen");
    terminLoeschenButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        terminLoeschen();
      }
    });
    terminHinzufuegenButton = new JButton("Hinzuf�gen");
    terminHinzufuegenButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
        neuenTerminAnlegen();
			}
		});
    buttonPanel.add(terminHinzufuegenButton);
    buttonPanel.add(terminLoeschenButton);
   
		JScrollPane jScrollPane2 = new JScrollPane();
		jScrollPane2.setMinimumSize(new Dimension(0, 40));
		jScrollPane2.setPreferredSize(new Dimension(0, 40));
		jScrollPane2.getViewport().add(terminTabelle, null);

		this.setLayout(new GridBagLayout());
		this.add(
			jLabel1,
			new GridBagConstraints(
				0,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		this.add(
			titelFeld,
			new GridBagConstraints(
				1,
				0,
				2,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTH,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			jLabel2,
			new GridBagConstraints(
				3,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 20, 5, 5),
				0,
				0));
		this.add(
			jLabel3,
			new GridBagConstraints(
				0,
				1,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		this.add(
			jLabel8,
			new GridBagConstraints(
				0,
				3,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		this.add(
			maximaleTeilnehmeranzahlFeld,
			new GridBagConstraints(
				1,
				3,
				2,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			jLabel7,
			new GridBagConstraints(
				0,
				2,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		this.add(
			anmeldungErforderlichBox,
			new GridBagConstraints(
				1,
				2,
				2,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTH,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			bezugsgruppeFeld,
			new GridBagConstraints(
				1,
				1,
				2,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTH,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			veranstaltungsgruppeFeld,
			new GridBagConstraints(
				4,
				0,
				2,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTH,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			jScrollPane1,
			new GridBagConstraints(
				1,
				4,
				5,
				1,
				1.0,
				1.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.BOTH,
				new Insets(0, 0, 20, 0),
				0,
				0));
		this.add(
			jLabel4,
			new GridBagConstraints(
				3,
				2,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 20, 5, 5),
				0,
				0));
		this.add(
			kostenFeld,
			new GridBagConstraints(
				4,
				2,
				1,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			waehrungFeld,
			new GridBagConstraints(
				5,
				2,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 5, 5, 0),
				0,
				0));
		this.add(
			jLabel11,
			new GridBagConstraints(
				3,
				3,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 20, 5, 5),
				0,
				0));
		this.add(
			jLabel15,
			new GridBagConstraints(
				0,
				4,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		this.add(
			ansprechpartnerFeld,
			new GridBagConstraints(
				4,
				1,
				2,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTH,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			jLabel12,
			new GridBagConstraints(
				3,
				1,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE,
				new Insets(0, 20, 5, 5),
				0,
				0));
		this.add(
			kurzTitelFeld,
			new GridBagConstraints(
				4,
				3,
				2,
				1,
				1.0,
				0.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			jScrollPane2,
			new GridBagConstraints(
				0,
				5,
				3,
				1,
				1.0,
				1.0,
				GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH,
				new Insets(0, 0, 5, 0),
				0,
				0));
		this.add(
			terminPanel,
			new GridBagConstraints(
				3,
				5,
				3,
				1,
				0.0,
				0.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.BOTH,
				new Insets(0, 20, 0, 0),
				0,
				0));
		terminPanel.add(
			jLabel16,
			new GridBagConstraints(
				0,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 5),
				0,
				0));
		terminPanel.add(
			jLabel17,
			new GridBagConstraints(
				0,
				1,
				2,
				1,
				0.0,
				0.0,
				GridBagConstraints.WEST,
				GridBagConstraints.NONE,
				new Insets(0, 0, 5, 0),
				0,
				0));
		terminPanel.add(
			beginnFeld,
			new GridBagConstraints(
				1,
				0,
				1,
				1,
				1.0,
				1.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		terminPanel.add(
			endeFeld,
			new GridBagConstraints(
				1,
				1,
				1,
				1,
				1.0,
				1.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 0, 5, 0),
				0,
				0));
		terminPanel.add(
			beginnAendernButton,
			new GridBagConstraints(
				2,
				0,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 5, 5, 0),
				0,
				0));
		terminPanel.add(
			endeAendernButton,
			new GridBagConstraints(
				2,
				1,
				1,
				1,
				0.0,
				0.0,
				GridBagConstraints.CENTER,
				GridBagConstraints.HORIZONTAL,
				new Insets(0, 5, 5, 0),
				0,
				0));
    terminPanel.add(
      buttonPanel,
      new GridBagConstraints(
        0,
        2,
        3,
        1,
        0.0,
        0.0,
        GridBagConstraints.CENTER,
        GridBagConstraints.HORIZONTAL,
        new Insets(10, 0, 5, 0),
        0,
        0));
	}

	protected boolean checkAktuellenTermin() {
    if (terminWirdGeradeGecheckt) return true;
    terminWirdGeradeGecheckt = true;

    boolean erg = true;
    try {
      if (aktuellerTermin != null) aktuellerTermin.check();
    } catch (TerminInkonsistenzException e) {
      JOptionPane.showMessageDialog(
        hauptFenster,
        e.getMessage(),
        "Ung�ltiger Termin!",
        JOptionPane.ERROR_MESSAGE);
      terminTabelle.getSelectionModel().setSelectionInterval(
        aktuellerTerminIndex, aktuellerTerminIndex);
      erg = false;
    }
    
    terminWirdGeradeGecheckt = false;    
    return erg;
	}

	public void aktualisiere() {
		if (aktuelleVeranstaltung != null) {
			aktuelleVeranstaltung.reload();
			this.setVeranstaltung(aktuelleVeranstaltung);
		}
		VeranstaltungsgruppenListe liste =
			Veranstaltungsgruppe.getAlleVeranstaltungsgruppen();
		liste.setSortierung(
			VeranstaltungsgruppenListe.alphabetischeSortierung,
			true);
		veranstaltungsgruppeFeld.setDaten(liste);
	}

	void checkMaxTeilnehmerAnzahl() {
		String maximaleTeilnehmerAnzahlString =
			maximaleTeilnehmeranzahlFeld.getText();

		boolean anzahlOK = true;
		if (maximaleTeilnehmerAnzahlString == null
			|| maximaleTeilnehmerAnzahlString.equals(""))
			anzahlOK = false;

		int anzahl = 0;
		if (anzahlOK) {
			try {
				anzahl = Integer.parseInt(maximaleTeilnehmerAnzahlString);
				if (anzahl < 0)
					anzahlOK = false;
			} catch (NumberFormatException e) {
				anzahlOK = false;
			}
		}

		if (!anzahlOK)
			anzahl = 0;
		maximaleTeilnehmeranzahlFeld.setText(Integer.toString(anzahl));
		if (!anzahlOK) {
			JOptionPane.showMessageDialog(
				hauptFenster,
				"Die Eingabe '"
					+ maximaleTeilnehmerAnzahlString
					+ "' kann\nnicht als positive Zahl interpretiert\n"
					+ "werden!",
				"Ung�ltige maximale Teilnehmeranzahl!",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	void checkKosten() {
		String kostenString = kostenFeld.getText();

		boolean kostenOK = true;
		if (kostenString == null || kostenString.equals(""))
			kostenOK = false;

		double kosten = 0;
		if (kostenOK) {
			try {
				kosten = waehrungsFormat.parse(kostenString).doubleValue();
				if (kosten < 0)
					kostenOK = false;
			} catch (ParseException e) {
				kostenOK = false;
			}
		}

		if (!kostenOK)
			kosten = 0;
		kostenFeld.setText(waehrungsFormat.format(kosten));
		if (!kostenOK) {
			JOptionPane.showMessageDialog(
				hauptFenster,
				"Die Eingabe '"
					+ kostenString
					+ "' kann\nnicht als Betrag interpretiert\n"
					+ "werden!",
				"Ung�ltige Kosten!",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Liefert die aktuell angezeigte Veranstaltung
	 */
	public Veranstaltung getVeranstaltung() {
		return aktuelleVeranstaltung;
	}

	/**
	 * Speichert die gemachten �nderungen an der Veranstaltung, falls dies m�glich ist. Ist
	 * dies nicht m�glich, weil bspw. nicht alle Daten angegeben sind, wird eine
	 * entsprechende Fehlermeldung angezeigt.
	 *
	 * @return <code>true</code> gdw die �nderungen gespeichert werden konnten
	 */
	public boolean saveChanges() {
    if (!checkAktuellenTermin()) return false;
    
		if (aktuelleVeranstaltung == null)
			throw new NullPointerException();

		try {
			aktuelleVeranstaltung.setTitel(titelFeld.getText());
			aktuelleVeranstaltung.setKurzTitel(kurzTitelFeld.getText());
			aktuelleVeranstaltung.setAnsprechpartner(ansprechpartnerFeld.getText());
			aktuelleVeranstaltung.setBezugsgruppe(bezugsgruppeFeld.getText());
			aktuelleVeranstaltung.setBeschreibung(beschreibungFeld.getText());
			aktuelleVeranstaltung.setMaximaleTeilnehmerAnzahl(
				Integer.parseInt(maximaleTeilnehmeranzahlFeld.getText()));
			aktuelleVeranstaltung.setKosten(
				waehrungsFormat.parse(kostenFeld.getText()).doubleValue());
			aktuelleVeranstaltung.setAnmeldungErforderlich(
				anmeldungErforderlichBox.isSelected());
			aktuelleVeranstaltung.setWaehrung(waehrungFeld.getText());
			aktuelleVeranstaltung.setVeranstaltungsgruppe(
				(Veranstaltungsgruppe) veranstaltungsgruppeFeld.getSelectedItem());
			aktuelleVeranstaltung.setTermine(terminModell.getDaten());

			aktuelleVeranstaltung.save();
			return true;
		} catch (UnvollstaendigeDatenException e) {
			JOptionPane.showMessageDialog(
				hauptFenster,
				e.getMessage(),
				"Unvollst�ndige Daten!",
				JOptionPane.ERROR_MESSAGE);
		} catch (ParseException e) {
			//Sollte nie auftreten
			e.printStackTrace();
			System.exit(1);
		}
		return false;
	}

	/**
	 * Verwirft die aktuellen �nderungen. Dies kann eventuell nicht m�glich sein.
	 *
	 * @return <code>true</code> gdw die Aenderungen rueckgaengig
	 *   gemacht werden konnten.
	 */
	public boolean aenderungenVerwerfen() {
		try {
			if (oldVeranstaltung != null)
				oldVeranstaltung.reload();
			setVeranstaltung(oldVeranstaltung);
			setVeraenderbar(false);
		} catch (DatenNichtGefundenException e) {
			return false;
		}
		return true;
	}

  void neuenTerminAnlegen() {
    if (!checkAktuellenTermin()) return;
    
    Termin neuerTermin = new Termin(aktuelleVeranstaltung, null, null);
    int index = terminModell.add(neuerTermin);
    terminModell.fireTableDataChanged();
    terminTabelle.getSelectionModel().setSelectionInterval(index,index);
  }

  void terminLoeschen() {
    terminWirdGeradeGecheckt = true;
    try {
      int erg = JOptionPane.showConfirmDialog(hauptFenster, "Soll der Termin "+
        aktuellerTermin.getLangesTerminFormat() +
        " wirklich gel�scht werden?",
        "Termin l�schen?", JOptionPane.YES_NO_OPTION);
      if (erg == JOptionPane.YES_OPTION) {        
        terminModell.remove(aktuellerTermin);
        terminModell.fireTableDataChanged();
        if (terminModell.size() > 0)
          terminTabelle.getSelectionModel().setSelectionInterval(0,0);
      }
    } catch (DatenbankInkonsistenzException e) {
      ErrorHandler.getInstance().handleException(e, "Beim L�schen des Mediums wurde eine" +
        "Datenbank-Inkonsistenz bemerkt.", false);
    }
    terminWirdGeradeGecheckt = false;
  }
}