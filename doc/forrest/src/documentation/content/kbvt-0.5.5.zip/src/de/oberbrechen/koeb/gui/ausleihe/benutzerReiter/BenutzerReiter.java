/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.benutzerReiter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.gui.components.BenutzerPanel;
import de.oberbrechen.koeb.gui.ausleihe.*;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Benutzer in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.10 $
 */

public class BenutzerReiter extends JPanel implements AusleiheMainReiter {

  private Main hauptFenster;
  private BenutzerPanel benutzerPanel;
  boolean istVeraenderbar;

  // die verwendeten Buttons;
  private JButton neuButton = new JButton();
  private JButton saveButton = new JButton();
  private JButton ladenButton = new JButton();

  /**
   * Zeigt den �bergebenen Benutzer an.
   * @param benutzer der anzuzeigende Benutzer
   */
  public void setBenutzer(Benutzer benutzer) {
    if (benutzer == null) return;
    setVeraenderbar(!benutzer.istGespeichert());
    benutzerPanel.setBenutzer(benutzer);
  }

  //Doku siehe bitte Interface
  public void refresh() {
    setBenutzer(hauptFenster.getAktuellerBenutzer());
  }

  /**
   * Mit dieser Methode wird der GUI mitgeteilt, ob der aktuell angezeigte
   * Benutzer ver�ndert werden darf. Dies ist wichtig, da abh�ngig davon einige
   * Buttons ver�ndert werden m�ssen.
   * @param gespeichert ist Benutzer gespeichert oder nicht?
   */
  void setVeraenderbar(boolean veraenderbar) {
    istVeraenderbar = veraenderbar;

    //Buttons anpassen
    neuButton.setEnabled(!veraenderbar);
    hauptFenster.erlaubeAenderungen(!veraenderbar);

    if (!veraenderbar) {
      ladenButton.setText("L�schen");
      saveButton.setText("Bearbeiten");
    } else {
      ladenButton.setText("�nderungen verwerfen");
      saveButton.setText("Speichern");
    }

    benutzerPanel.setVeraenderbar(veraenderbar);
  }

  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public BenutzerReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    try {
      jbInit();
      aktualisiere();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  void jbInit() throws Exception {
    JPanel ButtonPanel = new JPanel();
    benutzerPanel = new BenutzerPanel(hauptFenster);

    this.setLayout(new BorderLayout());
    neuButton.setText("Neuen Benutzer anlegen");
    neuButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setBenutzer(new Benutzer());
      }
    });
    saveButton.setText("Speichern");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (istVeraenderbar) {
          saveChanges();
        } else {
          setVeraenderbar(true);
        }
      }
    });
    ladenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if (!istVeraenderbar) {
          loescheBenutzer();
        } else {
          aenderungenVerwerfen();
        }
      }
    });
    ButtonPanel.setLayout(new GridLayout(1, 3, 15, 5));
    ButtonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    benutzerPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

    this.add(ButtonPanel, BorderLayout.SOUTH);
    ButtonPanel.add(saveButton, null);
    ButtonPanel.add(ladenButton, null);
    ButtonPanel.add(neuButton, null);
    this.add(benutzerPanel, BorderLayout.CENTER);
  }

  /**
   * L�d die Orte neu aus der Datenbank
   */
  public void aktualisiere() {
    benutzerPanel.aktualisiere();
    setVeraenderbar(istVeraenderbar);
  }

  /**
   * L�scht den aktuellen Benutzer
   */
  void loescheBenutzer() {
    Benutzer currentBenutzer = benutzerPanel.getBenutzer();
    boolean loeschenOK = benutzerPanel.loescheBenutzer();
    if (loeschenOK) hauptFenster.removeBenutzer(currentBenutzer);
  }

  /**
   * Speichert die gemachten �nderungen
   */
  void saveChanges() {
    boolean speichernOK = benutzerPanel.saveChanges();
    if (speichernOK) {
      setVeraenderbar(false);
      hauptFenster.setAktiverBenutzer(benutzerPanel.getBenutzer());
    }
  }

  /**
   * Verwirft die aktuellen �nderungen.
   */
  void aenderungenVerwerfen() {
    if (!benutzerPanel.aenderungenVerwerfen()) {
      hauptFenster.aktualisiereBenutzer();
    } else {
      setVeraenderbar(false);
    }
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
  }
}