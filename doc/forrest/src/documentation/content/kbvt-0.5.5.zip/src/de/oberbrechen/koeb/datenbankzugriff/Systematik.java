/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;

/**
* Diese Klasse repr�sentiert eine Systematik der B�cherei. Es stellt die
* Verbindung zur Datenbank her und Methoden, um auf die Systematik zuzugreifen.
* Mit dieser Klasse kann die Systematik aber nicht ver�ndert werden.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.8 $
*/

public class Systematik implements Comparable{

  // Statische Speicherung der Systematiken, um weniger Objekte erzeugen
  // zu m�ssen
  private static Hashtable cache = new Hashtable();

  // Die Attribute des Mediums wie in der Datenbank
  private String name, beschreibung;

  /**
   * Liefert ein zur �bergebenen Systematik passendes Systematikobjekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jede Systematik
   * existiert nur ein Objekt.
   *
   * @param systematik die Systematik, die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene Systematik
   *  nicht in der Datenbank existiert
   */
  public static Systematik getSystematik(String systematik) throws DatenNichtGefundenException {

    Systematik erg = (Systematik) cache.get(systematik);
    if (erg == null) {
      erg = new Systematik(systematik);
      cache.put(systematik, erg);
    }
    return erg;
  }

  /**
   * L�d das zum Parameter geh�rende
   * <code>Systematik</code>-Objekt aus der Datenbank.
   * @param systematik die Systematik, die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene Systematik
   *  nicht in der Datenbank existiert
   */
  private Systematik(String systematik) throws DatenNichtGefundenException {

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from systematik where Systematik = \"" + systematik + "\"");
      boolean systematikGefunden = result.next();
      if (!systematikGefunden) throw new DatenNichtGefundenException(
        "Die Systematik '"+systematik+"' existiert nicht!");

      name = systematik;
      beschreibung = result.getString("Beschreibung");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Systematik "+
        systematik +"!", true);
    }
  }

  /**
   * Intern benutzter Konstruktor
   *
   */
  private Systematik() {
  }
  
  /**
   * Liefert der Namen der Systematik
   * @return den Namen der Systematik
   */
  public String getName() {
    return name;
  }

  /**
   * Liefert die Beschreibung der Systematik
   * @return die Beschreibung der Systematik
   */
  public String getBeschreibung() {
    return beschreibung;
  }

  public String toString() {
    return name;
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.getName() + ":\n"+this.getBeschreibung();
  }

  /**
   * Entsprechend dem Comparator-Interface vergleicht diese Methode das
   * Systematik-Objekt mit einem anderen Systematik-Objekt.
   * Die Stringdarstellung dieses und des anderen Objektes werden dabei
   * alphabetisch verglichen.
   * @param o das zu vergleichende Objekt
   */
  public int compareTo(Object o) {
    return this.toString().compareTo(o.toString());
  }
  
  /**
   * Liefert eine Liste aller Untersystematiken der uebergebenen Systematik.
   * @return eine Liste aller Untersystematiken der uebergebenen Systematik
   */
  public SystematikListe getUntersystematiken() throws DatenbankInkonsistenzException {
    SystematikListe systematiken = new SystematikListe();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select Systematik from systematik_spezialisiert " +
        "where spezialisiert = \"" + this.getName() + "\"");
      while (result.next()) {
        String eintrag = result.getString("Systematik");
        try {
          Systematik sys = Systematik.getSystematik(eintrag);
          systematiken.add(sys);
        } catch (DatenNichtGefundenException e) {
          throw new DatenbankInkonsistenzException("Die nicht existierende "+
            " Systematik '"+result+"' spezialisiert die Systematik "+
            this.getName()+"!");
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Untersystematiken!", true);
    }
    return systematiken;
  }

  /**
   * Liefert eine sortierte Liste aller Systematiken, die in der Datenbank
   * eingetragen sind.
   * Die verf�gbaren Sortierungen sind als �ffentliche Konstanten der Klasse
   * SystematikListe ansprechbar.
   *
   * @param sortierung die anzuwendende Sortierung
   * @throws IllegalArgumentExeception falls die �bergebene Sortierung unbekannt
   *  ist
   * @see SystematikListe
   * @return die Liste der Systematiken
   */
  public static SystematikListe getAlleSystematiken(int sortierung) {
    SystematikListe liste = new SystematikListe();
    cache.clear();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from systematik;");
      while (result.next()) {
        Systematik neueSystematik = new Systematik();

        neueSystematik.name = result.getString("systematik");
        neueSystematik.beschreibung = result.getString("beschreibung");
        cache.put(neueSystematik.name, neueSystematik);
        liste.addNoDuplicate(neueSystematik);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Systematikliste!", true);
    }

    liste.setSortierung(sortierung, false);
    return liste;
  }  
}