/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.medienInfoReiter;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Date;

import de.oberbrechen.koeb.gui.ausleihe.*;
import de.oberbrechen.koeb.gui.components.medienDetails.*;
import de.oberbrechen.koeb.gui.components.medienDetails.MedienDetailsListener;
import de.oberbrechen.koeb.gui.framework.*;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;


/**
 * Diese Klasse repr�sentiert den Reiter, der Informationen �ber ein Medium
 * erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.14 $
 */

public class MedienInfoReiter extends JPanel implements 
  AusleiheMainReiter, MedienDetailsListener {

  private Main hauptFenster;

  private MedienDetailsPanel mediumDetailsPanel;
  private AusleiheTableModel ausleihen;
  private Ausleihe aktuelleAusleihe;
  private Ausleihe ersteAusleihe;
  private JButton zurAktuellenAusleiheButton;
  private JButton irregulaerZurueckgebenButton;

  public MedienInfoReiter(Main parentFrame) {
    hauptFenster = parentFrame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    aktualisiere();
  }

  private void jbInit() throws Exception {
    //Buttonpanel
    irregulaerZurueckgebenButton = new JButton("Medium irregul�r zur�ckgeben");
    zurAktuellenAusleiheButton = new JButton("zur aktuellen Ausleihe");

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new GridLayout(1,4,15,0));
    buttonPanel.setBorder(BorderFactory.createEmptyBorder(5,10,10,10));
    zurAktuellenAusleiheButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        zeigeAktuelleAusleihe();
      }
    });
    irregulaerZurueckgebenButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        irregulaerZurueckgeben();
      }
    });
    buttonPanel.add(irregulaerZurueckgebenButton, null);
    buttonPanel.add(zurAktuellenAusleiheButton, null);

    //Ausleihen-Tabelle
    JScrollPane ausleihenScrollPane = new JScrollPane();
    ausleihenScrollPane.setBorder(BorderFactory.createCompoundBorder(
      BorderFactory.createEmptyBorder(10,10,10,10),
      BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140))));
    JComponentFormatierer.setDimension(
      ausleihenScrollPane, new Dimension(0, 40));
    JTable ausleihenTabelle = new JTable();
    ausleihen = new AusleiheTableModel();
    ausleihenTabelle.setModel(ausleihen);
    ausleihenTabelle.setDefaultRenderer(
      Object.class, new AusleiheTableRenderer());
    ausleihenTabelle.setEnabled(false);
    ausleihenScrollPane.getViewport().add(ausleihenTabelle);


    mediumDetailsPanel = new MedienDetailsPanel();
    mediumDetailsPanel.setBorder(BorderFactory.createEmptyBorder(10,10,4,10));    
    mediumDetailsPanel.addMedienDetailsListener(this);
    
    //Splitpanel
    JSplitPane jSplitPane1 = new JSplitPane();
    jSplitPane1.setBorder(BorderFactory.createEmptyBorder());
    jSplitPane1.add(mediumDetailsPanel, JSplitPane.LEFT);
    jSplitPane1.add(ausleihenScrollPane, JSplitPane.RIGHT);

    //alles zusammenbauen
    this.setLayout(new BorderLayout());
    this.add(jSplitPane1, BorderLayout.CENTER);
    this.add(buttonPanel, BorderLayout.SOUTH);
  }

  //Doku siehe bitte Interface
  public void aktualisiere() {
    mediumDetailsPanel.aktualisiere();
  }

  //Doku siehe bitte Interface
  public void setBenutzer(Benutzer benutzer) {
    irregulaerZurueckgebenButton.setEnabled(ersteAusleihe != null &&
      (ersteAusleihe.istZurueckgegeben() || !ersteAusleihe.getBenutzer().equals(
      hauptFenster.getAktuellerBenutzer())));
  }

  // Doku siehe bitte Interface
  public void mediumEANGelesen(Medium medium) {
    //Mediumdetails wird aktualisiert. Dies aktualisiert automatisch
    //auch die Ausleihen, etc.
    mediumDetailsPanel.setMedium(medium);
  }

  //Doku siehe bitte Interface
  public void refresh() {
    setBenutzer(hauptFenster.getAktuellerBenutzer());
    mediumDetailsPanel.refresh();
  }

  /**
   * Zeigt die aktuelle Ausleihe an.
   */
  void zeigeAktuelleAusleihe() {
    hauptFenster.zeigeAusleihe(aktuelleAusleihe);
  }

  /**
   * Gibt das Medium irregul�r zur�ck
   */
  void irregulaerZurueckgeben() {
    if (ersteAusleihe == null) return;
    Medium aktuellesMedium = mediumDetailsPanel.getMedium();
    if (aktuellesMedium == null) return;
    Benutzer aktuellerBenutzer = (Benutzer) hauptFenster.getAktuellerBenutzer();

    if (ersteAusleihe.istZurueckgegeben()) {
      int erg = JOptionPane.showConfirmDialog(hauptFenster, "Wollen Sie "+
        "wirklich das Medium '"+aktuellesMedium.getTitel()+"' ("+
        aktuellesMedium.getMedienNr()+")\nals von "+aktuellerBenutzer.getName()+
        " Zur�ckgegeben eintragen,\nobwohl dieses Medium zur Zeit nicht als\n"+
        "ausgeliehen eingetragen ist?",
        "Irregul�re R�ckgabe best�tigen", JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);
      if (erg != JOptionPane.YES_OPTION) return;

      Ausleihe neueAusleihe = new Ausleihe();
      neueAusleihe.setMedium(aktuellesMedium);
      neueAusleihe.setBenutzer(aktuellerBenutzer);
      neueAusleihe.setRueckgabedatum(new Date());
      neueAusleihe.setBemerkungen("Ausleihe irregul�r zurueckgegeben!");
      neueAusleihe.save();

    } else {
      int erg = JOptionPane.showConfirmDialog(hauptFenster, "Wollen Sie "+
        "wirklich das Medium '"+aktuellesMedium.getTitel()+"' ("+
        aktuellesMedium.getMedienNr()+")\nals von "+aktuellerBenutzer.getName()+
        " Zur�ckgegeben eintragen,\nobwohl dieses Medium zur Zeit als "+
        "von\n"+ersteAusleihe.getBenutzer().getName()+ " Ausgeliehen "+
        "eingetragen ist?",
        "Irregul�re R�ckgabe best�tigen", JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);
      if (erg != JOptionPane.YES_OPTION) return;

      Date rueckgabeDatum = new Date();
      if (ersteAusleihe.getSollRueckgabedatum().before(rueckgabeDatum))
        rueckgabeDatum = ersteAusleihe.getSollRueckgabedatum();
      ersteAusleihe.setRueckgabedatum(rueckgabeDatum);
      ersteAusleihe.setMitarbeiterRueckgabe(
        Mitarbeiter.getAktuellenMitarbeiter());
      ersteAusleihe.setBemerkungen("Ausleihe irregul�r zurueckgegeben!");
      ersteAusleihe.save();

      Ausleihe neueAusleihe = new Ausleihe();
      neueAusleihe.setMedium(aktuellesMedium);
      neueAusleihe.setBenutzer(aktuellerBenutzer);
      neueAusleihe.setRueckgabedatum(new Date());
      neueAusleihe.setBemerkungen("Ausleihe irregul�r zurueckgegeben!");
      neueAusleihe.save();
    }
    this.refresh();
  }

  public void neuesMediumAusgewaehlt(Medium medium) {
    if (medium == null) {
      ausleihen.setDaten(new AusleihenListe());
      aktuelleAusleihe = null;
      ersteAusleihe = null;
    } else {
      AusleihenListe liste = Ausleihe.getAlleAusleihenVon(medium);
      liste.setSortierung(AusleihenListe.AusleihdatumSortierung, true);
      ausleihen.setDaten(liste);
      if (liste.size() > 0) {
        ersteAusleihe = (Ausleihe) liste.first();
        aktuelleAusleihe = ersteAusleihe;
        if (aktuelleAusleihe.istZurueckgegeben()) aktuelleAusleihe = null;
      } else {
        ersteAusleihe = null;
        aktuelleAusleihe = null;
      }
    }    
    
    zurAktuellenAusleiheButton.setEnabled(aktuelleAusleihe != null);
    irregulaerZurueckgebenButton.setEnabled(ersteAusleihe != null &&
      (ersteAusleihe.istZurueckgegeben() || !ersteAusleihe.getBenutzer().equals(
      hauptFenster.getAktuellerBenutzer())));

  }

}