/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff.exceptions;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
* Diese Exception wird geworfen, wenn versucht wird, einen Mitarbeiter zu
* speichern, dessen Mitarbeiterbenutzername schon verwendet wird.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.3 $

*/
public class MitarbeiterbenutzernameSchonVergebenException extends
  EindeutigerSchluesselSchonVergebenException {

  /**
   * Erstellt eine neue MitarbeiterbenutzernameSchonVergebenException mit
   * der �bergebenen Fehlermeldung und dem �bergebenen Mitarbeiter, der den
   * Mitarbeiterbenutzernamen schon verwendet.
   *
   * @param meldung die Beschreibung der aufgetretenen Ausnahme
   * @param konfliktMitarbeiter der Mitarbeiter, der den
   *   Mitarbeiterbenutzernamen schon verwendet
   */
  public MitarbeiterbenutzernameSchonVergebenException(String meldung,
    Mitarbeiter konfliktMitarbeiter) {

    super(meldung, konfliktMitarbeiter);
  }

  /**
   * Erstellt eine neue MitarbeiterbenutzernameSchonVergebenException mit
   * einer Standardfehlermeldung und dem �bergebenen Mitarbeiter, der den
   * Benutzermitarbeiternamen schon verwendet.
   *
   * @param konfliktMitarbeiter der Mitarbeiter, der den
   *   Mitarbeiterbenutzernamen schon verwendet
   */
  public MitarbeiterbenutzernameSchonVergebenException(Mitarbeiter konfliktMitarbeiter) {
    super("Der Mitarbeiterbenutzername '"+
      konfliktMitarbeiter.getMitarbeiterBenutzername()+"' wird "+
      "bereits von "+konfliktMitarbeiter.getName()+" verwendet.",
      konfliktMitarbeiter);
  }

  /**
   * Liefert den Mitarbeiter, der den Mitarbeiterbenutzernamen
   * bereits verwendet.
   * @return den Mitarbeiter, der den Mitarbeiterbenutzernamen bereits verwendet
   */
  public Mitarbeiter getKonfliktMitarbeiter() {
    return (Mitarbeiter) super.getKonfliktDatensatz();
  }

}
