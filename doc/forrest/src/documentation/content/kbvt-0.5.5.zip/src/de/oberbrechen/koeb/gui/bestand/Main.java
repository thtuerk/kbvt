/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.bestand;

import java.awt.Cursor;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.gui.AbstractMain;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeGelesenEventHandler;
import de.oberbrechen.koeb.gui.barcodescanner.BarcodeReaderKeyAdapter;
import de.oberbrechen.koeb.gui.bestand.medienReiter.MedienReiter;

/**
 * Diese Klasse ist die Hauptklasse f�r die graphische Oberfl�che, die zur
 * Verwaltung und Eingabe von Medien dient.
 *
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.9 $
 */
public class Main extends AbstractMain implements BarcodeGelesenEventHandler {

  public Main(boolean isMain) {
    super(isMain, "Bestandsverwaltung", Mitarbeiter.BERECHTIGUNG_BESTAND_EINGABE,
          "de/oberbrechen/koeb/gui/icon-bestand.png");
    this.addKeyListener(new BarcodeReaderKeyAdapter("\5", "\12", this));          
  }

  public static void main(String[] args) {
    init();
    new Main(true);
  }

  /**
   * Wird aufgerufen, wenn ein anderer Reiter gew�hlt wurde
   */
  public void refresh() {
    this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
    ((BestandMainReiter) reiter.getSelectedComponent()).refresh();
    this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
  }

  //Doku siehe bitte Interface
  public void barcodeGelesen(String barcode) {
    EAN neuerBarcode = new EAN(barcode);
    if (neuerBarcode.getTyp() != EAN.MediumEAN ||
        neuerBarcode.getReferenz() == null) return;

    Medium medium = (Medium) neuerBarcode.getReferenz();
    ((BestandMainReiter) reiter.getSelectedComponent()).mediumEANGelesen(medium);
  }

  //Doku siehe bitte Interface
  public void barcodeStartGelesen() {
    reiter.grabFocus();
  }

  protected void initDaten() {
  }

  protected void reiterHinzufuegen() {
    reiter.add(new MedienReiter(this), "Bestand");
  }
}