/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.ausgaben;

/**
* Dieses Interface repr�sentiert Factory, die in der Lage ist, verschiedene
* Ausgaben zu erzeugen und zu einem AusgabenTreeModel hinzuf�gen. Dieses
* Interface implementierende Klassen sollten einen parameterlosen Konstruktor
* besitzen, um leicht automatisch erzeugt werden zu k�nnen. Eventuell n�tige
* Parameter k�nnen mittels setParameter �bergeben werden.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public interface AusgabenFactory {

  /**
   * Liefert den Namen der AusgabenFactory
   * @return den Namen der AusgabenFactory
   */
  public String getName();

  /**
   * Liefert eine Kurzbeschreibung der AusgabenFactory. 
   * Insbesondere sollten hier m�gliche Parameter erkl�rt werden.
   * @return eine Kurzbeschreibung der AusgabenFactory
   */
  public String getBeschreibung();

  /**
   * Setzt einen Parameter. Paramter k�nnen mehrfach gesetzt werden.
   * Dies hat evtl. eine andere Interpretation als das einmalige Setzen. 
   * Dagegen darf die Reihenfolge der Paramter keine Bedeutung besitzen.
   * @param name der Name des Parameters
   * @param wert der Wert des Parameters
   * @throws ParameterException falls beim Setzen des Paramters ein Problem auftritt
   */
  public void setParameter(String name, String wert) throws 
    ParameterException;  
    
  /**
   * Erzeugt die Ausgaben und f�gt sie zu dem �bergebenen Knoten hinzu. Dabei k�nnen
   * auch neue Unterknoten angelegt werden.  
   * @param knoten der Knoten, unterhalb dem eingef�gt werden soll
   */
  public void addToKnoten(AusgabenTreeKnoten knoten) throws Exception;
}