/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenNichtGefundenException;
import de.oberbrechen.koeb.datenstrukturen.*;
import java.util.Date;

/**
* Diese Klasse repr�sentiert ein nicht eingestelltes Medium. 
* Es wird an einigen Stellen benutzt, an denen expliziet ein nicht
* n�her spezifiertes Medium verwendet werden soll.
* Es stellt die
* Verbindung zur Datenbank her und Methoden, um das Medium zu manipulieren.
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.4 $
*/

public class NichtEingestelltesMedium extends Medium {

  public NichtEingestelltesMedium() {
  }

  public String getTitel() {
    return "nicht eingestelltes Medium";
  }

  public String getAutor() {
    return "";
  }

  public String getBeschreibung() {
    return "Ein unbekanntes Medium!";
  }

  public Medientyp getMedientyp() throws DatenNichtGefundenException {
    return Medientyp.getMeistBenutztenMedientyp();
  }

  public String getMedienNr() {
    return "-";
  }

  public EAN getEAN() {
    return null;
  }

  public int getMedienAnzahl() {
    return 1;
  }

  public Date getEinstellungsdatum() {
    return null;
  }

  public Date getEntfernungsdatum() {
    return null;
  }

  public SystematikListe getSystematiken() {
    return new SystematikListe();
  }

  public boolean gehoertZuSystematik(Systematik systematik) {
    return false;
  }

  public boolean istNochInBestand() {
    return false;
  }

  public String toDebugString() {
    return this.toString();
  }

  public String toString() {
    return getTitel();
  }

  public boolean istNeu() {
    return false;
  }

  public boolean istGespeichert() {
    return true;
  }

  public void reload() {}
  public void save() {}  
  protected void load(String medienNr) {}
  public void loesche() {}
  public void setEinstellungsdatum(Date datum) {}
  public void setEAN(EAN ean) {}
  public void setMediennr(String nr) {}
  public void setMedientyp(Medientyp typ) {}
  public void setAutor(String autor) {}
  public void setTitel(String titel) {}
  public void setBeschreibung(String beschreibung) {}
  public void setMedienAnzahl(int anzahl) {}
  public void setEntfernungsdatum(Date datum) {}
  public void setSystematiken(SystematikListe systematiken) {}
}