/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.standarddialoge;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.gui.components.*;
import java.util.Iterator;
import javax.swing.*;
import java.awt.*;

/**
 * Diese Klasse zeigt einen Dialog an, der die Auswahl eines Mitarbeiters
 * erm�glicht. Der gew�hlte Mitarbeiter muss sich �ber Eingabe seines
 * Passwortes autentifizieren.
 */
public class MitarbeiterAuswahlDialog {

  private JFrame main;
  private JPanel ausgabe;
  private JPasswordField passwortFeld;
  private SortiertComboBox mitarbeiterFeld;

  /**
   * Erzeugt eine neue Instanz, die den Dialog als Chield des �bergebenen
   * Frames anzeigt.
   *
   * @param mainWindow das Hauptfenster
   */
  public MitarbeiterAuswahlDialog(JFrame mainWindow) {
    main = mainWindow;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Zeigt ein Dialogfeld zur Auswahl eines Mitarbeiters an, der die �bergebene
   * Berechtigung besitzt. Die Berechtigungen stehen als
   * �ffentliche Konstanten der Klasse Mitarbeiter zu Verf�gung.
   * @param berechtigung die Berechtigung, die die Mitarbeiter besitzen muss
   * @return den gew�hlten Mitarbeiter oder <code>null</code>, falls kein
   *   Mitarbeiter gew�hlt wurde
   */
  public Mitarbeiter waehleMitarbeiter(int berechtigung) {
    SwingUtilities.updateComponentTreeUI(ausgabe);
    ladeBenutzer(berechtigung);
    passwortFeld.setText(null);

    mitarbeiterFeld.grabFocus();

    Mitarbeiter gewaehlterMitarbeiter;
    boolean mitarbeiterGewaehlt = false;
    do {
      int erg = JOptionPane.showConfirmDialog(main, ausgabe,"Mitarbeiter-Auswahl",
          JOptionPane.OK_CANCEL_OPTION);

      if (erg != JOptionPane.OK_OPTION) return null;
      gewaehlterMitarbeiter = (Mitarbeiter) mitarbeiterFeld.getSelectedItem();

      mitarbeiterGewaehlt = true;
      if (!gewaehlterMitarbeiter.checkMitarbeiterPasswort(
          new String(passwortFeld.getPassword()))) {

        mitarbeiterGewaehlt = false;
        JOptionPane.showMessageDialog(main, "Das angegebene Passwort ist f�r "+
                                      "den Mitarbeiter "+gewaehlterMitarbeiter.getName()+" ung�ltig!",
                                      "Passwort ung�ltig!", JOptionPane.ERROR_MESSAGE);

      }
    } while (!mitarbeiterGewaehlt);

    return gewaehlterMitarbeiter;
  }


  /**
   * L�d alle Benutzer, die die �bergebene Berechtigung besitzen aus der
   * Datenbank und setzt sie im mitarbeiterFeld.
   *
   * @param berechtigung die Berechtigung, die die Mitarbeiter besitzen sollen
   */
  private void ladeBenutzer(int berechtigung) {
    BenutzerListe alleMitarbeiter = Mitarbeiter.getAlleMitarbeiter();
    BenutzerListe ausgewaehlteMitarbeiter = new BenutzerListe();
    ausgewaehlteMitarbeiter.setSortierung(
      BenutzerListe.NachnameVornameSortierung, false);

    Iterator it = alleMitarbeiter.iterator();
    while (it.hasNext()) {
      Mitarbeiter currentMitarbeiter = (Mitarbeiter) it.next();
      if (currentMitarbeiter.besitztBerechtigung(berechtigung)) {
        ausgewaehlteMitarbeiter.add(currentMitarbeiter);
      }
    }
    
    //neuen Mitarbeiter anlegen, falls keiner existiert
    if (ausgewaehlteMitarbeiter.isEmpty()) {
      Mitarbeiter neuerMitarbeiter = new Mitarbeiter();
      neuerMitarbeiter.setVorname("Neuer");
      neuerMitarbeiter.setNachname("Mitarbeiter");
      neuerMitarbeiter.setBerechtigung(Mitarbeiter.BERECHTIGUNG_BESTAND_EINGABE, true);
      neuerMitarbeiter.setBerechtigung(Mitarbeiter.BERECHTIGUNG_STANDARD, true);
      neuerMitarbeiter.setBerechtigung(Mitarbeiter.BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE, true);
      neuerMitarbeiter.setBerechtigung(Mitarbeiter.BERECHTIGUNG_ADMIN, true);
      neuerMitarbeiter.save();
      ausgewaehlteMitarbeiter.add(neuerMitarbeiter);
    }
    
    
    mitarbeiterFeld.setDaten(ausgewaehlteMitarbeiter);
  }

  private void jbInit() throws Exception {
    ausgabe = new JPanel();

    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    passwortFeld = new JPasswordField();
    Format benutzerFormat = new Format() {
      public String format (Object obj) {
        if (obj == null) return null;
        Mitarbeiter mit = ((Mitarbeiter) obj);
        return mit.getNameFormal();
      }
    };
    mitarbeiterFeld = new SortiertComboBox(benutzerFormat);

    jLabel1.setText("Mitarbeiter:");
    ausgabe.setLayout(new GridBagLayout());
    jLabel2.setText("Passwort:");
    ausgabe.add(jLabel1,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 10), 0, 0));
    ausgabe.add(mitarbeiterFeld,   new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
    ausgabe.add(jLabel2,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 5, 10), 0, 0));
    ausgabe.add(passwortFeld,   new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 0), 0, 0));
  }

}