/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin.alleEinstellungenReiter;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.TableColumnModel;

import de.oberbrechen.koeb.datenbankzugriff.Einstellung;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.DatenbankInkonsistenzException;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.admin.AdminMainReiter;
import de.oberbrechen.koeb.gui.admin.Main;

/**
 * Diese Klasse repr�sentiert den Reiter, der das �ndern und Erstellen
 * von Benutzern in der GUI erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.5 $
 */

public class AlleEinstellungenReiter extends JPanel
  implements AdminMainReiter {
  
  private EinstellungenTableModel einstellungenTableModel;
  private JTable einstellungenTable;
  private Main hauptFenster;
  
  /**
   * Erzeugt einen BenutzerReiter, der im �bergebenen Frame angezeigt wird
   * @param parentFrame Frame, zu dem der Reiter geh�rt
   */
  public AlleEinstellungenReiter(Main parentFrame) {
    hauptFenster = parentFrame;

    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  // erzeugt die GUI
  private void jbInit() throws Exception {
    //Medienliste
    einstellungenTable = new JTable();
    einstellungenTableModel = 
      new EinstellungenTableModel();
    einstellungenTable.setModel(einstellungenTableModel);
    einstellungenTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    einstellungenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    einstellungenTable.registerKeyboardAction( new ActionListener() {
       public void actionPerformed(ActionEvent e) {
         removeEinstellung();
      }}, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), JComponent.WHEN_FOCUSED);
    TableColumnModel columnModel = einstellungenTable.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(50);
    columnModel.getColumn(1).setPreferredWidth(50);
    columnModel.getColumn(2).setPreferredWidth(750);
    columnModel.getColumn(3).setPreferredWidth(500);

    JScrollPane jScrollPane1 = new JScrollPane(einstellungenTable);
    jScrollPane1.setMinimumSize(new Dimension(150,150));
    jScrollPane1.setPreferredSize(new Dimension(150,150));
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(Color.white,new Color(148, 145, 140)));
    this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));    
  
    this.setLayout(new BorderLayout());
    this.add(jScrollPane1, BorderLayout.CENTER);
  }

  
  /**
   * L�scht die in der Tabelle markierte Einstellung 
   * nach einer Sicherheitsabfrage aus der Datenbank.  
   */
  protected void removeEinstellung() {
    int selectedRow = einstellungenTable.getSelectedRow();
    if (selectedRow != -1) {
      Einstellung einstellung = einstellungenTableModel.getEinstellung(selectedRow);
      try {
        int erg = JOptionPane.showConfirmDialog(hauptFenster, "Soll die Einstellung\n\n"+
          einstellung.toDebugString() +
          "\n\nwirklich gel�scht werden?",
          "Einstellung l�schen?", JOptionPane.YES_NO_OPTION);
        if (erg != JOptionPane.YES_OPTION) return;
  
        einstellung.loesche();
        einstellungenTable.clearSelection();
        einstellungenTableModel.getDaten().remove(selectedRow);
        einstellungenTableModel.fireTableDataChanged();
      } catch (DatenbankInkonsistenzException e) {
        ErrorHandler.getInstance().handleException(e, "Beim L�schen des Mediums wurde eine" +
          "Datenbank-Inkonsistenz bemerkt.", false);
      }
    }
  }

  public void aktualisiere() {
    refresh();
  }

  public void refresh() {
    einstellungenTableModel.refresh();
    einstellungenTable.doLayout();
  }
}