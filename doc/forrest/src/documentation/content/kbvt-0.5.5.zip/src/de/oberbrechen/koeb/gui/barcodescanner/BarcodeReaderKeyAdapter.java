/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.barcodescanner;

import java.awt.event.*;

/**
 * Diese Klasse stellt einen KeyAdapter da, der dazu dient,
 * die Eingabe auf m�gliche Barcodes zu �berpr�fen. Dazu wird
 * nach einer bestimmten Anfangszeichenfolge gesucht. Wird dieser
 * erkannt, wird ein entsprechendes Event ausgel�st. Dann wird nach
 * einer Endzeichenfolge gesucht. Wird diese gefunden, so werden
 * die dazwischenliegenden Zeichen als gelesener Barcode ausgegeben
 * und die Suche neu begonnen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class BarcodeReaderKeyAdapter extends KeyAdapter {
  private StringBuffer buffer;
  private String start;
  private String ende;
  private BarcodeGelesenEventHandler eventHandler;
  private boolean praefixSchonGelesen;

  public BarcodeReaderKeyAdapter(String start, String ende,
    BarcodeGelesenEventHandler eventHandler) {

    buffer = new StringBuffer();
    this.start = start;
    this.ende = ende;
    this.eventHandler = eventHandler;
    praefixSchonGelesen = false;
  }

  public void keyReleased(KeyEvent e) {
    buffer.append(e.getKeyChar());
    if (!praefixSchonGelesen) {
      while (buffer.length() > start.length()) buffer.deleteCharAt(0);
      if (buffer.toString().equals(start)) {
        praefixSchonGelesen = true;
        buffer = new StringBuffer();
        eventHandler.barcodeStartGelesen();
      }
    } else {
      if (buffer.toString().endsWith(ende)) {
        int i = 0;
        while (i < buffer.length()) {
          if (!(Character.isLetter(buffer.charAt(i)) ||
                Character.isDigit(buffer.charAt(i)))) {
            buffer.deleteCharAt(i);
          } else {
            i++;
          }
        }

        String ausgabe = buffer.substring(0, buffer.length()-ende.length()+1);
        eventHandler.barcodeGelesen(ausgabe);

        buffer = new StringBuffer();
        praefixSchonGelesen = false;
      }
    }
  }
}