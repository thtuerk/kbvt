/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;
import java.sql.*;
import java.text.SimpleDateFormat;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.framework.ErrorHandler;
/**
 * Diese Klasse ist eine konfigurierbare Implementierung einer Buecherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.10 $
*/

public class KonfigurierbareBuecherei extends Buecherei {

  class MedientypEinstellung {
    Medientyp medientyp;
    String EANPraefix;
  	String MediennrPraefix;
  	boolean einstellungsjahrInMediennr;
  }
  
  private Vector medientypEinstellungen;
	private double internetKostenProEinheitInEuro;
  private int laengeInternetEinheitInSec;
  private int kulanzZeitInternetZugangInSec;
  private boolean[] istGeoeffnet;
  
  private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy");
  private Ausleihordnung ausleihordnung;

  public KonfigurierbareBuecherei() {
    Einstellungen einstellungen = Einstellungen.getInstance();
    ausleihordnung = ((AusleihordnungFactory) einstellungen.
      getEinstellungObject(null, null, this.getClass().getName(), 
      "ausleihordnung", AusleihordnungFactory.class, "de.oberbrechen.koeb.einstellungen.KonfigurierbareAusleihordnungFactory")).
      createAusleihordnung();
    
    kulanzZeitInternetZugangInSec = einstellungen.getEinstellungInt(null, null, 
      this.getClass().getName(), "kulanzZeitInternetZugangInSec", 90);
    laengeInternetEinheitInSec = einstellungen.getEinstellungInt(null, null, 
      this.getClass().getName(), "laengeInternetEinheitInSec", 900);
    internetKostenProEinheitInEuro = einstellungen.getEinstellungDouble(null, null, 
    this.getClass().getName(), "internetKostenProEinheitInEuro", 0.5);
    
    istGeoeffnet = new boolean[8];
      istGeoeffnet[Calendar.MONDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Montag", false);
    istGeoeffnet[Calendar.TUESDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Dienstag", false);
    istGeoeffnet[Calendar.WEDNESDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Mittwoch", false);
    istGeoeffnet[Calendar.THURSDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Donnerstag", false);
    istGeoeffnet[Calendar.FRIDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Freitag", false);
    istGeoeffnet[Calendar.SATURDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Samstag", false);
    istGeoeffnet[Calendar.SUNDAY] = einstellungen.getEinstellungBoolean(null, null, 
      this.getClass().getName(), "istGeoeffnet.Sonntag", true);


  	medientypEinstellungen = new Vector();
  	Iterator medienTypIterator = Medientyp.getAlleMedientypen().iterator();
  	while (medienTypIterator.hasNext()) {
  	  Medientyp currentTyp = (Medientyp) medienTypIterator.next();
  	  
  	  MedientypEinstellung einstellung = new MedientypEinstellung();
      einstellung.EANPraefix = 
        Einstellungen.getInstance().getEinstellungString(null, null, 
        this.getClass().getName(), "EANPraefix."+currentTyp.getName(), "01");
      einstellung.MediennrPraefix = 
        Einstellungen.getInstance().getEinstellungString(null, null, 
        this.getClass().getName(), "MediennrPraefix."+currentTyp.getName(), currentTyp.getName());
      if (einstellung.MediennrPraefix != null) {
        einstellung.MediennrPraefix = einstellung.MediennrPraefix.trim();
        if (einstellung.MediennrPraefix.equals("")) 
          einstellung.MediennrPraefix = null;
      } 
      einstellung.einstellungsjahrInMediennr = 
        Einstellungen.getInstance().getEinstellungBoolean(null, null, 
        this.getClass().getName(), "EinstellungsjahrInMediennr."+currentTyp.getName(), true);
      einstellung.medientyp = currentTyp;
      medientypEinstellungen.add(einstellung);
  	}
  }

  // Doku siehe bitte Buecherei
  public Ausleihordnung getAusleihordnung() {
    return ausleihordnung;
  }

  // Doku siehe bitte Buecherei
  public boolean istGeoeffnet(Calendar datum) {
    return (istGeoeffnet[datum.get(Calendar.DAY_OF_WEEK)]);
  }

  // Doku siehe bitte Buecherei
  public double berechneInternetzugangsKosten(int dauer) {
    if (dauer < kulanzZeitInternetZugangInSec) return 0;
    int anzahlEinheiten = (dauer - kulanzZeitInternetZugangInSec) / laengeInternetEinheitInSec + 1;
    return anzahlEinheiten*internetKostenProEinheitInEuro;
  }

  public EAN getStandardMedienEAN(String medienNr) {
    /*
     * EAN besitzt Form:
     * - "20"
     * - 2 Stellen Medientyp
     * - 4 Stellen Einstellungsjahr
     * - 4 Stellen Nr in Jahr
     */

    StringBuffer ean = new StringBuffer();
    ean.append("20");
    
    //Suche passende MedientypEinstellung
    int leerZeichenPos = medienNr.indexOf(" ");
    if (leerZeichenPos == -1) return null;

    String medienTypString = medienNr.substring(0, leerZeichenPos);

    MedientypEinstellung benoetigteEinstellung = null;
    Iterator it = medientypEinstellungen.iterator();
    while (it.hasNext() && benoetigteEinstellung == null) {
      MedientypEinstellung aktuelleEinstellung = 
        (MedientypEinstellung) it.next();
      if (aktuelleEinstellung.MediennrPraefix.equals(medienTypString))
        benoetigteEinstellung = aktuelleEinstellung;          
    }
    if (benoetigteEinstellung == null) return null;
    
    //Medientypkennung einf�gen
    ean.append(benoetigteEinstellung.EANPraefix);
    
    //Nr erweitern
    String nr;
    int sollLaenge;
    if (medienNr.length() > leerZeichenPos+6 && 
        medienNr.substring(leerZeichenPos+5, leerZeichenPos+6).equals("-")) {
      ean.append(medienNr.substring(leerZeichenPos+1,leerZeichenPos+5));
      nr = medienNr.substring(leerZeichenPos+6);
      sollLaenge=4;
    } else {
      nr = medienNr.substring(leerZeichenPos+1);
      sollLaenge=8;
    }
    
    while (nr.length() < sollLaenge) nr = "0"+nr;
    ean.append(nr);

    
    EAN neueEAN;
    try {
      neueEAN = new EAN(ean.toString());
      if (neueEAN.getTyp() != EAN.MediumEAN) return null;
    } catch (IllegalArgumentException e) {
      return null;
    }
    
    return neueEAN;
  }

  public String getStandardMedienNr(Medientyp medientyp, Date einstellungsDatum) {
    if (medientyp == null || einstellungsDatum == null)
      throw new NullPointerException();
    
    MedientypEinstellung benoetigteEinstellung = null;
    Iterator it = medientypEinstellungen.iterator();
    while (it.hasNext() && benoetigteEinstellung == null) {
      MedientypEinstellung aktuelleEinstellung = 
        (MedientypEinstellung) it.next();
      if (aktuelleEinstellung.medientyp.equals(medientyp))
        benoetigteEinstellung = aktuelleEinstellung;          
    }
    if (benoetigteEinstellung == null) return "???";
    
    String jahr = dateFormat.format(einstellungsDatum);
    StringBuffer medienNr = new StringBuffer();
    if (benoetigteEinstellung.MediennrPraefix != null) {
      medienNr.append(benoetigteEinstellung.MediennrPraefix);
      medienNr.append(" ");
    }
    if (benoetigteEinstellung.einstellungsjahrInMediennr) {
      medienNr.append(jahr);
      medienNr.append("-");
    } 

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(substring(nr, "+(medienNr.length()+1)+")+1) from medium where nr like \""+
        medienNr.toString()+"%\"");
      result.next();
      int nr=result.getInt(1);
      if (nr == 0) nr=1;
      medienNr.append(nr);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Bestimmen der Mediennr!", true);
    }
    
    return medienNr.toString();
  }
}
