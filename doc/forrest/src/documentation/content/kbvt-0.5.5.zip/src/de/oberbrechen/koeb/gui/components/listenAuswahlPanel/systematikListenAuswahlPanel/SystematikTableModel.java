/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.systematikListenAuswahlPanel;

import java.awt.event.KeyListener;

import javax.swing.JTable;

import de.oberbrechen.koeb.datenbankzugriff.Systematik;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.datenstrukturen.SystematikListe;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManagerListenDaten;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Systematiken.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class SystematikTableModel extends AuswahlTableModel
  implements KeyListener, ListenKeySelectionManagerListenDaten {

	public SystematikTableModel(JTable tabelle, Liste daten) {
		super(tabelle, daten);
	}

	public int getColumnCount() {
    return 2;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Systematik";
    if (columnIndex == 1) return "Beschreibung";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }

  /**
   * Liefert die Systematik, die in der �bergebene Zeile dargestellt wird.
   * @param rowIndex
   * @return die Systematik
   */
  public Systematik getSystematik(int rowIndex) {
    return (Systematik) daten.get(rowIndex);
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    Systematik gewaehlteSystematik = (Systematik) daten.get(rowIndex);
    switch (columnIndex) {
      case 0:
        return gewaehlteSystematik.getName();
      case 1:
        return gewaehlteSystematik.getBeschreibung();
    }
    return "nicht definierte Spalte";
  }

	protected void sortiereNachSpalte(int spalte, boolean umgekehrteSortierung) {
    if (spalte == 0) daten.setSortierung(
      SystematikListe.alphabetischeSortierung, umgekehrteSortierung);
	  else return;
    
    sortierteSpalte = spalte;
  }

	public void sortiereNachStandardSortierung() {
    sortiereNachSpalte(0, false);
	}
}
