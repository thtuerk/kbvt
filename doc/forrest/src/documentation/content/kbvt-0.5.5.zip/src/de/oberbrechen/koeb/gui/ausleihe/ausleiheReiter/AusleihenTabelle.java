/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.ausleihe.ausleiheReiter;

import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.oberbrechen.koeb.ausgaben.AktuelleAusleihenListeAusgabenFactory;
import de.oberbrechen.koeb.ausgaben.Ausgabe;
import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.AusleihenListe;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.einstellungen.Buecherei;
import de.oberbrechen.koeb.framework.ErrorHandler;
import de.oberbrechen.koeb.gui.ausleihe.Main;
import de.oberbrechen.koeb.gui.components.DelayListSelectionListener;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.benutzerListenAuswahlPanel.BenutzerListenAuswahlPanel;
import de.oberbrechen.koeb.gui.framework.JComponentFormatierer;
import de.oberbrechen.koeb.gui.standarddialoge.DatumAuswahlDialog;

/**
 * Diese Klasse repr�sentiert die Ausleihenliste in dem Reiter, der die
 * Ausleihe und R�ckgabe erm�glicht.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.13 $
 */

public class AusleihenTabelle extends JPanel {

  static SimpleDateFormat dateFormat =
    new SimpleDateFormat("d. MMMM yyyy");

  Main hauptFenster;
	DatumAuswahlDialog datumAuswahlDialog;
  
	JLabel mahngebuehrenLabel;
  JTable ausleihTable;
  JButton neuButton;
  JButton allesVerlaengernButton;
  JButton ausgabeButton;
  AusleiheTableModel ausleihen;

  AusleiheReiter ausleiheReiter;
  DecimalFormat waehrungsFormat;
  Benutzer aktuellerBenutzer;

  boolean auswahlWirdGeradeGeaendert;
  DelayListSelectionListener delayListSelectionListener;
  AktuelleAusleihenListeAusgabenFactory aktuelleAusleihenListeAusgabenFactory;

  public AusleihenTabelle(AusleiheReiter ausleiheReiter, Main hauptFenster) {
    this.hauptFenster = hauptFenster;
    auswahlWirdGeradeGeaendert = false;
    waehrungsFormat = new DecimalFormat("0.00 EUR");
    datumAuswahlDialog = new DatumAuswahlDialog(hauptFenster);

    aktuelleAusleihenListeAusgabenFactory = 
      (AktuelleAusleihenListeAusgabenFactory) 
      Einstellungen.getInstance().getEinstellungObject(
      null, null, this.getClass().getName(), "AktuelleAusleihenListeAusgabe", 
      AktuelleAusleihenListeAusgabenFactory.class, "de.oberbrechen.koeb.pdf." +
      "pdfAktuelleAusleihenListe.PdfAktuelleAusleihenListeAusgabenFactory");

    this.ausleiheReiter = ausleiheReiter;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    ausleiheReiter.ausleiheGewechselt(null);
  }

  private void jbInit() throws Exception {
    ausleihen = new AusleiheTableModel();
    ausleihTable = new JTable(ausleihen);
    ausleihTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    ausleihTable.setDefaultRenderer(Object.class, new AusleiheTableRenderer());
    ausleihTable.sizeColumnsToFit(JTable.AUTO_RESIZE_OFF);
    ausleihTable.getTableHeader().addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        int spalteView = ausleihTable.getColumnModel().
                         getColumnIndexAtX(e.getX());
        int spalte = ausleihTable.convertColumnIndexToModel(spalteView);

        boolean umgekehrteSortierung =
          (e.getModifiers()&InputEvent.SHIFT_MASK) != 0;
        if (spalte == 0) ausleihen.getDaten().
          setSortierung(AusleihenListe.MedienTitelSortierung,
                        umgekehrteSortierung);
        if (spalte == 1) ausleihen.getDaten().
          setSortierung(AusleihenListe.SollrueckgabeDatumSortierung,
                        umgekehrteSortierung);
      }
    });
    mahngebuehrenLabel = new JLabel("Mahngeb�hren:");

    JLabel beschriftung = new JLabel("Mahngeb�hren:");
    beschriftung.setBorder(BorderFactory.createEmptyBorder(15,0,0,2));
    mahngebuehrenLabel.setBorder(BorderFactory.createEmptyBorder(15,0,0,2));
    mahngebuehrenLabel.setHorizontalAlignment(SwingConstants.RIGHT);


    neuButton = new JButton("neue Ausleihe");
    JComponentFormatierer.setDimension(neuButton, new Dimension(50, 21));
    neuButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        auswahlWirdGeradeGeaendert = true;
        ausleihTable.clearSelection();
        delayListSelectionListener.fireDelayListSelectionEvent();
        auswahlWirdGeradeGeaendert = false;
        ausleiheReiter.neueAusleiheErstellen();
      }
    });
    allesVerlaengernButton = new JButton("alle Verl�ngern");
    JComponentFormatierer.setDimension(
      allesVerlaengernButton, new Dimension(50, 21));
    allesVerlaengernButton.addActionListener(
      new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        verlaengereAlleAusleihen();
      }
    });
    ausgabeButton = new JButton("Ausgabe");
    JComponentFormatierer.setDimension(
      ausgabeButton, new Dimension(50, 21));
    ausgabeButton.addActionListener(
      new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        aktuelleAusgabenAusgabe();
      }
    });

    JPanel buttonPanel = new JPanel(new GridLayout(1, 3));
    buttonPanel.add(neuButton);
    buttonPanel.add(allesVerlaengernButton);
    buttonPanel.add(ausgabeButton);
    
    JPanel mahngebuehrenPanel = new JPanel(new BorderLayout());
    mahngebuehrenPanel.add(buttonPanel, BorderLayout.NORTH);
    mahngebuehrenPanel.add(beschriftung, BorderLayout.WEST);
    mahngebuehrenPanel.add(mahngebuehrenLabel, BorderLayout.EAST);

    JScrollPane jScrollPane1 = new JScrollPane();
    jScrollPane1.setAutoscrolls(true);
    jScrollPane1.getViewport().add(ausleihTable);
    jScrollPane1.setBorder(BorderFactory.createEtchedBorder(
      Color.white,new Color(148, 145, 140)));
    JComponentFormatierer.setDimension(jScrollPane1, new Dimension(100, 50));

    this.setLayout(new BorderLayout());
    this.add(jScrollPane1, BorderLayout.CENTER);
    this.add(mahngebuehrenPanel, BorderLayout.SOUTH);

    delayListSelectionListener = new DelayListSelectionListener(250);
    delayListSelectionListener.addListSelectionListener(
        new ListSelectionListener() {
          public void valueChanged(ListSelectionEvent e) {
            if (auswahlWirdGeradeGeaendert) return;
            int gewaehlteReihe = ausleihTable.getSelectedRow();
            Ausleihe gewaehlteAusleihe = ausleihen.getAusleihe(gewaehlteReihe);
            ausleiheReiter.ausleiheGewechselt(gewaehlteAusleihe);
          }
      });
    ausleihTable.getSelectionModel().addListSelectionListener(
      delayListSelectionListener);

  }

	protected void aktuelleAusgabenAusgabe() {
    try {
      BenutzerListe benutzerListe = null;
      if (hauptFenster != null) { 
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        BenutzerListenAuswahlPanel auswahlPanel = 
          new BenutzerListenAuswahlPanel(hauptFenster);
        panel.add(auswahlPanel, BorderLayout.CENTER);
        panel.add(new JLabel("Bitte w�hlen Sie die Benutzer aus, deren " +
          "aktuelle Ausleihen gedruckt werden sollen:"), BorderLayout.NORTH);
        auswahlPanel.sortiereNachSpalte(1, false);
        Vector auswahl = new Vector();
        auswahl.add(hauptFenster.getAktuellerBenutzer());
        auswahlPanel.setAuswahl(auswahl);
        int erg = JOptionPane.showConfirmDialog(hauptFenster, panel,
          "Benutzerauswahl", JOptionPane.OK_CANCEL_OPTION, 
          JOptionPane.PLAIN_MESSAGE);
  
        if (erg != JOptionPane.OK_OPTION) return; 
        benutzerListe = (BenutzerListe) auswahlPanel.getAuswahl();         
      } else {
        benutzerListe = Benutzer.getAlleBenutzer();          
      }
      benutzerListe.setSortierung(
        BenutzerListe.NachnameVornameSortierung, false);
          
      Ausgabe liste = aktuelleAusleihenListeAusgabenFactory.
        createAktuelleAusleihenListeAusgabe(benutzerListe); 
      liste.run(hauptFenster);
    } catch (Exception e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Erstellen der"+        " aktuellen Ausleihen-Liste!", false);
    }
	}

	/**
   * L�d die aktuellen Ausleihen des �bergebenen Benutzers und zeigt sie an.
   * @param benutzer der Benutzer, dessen Ausleihen geladen werden sollen
   */
  public void ladeAusleihenVon(Benutzer benutzer) {
    aktuellerBenutzer = benutzer;
    ausleihTable.clearSelection();
    AusleihenListe liste = Ausleihe.getAlleAktuellenAusleihenVon(benutzer);
    liste.setSortierung(ausleihen.getDaten().comparator());
    ausleihen.setDaten(liste);
    if (liste.size() > 0) {
      ausleihTable.setRowSelectionInterval(0, 0);
      ausleihTable.scrollRectToVisible(ausleihTable.getCellRect(0, 0, true));
    }
    berechneMahngebuehren();
  }

  /**
   * Zeigt die Tabelle neu an, ohne die Daten neu zu laden
   */
  public void refresh() {
    ausleihen.fireTableDataChanged();
    berechneMahngebuehren();
  }

  /**
   * F�gt eine Ausleihe zu der Tabelle hinzu.
   * @param ausleihe die hinzuzuf�gende Ausleihe
   */
  public void add(Ausleihe ausleihe) {
    ausleihen.add(ausleihe);
  }

  /**
   * Entfernt eine Ausleihe aus der Tabelle.
   * @param ausleihe die zu entfernende Ausleihe
   */
  public void remove(Ausleihe ausleihe) {
    ausleihen.remove(ausleihe);
  }

  /**
   * Berechnet die Mahngeb�hren der aktuell angezeigten Ausleihen neu und
   * zeigt sie an.
   */
  private void berechneMahngebuehren() {
    AusleihenListe alleAusleihen = ausleihen.getDaten();
    AusleihenListe relevanteAusleihen = new AusleihenListe();

    Iterator it = alleAusleihen.iterator();
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      if (aktuelleAusleihe.heuteZurueckgegeben()) {
        relevanteAusleihen.add(aktuelleAusleihe);
      }
      if (aktuelleAusleihe.istAktuellVerlaengert()) {
        relevanteAusleihen.add(
          aktuelleAusleihe.getErsteAusleiheDerAktuellenVerlaengerungen());
      }
    }

    double mahngebuehren = Buecherei.getInstance().getAusleihordnung()
      .berechneMahngebuehren(relevanteAusleihen);

    if (mahngebuehren == 0) {
      mahngebuehrenLabel.setForeground(Color.black);
      mahngebuehrenLabel.setText("-");
    } else {
      mahngebuehrenLabel.setForeground(Color.red);
      mahngebuehrenLabel.setText(
        waehrungsFormat.format(mahngebuehren));
    }
  }

  /**
   * Erlaubt / verbietet �nderungen, d.h. das Ausw�hlen einer anderen
   * Ausleihe oder das Anlegen einer neuen Ausleihe.
   *
   * @param erlaubt bestimmt, ob �nderungen erlaubt sind
   */
  public void erlaubeAenderungen(boolean erlaubt) {
    neuButton.setEnabled(erlaubt);
    allesVerlaengernButton.setEnabled(erlaubt);
    ausleihTable.setEnabled(erlaubt);
  }

  /**
   * Aktualisiert die AusleiheTabelle, d.h. alle Daten werden erneut aus der
   * Datenbank geladen und die Anzeige aktualisiert.
   */
  public void aktualisiere() {
    int gewaehlteReihe = ausleihTable.getSelectedRow();
    Ausleihe gewaehlteAusleihe = ausleihen.getAusleihe(gewaehlteReihe);
    ausleihen.fireTableDataChanged();
    markiereAusleihe(gewaehlteAusleihe);
    berechneMahngebuehren();
  }

  /**
   * Markiert die �bergebene Ausleihe in der Tabelle. Ist die Ausleihe nicht in
   * der Tabelle enthalten, wird keine Ausleihe markiert.
   *
   * @param ausleihe die zu selektierende Ausleihe
   */
  public void markiereAusleihe(Ausleihe ausleihe) {
    auswahlWirdGeradeGeaendert = true;
    Iterator it = ausleihen.getDaten().iterator();
    int pos = 0;
    while (it.hasNext()) {
      Ausleihe aktuelleAusleihe = (Ausleihe) it.next();
      if (aktuelleAusleihe.equals(ausleihe)) {
        ausleihTable.setRowSelectionInterval(pos, pos);
        ausleihTable.scrollRectToVisible(
          ausleihTable.getCellRect(pos, 0, true));
        ausleiheReiter.ausleiheGewechselt(ausleihe);
        delayListSelectionListener.fireDelayListSelectionEvent();
        auswahlWirdGeradeGeaendert = false;
        return;
      }
      pos++;
    }
    ausleihTable.clearSelection();
    ausleiheReiter.ausleiheGewechselt(null);
    auswahlWirdGeradeGeaendert = false;
  }

  /**
   * Markiert die erste Ausleihe in der Tabelle. Ist keine Ausleihe in
   * der Tabelle enthalten, wird keine Ausleihe markiert.
   */
  public void markiereErsteAusleihe() {
    if (ausleihen.getRowCount() > 0) {
      ausleihTable.setRowSelectionInterval(0, 0);
      ausleihTable.scrollRectToVisible(ausleihTable.getCellRect(0, 0, true));
    }
    ausleiheReiter.ausleiheGewechselt(ausleihen.getAusleihe(0));
  }

  // Doku siehe Component
  public void grabFocus() {
    ausleihTable.grabFocus();
  }
  
  /**
   * Verl�ngert alle Ausleihen bis zu einem festen Datum
   * @author thtuerk
   */
  private void verlaengereAlleAusleihen() {    
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(new Date());
    calendar.add(Calendar.DATE, 1);
    
    Date aktuellesDatum = Buecherei.getInstance().getNaechstesOeffnungsdatum(
      calendar.getTime());

    Date gewaehltesDatum = datumAuswahlDialog.waehleDatum(
      "Bis wann sollen die Medien verl�ngert werden?", aktuellesDatum);
    if (gewaehltesDatum == null) return;
    
    int erg = JOptionPane.showConfirmDialog(hauptFenster, 
      "Sollen wirklich alle von " + 
      hauptFenster.getAktuellerBenutzer().getName() + 
      "\nausgeliehenen Medien wirklich " +
      "\nbis mindestens zum " +      dateFormat.format(gewaehltesDatum)+      
      "\nverl�ngert werden?", "Wirklich verl�ngern?",JOptionPane.YES_NO_OPTION);
    if (erg != JOptionPane.YES_OPTION) return;

    auswahlWirdGeradeGeaendert = true;

    ausleihTable.clearSelection();
    delayListSelectionListener.fireDelayListSelectionEvent();

    hauptFenster.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    Thread.yield();

    //alle Verl�ngern
    int ausleihenAnzahl = ausleihen.getRowCount(); 
    for (int i=0; i < ausleihenAnzahl; i++) {
      Ausleihe aktuelleAusleihe = ausleihen.getAusleihe(i);
      ausleihen.remove(aktuelleAusleihe);
      ausleihen.add(aktuelleAusleihe.verlaengereBisMindestens(gewaehltesDatum));
    }
    
    berechneMahngebuehren();      
    hauptFenster.setCursor(Cursor.getDefaultCursor());
    auswahlWirdGeradeGeaendert = false;

    if (ausleihen.getRowCount() > 0)
      ausleihTable.getSelectionModel().setSelectionInterval(0,0);
  }
}