/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.veranstaltungen.benutzerReiter;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import de.oberbrechen.koeb.datenbankzugriff.*;

/**
 * Diese Klasse ist ein TableCellRenderer f�r eine Liste von
 * Veranstaltungen.
 */
public class VeranstaltungenTableRenderer implements TableCellRenderer {

  private JCheckBox rendererCheckBox;
  private DefaultTableCellRenderer rendererLabel;

  private static final Color belegtForeground = new Color(255,0,0);
  private static final Color belegtBackground = new Color(255,0,0,30);
  private static final Color standardForeground = new Color(0,0,0);
  private static final Color standardBackground = new Color(0,0,0,30);
  private static final Border belegtBorder = new LineBorder(new Color(255,0,0, 150), 1);
  private static final Border standardBorder = new LineBorder(new Color(0,0,0, 150), 1);

  public VeranstaltungenTableRenderer() {
    rendererLabel = new DefaultTableCellRenderer();
    rendererLabel.setOpaque(true);

    Font bisherigeFont = rendererLabel.getFont();
    rendererLabel.setFont(bisherigeFont.deriveFont(Font.PLAIN));

    rendererCheckBox = new JCheckBox();
    rendererCheckBox.setBorderPaintedFlat(true);
    rendererCheckBox.setBorderPainted(true);
    rendererCheckBox.setHorizontalAlignment(JCheckBox.CENTER);
  }

  public Component getTableCellRendererComponent(
    JTable table, Object value, boolean isSelected,
    boolean hasFocus, int row, int columnView) {

    Component renderer;
    if (value instanceof Boolean) {
      renderer = rendererCheckBox;
      rendererCheckBox.setSelected(((Boolean) value).booleanValue());
    } else {
      renderer = rendererLabel;
      if (value == null) value = "";
      rendererLabel.setText(value.toString());
      int column = table.convertColumnIndexToModel(columnView);
      if (column == 1 || column == 3 || column == 4)
        rendererLabel.setHorizontalAlignment(JLabel.LEFT);
      else
        rendererLabel.setHorizontalAlignment(JLabel.CENTER);
    }

    boolean veranstaltungBelegt = false;
    VeranstaltungenTableModel model =
        (VeranstaltungenTableModel) table.getModel();
    Veranstaltung aktuelleVeranstaltung = model.getVeranstaltung(row);
    if (aktuelleVeranstaltung.getMaximaleTeilnehmerAnzahl() != 0 &&
        aktuelleVeranstaltung.getMaximaleTeilnehmerAnzahl() <=
        aktuelleVeranstaltung.getTeilnehmerAnzahl())
      veranstaltungBelegt = true;

    if (isSelected) {
      if (veranstaltungBelegt) {
        renderer.setBackground(belegtBackground);
        renderer.setForeground(belegtForeground);
      } else {
        renderer.setBackground(standardBackground);
        renderer.setForeground(standardForeground);
      }
    } else {
      if (veranstaltungBelegt) {
        renderer.setForeground(belegtForeground);
      } else {
        renderer.setForeground(standardForeground);
      }
      renderer.setBackground(Color.white);
    }
        
    
    if (hasFocus) {
      if (veranstaltungBelegt) {
        rendererLabel.setBorder(belegtBorder);
        rendererCheckBox.setBorder(belegtBorder);
      } else {
        rendererLabel.setBorder(standardBorder);
        rendererCheckBox.setBorder(standardBorder);
      }
    } else {
      rendererLabel.setBorder(null);
      rendererCheckBox.setBorder(null);      
    }
    
    if (hasFocus && model.isCellEditable(row, table.convertColumnIndexToModel(columnView)))
      renderer.setBackground(Color.white);
    return renderer;
  }
}