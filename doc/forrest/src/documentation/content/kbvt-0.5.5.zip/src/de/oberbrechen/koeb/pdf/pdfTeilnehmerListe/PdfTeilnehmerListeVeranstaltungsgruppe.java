/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfTeilnehmerListe;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.*;

public class PdfTeilnehmerListeVeranstaltungsgruppe extends PdfDokument {

  private Veranstaltungsgruppe veranstaltungsgruppe;

  public PdfTeilnehmerListeVeranstaltungsgruppe() {
    veranstaltungsgruppe = null;
  }

  /**
   * Setzt die Veranstaltungsgruppe, deren Teilnehmerliste
   * angezeigt werden soll.
   *
   * @param veranstaltungsgruppe die neue Veranstaltungsgruppe
   */
  public void setVeranstaltungsgruppe
    (Veranstaltungsgruppe veranstaltungsgruppe) {

    this.veranstaltungsgruppe = veranstaltungsgruppe;
  }

  //Doku siehe bitte Interface
  public void schreibeInDokument(PdfWriter writer, Document doc) throws Exception {

    //Modell bauen
    TabellenModell modell=new PdfTeilnehmerListeVeranstaltungsgruppeTabellenModell(
      veranstaltungsgruppe);

    //alles zusammenbauen
    PdfTabelle tabelle = new PdfTabelle(modell);
    TabellenKopf tabellenKopf = tabelle.getTabellenKopf();
    PdfTeilnehmerListeVeranstaltungsgruppeSeitenKopfErsteSeite
      seitenKopfErsteSeite =
      new PdfTeilnehmerListeVeranstaltungsgruppeSeitenKopfErsteSeite(
      veranstaltungsgruppe, tabellenKopf);

    PdfTabelleDokument tabelleDoc = new PdfTabelleDokument(veranstaltungsgruppe.getName(),
      tabelle, seitenKopfErsteSeite, null, null, false, true);

    tabelleDoc.schreibeInDokument(writer, doc);
  }
}
