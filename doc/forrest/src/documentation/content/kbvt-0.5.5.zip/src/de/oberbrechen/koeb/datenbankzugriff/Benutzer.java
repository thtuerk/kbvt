/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;
import java.security.*;
import java.util.Observable;


/**
* Diese Klasse repr�sentiert einen Benutzer der B�cherei. Es stellt die
* Verbindung zur Datenbank her und Methoden, um die Benutzer zu manipulieren.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.21 $
*/

public class Benutzer extends Observable {

  // Die Attribute der Benutzer wie in der Datenbank
  private int benutzerNr;
  private String vorname, nachname, adresse, ort, klasse;
  private String tel, fax, eMail, benutzername, passwort, bemerkungen;
  private Date geburtsdatum, anmeldedatum;

  private boolean isSaved;

  // Statische Speicherung der Benutzer
  private static Hashtable cache = new Hashtable();
  private static String standardBenutzerwohnort = null;
  
  /**
   * Liefert das zur �bergebenen Benutzernr passende Benutzer-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jeden Benutzer
   * existiert nur ein Objekt.
   *
   * @param benutzernr die Benutzernummer, die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene Benutzernummer
   *  nicht in der Datenbank existiert
   */
  public static Benutzer getBenutzer(int benutzerNr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    Integer benutzerNrWrapper = new Integer(benutzerNr);
    Benutzer erg = (Benutzer) cache.get(benutzerNrWrapper);
    if (erg == null) {
      erg = new Benutzer(benutzerNr);
      cache.put(benutzerNrWrapper, erg);
    }
    return erg;
  }

  /**
   * Liefert den Standardwohnwort f�r Benutzer. Dieser wird automatisch
   * gesetzt, wenn ein neuer Benutzer erstellt wird.
   * @return den Standardwohnwort f�r Benutzer
   */
  public static String getStandardBenutzerwohnort() {
    if (standardBenutzerwohnort != null) return standardBenutzerwohnort;
    
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select count(*) as anzahl, ort from benutzer group by ort order" +
        " by anzahl DESC limit 1");
      boolean ortGefunden = result.next();
      if (!ortGefunden) return null;
      String erg = result.getString("ort");

      Datenbank.getInstance().releaseStatement(statement);
      standardBenutzerwohnort = erg;
      return erg;
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Bestimmen des Standardwohnorts!", true);
    }
    return null;
  }

  /**
   * Bestimmt, ob es sich um einen neuen Benutzer handelt, d.h. um einen
   * Benutzer der gerade neu angelegt wird und noch nicht in der Datenbank
   * gespeichert ist.
   *
   * @return <code>true</code> gdw der Benutzer neu ist
   */
  public boolean istNeu() {
    return (benutzerNr == 0);
  }

  /**
   * Berechnet zum �bergebenen Passwort die Pr�fziffer nach dem MD5
   * Algorithmus
   *
   * @param passwort das Passwort, dessen Pr�fziffer berechnet werden soll
   * @return die Pr�fziffer
   */
  public static String berechnePruefziffer(String passwort) {
    if (passwort == null) return null;
    try {
      MessageDigest md = MessageDigest.getInstance("MD5");
      byte[] passwortMD5 = md.digest(passwort.getBytes());
      StringBuffer buffer = new StringBuffer();
      for (int i=0; i < passwortMD5.length; i++) {
        int value = (passwortMD5[i] & 0x7F) + (passwortMD5[i] < 0 ? 128 : 0);
        String codeValue = Integer.toHexString(value);
        if (codeValue.length() == 1) buffer.append("0");
        buffer.append(codeValue);
      }
      return buffer.toString();
    } catch (NoSuchAlgorithmException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Berechnen der Pr�fziffer f�r das Passwort!", true); 
    }
    return null;
  }

  /**
   * Liefert eine unsortierte Liste aller Benutzer, die in der Datenbank
   * eingetragen sind.
   *
   * @see BenutzerListe
   */
  public static BenutzerListe getAlleBenutzer() {
    BenutzerListe liste = new BenutzerListe();
    cache.clear();
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from benutzer;");
      while (result.next()) {

        Benutzer neuBenutzer = new Benutzer();

        neuBenutzer.isSaved = true;
        neuBenutzer.benutzerNr = result.getInt("nr");
        neuBenutzer.vorname = result.getString("vorname");
        neuBenutzer.nachname = result.getString("nachname");
        neuBenutzer.adresse = result.getString("adresse");
        neuBenutzer.ort = result.getString("ort");
        neuBenutzer.klasse = result.getString("klasse");
        neuBenutzer.tel = result.getString("tel");
        neuBenutzer.fax = result.getString("fax");
        neuBenutzer.eMail = result.getString("eMail");
        neuBenutzer.benutzername = result.getString("benutzername");
        neuBenutzer.passwort = result.getString("Passwort");
        neuBenutzer.bemerkungen = result.getString("bemerkungen");
        neuBenutzer.geburtsdatum = result.getDate("geburtsdatum");
        neuBenutzer.anmeldedatum = result.getDate("anmeldedatum");
        cache.put(new Integer(neuBenutzer.benutzerNr), neuBenutzer);
        liste.addNoDuplicate(neuBenutzer);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Benutzerliste!", true);
    }

    return liste;
  }

  /**
   * Liefert eine alphabetisch sortierte Liste aller Orte, in denen Benutzer
   * wohnen. In der Liste sind die Orte als String-Objekte abgelegt.
   *
   * @return eine alphabetisch sortierte Liste aller Orte, in denen Benutzer
   * wohnen
   */
  public static Liste getAlleOrte() {
    Liste liste = new Liste();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select distinct ort from benutzer;");
      while (result.next()) {
        String ort = result.getString("ort");
        if (ort != null) liste.add(ort);
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Wohnortsliste der Benutzer!", true);
    }

    liste.setSortierung(Liste.StringSortierung, false);
    return liste;
  }


  /**
   * Erstellt einen neuen, bisher noch nicht in der Datenbank vorhandenen
   * Benutzer. Alle Attribute des Benutzers werden mit Standardwerten
   * initialisiert. Insbesondere wird die Benutzernr mit undefiniert
   * initialisiert. Beim ersten Speichern wird dann automatisch eine passende
   * Nummer zugewiesen.
   */
  public Benutzer() {
    benutzerNr = 0;
    vorname = null;
    nachname = null;
    adresse = null;
    ort = Benutzer.getStandardBenutzerwohnort();
    klasse = null;
    tel = null;
    fax = null;
    eMail = null;
    benutzername = null;
    passwort = null;
    bemerkungen = null;
    geburtsdatum = null;
    anmeldedatum = new Date(System.currentTimeMillis());

    isSaved = false;
  }

  /**
   * L�d die Daten zu der �bergebenen Benutzernummer aus der Datenbank.
   * Existiert die Benutzernummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param benutzerNr die Benutzernummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Benutzernr nicht in der
   *   Datenbank vorhanden ist
   */
  protected void load(int benutzerNr)
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    try {
      isSaved = true;

      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from benutzer where nr = " + benutzerNr);
      boolean benutzerGefunden = result.next();
      if (!benutzerGefunden) throw new DatenNichtGefundenException(
        "Ein Benutzer mit der Nr "+benutzerNr+" existiert nicht!");

      this.benutzerNr = benutzerNr;
      vorname = result.getString("vorname");
      nachname = result.getString("nachname");
      adresse = result.getString("adresse");
      ort = result.getString("ort");
      klasse = result.getString("klasse");
      tel = result.getString("tel");
      fax = result.getString("fax");
      eMail = result.getString("eMail");
      benutzername = result.getString("benutzername");
      passwort = result.getString("Passwort");
      bemerkungen = result.getString("bemerkungen");
      geburtsdatum = result.getDate("geburtsdatum");
      anmeldedatum = result.getDate("anmeldedatum");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "des Benutzers mit der Nummer "+benutzerNr, true);
    }
    this.setChanged();
    this.notifyObservers();
  }

  /**
   * L�d alle Daten des aktuellen Benutzers erneut aus der Datenbank. Ist der
   * Benutzer noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls der Benutzer inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    this.load(this.getBenutzerNr());
  }

  /**
   * Erstellt ein neues <code>Benutzer</code>-Objekt. Dazu wird der Benutzer
   * mit der �bergebenen Benutzernummer aus der Datenbank geladen. Existiert
   * die Benutzernummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param BenutzerNr die Benutzernummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Benutzernr nicht in der
   *   Datenbank vorhanden ist
   */
  public Benutzer(int BenutzerNr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.load(BenutzerNr);
  }

  /**
   * �berpr�ft, ob die aktuellen Daten schon gespeichert sind.
   * @return <code>TRUE</code> falls die Daten schon gespeichert sind<br>
   *         <code>FALSE</code> sonst
   */
  public boolean istGespeichert() {
    return isSaved;
  }

  /**
   * Speichert den aktuellen Benutzer bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws BenutzernameSchonVergebenException falls der Benutzername
   *  schon von einem anderen Benutzer verwendet wird
   * @throws UnvollstaendigeDatenException falls Vorname oder Nachname nicht
   *  angegeben sind
   */
  public void save() throws UnvollstaendigeDatenException, 
    MitarbeiterbenutzernameSchonVergebenException, 
    BenutzerSchonMitarbeiterException, BenutzernameSchonVergebenException, DatenNichtGefundenException, DatenbankInkonsistenzException {
      
    if (isSaved) return;

    if (this.getVorname() == null || this.getNachname() == null)
      throw new UnvollstaendigeDatenException("Vorname und Nachname jedes "+
        "Benutzers m�ssen eingegeben sein.");
    if (istBenutzernameSchonVergeben()) {
      throw new BenutzernameSchonVergebenException(
        new Benutzer(sucheBenutzername(this.getBenutzername())));
    }

    try {
      Connection connection = Datenbank.getInstance().getConnection();
      connection.setAutoCommit(false);      
      PreparedStatement statement = null;

      if (this.istNeu()) {
        benutzerNr = Benutzer.getNeueBenutzernr();
        statement = connection.prepareStatement(
          "insert into benutzer set nr = ?, Nachname = ?, "+
          "Vorname = ?, Ort = ?, Adresse = ?, Tel = ?, Fax = ?, eMail = ?, "+
          "Benutzername = ?, Passwort = ?, Bemerkungen = ?, Geburtsdatum = ?, "+
          "Anmeldedatum = ?, klasse = ?");
      } else {
        statement = connection.prepareStatement(
          "update benutzer set nr=?, Nachname = ?, Vorname = ?, "+
          "Ort = ?, Adresse = ?, Tel = ?, Fax = ?, eMail = ?, Benutzername = ?, "+
          "Passwort = ?, Bemerkungen = ?, Geburtsdatum = ?, Anmeldedatum = ?,"+
          "klasse = ? "+
          "where nr="+benutzerNr);
      }
      statement.setLong(1,this.getBenutzerNr());
      statement.setString(2, this.getNachname());
      statement.setString(3, this.getVorname());
      statement.setString(4, this.getOrt());
      statement.setString(5, this.getAdresse());
      statement.setString(6, this.getTel());
      statement.setString(7, this.getFax());
      statement.setString(8, this.getEMail());
      statement.setString(9, this.getBenutzername());
      statement.setString(10, passwort);
      statement.setString(11, this.getBemerkungen());
      statement.setDate(12, this.getGeburtsdatum());
      statement.setDate(13, this.getAnmeldedatum());
      statement.setString(14, this.getKlasse());

      statement.execute();
      connection.commit();
      connection.setAutoCommit(true);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Speichern des folgenden "+
        "Benutzers:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    this.setChanged();
    this.notifyObservers();
  }

  /**
   * �berpr�ft, ob dieser Benutzer einen Benutzernamen verwendet.
   * @return <code>TRUE</code> gdw. der Benutzer einen Benutzernamen verwendet
   */
  public boolean istBenutzernameGesetzt() {
    return (this.getBenutzername() != null);
  }

  /**
   * �berpr�ft, ob der Benutzername des Benutzers schon von einem
   * anderen Benutzer verwendet wird.
   * @return <code>TRUE</code> gdw der Benutzername schon von einem anderen
   * Benutzer verwendet wird
   */
  public boolean istBenutzernameSchonVergeben() {
    return istBenutzernameSchonVergeben(this.getBenutzername());
  }

  /**
   * �berpr�ft, ob der �bergebene Benutzername schon von einem anderen
   * Benutzer verwendet wird.
   * @param benutzername der zu testende Benutzername
   * @return <code>TRUE</code> gdw der Benutzername schon von einem anderen
   * Benutzer verwendet wird
   */
  public boolean istBenutzernameSchonVergeben(String benutzername) {
    if (benutzername == null) return false;

    try {
      int zugehoerigeBenutzernr =
        Benutzer.sucheBenutzername(benutzername);
      return (zugehoerigeBenutzernr != this.getBenutzerNr());
    } catch (DatenNichtGefundenException e) {
      return false;
    }
  }

  /**
   * Bestimmt die Benutzernr, die zu dem �bergebenen Benutzernamen geh�rt.
   * @param benutzername der Benutzername
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit diesem Mitarbeiter-Benutzernamen existiert
   *
   * @return die zugeh�rige Benutzernr
   */
  public static int sucheBenutzername(String benutzername) throws DatenNichtGefundenException {

    int erg = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from benutzer where "+
        "Benutzername=\""+benutzername+"\"");

      boolean benutzerGefunden = result.next();
      if (!benutzerGefunden) throw new DatenNichtGefundenException(
        "Ein Benutzer mit dem Benutzernamen '"+benutzername+"' existiert "+
        "nicht.");

      erg = result.getInt(1);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des Benutzers mit "+
        "dem Benutzernamen '"+benutzername+"'!", true);
    }

    return erg;
  }

  /**
   * L�scht den Benutzer aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieser Benutzer noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise Ausleihen dieses Benutzers existieren. Nur
   * wenn keine solchen Beziehungen existieren, wird der Benutzer gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *  Benutzers in der Datenbank existieren
   */
  public void loesche() throws DatenbankInkonsistenzException {
    //nichts zu tun, falls Benutzer noch nicht gespeichert ist
    if (this.istNeu()) return;

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(Nr) from ausleihe where "+
        "Benutzer=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Benutzers "+
        "existieren.");

      // Veranstaltungen
      result = statement.executeQuery(
        "select count(Nr) from benutzer_besucht_veranstaltung where "+
        "benutzerNr=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Veranstaltungsteilnahmen dieses "+
        "Benutzers existieren.");

      // Internet
      result = statement.executeQuery(
        "select count(Nr) from internet_zugang where "+
        "Benutzer=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Internetfreigaben dieses "+
        "Benutzers existieren.");

      // Mitarbeiter
      result = statement.executeQuery(
        "select count(Nr) from mitarbeiter where "+
        "benutzerNr=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da er noch als Mitarbeiter eingetragen "+
        "ist.");

      // Benutzer l�schen
      statement.execute("delete from benutzer where "+
        "Nr=\""+this.getBenutzerNr()+"\"");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Benutzers:\n\n"+this.toDebugString(), true);
    }
  }

  /**
   * Bestimmt die gr��te verwendete Benutzernummer.
   * @return die gr��te verwendete Benutzernummer
   */
  public static int getGroessteBenutzernr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from benutzer");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Benutzernummer!", true);
    }

    return maxNr;
  }

  /**
   * Bestimmt die n�chste freie Benutzernummer.
   * @return die n�chste freie Benutzernummer
   */
  public static int getNeueBenutzernr() {
    return getGroessteBenutzernr()+1;
  }

  /**
   * Liefert die Nummer des Benutzers, 0 steht dabei f�r eine noch nicht
   * zugewiesene Nummer
   * @return Nummer des Benutzers
   */
  public int getBenutzerNr() {
    return benutzerNr;
  }

  /**
   * Liefert den vollst�ndigen Namen des Benutzers in der Form
   * "Vorname Nachname".
   * @return Name des Benutzers
   */
  public String getName() {
    return vorname+" "+nachname;
  }

  /**
   * Liefert den vollst�ndigen Namen des Benutzers in der Form
   * "Nachname, Vorname".
   * @return Name des Benutzers
   */
  public String getNameFormal() {
    return nachname+", "+vorname;
  }

  /**
   * Liefert den Vornamen des Benutzers
   * @return Vorname des Benutzers
   */
  public String getVorname() {
    return vorname;
  }

  /**
   * Liefert den Nachnamen des Benutzers
   * @return Nachname des Benutzers
   */
  public String getNachname() {
    return nachname;
  }

  /**
   * Liefert die Adresse des Benutzers
   * @return Adresse des Benutzers
   */
  public String getAdresse() {
    return adresse;
  }

  /**
   * Liefert den Ort des Benutzers
   * @return Ort des Benutzers
   */
  public String getOrt() {
    return ort;
  }

  /**
   * Liefert die Klasse des Benutzers
   * @return Klasse des Benutzers
   */
  public String getKlasse() {
    return klasse;
  }

  /**
   * Liefert die Telefonnummer des Benutzers
   * @return Telefonnummer des Benutzers
   */
  public String getTel() {
    return tel;
  }

  /**
   * Liefert Faxnummer zum Benutzers
   * @return Faxnummer des Benutzers
   */
  public String getFax() {
    return fax;
  }

  /**
   * Liefert eMail-Adresse zum Benutzers
   * @return eMail-Adresse des Benutzers
   */
  public String getEMail() {
    return eMail;
  }

  /**
   * Liefert den Benutzernamen des Benutzers f�r die elektronische Anmeldung
   * @return Benutzernamen des Benutzers
   */
  public String getBenutzername() {
    return benutzername;
  }

  /**
   * Liefert die Bemerkungen zum Benutzer
   * @return Bemerkungen zum Benutzer
   */
  public String getBemerkungen() {
    return bemerkungen;
  }

  /**
   * Liefert das Anmeldedatum des Benutzers
   * @return Anmeldedatum des Benutzers
   */
  public Date getAnmeldedatum() {
    return anmeldedatum;
  }

  /**
   * Liefert das Geburtsdatum des Benutzers
   * @return Geburtsdatum des Benutzer
   */
  public Date getGeburtsdatum() {
    return geburtsdatum;
  }

  /**
   * Setzt den Vornamen des Benutzers
   * @param Vorname Vorname des Benutzers
   */
  public void setVorname(String Vorname) {
    isSaved = false;
    vorname = Datenbank.entferneNullString(Vorname);
  }

  /**
   * Setzt den Nachnamen des Benutzers
   * @param Nachname Nachname des Benutzers
   */
  public void setNachname(String Nachname) {
    isSaved = false;
    nachname = Datenbank.entferneNullString(Nachname);
  }

  /**
   * Setzt die Adresse des Benutzers
   * @param Adresse Adresse des Benutzers
   */
  public void setAdresse(String Adresse) {
    isSaved = false;
    adresse = Datenbank.entferneNullString(Adresse);
  }

  /**
   * Setzt den Ort des Benutzers
   * @param Ort des Benutzers
   */
  public void setOrt(String Ort) {
    isSaved = false;
    ort = Datenbank.entferneNullString(Ort);
  }

  /**
   * Setzt die Klasse des Benutzers
   * @param Klasse des Benutzers
   */
  public void setKlasse(String Klasse) {
    isSaved = false;
    klasse = Datenbank.entferneNullString(Klasse);
  }

  /**
   * Setzt die Telefonnummer des Benutzers
   * @param Telefonnummer des Benutzers
   */
  public void setTel(String Tel) {
    isSaved = false;
    tel = Datenbank.entferneNullString(Tel);
  }

  /**
   * Setzt Faxnummer zum Benutzers
   * @param Fax Faxnummer des Benutzers
   */
  public void setFax(String Fax) {
    isSaved = false;
    fax = Datenbank.entferneNullString(Fax);
  }

  /**
   * Setzt eMail-Adresse des Benutzers
   * @param eMail eMail-Adresse des Benutzers
   */
  public void setEMail(String eMail) {
    isSaved = false;
    this.eMail = Datenbank.entferneNullString(eMail);
  }

  /**
   * Setzt den Benutzernamen des Benutzers f�r die elektronische Anmeldung
   * @param Benutzername Benutzernamen des Benutzers
   */
  public void setBenutzername(String Benutzername) {
    isSaved = false;
    benutzername = Datenbank.entferneNullString(Benutzername);
  }

  /**
   * Setzt das Passwort des Benutzers f�r die elektronische Anmeldung. Beachten
   * Sie bitte, dass nicht das Passwort selbst, sondern die zugeh�rige
   * Pr�fziffer nach dem MD5-Algorithmus
   * @param Passwort Passwort des Benutzers
   */
  public void setPasswort(String Passwort) {
    isSaved = false;
    passwort = berechnePruefziffer(Passwort);
  }

  /**
   * �berpr�ft, ob das �bergebene Passwort dem Passwort des Benutzer entspricht
   * @param Passwort das zu testende Passwort
   * @return <code>TRUE</code> gdw das Passwort g�ltig ist
   */
  public boolean checkPasswort(String Passwort) {
    if (passwort == null)
      return (Datenbank.entferneNullString(Passwort) == null);
    return passwort.equals(berechnePruefziffer(Passwort));
  }

  /**
   * �berpr�ft, ob dieser Benutzer ein Passwort verwendet
   * @return <code>TRUE</code> gdw der Benutzer ein Passwort verwendet
   */
  public boolean istPasswortGesetzt () {
    return (passwort != null);
  }

  /**
   * Setzt die Bemerkungen zum Benutzer
   * @param Bemerkungen Bemerkungen zum Benutzer
   */
  public void setBemerkungen(String Bemerkungen) {
    isSaved = false;
    bemerkungen = Datenbank.entferneNullString(Bemerkungen);
  }

  /**
   * Setzt das Anmeldedatum des Benutzers
   * @param Anmeldedatum Anmeldedatum des Benutzers
   */
  public void setAnmeldedatum(java.util.Date Anmeldedatum) {
    isSaved = false;
    if (Anmeldedatum == null)
      anmeldedatum = null;
    else
      anmeldedatum = new Date(Anmeldedatum.getTime());
  }

  /**
   * Setzt das Geburtsdatum des Benutzers
   * @param Geburtsdatum Geburtsdatum des Benutzer
   */
  public void setGeburtsdatum(java.util.Date Geburtsdatum) {
    isSaved = false;
    if (Geburtsdatum == null)
      geburtsdatum = null;
    else
      geburtsdatum = new Date(Geburtsdatum.getTime());
  }

  /**
   * Berechnet das Alter des Benutzers aus dem Geburtsdatum und dem aktuellen
   * Datum. Falls kein Geburtsdatum angeben ist, wird -1 geliefert.
   *
   * @return Alter in Jahren
   */
  public double getAlter() {
    return getAlter(new java.util.Date());
  }

  /**
    * Berechnet das Alter des Benutzers zum �bergebenen Zeitpunkt. Falls kein
    * Zeitpunkt �bergeben wird, wird -1 geliefert.
    *
    * @param zeitpunkt der Zeitpunkt, zu dem das Alter berechnet werden soll
    * @return Alter in Jahren
    */
   public double getAlter(java.util.Date zeitpunkt) {
     if (geburtsdatum == null || zeitpunkt == null) return -1;

     long alterInMillisekunden = zeitpunkt.getTime() -
                                 geburtsdatum.getTime();

     long milliSekundenInJahr = 31536;
     milliSekundenInJahr *= 1000000;

     return (((double) alterInMillisekunden) / milliSekundenInJahr);
   }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Benutzer ").append(benutzerNr).append("\n");
    ausgabe.append("-------------------------------\n");
    ausgabe.append(this.getName()).append("\n");
    if (adresse != null)     ausgabe.append(adresse).append("\n");
    if (ort != null)          ausgabe.append(ort).append("\n");
    if (tel != null)          ausgabe.append("Tel.  : ").append(tel).append("\n");
    if (fax != null)          ausgabe.append("Fax   : ").append(fax).append("\n");
    if (eMail != null)        ausgabe.append("eMail : ").append(eMail).append("\n");
    if (klasse != null)       ausgabe.append("Klasse: ").append(klasse).append("\n");
    if (geburtsdatum != null) ausgabe.append("Geburtsdatum: ").append(Datenbank.getInstance().formatDatum(geburtsdatum)).append("\n");
    if (anmeldedatum != null) ausgabe.append("Anmeldedatum: ").append(Datenbank.getInstance().formatDatum(anmeldedatum)).append("\n");

    if (benutzername != null || passwort != null) {
      ausgabe.append("\nBenutzername: ");
      if (benutzername != null) ausgabe.append(benutzername);
      ausgabe.append("\nPasswort    : ");
      if (passwort != null) ausgabe.append("********\n");
    }

    return ausgabe.toString();
  }

  /**
   * Weist dem Benutzer einen neuen, eindeutigen Benutzernamen zu. Dieser
   * Benutzername setzt sich aus den ersten beiden Buchstaben des Vornamens,
   * sowie den ersten 6 (soweit vorhanden) Buchstaben des Nachnamens zusammen.
   * Dabei werden nur Kleinbuchstaben verwendet und Umlaute durch die
   * jeweiligen Umschreibungen ersetzt. <br>
   * Ist dieser Standardname schon vergeben, wird noch eine eindeutige Nummer
   * angeh�ngt. Der Benutzer "Thomas T�rk" erhielte beispielsweise den
   * Benutzernamen "thtuerk".
   */
  public void setStandardBenutzername() {
    if (vorname == null || nachname == null) return;

    String neuerBenutzername =
        vorname.substring(0, Math.min(2, vorname.length())) +
        nachname.substring(0, Math.min(6, nachname.length()));
    neuerBenutzername = neuerBenutzername.toLowerCase();

    // Umlaute entfernen
    StringBuffer buffer = new StringBuffer();
    for (int i = 0; i < neuerBenutzername.length(); i++) {
      char currentChar = neuerBenutzername.charAt(i);
      switch (currentChar) {
        case '�':
          buffer.append("ae"); break;
        case '�':
          buffer.append("oe"); break;
        case '�':
          buffer.append("ue"); break;
        case '�':
          buffer.append("ss"); break;
        default:
          buffer.append(currentChar);
      }
    }
    neuerBenutzername = buffer.toString();

    //Eindeutigkeit sicherstellen
    int Nr = 1;
    String neuerBenutzernameNr = neuerBenutzername;
    while (this.istBenutzernameSchonVergeben(neuerBenutzernameNr)) {
      Nr++;
      neuerBenutzernameNr = neuerBenutzername+Nr;
    }

    this.setBenutzername(neuerBenutzernameNr);
  }

  public String toString() {
    return this.getName();
  }
  
  public boolean equals(Object benutzer) {
    if (benutzer == null) return false;
    if (!(benutzer instanceof Benutzer)) return false;

    return (this.getBenutzerNr() == ((Benutzer) benutzer).getBenutzerNr());
  }  
}