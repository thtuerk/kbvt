/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.InternetfreigabenListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
* Diese Klasse repr�sentiert eine Internetfreigabe der B�cherei.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.10 $
*/

public class Internetfreigabe {

  // Die Attribute der Internetfreigabe
  private Client client;
  private int nr;
  private Benutzer benutzer;
  private Mitarbeiter mitarbeiter;
  private Timestamp von, bis;

  /**
   * L�d die Internetfreigabe mit der �bergebenen Nummer aus der Datenbank
   * @param nr die zu ladende Nummer
   * @throws DatenNichtGefundenException falls die Freigabe mit der �bergebenen
   *   Nummer nicht in der Datenbank existiert
   */
  public Internetfreigabe(int nr) throws DatenNichtGefundenException {
    load(nr);
  }

  private Internetfreigabe(int nr, Client client, Benutzer benutzer, 
    Mitarbeiter mitarbeiter, Timestamp von, Timestamp bis) {
    this.nr = nr;
    this.client = client;
    this.benutzer = benutzer;
    this.mitarbeiter = mitarbeiter;
    this.von = von;
    this.bis = bis;
  }
    
  /**
   * Erstellt eine neue Internetfreigabe, die den �bergebenen Rechner
   * f�r den �bergebenen Benutzer ab dem aktuellen Zeitpunkt freigibt und
   * vom aktuellen Mitarbeiter get�tigt wird.
   *
   * @param benutzer der Benutzer, f�r den der Internetzugang freigeschaltet
   *   werden soll
   * @param rechner der Rechner, an dem der Internetzugang freigeschaltet werden
   *   soll
   */
  public Internetfreigabe(Benutzer benutzer, Client rechner) throws DatenNichtGefundenException {
    this(benutzer, rechner, Mitarbeiter.getAktuellenMitarbeiter());
  }

  /**
   * Erstellt eine neue Internetfreigabe, die den �bergebenen Client
   * f�r den �bergebenen Benutzer ab dem aktuellen Zeitpunkt freigibt und
   * vom �bergebenen Mitarbeiter get�tigt wird.
   *
   * @param benutzer der Benutzer, f�r den der Internetzugang freigeschaltet
   *   werden soll
   * @param Client der Client, an dem der Internetzugang freigeschaltet werden
   *   soll
   * @param mitarbeiter der Mitarbeiter, der die Freigabe t�tigt
   */
  public Internetfreigabe(Benutzer benutzer, Client client,
    Mitarbeiter mitarbeiter) throws DatenNichtGefundenException {

    try {
      nr = getNeueInternetfreigabenr();
      PreparedStatement statement = Datenbank.getInstance().
        getConnection().prepareStatement(
          "insert into internet_zugang set nr = "+nr+
          ", Client = ?, Benutzer = ?, Mitarbeiter = ?, Von = ?");

      statement.setInt(1, client.getNr());
      statement.setInt(2, benutzer.getBenutzerNr());
      statement.setInt(3, mitarbeiter.getMitarbeiterNr());
      statement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));

      statement.execute();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Freigeben des Internets "+
        "f�r den Rechner "+client.getName(), true);
    }
    this.reload();
  }

  /**
   * Bestimmt die gr��te verwendete Nummer.
   * @return die gr��te verwendete Nummer
   */
  public static int getGroessteInternetfreigabenr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from internet_zugang");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Internetfreigabenummer!", true);
    }

    return maxNr;
  }
  
  /**
   * Liefert eine unsortierte Liste aller Internetfreigaben, die im �bergebenen
   * Monat get�tigt wurden.
   * 
   * @param monat die Nr des Monats von 1 bis 12
   * @param jahr das Jahr
   */
  public static InternetfreigabenListe getAlleInternetFreigabenInMonat(int monat, int jahr) {
    Calendar calendar = Calendar.getInstance();
    calendar.set(jahr, monat-1, 1);
    java.util.Date von = calendar.getTime();
    
    calendar.set(jahr, monat, 1);
    calendar.add(Calendar.DATE, -1);
    java.util.Date bis = calendar.getTime();    
    
    return getAlleInternetfreigabenInZeitraum(von, bis);
  }  

  /**
   * Liefert eine unsortierte Liste aller Internetfreigaben, 
   * die zwischen den beiden �bergebenen
   * Zeitpunkten get�tigt wurden.
   * 
   * @param von der Startzeitpunkt
   * @param bis der Entzeitpunkt
   */
  public static InternetfreigabenListe getAlleInternetfreigabenInZeitraum(
    java.util.Date von, java.util.Date bis) {
    InternetfreigabenListe liste = new InternetfreigabenListe();

    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection().prepareStatement(
        "select * from internet_zugang where von >= ? AND von <= ?");
      statement.setDate(1, new java.sql.Date(von.getTime()));
      statement.setDate(2, new java.sql.Date(bis.getTime()));
      ResultSet result = statement.executeQuery();
      while (result.next()) {
        int nr = -1;
        try {
          Benutzer benutzer = null;
          Mitarbeiter mitarbeiter = null;
          Client client = null;
          Timestamp vonTimeStamp = null;
          Timestamp bisTimeStamp = null;
          
          nr = result.getInt("Nr");
          try {
            benutzer = Benutzer.getBenutzer(result.getInt("Benutzer"));
          } catch (DatenNichtGefundenException e) {
            throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
              "Nr. "+nr+" verweist auf einen ung�ltigen Benutzer!");
          }
          try {
            mitarbeiter = Mitarbeiter.getMitarbeiter(result.getInt("Mitarbeiter"));
          } catch (DatenNichtGefundenException e) {
            throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
              "Nr. "+nr+" verweist auf einen ung�ltigen Mitarbeiter!");
          }
          try {
            client = new Client(result.getInt("client"));
          } catch (DatenNichtGefundenException e) {
            throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
              "Nr. "+nr+" verweist auf einen ung�ltigen Client!");
          }
          vonTimeStamp = result.getTimestamp("Von");
          bisTimeStamp = result.getTimestamp("Bis");
    
          Internetfreigabe aktuelleFreigabe = new Internetfreigabe(nr, client, benutzer, mitarbeiter, vonTimeStamp, bisTimeStamp);
          if (aktuelleFreigabe.getDauer() >= 60) {
            liste.add(aktuelleFreigabe);
          }
        } catch (DatenbankInkonsistenzException e) {
          ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Internetfreigabe "+
            "mit der Nummer "+nr+".", false);      
        } catch (SQLException e) {
          ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Internetfreigabe "+
            "mit der Nummer "+nr+".", true);
        }
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Laden der Internetfreigabenliste!", true);
    }

    return liste;
  }

  /**
   * Bestimmt die n�chste freie Benutzernummer.
   * @return die n�chste freie Benutzernummer
   */
  public static int getNeueInternetfreigabenr() {
    return getGroessteInternetfreigabenr()+1;
  }

  /**
   * L�d alle Daten der aktuellen Freigabe erneut aus der Datenbank.
   *
   * @throws DatenNichtGefundenException falls die Freigabe inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException {
    this.load(this.getNr());
  }

  /**
   * L�d alle Daten der Internetfreigabe mit der �bergebenen Nr
   * erneut aus der Datenbank.
   * @param nr die Nummer der Internetfreigabe, die geladen werden soll
   * @throws DatenNichtGefundenException falls die Freigabe mit der �bergebenen
   *   Nummer nicht in der Datenbank existiert
   */
  protected void load(int nr) throws DatenNichtGefundenException {
    try {
      Statement statement = Datenbank.getInstance().getStatement();

      ResultSet result = statement.executeQuery(
        "select * from internet_zugang where nr = "+nr);

      boolean freigabeGefunden = result.next();
      if (!freigabeGefunden) throw new DatenNichtGefundenException("Eine "+
        "Internetfreigabe mit der Nummer "+nr+" existiert nicht!");

      this.nr = result.getInt("Nr");
      try {
        benutzer = Benutzer.getBenutzer(result.getInt("Benutzer"));
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
          "Nr. "+nr+" verweist auf einen ung�ltigen Benutzer!");
      }
      try {
        mitarbeiter = Mitarbeiter.getMitarbeiter(result.getInt("Mitarbeiter"));
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
          "Nr. "+nr+" verweist auf einen ung�ltigen Mitarbeiter!");
      }
      try {
        client = new Client(result.getInt("client"));
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Internetfreigabe "+
          "Nr. "+nr+" verweist auf einen ung�ltigen Client!");
      }
      von = result.getTimestamp("Von");
      bis = result.getTimestamp("Bis");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (DatenbankInkonsistenzException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Internetfreigabe "+
        "mit der Nummer "+nr+".", false);      
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der Internetfreigabe "+
        "mit der Nummer "+nr+".", true);
    }
  }



  public String toString() {
    return "Internetfreigabe f�r "+client.getName();
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Internetfreigabe ").append(getNr()).append("\n");
    ausgabe.append("-------------------------------\n");
    ausgabe.append("Rechner    : ").append(getRechner().getName()).append("\n");
    ausgabe.append("Benutzer   : ").append(getBenutzer().getName()).append("\n");
    ausgabe.append("Mitarbeiter: ").append(getMitarbeiter().getName()).append("\n");
    ausgabe.append("Startzeit  : ").append(dateFormat.format(von)).append("\n");
    ausgabe.append("Stoppzeit  : ").append(dateFormat.format(bis)).append("\n");
    return ausgabe.toString();
  }

  /**
   * Liefert die Dauer in Sekunden die der letzte Internetzugang f�r den
   * Rechner freigeschaltet war. Ist der Zugang noch freigeschaltet, wird die
   * Dauer bis zum aktuellen Zeitpunkt geliefert. War der Rechner noch nie
   * freigeschaltet wird 0 geliefert.
   *
   * @return die Dauer in Sekunden die der letzte Internetzugang f�r den
   *   Rechner freigeschaltet war
   */
  public int getDauer() {
    if (von == null) return 0;

    long freigabeVon = von.getTime();

    long freigabeBis;
    if (bis != null)
      freigabeBis = bis.getTime();
    else
      freigabeBis = System.currentTimeMillis();

    long dauerInMillisekunden = freigabeBis - freigabeVon;
    long dauerInSekunden = dauerInMillisekunden / 1000;

    return (int) dauerInSekunden;
  }
  
  /**
   * Liefert den Zeitpunkt, an dem der Internetzugang freigeschaltet wurde
   * @return den Zeitpunkt, an dem der Internetzugang freigeschaltet wurde
   */
  public Date getStartZeitpunkt() {
    if (von == null) return null;
    return new Date(von.getTime());
  }

  /**
   * Liefert den Zeitpunkt, bis zu dem der Internetzugang freigeschaltet wurde
   * @return den Zeitpunkt, bis zu dem Internetzugang freigeschaltet wurde
   */
  public Date getEndZeitpunkt() {
    if (bis == null) return null;
    return new Date(bis.getTime());
  }

  /**
   * Liefert den Rechner dieser Internetfreigabe.
   * @return den Rechner dieser Internetfreigabe
   */
  public Client getRechner() {
    return client;
  }

  /**
   * Liefert die Nummer diesr Internetfreigabe.
   * @return den Nummer diesr Internetfreigabe
   */
  public int getNr() {
    return nr;
  }

  /**
   * Bestimmt, ob die Freigabe aktuell ist. Eine Freigabe ist aktuell, wenn
   * sie nicht vor mehr als 3 Stunden beendet wurde.
   *
   * @return <code>true</code> gdw. die Freigabe aktuell ist
   */
  public boolean istAktuell() {
    //Freigabe l�uft noch
    if (bis == null) return true;

    long beendetSeitMillisekunden = System.currentTimeMillis() - bis.getTime();
    return (beendetSeitMillisekunden < 1000*60*60*3);
  }

  /**
   * Liefert den Benutzer der Internetfreigabe, d.h. den Benutzer, f�r den der
   * Internetzugang freigeschaltet war bzw. ist.
   * @return den Benutzer der Internetfreigabe
   */
  public Benutzer getBenutzer() {
    return benutzer;
  }

  /**
   * Liefert den Mitarbeiter der Internetfreigabe, d.h. den Mitarbeiter, der
   * die Freigabe t�tigte.
   * @return den Benutzer der Internetfreigabe
   */
  public Mitarbeiter getMitarbeiter() {
    return mitarbeiter;
  }

  /**
   * Bestimmt, ob der Internetzugang f�r den Rechner zu Zeit freigeschaltet ist.
   * @return <code>true</code> gdw. der Internetzugang freigeschaltet ist.
   */
  public boolean istFreigegeben() {
    return (bis == null);
  }

  /**
   * Sperrt den Internetzugang
   */
  public void sperren() {
    if (bis != null)
      throw new IllegalStateException("Der Internetzugang mit der Nummer "+nr+
        " konnte nicht gesperrt werden, da er bereits gesperrt ist!");

    try {
      PreparedStatement statement = Datenbank.getInstance().getConnection()
        .prepareStatement("update internet_zugang set Bis=? "+
          "where nr = "+nr);

      bis = new Timestamp(System.currentTimeMillis());
      statement.setTimestamp(1, bis);

      statement.execute();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Sperren des Internets "+
        "mit der Nummer "+nr+"!", true);
    }
  }
}