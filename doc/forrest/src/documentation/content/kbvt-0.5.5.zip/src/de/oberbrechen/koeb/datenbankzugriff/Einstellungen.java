/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import java.sql.*;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenstrukturen.EinstellungenListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

/**
 * Diese Klasse kapselt Methoden zum Zugriff auf Einstellungen.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.16 $
 */
public class Einstellungen {

	private static Einstellungen instance;

	/**
	 * Liefert eine Instanz einer Einstellung.
	 * @return Einstellung
	 */
	public static Einstellungen getInstance() {
		if (instance == null)
			instance = new Einstellungen();
		return instance;
	}

	public Einstellungen() {
	}

	/**
	 * L�scht alle Einstellungen f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist.
	 * @param client
	 * @param mitarbeiter
	 * @param name
	 * @return Vector
	 */
	protected void removeEinstellungListe(
		Client client,
		Mitarbeiter mitarbeiter,
		String name) {
		//Parameter checken
		if (client != null && !client.istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Clients d�rfen verwendet werden!");
		if (mitarbeiter != null && !mitarbeiter.istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Mitarbeiter d�rfen verwendet werden!");
		if (name == null)
			throw new IllegalArgumentException("Name muss �bergeben werden!");

		try {
			//Statement zusammenbauen
			StringBuffer statementBuffer =
				new StringBuffer("delete from einstellung where ");
			if (client == null) {
				statementBuffer.append("isNull(client)");
			} else {
				statementBuffer.append("client = " + client.getNr());
			}
			statementBuffer.append(" AND ");
			if (mitarbeiter == null) {
				statementBuffer.append("isNull(mitarbeiter)");
			} else {
				statementBuffer.append(
					"mitarbeiter = " + mitarbeiter.getMitarbeiterNr());
			}
			statementBuffer.append(" AND ");
			statementBuffer.append("name = \"" + name + "\"");

			Statement statement = Datenbank.getInstance().getStatement();
			statement.execute(statementBuffer.toString());
			Datenbank.getInstance().releaseStatement(statement);
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Fehler beim L�schen der " + "Einstellungen!",
				true);
		}
	}

	/**
	 * Liefert eine unsortierte Liste aller in der Datenbank gespeicherten
	 * Einstellungen
	 * @return die Einstellungenliste
	 */
	public EinstellungenListe getAlleEinstellungen() {
		EinstellungenListe liste = new EinstellungenListe();
		try {
			PreparedStatement deleteStatement =
				Datenbank.getInstance().getConnection().prepareStatement(
					"delete from einstellung where nr = ?");

			//Statement zusammenbauen
			Statement statement = Datenbank.getInstance().getStatement();
			ResultSet result =
				statement.executeQuery(
					"select nr, client, mitarbeiter, " + "name, wert from einstellung;");

			while (result.next()) {
				Exception zugriffsException = null;

				Client client = null;
				int clientNr = result.getInt("client");
				try {
					if (clientNr > 0)
						client = new Client(clientNr);
				} catch (DatenNichtGefundenException e) {
					zugriffsException =
						new DatenbankInkonsistenzException(
							"Fehler beim Laden der Einstellungenliste. Ein Client mit der Nr. "
								+ clientNr
								+ " existiert nicht.");
				}

				Mitarbeiter mitarbeiter = null;
				int mitarbeiterNr = result.getInt("mitarbeiter");
				try {
					if (mitarbeiterNr > 0)
						mitarbeiter = Mitarbeiter.getMitarbeiter(mitarbeiterNr);
				} catch (DatenNichtGefundenException e) {
					zugriffsException =
						new DatenbankInkonsistenzException(
							"Fehler beim Laden der Einstellungenliste. Ein Mitarbeiter mit der Nr. "
								+ mitarbeiterNr
								+ " existiert nicht.");
				}

				if (zugriffsException != null) {
					ErrorHandler.getInstance().handleException(
						zugriffsException,
						"Datenbankinkonsitenz beim Laden der Einstellungenliste. Die "
							+ "verursachende Einstellung wird gel�scht.",
						false);
					deleteStatement.setInt(1, result.getInt("nr"));
					deleteStatement.execute();
				} else {
					Einstellung neueEinstellung =
						new Einstellung(
							result.getString("name"),
							result.getString("wert"),
							client,
							mitarbeiter);
					liste.add(neueEinstellung);
				}
			}
			Datenbank.getInstance().releaseStatement(statement);
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Fehler beim Laden der " + "Einstellungenliste!",
				false);
			return liste;
		}

		return liste;
	}

	/**
	 * F�gt die Einstellung zur Datenbank hinzu.
	 * @param einstellung die hinzuzuf�gende Einstellung.
	 */
	private void insertEinstellung(Einstellung einstellung) {
		//Parameter checken
		if (einstellung.getClient() != null
			&& !einstellung.getClient().istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Clients d�rfen verwendet werden!");
		if (einstellung.getMitarbeiter() != null
			&& !einstellung.getMitarbeiter().istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Mitarbeiter d�rfen verwendet werden!");
		if (einstellung.getName() == null)
			throw new IllegalArgumentException("Name der Einstellung muss gesetzt sein!");

		try {
			//Statement zusammenbauen
			StringBuffer statementBuffer =
				new StringBuffer("insert into einstellung set ");
			if (einstellung.getClient() != null)
				statementBuffer.append(
					"client = " + einstellung.getClient().getNr() + ", ");
			if (einstellung.getMitarbeiter() != null)
				statementBuffer.append(
					"mitarbeiter = "
						+ einstellung.getMitarbeiter().getMitarbeiterNr()
						+ ", ");
			if (einstellung.getWert() != null)
				statementBuffer.append("wert = \"" + einstellung.getWert() + "\", ");
			statementBuffer.append("name = \"" + einstellung.getName() + "\"");

			Statement statement = Datenbank.getInstance().getStatement();
			statement.execute(statementBuffer.toString());
			Datenbank.getInstance().releaseStatement(statement);
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Fehler beim L�schen der " + "Einstellungen!",
				true);
		}
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * gleich dem �bergebenen Namen ist.
	 * @param client
	 * @param mitarbeiter
	 * @param name
	 * @return Vector
	 */
	private Einstellung getEinstellung(
		Client client,
		Mitarbeiter mitarbeiter,
		String name)
		throws DatenNichtGefundenException {
		//Parameter checken
		if (client != null && !client.istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Clients d�rfen verwendet werden!");
		if (mitarbeiter != null && !mitarbeiter.istGespeichert())
			throw new IllegalArgumentException("Nur gespeicherte Mitarbeiter d�rfen verwendet werden!");
		if (name == null)
			throw new IllegalArgumentException("Name muss �bergeben werden!");

		Einstellung neueEinstellung = null;
		try {
			//Statement zusammenbauen
			StringBuffer statementBuffer =
				new StringBuffer("select * from einstellung where ");
			if (client == null) {
				statementBuffer.append("isNull(client)");
			} else {
				statementBuffer.append("client = " + client.getNr());
			}
			statementBuffer.append(" AND ");
			if (mitarbeiter == null) {
				statementBuffer.append("isNull(mitarbeiter)");
			} else {
				statementBuffer.append(
					"mitarbeiter = " + mitarbeiter.getMitarbeiterNr());
			}
			statementBuffer.append(" AND ");
			statementBuffer.append("name = \"" + name + "\"");

			Statement statement = Datenbank.getInstance().getStatement();
			ResultSet result = statement.executeQuery(statementBuffer.toString());
			boolean einstellungGefunden = result.next();

			if (!einstellungGefunden)
				throw new DatenNichtGefundenException(
					"Fehler beim Laden der Einstellung "
						+ convertToDescription(client, mitarbeiter, null, name));

			neueEinstellung =
				new Einstellung(
					result.getString("name"),
					result.getString("wert"),
					client,
					mitarbeiter);

			if (result.next())
				throw new DatenNichtGefundenException(
					"Fehler beim Laden der Einstellung "
						+ convertToDescription(client, mitarbeiter, null, name));

			Datenbank.getInstance().releaseStatement(statement);
		} catch (SQLException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Fehler beim Laden der " + "Einstellungen!",
				true);
		}
		return neueEinstellung;
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, wird eine DatenNichtGefundenException
	 * geworfen. 
	 */
	public String getEinstellungString(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name)
		throws DatenNichtGefundenException {
		String nameVollstaendig = name;
		if (namespace != null)
			nameVollstaendig = namespace + "." + nameVollstaendig;
		return getEinstellung(client, mitarbeiter, nameVollstaendig).getWert();
	}

	private String convertToDescription(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Client:      ");
		if (client != null) {
			buffer.append(client.toString());
		} else {
			buffer.append("-");
		}
		buffer.append("\nMitarbeiter: ");
		if (mitarbeiter != null) {
			buffer.append(mitarbeiter.toString());
		} else {
			buffer.append("-");
		}
		buffer.append("\nNamespace:   ");
		if (namespace != null) {
			buffer.append(namespace);
		} else {
			buffer.append("-");
		}
		buffer.append("\nName:        ");
		if (name != null) {
			buffer.append(name);
		} else {
			buffer.append("-");
		}

		return buffer.toString();
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, so wird der standard-Wert
	 * zur�ckgeliefert und diese in die Datenbank geschrieben. Achtung: 
	 * dabei werden, falls vorher mehrere passende Einstellungen gefunden wurden,
	 * diese alle �berschrieben.
	 */
	public String getEinstellungString(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		String standard) {
		try {
			return getEinstellungString(client, mitarbeiter, namespace, name);
		} catch (DatenNichtGefundenException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert '"
					+ standard
					+ "' wird gesetzt!",
				false);
			setEinstellungString(client, mitarbeiter, namespace, name, standard);
		}
		return standard;
	}

	/**
	 * Setzt die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. 
	 * @param wert der neue Wert der Einstellung
	 */
	public void setEinstellungString(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		String wert) {
		String nameVollstaendig = name;
		if (namespace != null)
			nameVollstaendig = namespace + "." + nameVollstaendig;
		removeEinstellungListe(client, mitarbeiter, nameVollstaendig);
		Einstellung neueEinstellung =
			new Einstellung(nameVollstaendig, wert, client, mitarbeiter);
		insertEinstellung(neueEinstellung);
	}

	/// Integer

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, wird eine DatenNichtGefundenException
	 * geworfen. 
	 */
	public int getEinstellungInt(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name)
		throws DatenNichtGefundenException, UnpassendeEinstellungException {
		String intString =
			getEinstellungString(client, mitarbeiter, namespace, name);
		try {
			return Integer.parseInt(intString);
		} catch (NumberFormatException e) {
			throw new UnpassendeEinstellungException(
				"Der Wert '"
					+ intString
					+ "' kann nicht als Zahl interpretiert werden!");
		}
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als Integer. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, so wird der standard-Wert
	 * zur�ckgeliefert und diese in die Datenbank geschrieben. Achtung: 
	 * dabei werden, falls vorher mehrere passende Einstellungen gefunden wurden,
	 * diese alle �berschrieben.
	 */
	public int getEinstellungInt(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		int standard) {
		try {
			return getEinstellungInt(client, mitarbeiter, namespace, name);
		} catch (DatenNichtGefundenException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungInt(client, mitarbeiter, namespace, name, standard);
		} catch (UnpassendeEinstellungException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungInt(client, mitarbeiter, namespace, name, standard);
		}
		return standard;
	}

	/**
	 * Setzt die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. 
	 * @param wert der neue Wert der Einstellung
	 */
	public void setEinstellungInt(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		int wert) {
		setEinstellungString(
			client,
			mitarbeiter,
			namespace,
			name,
			Integer.toString(wert));
	}

	/// Double

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, wird eine DatenNichtGefundenException
	 * geworfen. 
	 */
	public double getEinstellungDouble(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name)
		throws DatenNichtGefundenException, UnpassendeEinstellungException {
		String doubleString =
			getEinstellungString(client, mitarbeiter, namespace, name);
		try {
			return Double.parseDouble(doubleString);
		} catch (NumberFormatException e) {
			throw new UnpassendeEinstellungException(
				"Der Wert '"
					+ doubleString
					+ "' kann nicht als Zahl interpretiert werden!");
		}
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als Integer. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, so wird der standard-Wert
	 * zur�ckgeliefert und diese in die Datenbank geschrieben. Achtung: 
	 * dabei werden, falls vorher mehrere passende Einstellungen gefunden wurden,
	 * diese alle �berschrieben.
	 */
	public double getEinstellungDouble(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		double standard) {
		try {
			return getEinstellungDouble(client, mitarbeiter, namespace, name);
		} catch (DatenNichtGefundenException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungDouble(client, mitarbeiter, namespace, name, standard);
		} catch (UnpassendeEinstellungException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungDouble(client, mitarbeiter, namespace, name, standard);
		}
		return standard;
	}

	/**
	 * Setzt die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist. 
	 * @param wert der neue Wert der Einstellung
	 */
	public void setEinstellungDouble(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		double wert) {
		setEinstellungString(
			client,
			mitarbeiter,
			namespace,
			name,
			Double.toString(wert));
	}

	//Boolean

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als String. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, wird eine DatenNichtGefundenException
	 * geworfen. 
	 */
	public boolean getEinstellungBoolean(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name)
		throws DatenNichtGefundenException, UnpassendeEinstellungException {
		String booleanString =
			getEinstellungString(client, mitarbeiter, namespace, name);
		if (booleanString.equalsIgnoreCase("true"))
			return true;
		if (booleanString.equalsIgnoreCase("false"))
			return false;

		throw new UnpassendeEinstellungException(
			"Der Wert '"
				+ booleanString
				+ "' kann nicht als boolscher Wert interpretiert werden!");
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist als Integer. Wird mehr als eine
	 * oder keine passende Einstellung gefunden, so wird der standard-Wert
	 * zur�ckgeliefert und diese in die Datenbank geschrieben. Achtung: 
	 * dabei werden, falls vorher mehrere passende Einstellungen gefunden wurden,
	 * diese alle �berschrieben.
	 */
	public boolean getEinstellungBoolean(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		boolean standard) {
		try {
			return getEinstellungBoolean(client, mitarbeiter, namespace, name);
		} catch (DatenNichtGefundenException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungBoolean(client, mitarbeiter, namespace, name, standard);
		} catch (UnpassendeEinstellungException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Standardwert "
					+ standard
					+ " wird gesetzt!",
				false);
			setEinstellungBoolean(client, mitarbeiter, namespace, name, standard);
		}
		return standard;
	}

	/**
	 * Setzt die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * �hnlich (LIKE) dem �bergebenen Namen ist. 
	 * @param wert der neue Wert der Einstellung
	 */
	public void setEinstellungBoolean(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		boolean wert) {
		String wertString;
		if (wert)
			wertString = "TRUE";
		else
			wertString = "FALSE";
		setEinstellungString(client, mitarbeiter, namespace, name, wertString);
	}

	//Boolean

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * gleich dem �bergebenen Namen ist. Der dort gespeicherte Wert wird
	 * als Klassenname interpretiert und versucht mit einem parameterlosen Konstruktor 
	 * eine Instanz zu erzeugen. Diese wird zur�ckgeliefert.
	 */
	public Object getEinstellungObject(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		Class typ)
		throws DatenNichtGefundenException, UnpassendeEinstellungException {
		String className =
			getEinstellungString(client, mitarbeiter, namespace, name);

		Object retVal = getInstanz(className);
		if (retVal == null || !typ.isInstance(retVal)) {
			throw new UnpassendeEinstellungException(
				"Der Wert '"
					+ className
					+ "' kann nicht als Klassenname "
					+ "einer Klasse mit paraterlosem Konstruktor vom Typ "
					+ typ.getName()
					+ " interpretiert werden!");
		}

		return retVal;
	}

	private Object getInstanz(String className) {
		Object retVal = null;
		try {
			retVal = Class.forName(className).newInstance();
		} catch (ClassNotFoundException cnfe) {
		} catch (InstantiationException ie) {
		} catch (IllegalAccessException iae) {
		}

		return retVal;
	}

	/**
	 * Liefert die Einstellung f�r den
	 * �bergebenen Client und Mitarbeiter, deren Name
	 * gleich dem �bergebenen Namen ist. Der dort gespeicherte Wert wird
	 * als Klassenname interpretiert und versucht mit einem parameterlosen Konstruktor 
	 * eine Instanz zu erzeugen. Diese wird zur�ckgeliefert. Bei Fehlern wird stattdessen
	 * standard als Klassenname verwendet.
	 */
	public Object getEinstellungObject(
		Client client,
		Mitarbeiter mitarbeiter,
		String namespace,
		String name,
		Class typ,
		String standard) {
		try {
			return getEinstellungObject(client, mitarbeiter, namespace, name, typ);
		} catch (DatenNichtGefundenException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Es wird versucht, den Standardwert '"
					+ standard
					+ "' zu setzen!",
				false);
			setEinstellungString(client, mitarbeiter, namespace, name, standard);
			Object retVal = getInstanz(standard);
			if (retVal == null) {
				ErrorHandler.getInstance().handleException(
					e,
					"Probleme beim Laden der Einstellung\n"
						+ convertToDescription(client, mitarbeiter, namespace, name)
						+ "\n\n"
						+ "Auch der Standardwert '"
						+ standard
						+ "' kann nicht als Klassenname "
						+ "einer Klasse mit paraterlosem Konstruktor interpretiert werden!!",
					true);
			}
			return retVal;
		} catch (UnpassendeEinstellungException e) {
			ErrorHandler.getInstance().handleException(
				e,
				"Probleme beim Laden der Einstellung\n"
					+ convertToDescription(client, mitarbeiter, namespace, name)
					+ "\n\n"
					+ "Es wird versucht, den Standardwert '"
					+ standard
					+ "' zu setzen!",
				false);
			setEinstellungString(client, mitarbeiter, namespace, name, standard);
			Object retVal = getInstanz(standard);
			if (retVal == null) {
				ErrorHandler.getInstance().handleException(
					e,
					"Probleme beim Laden der Einstellung\n"
						+ convertToDescription(client, mitarbeiter, namespace, name)
						+ "\n\n"
						+ "Auch der Standardwert '"
						+ standard
						+ "' kann nicht als Klassenname "
						+ "einer Klasse mit paraterlosem Konstruktor interpretiert werden!!",
					true);
			}
			return retVal;
		}
	}
}