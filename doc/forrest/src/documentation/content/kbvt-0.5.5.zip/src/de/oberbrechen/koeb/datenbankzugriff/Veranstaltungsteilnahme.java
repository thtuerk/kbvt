/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;

/**
 * Diese Klasse repr�sentiert die Teilnahme eines Benutzers an einer
 * Veranstaltung der B�cherei.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
*/

public class Veranstaltungsteilnahme {

  // Die Attribute der Teilnahme
  private Benutzer benutzer;
  private Veranstaltung veranstaltung;
  private int nr, anmeldenr;
  private String bemerkungen;

  private boolean isSaved;
  /**
   * Erstellt ein neues Veranstaltungsteilnahme-Objekt und speichert es in der
   * Datenbank.
   * @param nr die Nummer der Veranstaltungsteilnahme, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  public Veranstaltungsteilnahme(Benutzer benutzer,
    Veranstaltung veranstaltung) throws BenutzerBereitsAngemeldetException, DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.benutzer = benutzer;
    this.veranstaltung = veranstaltung;
    this.bemerkungen = null;

    this.nr = 0;
    this.anmeldenr = 0;
    isSaved = false;
    this.save();
  }

  /**
   * L�d das zur �bergebenen Nummer geh�rende
   * <code>Veranstaltungsteilnahme</code>-Objekt aus der Datenbank.
   * @param nr die Nummer der Veranstaltungsteilnahme, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  public Veranstaltungsteilnahme(int nr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.load(nr);
  }

  /**
   * L�d das zur �bergebenen Nummer geh�rende
   * <code>Veranstaltungsteilnahme</code>-Objekt aus der Datenbank.
   * @param nr die Nummer der Veranstaltungsteilnahme, die geladen
   *   werden soll
   * @throws DatenNichtGefundenException falls die �bergebene
   *   Veranstaltung nicht in der Datenbank existiert
   */
  protected void load(int nr) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from benutzer_besucht_veranstaltung where nr = \"" +nr+"\"");
      boolean teilnahmeGefunden = result.next();
      if (!teilnahmeGefunden) throw new DatenNichtGefundenException(
        "Eine Veranstaltungsteilnahme mit der Nummer "+nr+
        " existiert nicht!");

      this.nr = nr;
      anmeldenr = result.getInt("anmeldenr");
      bemerkungen = result.getString("bemerkungen");

      int veranstaltungsNr = result.getInt("VeranstaltungsNr");
      try {
        veranstaltung = Veranstaltung.getVeranstaltung(
          veranstaltungsNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Veranstaltungsteilnahme "+
          "mit der Nummer "+veranstaltungsNr+" verweist auf die unbekannte "+
          "Veranstaltung mit der Nummer "+veranstaltungsNr+"!");
      }

      int benutzerNr = result.getInt("benutzerNr");
      try {
        benutzer = Benutzer.getBenutzer(benutzerNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Die Veranstaltungsteilnahme "+
          "mit der Nummer "+veranstaltungsNr+" verweist auf einen unbekannten "+
          "Benutzer mit der Nummer "+benutzerNr+"!");
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden der "+
        "Veranstaltungsteilnahme mit der Nummer "+nr+"!", true);
    }
    isSaved = true;
  }

  /**
   * Sucht die Veranstaltungsteilnahme, die den �bergebenen Benutzers f�r die
   * �bergebene Veranstaltung anmeldet.
   *
   * @param benutzer der zu �berpr�fende Benutzer
   * @param veranstaltung die zu �berpr�fende Veranstaltung
   * @return die Veranstaltungsteilnahme, die den �bergebenen Benutzers f�r die
   * �bergebene Veranstaltung anmeldet, oder <code>null</code> falls keine
   * solche existiert
   */
  public static Veranstaltungsteilnahme getVeranstaltungsteilnahme(
    Benutzer benutzer, Veranstaltung veranstaltung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    int nr = 0;
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from benutzer_besucht_veranstaltung where "+
        "veranstaltungsnr="+veranstaltung.getVeranstaltungsNr()+" AND "+
        "benutzernr="+benutzer.getBenutzerNr());
      boolean teilnahmeGefunden =  result.next();
      if (!teilnahmeGefunden) return null;

      nr = result.getInt(1);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, 
        "Fehler beim Bestimmen der Teilnahme "+
        "des Benutzers "+benutzer.getName()+ " an der Veranstaltung "+
        veranstaltung.getTitel()+"!", true);
    }

    return new Veranstaltungsteilnahme(nr);
  }

  /**
   * Bestimmt, ob der �bergebene Benutzer f�r der �bergebene Veranstaltung
   * angemeldet ist.
   *
   * @param benutzer der zu �berpr�fende Benutzer
   * @param veranstaltung die zu �berpr�fende Veranstaltung
   * @return <code>true</code> gdw der �bergebene Benutzer f�r der �bergebene Veranstaltung
   * angemeldet ist
   */
  public static boolean istAngemeldet(
    Benutzer benutzer, Veranstaltung veranstaltung) throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    return getVeranstaltungsteilnahme(benutzer, veranstaltung) != null;
  }

  /**
   * Liefert ein Array, in dem eingetragen ist, ob die �bergebenen Benutzer
   * an den �bergebenen Veranstaltungen teilnehmen. Der erste Array-Index
   * gibt die Veranstaltung, der zweite den Benutzer an.
   *
   * @param veranstaltungen die zu pr�fenden Veranstaltungen
   * @param benutzer die zu pr�fenden Benutzer
   * @return das Array
   */
  public static boolean[][] getTeilnahmeArray(Veranstaltung[] veranstaltungen,
    Benutzer[] benutzer) {

    boolean[][] erg = new boolean[veranstaltungen.length][benutzer.length];

    if (veranstaltungen == null || veranstaltungen.length == 0 ||
        benutzer == null || benutzer.length == 0) return erg;

    String veranstaltungenString = "";
    for (int i=0; i < veranstaltungen.length-1; i++)
      veranstaltungenString += veranstaltungen[i].getVeranstaltungsNr()+", ";
    veranstaltungenString += veranstaltungen[veranstaltungen.length-1]
                           .getVeranstaltungsNr();

    String benutzerString = "";
    for (int i=0; i < benutzer.length-1; i++)
      benutzerString += benutzer[i].getBenutzerNr()+", ";
    benutzerString += benutzer[benutzer.length-1].getBenutzerNr();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select benutzerNr, veranstaltungsNr from benutzer_besucht_veranstaltung "+
        "where veranstaltungsnr IN ("+veranstaltungenString+") AND "+
        "benutzernr IN ("+benutzerString+")");
      while (result.next()) {
        int benutzerNr = result.getInt(1);
        int benutzerIndex = 0;
        while (benutzer[benutzerIndex].getBenutzerNr() != benutzerNr)
          benutzerIndex++;

        int veranstaltungsNr = result.getInt(2);
        int veranstaltungsIndex = 0;
        while (veranstaltungen[veranstaltungsIndex].getVeranstaltungsNr() !=
          veranstaltungsNr) veranstaltungsIndex++;

        erg[veranstaltungsIndex][benutzerIndex] = true;
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen des "+
        "Teilnahmenarrays.", true);
    }

    return erg;
  }

  /**
   * Speichert die Veranstaltungsteilnahme bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws BenutzerBereitsAngemeldetException falls der Benutzer nicht f�r die
   *   Veranstaltung angemeldet werden kann, da er bereits daf�r angemeldet ist
   */
  public void save() throws BenutzerBereitsAngemeldetException, DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (isSaved) return;

    Veranstaltungsteilnahme konfliktTeilnahme =
      getVeranstaltungsteilnahme(this.getBenutzer(), this.getVeranstaltung());
    if (konfliktTeilnahme != null && !konfliktTeilnahme.equals(this)){
      throw new BenutzerBereitsAngemeldetException(konfliktTeilnahme);
    }

    try {
      PreparedStatement statement = null;

      if (nr == 0) {
        nr = getNeueNr();
        anmeldenr = getNeueAnmeldenr(this.getVeranstaltung());
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "insert into benutzer_besucht_veranstaltung set "+
          "Nr = ?, Benutzernr = ?, Veranstaltungsnr = ?, Anmeldenr = ?, "+
          "Bemerkungen = ?");
      } else {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "update benutzer_besucht_veranstaltung set "+
          "Nr = ?, Benutzernr = ?, Veranstaltungsnr = ?, Anmeldenr = ?, "+
          "Bemerkungen = ? " +
          "where Nr="+nr);
      }
      statement.setInt(1,this.getNr());
      statement.setInt(2, this.getBenutzer().getBenutzerNr());
      statement.setInt(3, this.getVeranstaltung().getVeranstaltungsNr());
      statement.setInt(4, this.getAnmeldeNr());
      statement.setString(5, this.getBemerkungen());

      statement.execute();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern der folgenden "+
        "Veranstaltungsteilnahme:\n\n"+this.toDebugString(), true);
    }

    isSaved = true;
    this.getVeranstaltung().berechneTeilnehmerAnzahl();
  }

  public boolean equals(Object o) {
    if (!(o instanceof Veranstaltungsteilnahme)) return false;
    return ((Veranstaltungsteilnahme) o).getNr() == this.getNr();
  }

  /**
   * L�d alle Daten der Veranstaltungteilnahme erneut aus der Datenbank.
   *
   * @throws DatenNichtGefundenException falls die Teilnahme inzwischen aus der
   *   Datenbank entfernt wurde
   */
  public void reload() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.load(this.getNr());
  }

  /**
   * Bestimmt die naechste freie Veranstaltungsfreigabenummer.
   * @return die naechste freie Veranstaltungsfreigabenummer
   */
  public static int getNeueNr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(nr) from benutzer_besucht_veranstaltung");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Veranstaltungsteilnahmenummer!", true);
    }

    return maxNr+1;
  }

  /**
   * Bestimmt die naechste freie Anmeldenummer f�r die �bergebene Veranstaltung.
   *
   * @param veranstaltung die Veranstaltung, f�r die die Anmeldenummer gesucht
   *   werden soll
   * @return die naechste freie Anmeldenummer f�r die �bergebene Veranstaltung
   */
  public static int getNeueAnmeldenr(Veranstaltung veranstaltung) {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(anmeldenr) from benutzer_besucht_veranstaltung "+
        "where veranstaltungsnr="+veranstaltung.getVeranstaltungsNr());
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Anmeldenummer f�r die Veranstaltung "+
        veranstaltung.getTitel()+"!", true);
    }

    return maxNr+1;
  }

  /**
   * L�scht die Veranstaltungsteilnahme aus der Datenbank.
   */
  public void loesche() {
    try {
      Statement statement = Datenbank.getInstance().getStatement();

      // Benutzer l�schen
      statement.execute("delete from benutzer_besucht_veranstaltung where "+
        "nr=\""+this.getNr()+"\"");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen der folgenden "+
        "Veranstaltungsteilnahme:\n\n"+this.toDebugString(), true);
    }
    this.getVeranstaltung().teilnehmerAnzahl--;
  }

  /**
   * Liefert den Benutzer der an der Veranstaltung teilnimmt
   * @return den Benutzer der an der Veranstaltung teilnimmt
   */
  public Benutzer getBenutzer() {
    return benutzer;
  }

  /**
   * Liefert die Veranstaltung, an der der Benutzer teilnimmt
   * @return die Veranstaltung, an der der Benutzer teilnimmt
   */
  public Veranstaltung getVeranstaltung() {
    return veranstaltung;
  }

  /**
   * Liefert die Nummer der Veranstaltungsteilnahme
   * @return die Nummer der Veranstaltungsteilnahme
   */
  public int getNr() {
    return nr;
  }

  /**
   * Liefert die Anmeldenummer des Benutzers f�r die Veranstaltung
   * @return die Anmeldenummer des Benutzers f�r die Veranstaltung
   */
  public int getAnmeldeNr() {
    return anmeldenr;
  }

  /**
   * Liefert die Bemerkungen zur Teilnahme des Benutzers an der Veranstaltung
   * @return die Bemerkungen zur Teilnahme des Benutzers an der Veranstaltung
   */
  public String getBemerkungen() {
    return bemerkungen;
  }

  /**
   * Setzt die Bemerkungen zur Teilnahme des Benutzers an der Veranstaltung
   * @param bemerkungen die neuem Bemerkungen
   */
  public void setBemerkungen(String bemerkungen) {
    isSaved = false;
    this.bemerkungen = bemerkungen;
  }

  public String toString() {
    return benutzer.getName()+" nimmt an der Veranstaltung "+
      veranstaltung.getTitel()+" teil!";
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    return this.toString();
  }
}