/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.datenbankzugriff;

import de.oberbrechen.koeb.datenbankzugriff.exceptions.*;
import de.oberbrechen.koeb.datenbankzugriff.exceptions.BenutzerSchonMitarbeiterException;
import de.oberbrechen.koeb.datenstrukturen.BenutzerListe;
import de.oberbrechen.koeb.framework.ErrorHandler;

import java.sql.*;
import java.util.Hashtable;

/**
* Diese Klasse repr�sentiert einen Mitarbeiter der B�cherei. Es stellt die
* Verbindung zur Datenbank her und Methoden, um einen Mitarbeiter
* zu manipulieren. Ein Mitarbeiter ist dabei ein Benutzer mit speziellen
* Eigenschaften. Dies �u�ert sich darin, dass die Klasse Mitarbeiter von
* Benutzer erbt.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.15 $
*/

public class Mitarbeiter extends Benutzer {

  public static final int BERECHTIGUNG_STANDARD = 0;
  public static final int BERECHTIGUNG_VERANSTALTUNGSTEILNAHME_EINGABE = 1;
  public static final int BERECHTIGUNG_BESTAND_EINGABE = 2;
  public static final int BERECHTIGUNG_ADMIN = 4;

  private int mitarbeiterNr;
  private String mitarbeiterBenutzername, mitarbeiterPasswort;
  private int berechtigungen;
  private boolean istMitarbeiterGespeichert;

  private static Mitarbeiter aktuellerMitarbeiter = null;
  // Statische Speicherung der Mitarbeiter
  private static Hashtable cache = new Hashtable();


  /**
   * Liefert den aktuell angemeldeten Mitarbeiter.
   * @return den Standardmitarbeiter
   * @see setAktuellenMitarbeiter
   */
  public static Mitarbeiter getAktuellenMitarbeiter() {
    return aktuellerMitarbeiter;
  }

  /**
   * Setzt den aktuellen Mitarbeiter. Bei einigen Datenbankoperation wie dem
   * t�tigen einer Ausleihe wird ein Mitarbeiter ben�tigt. Wird dort nicht
   * explizit ein Mitarbeiter angegeben, wird der hier gesetzte Mitarbeiter
   * verwendet. Vor dem ersten Setzten des aktuellen Mitarbeiters wird
   * der aktuelle Mitarbeiter mit <code>null</code> initialisiert.
   *
   * @param mitarbeiter der als aktueller Mitarbeiter gesetzt werden soll
   */
  public static void setAktuellenMitarbeiter(Mitarbeiter mitarbeiter) {
    aktuellerMitarbeiter = mitarbeiter;
  }

  /**
   * Liefert das zur �bergebenen Mitarbeiter passende Mitarbeiter-Objekt, das
   * entweder aus dem Cache geholt oder neu erzeugt wird. F�r jeden Mitarbeiter
   * existiert nur ein Objekt.
   *
   * @param mitarbeiterNr die Mitarbeiternummer, die geladen werden soll
   * @throws DatenNichtGefundenException falls die �bergebene Mitarbeiternummer
   *  nicht in der Datenbank existiert
   */
  public static Mitarbeiter getMitarbeiter(int mitarbeiterNr) 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {

    Integer mitarbeiterNrWrapper = new Integer(mitarbeiterNr);
    Mitarbeiter erg = (Mitarbeiter) cache.get(mitarbeiterNrWrapper);
    if (erg == null) {
      erg = new Mitarbeiter(mitarbeiterNr);
      cache.put(mitarbeiterNrWrapper, erg);
    }
    return erg;
  }

  /**
   * Liefert eine Liste aller Mitarbeiter, die in der Datenbank
   * eingetragen sind
   */
  public static BenutzerListe getAlleMitarbeiter() 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    cache.clear();
    BenutzerListe liste = new BenutzerListe();

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from mitarbeiter;");
      while (result.next()) {

        Mitarbeiter neuMitarbeiter =
          new Mitarbeiter(result.getInt("nr"));
        cache.put(new Integer(neuMitarbeiter.getMitarbeiterNr()),
          neuMitarbeiter);
        liste.add(neuMitarbeiter);
      }
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e,
        "Fehler beim Laden der Mitarbeiterliste!", true);
    }

    return liste;
  }

  /**
   * Erstellt ein neues <code>Mitarbeiter</code>-Objekt. Dazu wird der
   * Mitarbeiter mit der �bergebenen Benutzernummer aus der Datenbank geladen.
   * Existiert die Mitarbeiternummer nicht in der Datenbank, so wird eine
   * <code>DatenNichtGefundenException</code> geworfen.
   *
   * @param mitarbeiterNr die Mitarbeiternummer, deren zugeh�rige Daten geladen
   *   werden sollen
   * @throws DatenNichtGefundenException falls die Mitarbeiternr nicht in der
   *   Datenbank vorhanden ist
   */
  public Mitarbeiter(int mitarbeiterNr) 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this.load(mitarbeiterNr);
  }

  /**
   * Erstellt einen neuen, bisher noch nicht in der Datenbank vorhandenen
   * Mitarbeiter.
   */
  public Mitarbeiter() {
    super();
    istMitarbeiterGespeichert = false;
    mitarbeiterNr = 0;
    mitarbeiterPasswort = null;
    mitarbeiterBenutzername = null;
  }

  /**
   * Erstellt einen neuen, bisher noch nicht in der Datenbank vorhandenen
   * Mitarbeiter aus dem �bergebenen Benutzer.
   *
   * @param benutzer Benutzer, der zu einem Mitarbeiter gemacht werden soll
   */
  public Mitarbeiter(Benutzer benutzer) 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    this();
    this.setBenutzerNr(benutzer.getBenutzerNr());
  }

  /**
   * �berpr�ft, ob der Mitarbeiter-Benutzername schon von einem anderen
   * Mitarbeiter verwendet wird.
   * @return <code>TRUE</code> gdw der Mitarbeiter-Benutzername schon von
   *  einem anderen Mitarbeiter verwendet wird
   */
  public boolean istMitarbeiterBenutzernameSchonVergeben() {
    if (this.getMitarbeiterBenutzername() == null)
      return false;
    try {
      int zugehoerigeMitarbeiternr =
        Mitarbeiter.sucheMitarbeiterBenutzername(getMitarbeiterBenutzername());
      return (zugehoerigeMitarbeiternr != this.getMitarbeiterNr());
    } catch (DatenNichtGefundenException e) {
      return false;
    }
  }

  /**
   * �berpr�ft, ob der Benutzer, dem der Mitarbeiter entspricht,
   * schon unter einer anderen Mitarbeiternummer als
   * Mitarbeiter eingetragen ist.
   * @return <code>TRUE</code> gdw der Benutzer schon als Mitarbeiter
   *   eingetragen ist
   */
  public boolean istBenutzerSchonMitarbeiter() {
    try {
      int zugehoerigeMitarbeiternr =
        Mitarbeiter.sucheBenutzerNr(getBenutzerNr());
      return (zugehoerigeMitarbeiternr != this.getMitarbeiterNr());
    } catch (DatenNichtGefundenException e) {
      return false;
    }
  }

  /**
   * Bestimmt die Mitarbeiternr, die zu der �bergebenen
   * Benutzernummer geh�rt.
   *
   * @param benutzernr die Benutzernummer
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit dieser Benutzernummer existiert
   * @return die zugeh�rige Mitarbeiternr
   */
  public static int sucheBenutzerNr(int benutzernr) throws DatenNichtGefundenException {
    int erg = 0;
    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select nr from mitarbeiter where "+
        "benutzernr=\""+benutzernr+"\"");

      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit der Benutzernummer '"+benutzernr+"' existiert "+
        "nicht.");

      erg = result.getInt(1);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des Mitarbeiters mit"+
        " der Benutzernummer '"+benutzernr+"'!", true);
    }

    return erg;
  }

  /**
   * Bestimmt die Mitarbeiternr, die zu dem �bergebenen
   * Mitarbeiter-Benutzernamen geh�rt.
   *
   * @param benutzername der Mitarbeiter-Benutzername
   * @throws DatenNichtGefundenException falls kein
   *   Mitarbeiter mit diesem Mitarbeiter-Benutzernamen existiert
   * @return die zugeh�rige Mitarbeiter
   */
  public static int sucheMitarbeiterBenutzername(String benutzername) 
    throws DatenNichtGefundenException {
    int erg = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select Nr from mitarbeiter where "+
        "Benutzername=\""+benutzername+"\"");

      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit dem Benutzernamen '"+benutzername+"' existiert "+
        "nicht.");

      erg = result.getInt(1);
      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Suchen des Mitarbeiters mit "+
        "dem Benutzernamen '"+benutzername+"'!", true);
    }

    return erg;
  }

  /**
   * L�d alle Daten des Mitarbeiters erneut aus der Datenbank. Ist der
   * Mitarbeiter noch nicht gespeichert, wird keine Aktion ausgef�hrt.
   *
   * @throws DatenNichtGefundenException falls der Benutzer inzwischen aus der
   *   Datenbank entfernt wurde
   * @throws DatenbankInkonsistenzException falls der zugeordnete Benutzer nicht
   *  existiert
   */
  public void reload() throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    if (this.istNeu()) return;
    this.load(this.getMitarbeiterNr());
  }

  /**
   * L�d die Daten zu der �bergebenen Mitarbeiternummer aus der Datenbank.
   *
   * @param benutzerNr die Mitarbeiternummer, deren zugeh�rige Daten geladen werden
   *   sollen
   * @throws DatenNichtGefundenException falls die Mitarbeiternr nicht in der
   *   Datenbank vorhanden ist
   * @throws DatenbankInkonsistenzException falls der zugeordnete Benutzer nicht
   *  existiert
   */
  protected void load(int mitarbeiterNr) 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    try {
      istMitarbeiterGespeichert = true;
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select * from mitarbeiter where nr = " + mitarbeiterNr);
      boolean mitarbeiterGefunden = result.next();
      if (!mitarbeiterGefunden) throw new DatenNichtGefundenException(
        "Ein Mitarbeiter mit der Nr "+mitarbeiterNr+" existiert nicht!");

      this.mitarbeiterNr = mitarbeiterNr;
      mitarbeiterBenutzername = result.getString("benutzername");
      mitarbeiterPasswort = result.getString("Passwort");
      berechtigungen = result.getInt("Berechtigungen");

      int benutzerNr = result.getInt("Benutzernr");
      try {
        super.load(benutzerNr);
      } catch (DatenNichtGefundenException e) {
        throw new DatenbankInkonsistenzException("Der Mitarbeiter mit der "+
          "Nummer "+mitarbeiterNr+" verweist auf die nicht existierende "+
          "Benutzernummer "+benutzerNr+"!");
      }

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Laden "+
        "des Mitarbeiters mit der Nummer "+mitarbeiterNr, true);
    }
  }

  /**
   * Liefert die Nummer des Mitarbeiters, 0 steht dabei f�r eine noch nicht
   * zugewiesene Nummer
   * @return Nummer des Mitarbeiters
   */
  public int getMitarbeiterNr() {
    return mitarbeiterNr;
  }

  /**
   * Setzt den Mitarbeiterbenutzernamen des Benutzers f�r die elektronische
   * Anmeldung
   * @param benutzername Mitarbeiterbenutzername des Benutzers
   */
  public void setMitarbeiterBenutzername(String benutzername) {
    istMitarbeiterGespeichert = false;
    mitarbeiterBenutzername = Datenbank.entferneNullString(benutzername);
  }

  /**
   * Setzt das Mitarbeiter-Passwort des Mitarbeiters f�r die elektronische
   * Anmeldung. Beachten
   * Sie bitte, dass nicht das Passwort selbst, sondern die zugeh�rige
   * Pr�fziffer nach dem MD5-Algorithmus gespeichert wird.
   * @param Passwort Passwort des Benutzers
   * @see #checkMitarbeiterPasswort
   */
  public void setMitarbeiterPasswort(String passwort) {
    istMitarbeiterGespeichert = false;
    mitarbeiterPasswort = berechnePruefziffer(passwort);
  }

  /**
   * Liefert den Mitarbeiterbenutzernamen des Mitarbeiters f�r die
   * elektronische Anmeldung
   * @return Mitarbeiterbenutzername des Benutzers
   */
  public String getMitarbeiterBenutzername() {
    return mitarbeiterBenutzername;
  }

  /**
   * �berpr�ft, ob das �bergebene Passwort dem Mitarbeiter-Passwort des
   * Mitarbeiters entspricht
   * @param passwort das zu testende Passwort
   * @return <code>TRUE</code> gdw das Passwort g�ltig ist
   */
  public boolean checkMitarbeiterPasswort(String passwort) {
    if (mitarbeiterPasswort == null)
      return (Datenbank.entferneNullString(passwort) == null);
    return mitarbeiterPasswort.equals(berechnePruefziffer(passwort));
  }

  /**
   * �berpr�ft, ob dieser Mitarbeiter ein Mitarbeiter-Passwort verwendet
   * @return <code>TRUE</code> gdw der Mitarbeiter ein Mitarbeiter-Passwort
   *   verwendet
   */
  public boolean istMitarbeiterPasswortGesetzt () {
    return (mitarbeiterPasswort != null);
  }

  /**
   * Setzt den Benutzer, dem dieser Mitarbeiter entspricht. Dabei werden alle
   * Daten des Benutzers geladen. Evtl. vorher ge�nderte Benutzereigenschaften
   * werden �berschrieben.
   *
   * @param benutzerNr die Nummer des dem Mitarbeiter entsprechenden Benutzers
   * @throws DatenNichtGefundenException falls die Benutzernr nicht in der
   *   Datenbank vorhanden ist
   */
  public void setBenutzerNr(int benutzerNr) 
    throws DatenNichtGefundenException, DatenbankInkonsistenzException {
    super.load(benutzerNr);
  }

  public boolean istGespeichert() {
    return (istMitarbeiterGespeichert && super.istGespeichert());
  }

  /**
   * Liefert eine Textdarstellung des Objektes mit allen Informationen,
   * die vor allem zum Debuggen gedacht ist.
   *
   * @return die Textdarstellung
   */
  public String toDebugString() {
    StringBuffer ausgabe = new StringBuffer();
    ausgabe.append("Mitarbeiter ").append(this.getMitarbeiterNr()).
      append(" / ").append(super.toDebugString());

    if (this.getMitarbeiterBenutzername() != null ||
      this.istMitarbeiterPasswortGesetzt()) {

      ausgabe.append("\nMitarbeiter-Benutzername: ");
      if (this.getMitarbeiterBenutzername() != null)
        ausgabe.append(getMitarbeiterBenutzername());

      ausgabe.append("\nMitarbeiter-Passwort    : ");
      if (this.istMitarbeiterPasswortGesetzt()) ausgabe.append("********\n");

    }
    return ausgabe.toString();
  }

  /**
   * Bestimmt, ob es sich um einen neuen Mitarbeiter handelt, d.h. um einen
   * Mitarbeiter der gerade neu angelegt wird und noch nicht in der Datenbank
   * gespeichert ist.
   *
   * @return <code>true</code> gdw der Mitarbeiter neu ist
   */
  public boolean istNeu() {
    return (mitarbeiterNr == 0);
  }

  /**
   * L�scht den Mitarbeiter aus der Datenbank, ohne dass der zugeh�rige Benutzer
   * gel�scht wird. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieser Benutzer noch Beziehungen in der Datenbank
   * besitzt. Nur
   * wenn keine solchen Beziehungen existieren, wird der Mitarbeiter gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *  Mitarbeiters in der Datenbank existieren
   */
  public void loescheMitarbeiter() throws DatenbankInkonsistenzException {
    //nichts zu tun, falls Benutzer noch nicht gespeichert ist
    if (this.istNeu()) return;

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(Nr) from ausleihe where "+
        "MitarbeiterAusleihe="+this.getMitarbeiterNr()+" or "+
        "MitarbeiterRueckgabe="+this.getMitarbeiterNr());
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+this.getName()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Mitarbeiters "+
        "existieren.");

      // Internet
      result = statement.executeQuery(
        "select count(Nr) from internet_zugang where "+
        "Mitarbeiter=\""+this.getMitarbeiterNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+this.getName()+
        " kann nicht gel�scht werden, da noch Internetfreigaben dieses "+
        "Mitarbeiters existieren.");

      // Mitarbeiter l�schen
      statement.execute("delete from einstellung where "+
        "Mitarbeiter=\""+this.getMitarbeiterNr()+"\"");
      statement.execute("delete from mitarbeiter where "+
        "Nr=\""+this.getMitarbeiterNr()+"\"");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Mitarbeiters:\n\n"+this.toDebugString(), true);
    }
  }
  
  /**
   * L�scht den Mitarbeiter inklusive des passenden Benutzers 
   * aus der Datenbank. Damit keine Inkonsistenzen auftreten
   * wird �berpr�ft, ob dieser Mitarbeiter noch Beziehungen in der Datenbank
   * besitzt, ob also beispielsweise Ausleihen dieses Mitarbeiters existieren. Nur
   * wenn keine solchen Beziehungen existieren, wird der Mitarbeiter gel�scht.
   * Ansonsten wird eine DatenbankInkonsistenzException geworfen.
   *
   * @throws DatenbankInkonsistenzException falls noch Beziehungen dieses
   *  Mitarbeiters in der Datenbank existieren
   */
  public void loesche() throws DatenbankInkonsistenzException {
    //nichts zu tun, falls Benutzer noch nicht gespeichert ist
    if (this.istNeu()) return;

    try {
      Statement statement = Datenbank.getInstance().getStatement();

      //Ausleihen
      ResultSet result = statement.executeQuery(
        "select count(Nr) from ausleihe where "+
        "MitarbeiterAusleihe="+this.getMitarbeiterNr()+" or "+
        "MitarbeiterRueckgabe="+this.getMitarbeiterNr());
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+this.getName()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Mitarbeiters "+
        "existieren.");

      // Internet
      result = statement.executeQuery(
        "select count(Nr) from internet_zugang where "+
        "Mitarbeiter=\""+this.getMitarbeiterNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Mitarbeiter "+this.getName()+
        " kann nicht gel�scht werden, da noch Internetfreigaben dieses "+
        "Mitarbeiters existieren.");

      //Ausleihen
      result = statement.executeQuery(
        "select count(Nr) from ausleihe where "+
        "Benutzer=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Ausleihen dieses Benutzers "+
        "existieren.");

      // Veranstaltungen
      result = statement.executeQuery(
        "select count(Nr) from benutzer_besucht_veranstaltung where "+
        "benutzerNr=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Veranstaltungsteilnahmen dieses "+
        "Benutzers existieren.");

      // Internet
      result = statement.executeQuery(
        "select count(Nr) from internet_zugang where "+
        "Benutzer=\""+this.getBenutzerNr()+"\"");
      result.next();
      if (result.getInt(1) > 0)
        throw new DatenbankInkonsistenzException("Der Benutzer "+this.getName()+
        " kann nicht gel�scht werden, da noch Internetfreigaben dieses "+
        "Benutzers existieren.");

      // Mitarbeiter l�schen
      statement.execute("delete from einstellung where "+
        "Mitarbeiter=\""+this.getMitarbeiterNr()+"\"");
      statement.execute("delete from mitarbeiter where "+
        "Nr=\""+this.getMitarbeiterNr()+"\"");
      statement.execute("delete from benutzer where "+
        "Nr=\""+this.getBenutzerNr()+"\"");

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim L�schen des folgenden "+
        "Mitarbeiters:\n\n"+this.toDebugString(), true);
    }
  }  


 /**
   * Speichert den aktuellen Mitarbeiter bzw die gemachten �nderungen in der
   * Datenbank
   *
   * @throws MitarbeiterbenutzernameSchonVergebenException falls der
   *  Mitarbeiterbenutzername schon von einem anderen Mitarbeiter verwendet wird
   * @throws BenutzernameSchonVergebenException falls der Benutzername
   *  schon von einem anderen Benutzer verwendet wird
   * @throws UnvollstaendigeDatenException falls Vorname oder Nachname nicht
   *  angegeben sind
   */
  public void save() 
    throws MitarbeiterbenutzernameSchonVergebenException, BenutzerSchonMitarbeiterException, 
      BenutzernameSchonVergebenException, UnvollstaendigeDatenException, 
      DatenNichtGefundenException, DatenbankInkonsistenzException {
        
    super.save();
    if (istMitarbeiterGespeichert) return;

    if (istBenutzerSchonMitarbeiter())
      throw new BenutzerSchonMitarbeiterException(
          new Mitarbeiter(
            sucheBenutzerNr(this.getBenutzerNr())));
    if (istMitarbeiterBenutzernameSchonVergeben()) {
      throw new MitarbeiterbenutzernameSchonVergebenException(
          new Mitarbeiter(
            sucheMitarbeiterBenutzername(this.getMitarbeiterBenutzername())));
    }

    try {
      PreparedStatement statement = null;

      if (this.istNeu()) {
        mitarbeiterNr = Mitarbeiter.getNeueMitarbeiternr();
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "insert into mitarbeiter set Nr = ?, Benutzernr = ?, "+
          "Benutzername = ?, Passwort = ?, Berechtigungen = ?");
      } else {
        statement = Datenbank.getInstance().getConnection().prepareStatement(
          "update mitarbeiter set Nr = ?, Benutzernr = ?, "+
          "Benutzername = ?, Passwort = ?, Berechtigungen = ? "+
          "where Nr="+mitarbeiterNr);
      }
      statement.setInt(1,this.getMitarbeiterNr());
      statement.setInt(2, this.getBenutzerNr());
      statement.setString(3, this.getMitarbeiterBenutzername());
      statement.setString(4, mitarbeiterPasswort);
      statement.setInt(5, berechtigungen);

      statement.execute();
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Speichern des folgenden "+
        "Mitarbeiters:\n\n"+this.toDebugString(), true);
    }

    istMitarbeiterGespeichert = true;
  }

  /**
   * Bestimmt die gr��te verwendete Mitarbeiternr
   * @return die gr��te verwendete Mitarbeiternr
   */
  public static int getGroessteMitarbeiternr() {
    int maxNr = 0;

    try {
      Statement statement = Datenbank.getInstance().getStatement();
      ResultSet result = statement.executeQuery(
        "select max(Nr) from mitarbeiter");
      result.next();
      maxNr = result.getInt(1);

      Datenbank.getInstance().releaseStatement(statement);
    } catch (SQLException e) {
      ErrorHandler.getInstance().handleException(e, "Fehler beim Bestimmen der gr��ten "+
        "verwendeten Mitarbeiternummer!", true);
    }

    return maxNr;
  }

  /**
   * Bestimmt eine neue, noch nicht verwendete Mitarbeiternr
   * @return die neue Mitarbeiternr
   */
  public static int getNeueMitarbeiternr() {
    return getGroessteMitarbeiternr() + 1;
  }

  /**
   * Bestimmt, ob der Benutzer die �bergebene Berechtigung besitzt. Die zur
   * Verf�gung stehenden Berechtigungen sind �ber statische Konstanten dieser
   * Klasse festgelegt.
   *
   * @param berechtigung die Berechtigung, von der �berpr�ft werden soll, ob
   *   dieser Benutzer sie besitzt
   * @return <code>TRUE</code> gdw. der Benutzer die �bergebene Berechtigung
   *   besitzt
   */
  public boolean besitztBerechtigung(int berechtigung) {
    if (berechtigung == BERECHTIGUNG_STANDARD) return true;
    return (this.berechtigungen & berechtigung) != 0;
  }

  /**
   * Setzt oder entfernt die �bergebene Berechtigung.
   * @param berechtigung die zu �ndernde Berechtigung
   * @param wert <code>true</code>, wenn die Berechtigung erteilt werden soll<br>
   * <code>false</code>, wenn die Berechtigung entzogen werden sol
   */
  public void setBerechtigung(int berechtigung, boolean wert) {
    if (berechtigung == BERECHTIGUNG_STANDARD) return;
    if (wert) {
      berechtigungen = berechtigung | berechtigungen;
    } else {
      berechtigungen = berechtigungen & (~berechtigung);
    }
  }
}