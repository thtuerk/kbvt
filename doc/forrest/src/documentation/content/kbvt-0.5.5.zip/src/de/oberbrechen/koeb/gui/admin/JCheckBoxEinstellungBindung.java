/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.admin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenbankzugriff.Client;
import de.oberbrechen.koeb.datenbankzugriff.Mitarbeiter;

/**
 * Diese Klasse dient dazu eine BOOL-Wertige-Einstellung an eine 
 * JCheckBox zu binden. Initial wird der JCheckbox der Wert der 
 * Einstellung zugewiesen. Bei �nderung der Checkbox wird automatisch
 * der Einstellungswert in der Datenbank aktualisiert.
 *
 * @author Thomas T�rk (t_tuerk@gmx.de)
 * @version $Revision: 1.3 $
 */

public class JCheckBoxEinstellungBindung implements JComponentEinstellungBindung {

  final Client client;
  final Mitarbeiter mitarbeiter;
  final String name;
  final String namespace;
  final boolean standard;
  final JCheckBox jCheckBox;
  final Einstellungen einstellungen;  
    
  /**
   * Erstellt eine neue JCheckBoxEinstellungBindung, die
   * die �bergebene Checkbox an die beschriebene Einstellung bindet und
   * als Standardwert standard verwendet.
   * @param jCheckBox
   * @param client
   * @param mitarbeiter
   * @param namespace
   * @param name
   * @param standard
   */
  public JCheckBoxEinstellungBindung(JCheckBox jCheckBox, 
    Client client, Mitarbeiter mitarbeiter, String namespace, String name, 
    boolean standard) {

    this.client = client;
    this.mitarbeiter = mitarbeiter;
    this.name = name;
    this.namespace = namespace;
    this.standard = standard;
    this.jCheckBox = jCheckBox;
    einstellungen = Einstellungen.getInstance();

    initActionListener();
    refresh();
  }

  private void initActionListener() {
    jCheckBox.addActionListener(new ActionListener() {

      public void actionPerformed(ActionEvent e) {
        boolean value = jCheckBox.isSelected();
        einstellungen.setEinstellungBoolean(client, mitarbeiter, 
        namespace, name, value);
      }    
    });
  }

  public void refresh() {
    jCheckBox.setSelected(einstellungen.getEinstellungBoolean(
      client, mitarbeiter, namespace, name, standard));        
  }
}