/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.components.listenAuswahlPanel.mediumListenAuswahlPanel;

import java.awt.event.KeyListener;
import java.text.SimpleDateFormat;

import javax.swing.JTable;

import de.oberbrechen.koeb.datenbankzugriff.Medium;
import de.oberbrechen.koeb.datenstrukturen.*;
import de.oberbrechen.koeb.datenstrukturen.Liste;
import de.oberbrechen.koeb.gui.components.listenAuswahlPanel.AuswahlTableModel;
import de.oberbrechen.koeb.gui.components.listenKeySelectionManager.ListenKeySelectionManagerListenDaten;

/**
* Diese Klasse ist ein Tabellenmodell f�r eine Tabelle von Medien.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.1 $
*/

public class MediumTableModel extends AuswahlTableModel
  implements KeyListener, ListenKeySelectionManagerListenDaten {

  private SimpleDateFormat datumsformat = new SimpleDateFormat("dd.MM.yyyy");

	public MediumTableModel(JTable tabelle, Liste daten) {
		super(tabelle, daten);
	}

	public int getColumnCount() {
    return 5;
  }

  public String getColumnName(int columnIndex) {
    if (columnIndex == 0) return "Nr";
    if (columnIndex == 1) return "Titel";
    if (columnIndex == 2) return "Autor";
    if (columnIndex == 3) return "Einstellungsdatum";
    if (columnIndex == 4) return "Systematiken";
    return "nicht definierte Spalte";
  }

  public Class getColumnClass(int columnIndex) {
    return String.class;
  }
  
  public Object getValueAt(int rowIndex, int columnIndex) {
    Medium gewaehltesMedium = (Medium) daten.get(rowIndex);
    switch (columnIndex) {
      case 0:
        return gewaehltesMedium.getMedienNr();
      case 1:
        return gewaehltesMedium.getTitel();
      case 2:
        return gewaehltesMedium.getAutor();
      case 3:
        return gewaehltesMedium.getEinstellungsdatum() == null?"-":
               datumsformat.format(gewaehltesMedium.getEinstellungsdatum());
      case 4:
        return gewaehltesMedium.getSystematikenString();
    }
    return "nicht definierte Spalte";
  }

	protected void sortiereNachSpalte(int spalte, boolean umgekehrteSortierung) {
    if (spalte == 0) daten.setSortierung(
      MedienListe.MedienNummerSortierung, umgekehrteSortierung);
    else if (spalte == 1) daten.setSortierung(
      MedienListe.TitelAutorSortierung, umgekehrteSortierung);
    else if (spalte == 2) daten.setSortierung(
      MedienListe.AutorTitelSortierung, umgekehrteSortierung);
    else if (spalte == 3) daten.setSortierung(
      MedienListe.EinstellungsdatumSortierung, umgekehrteSortierung);
    else return;
    
    sortierteSpalte = spalte;
	}

	public void sortiereNachStandardSortierung() {
    sortiereNachSpalte(3, true);
	}
}
