/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.pdf.pdfInternetStatistik;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Vector;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;

import de.oberbrechen.koeb.pdf.*;
import de.oberbrechen.koeb.pdf.pdfTabelle.PdfTabelle;
import de.oberbrechen.koeb.pdf.pdfTemplateDokument.PdfTemplateDokument;

/**
 * Erstellt ein PdfDokument, das eine Liste aller aktuellen Mahnungen
 * enthaelt.
 */
public class PdfInternetstatistik extends PdfDokument {

  private PdfTemplateDokument pdfDokument; 
  private int jahr;
  private int monat;
  private SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM");
  
  public PdfInternetstatistik(int jahr) {
    this(-1, jahr);
  }

  public PdfInternetstatistik(int monat, int jahr) {
    this.monat = monat;
    this.jahr = jahr;
    
    pdfDokument = new PdfTemplateDokument();
    pdfDokument.setTemplateAbstand(30);
    String titel;
    if (monat > 0) {
      Calendar monatKalender = Calendar.getInstance();
      monatKalender.set(jahr, monat-1, 1);
      titel = "Internetstatistik "+monatDateFormat.format(monatKalender.getTime())+" "+jahr;      
    } else {
      titel = "Internetstatistik "+jahr;
    }
  
    SeitenKopfFuss seitenFuss = new StandardSeitenFuss(
      StandardSeitenFuss.LAYOUT_ZEIT_TITEL_SEITE, titel);
    SeitenKopfFuss seitenKopfErsteSeite = new StandardSeitenKopfErsteSeite(
      titel, null, null, null);
    pdfDokument.setSeitenKopf(null, seitenKopfErsteSeite);
    pdfDokument.setSeitenFuss(seitenFuss);
  }

  //Doku siehe bitte PdfDokument
  public void schreibeInDokument(PdfWriter writer, Document document) throws Exception {
    Vector templates = new Vector();

    if (monat > 0) {
      PdfTemplate currentTemplate = getMonatsTemplate(monat, jahr, writer);
      if (currentTemplate != null)
        templates.add(currentTemplate);
    } else {
      //Monatsdetails
      for (int i=1; i < 12; i++) {
        PdfTemplate currentTemplate = getMonatsTemplate(i, jahr, writer);
        if (currentTemplate != null) {
          PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(currentTemplate.getWidth(), currentTemplate.getHeight()+8);
          neuesTemplate.addTemplate(currentTemplate, 0, 0);
          
          neuesTemplate.beginText();
          neuesTemplate.setFontAndSize(PdfDokument.schriftFett, 18);
          neuesTemplate.setHorizontalScaling(100);
          neuesTemplate.setTextMatrix(pdfDokument.getSeitenRandLinks(), 
            neuesTemplate.getHeight()-18);

                
          neuesTemplate.showText(getMonatsNamen(i)+" "+jahr);
          neuesTemplate.endText();
          templates.add(neuesTemplate);          
        }
      }
      
      //Jahresstatistik
      templates.add(0, getJahresTemplate(jahr, writer));          
    }
    pdfDokument.setTemplates((PdfTemplate[]) templates.toArray(new PdfTemplate[templates.size()]));
    pdfDokument.schreibeInDokument(writer, document);
  }
  
  private PdfTemplate getMonatsTemplate(int monat, int jahr, PdfWriter writer) throws Exception {
    InternetStatistikMonatTabellenModell tabellenModell = new InternetStatistikMonatTabellenModell(monat, jahr); 
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1);

    if (tabellenModell.getZeilenAnzahl() > 1) {
      PdfTabelle tabelle = new PdfTabelle(tabellenModell);
      if (tabelle.hasNextTemplate()) {
        PdfTemplate tabellenTemplate = tabelle.getNextTemplate(true, maximaleHoehe, pdfDokument, writer.getDirectContent());
        PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(tabellenTemplate.getWidth(), tabellenTemplate.getHeight());
        neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
                
        return neuesTemplate;
      }
    }        
    return null;
  }
  
  private PdfTemplate getJahresTemplate(int jahr, PdfWriter writer) 
    throws Exception {
    InternetStatistikJahrTabellenModell tabellenModell = 
      new InternetStatistikJahrTabellenModell(jahr); 
    float maximaleHoehe = pdfDokument.getSeitenHoehe()-
      pdfDokument.getSeitenRandObenMitKopf(1)-
      pdfDokument.getSeitenRandUntenMitFuss(1);

    if (tabellenModell.getZeilenAnzahl() > 1) {
      PdfTabelle tabelle = new PdfTabelle(tabellenModell);
      if (tabelle.hasNextTemplate()) {
        PdfTemplate tabellenTemplate = tabelle.getNextTemplate(
          true, maximaleHoehe, pdfDokument, writer.getDirectContent());
        PdfTemplate neuesTemplate = writer.getDirectContent().createTemplate(
          tabellenTemplate.getWidth(), tabellenTemplate.getHeight()+8);
        neuesTemplate.addTemplate(tabellenTemplate, 0, 0);
                
        neuesTemplate.beginText();
        neuesTemplate.setFontAndSize(PdfDokument.schriftFett, 18);
        neuesTemplate.setHorizontalScaling(100);
        neuesTemplate.setTextMatrix(pdfDokument.getSeitenRandLinks(), 
          neuesTemplate.getHeight()-18);
              
        neuesTemplate.showText("Jahresstatistik");
        neuesTemplate.endText();

        return neuesTemplate;
      }
    }        
    return null;
  }

  private String getMonatsNamen(int monat) {
    SimpleDateFormat monatDateFormat = new SimpleDateFormat("MMMM");
    Calendar monatKalender = Calendar.getInstance();
    monatKalender.set(2002, monat-1, 1);
    return monatDateFormat.format(monatKalender.getTime());    
  }
}
