/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.einstellungen;

import de.oberbrechen.koeb.datenbankzugriff.*;
import de.oberbrechen.koeb.datenstrukturen.*;

import java.util.*;

/**
* Diese Klasse ist eine konfigurierbare Implementierung einer Ausleihordnung.
*
* @author Thomas T�rk (t_tuerk@gmx.de)
* @version $Revision: 1.8 $
*/

public class KonfigurierbareAusleihordnung extends Ausleihordnung {

  class MedientypEinstellung {
    Medientyp medientyp;
    int mindestAusleihdauerInTagen;
  }

  private int kulanzZeitInTagen;
  private double mahngebuehrProMediumProWocheInEuro;
  private Vector medientypEinstellungen;
  
  public KonfigurierbareAusleihordnung() {
    Einstellungen einstellungen = Einstellungen.getInstance();
    kulanzZeitInTagen = einstellungen.getEinstellungInt(null, null, 
      this.getClass().getName(), "kulanzZeitInTagen", 14);
    mahngebuehrProMediumProWocheInEuro = einstellungen.getEinstellungDouble(
      null, null, this.getClass().getName(), 
      "mahngebuehrProMediumProWocheInEuro", 0.25);
      
    medientypEinstellungen = new Vector();
    Iterator medienTypIterator = Medientyp.getAlleMedientypen().iterator();
    while (medienTypIterator.hasNext()) {
      Medientyp currentTyp = (Medientyp) medienTypIterator.next();
      MedientypEinstellung einstellung = new MedientypEinstellung();
      einstellung.medientyp = currentTyp;
      einstellung.mindestAusleihdauerInTagen = 
        Einstellungen.getInstance().getEinstellungInt(null, null, 
        this.getClass().getName(), "mindestAusleihdauerInTagen."+currentTyp.getName(), 21);
      medientypEinstellungen.add(einstellung);
    }
  }
  
  /**
   * Berechnet die Mahngeb�hren f�r die �bergebene Ausleihe.
   * @return die Mahngeb�hren f�r die �bergebene Ausleihe
   */
  public double berechneMahngebuehren(Ausleihe ausleihe, Date zeitpunkt) {
    int anzahlUeberzogeneTage = ausleihe.getUeberzogeneTage();
    if (anzahlUeberzogeneTage < kulanzZeitInTagen) return 0;

    int anzahlUeberzogeneWochen = (int) Math.floor(
      (double) anzahlUeberzogeneTage / 7);
    return anzahlUeberzogeneWochen*mahngebuehrProMediumProWocheInEuro;
  }

  // Doku siehe bitte Ausleihordnung
  public double berechneMahngebuehren(AusleihenListe liste, Date zeitpunkt) {
    double summe = 0;

    Iterator it = liste.iterator();
    while (it.hasNext()) {
      summe += berechneMahngebuehren((Ausleihe) it.next(), zeitpunkt);
    }

    return summe;
  }

  // Doku siehe bitte Ausleihordnung
  public Date getAusleihenBisDatum(Medium medium, Date datum) {
    if (medium == null) throw new NullPointerException("Medium darf nicht NULL sein!");

    MedientypEinstellung benoetigteEinstellung = null;
    Iterator it = medientypEinstellungen.iterator();
    while (it.hasNext() && benoetigteEinstellung == null) {
      MedientypEinstellung aktuelleEinstellung = 
        (MedientypEinstellung) it.next();
      if (aktuelleEinstellung.medientyp.equals(medium.getMedientyp()))
        benoetigteEinstellung = aktuelleEinstellung;          
    }
    //Hier wird immer etwas gefunden, da vorher !alle! Medientypen initialisiert wurden
    

    Calendar neuesDatum = Calendar.getInstance();
    if (datum != null) neuesDatum.setTime(datum);
    neuesDatum.add(Calendar.DATE, benoetigteEinstellung.mindestAusleihdauerInTagen);

    return Buecherei.getInstance().getNaechstesOeffnungsdatum(
      neuesDatum.getTime());
  }

}
