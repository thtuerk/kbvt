/*  Copyright 2002, 2003 Thomas T�rk  
 *
 *  This file is part of KBVT. 
 * 
 *  KBVT is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 * 
 *  KBVT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with KBVT; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package de.oberbrechen.koeb.gui.standarddialoge;

import de.oberbrechen.koeb.framework.*;
import javax.swing.*;

import java.awt.*;
import java.io.*;

/**
 * Diese Klasse ist eine Standardimplemntierung des Interfaces
 * DatenbankErrorHandler f�r Swing-Oberfl�chen. Tritt ein Datenbankfehler
 * auf zeigt, dieser ErrorHandler diesen in einem Dialogfeld an und beendet
 * anschlie�end das System.
 */
public class StandardGUIErrorHandler extends ErrorHandler {

  private JLabel beendenLabel;
  private JFrame main;
  private JPanel ausgabe;
  private JTextArea fehlerMeldung;
  private JScrollPane fehlerMeldungScrollPane;
  
  /**
   * Erzeugt eine neue Instanz, die das Dialogfeld als Chield des �bergebenen
   * Frames anzeigt.
   *
   * @param mainWindow das Hauptfenster
   */
  public StandardGUIErrorHandler(JFrame mainWindow) {
    main = mainWindow;
    jbInit();
  }

  private void jbInit() {
    fehlerMeldung = new JTextArea();
    ausgabe = new JPanel();

    JLabel jLabel1 = new JLabel();
    JLabel jLabel2 = new JLabel();
    beendenLabel = new JLabel();

    jLabel1.setText("Es trat ein unerwartetes Problem auf.");
    jLabel2.setText("Die Fehlermeldung lautet:");
    beendenLabel.setFont(new Font(jLabel1.getFont().getName(),
      Font.BOLD, 15));
    beendenLabel.setForeground(Color.red);
    beendenLabel.setHorizontalAlignment(SwingConstants.LEFT);
    beendenLabel.setText("System wird beendet!");

    ausgabe.setLayout(new GridBagLayout());
    ausgabe.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

    fehlerMeldung.setWrapStyleWord(true);
    fehlerMeldung.setLineWrap(true);
    fehlerMeldung.setMargin(new Insets(5, 5, 5, 5));
    fehlerMeldung.setEditable(false);
    fehlerMeldung.setTabSize(4);
    fehlerMeldung.setFont(new java.awt.Font("Monospaced", 0, 12));

    fehlerMeldungScrollPane = new JScrollPane();
    fehlerMeldungScrollPane.setAutoscrolls(true);
    fehlerMeldungScrollPane.setMinimumSize(new Dimension(357, 100));
    fehlerMeldungScrollPane.setPreferredSize(new Dimension(357, 100));

    ausgabe.add(jLabel1,     new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    ausgabe.add(jLabel2,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 10, 0), 0, 0));
    ausgabe.add(fehlerMeldungScrollPane,    new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    ausgabe.add(beendenLabel,      new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 0, 0, 0), 0, 0));
    fehlerMeldungScrollPane.getViewport().add(fehlerMeldung);
    
    ausgabe.setPreferredSize(new Dimension(780, 480));
  }

  public void handleError(String beschreibung, boolean istKritisch) {
    fehlerMeldung.setText(beschreibung);
    beendenLabel.setVisible(istKritisch);
    JOptionPane.showMessageDialog(main, ausgabe,
      "Problem!", JOptionPane.ERROR_MESSAGE);

    if (istKritisch) System.exit(1);
  }

  public void handleException(Exception e, String beschreibung, boolean istKritisch) {
    final StringBuffer buffer = new StringBuffer();
    e.printStackTrace(new PrintWriter(new Writer(){
			public void write(char[] cbuf, int off, int len) throws IOException {
        buffer.append(cbuf, off, len);
			}

			public void flush() throws IOException {}
			public void close() throws IOException {}
    }));
    
    String nachricht = e.getLocalizedMessage();
    if (beschreibung != null) nachricht = beschreibung + "\n\n"+nachricht;
    nachricht += "\n\n" + buffer.toString();

    e.printStackTrace();
    handleError(nachricht, istKritisch);
  }
}